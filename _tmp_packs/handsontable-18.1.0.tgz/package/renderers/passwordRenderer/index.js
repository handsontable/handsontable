"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return _passwordRenderer.RENDERER_TYPE;
    },
    get passwordRenderer () {
        return _passwordRenderer.passwordRenderer;
    }
});
const _passwordRenderer = require("./passwordRenderer");
