"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AUTOCOMPLETE_RENDERER () {
        return _autocompleteRenderer.RENDERER_TYPE;
    },
    get BASE_RENDERER () {
        return _baseRenderer.RENDERER_TYPE;
    },
    get CHECKBOX_RENDERER () {
        return _checkboxRenderer.RENDERER_TYPE;
    },
    get DATE_RENDERER () {
        return _dateRenderer.RENDERER_TYPE;
    },
    get DROPDOWN_RENDERER () {
        return _dropdownRenderer.RENDERER_TYPE;
    },
    get HANDSONTABLE_RENDERER () {
        return _handsontableRenderer.RENDERER_TYPE;
    },
    get HTML_RENDERER () {
        return _htmlRenderer.RENDERER_TYPE;
    },
    get INTL_DATETIME_RENDERER () {
        return _intlDatetimeRenderer.RENDERER_TYPE;
    },
    get INTL_DATE_RENDERER () {
        return _intlDateRenderer.RENDERER_TYPE;
    },
    get INTL_TIME_RENDERER () {
        return _intlTimeRenderer.RENDERER_TYPE;
    },
    get NUMERIC_RENDERER () {
        return _numericRenderer.RENDERER_TYPE;
    },
    get PASSWORD_RENDERER () {
        return _passwordRenderer.RENDERER_TYPE;
    },
    get SELECT_RENDERER () {
        return _selectRenderer.RENDERER_TYPE;
    },
    get TEXT_RENDERER () {
        return _textRenderer.RENDERER_TYPE;
    },
    get TIME_RENDERER () {
        return _timeRenderer.RENDERER_TYPE;
    },
    get autocompleteRenderer () {
        return _autocompleteRenderer.autocompleteRenderer;
    },
    get baseRenderer () {
        return _baseRenderer.baseRenderer;
    },
    get checkboxRenderer () {
        return _checkboxRenderer.checkboxRenderer;
    },
    get dateRenderer () {
        return _dateRenderer.dateRenderer;
    },
    get dropdownRenderer () {
        return _dropdownRenderer.dropdownRenderer;
    },
    get getRegisteredRendererNames () {
        return _registry.getRegisteredRendererNames;
    },
    get getRegisteredRenderers () {
        return _registry.getRegisteredRenderers;
    },
    get getRenderer () {
        return _registry.getRenderer;
    },
    get handsontableRenderer () {
        return _handsontableRenderer.handsontableRenderer;
    },
    get hasRenderer () {
        return _registry.hasRenderer;
    },
    get htmlRenderer () {
        return _htmlRenderer.htmlRenderer;
    },
    get intlDateRenderer () {
        return _intlDateRenderer.intlDateRenderer;
    },
    get intlDatetimeRenderer () {
        return _intlDatetimeRenderer.intlDatetimeRenderer;
    },
    get intlTimeRenderer () {
        return _intlTimeRenderer.intlTimeRenderer;
    },
    get numericRenderer () {
        return _numericRenderer.numericRenderer;
    },
    get passwordRenderer () {
        return _passwordRenderer.passwordRenderer;
    },
    get registerAllRenderers () {
        return registerAllRenderers;
    },
    get registerRenderer () {
        return _registry.registerRenderer;
    },
    get rendererFactory () {
        return _factory.rendererFactory;
    },
    get selectRenderer () {
        return _selectRenderer.selectRenderer;
    },
    get textRenderer () {
        return _textRenderer.textRenderer;
    },
    get timeRenderer () {
        return _timeRenderer.timeRenderer;
    }
});
const _autocompleteRenderer = require("./autocompleteRenderer");
const _baseRenderer = require("./baseRenderer");
const _dropdownRenderer = require("./dropdownRenderer");
const _checkboxRenderer = require("./checkboxRenderer");
const _handsontableRenderer = require("./handsontableRenderer");
const _htmlRenderer = require("./htmlRenderer");
const _intlDateRenderer = require("./intlDateRenderer");
const _intlDatetimeRenderer = require("./intlDatetimeRenderer");
const _intlTimeRenderer = require("./intlTimeRenderer");
const _numericRenderer = require("./numericRenderer");
const _passwordRenderer = require("./passwordRenderer");
const _selectRenderer = require("./selectRenderer");
const _textRenderer = require("./textRenderer");
const _timeRenderer = require("./timeRenderer");
const _dateRenderer = require("./dateRenderer");
const _registry = require("./registry");
const _factory = require("./factory");
function registerAllRenderers() {
    (0, _registry.registerRenderer)(_autocompleteRenderer.autocompleteRenderer);
    (0, _registry.registerRenderer)(_baseRenderer.baseRenderer);
    (0, _registry.registerRenderer)(_checkboxRenderer.checkboxRenderer);
    (0, _registry.registerRenderer)(_dropdownRenderer.dropdownRenderer);
    (0, _registry.registerRenderer)(_handsontableRenderer.handsontableRenderer);
    (0, _registry.registerRenderer)(_htmlRenderer.htmlRenderer);
    (0, _registry.registerRenderer)(_intlDateRenderer.intlDateRenderer);
    (0, _registry.registerRenderer)(_intlDatetimeRenderer.intlDatetimeRenderer);
    (0, _registry.registerRenderer)(_intlTimeRenderer.intlTimeRenderer);
    (0, _registry.registerRenderer)(_numericRenderer.numericRenderer);
    (0, _registry.registerRenderer)(_passwordRenderer.passwordRenderer);
    (0, _registry.registerRenderer)(_selectRenderer.selectRenderer);
    (0, _registry.registerRenderer)(_textRenderer.textRenderer);
    (0, _registry.registerRenderer)(_timeRenderer.timeRenderer);
    (0, _registry.registerRenderer)(_dateRenderer.dateRenderer);
}
