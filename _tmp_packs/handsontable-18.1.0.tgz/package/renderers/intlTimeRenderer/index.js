"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return _intlTimeRenderer.RENDERER_TYPE;
    },
    get intlTimeRenderer () {
        return _intlTimeRenderer.intlTimeRenderer;
    },
    get valueFormatter () {
        return _intlTimeRenderer.valueFormatter;
    }
});
const _intlTimeRenderer = require("./intlTimeRenderer");
