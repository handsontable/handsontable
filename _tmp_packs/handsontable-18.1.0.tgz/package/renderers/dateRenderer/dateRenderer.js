"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return RENDERER_TYPE;
    },
    get dateRenderer () {
        return dateRenderer;
    },
    get valueFormatter () {
        return valueFormatter;
    }
});
const _textRenderer = require("../textRenderer");
const _dateTime = require("../../helpers/dateTime");
const _mixed = require("../../helpers/mixed");
const _object = require("../../helpers/object");
const _constants = require("../../helpers/constants");
const _console = require("../../helpers/console");
const RENDERER_TYPE = 'date';
const DEFAULT_INTL_FORMAT = {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
};
const stringFormatWarnShown = new WeakSet();
function valueFormatter(value, cellProperties) {
    const { dateFormat, locale, allowEmpty, instance } = cellProperties;
    if ((0, _mixed.isEmpty)(value)) {
        return allowEmpty ? value : _constants.BAD_VALUE_TEXT;
    }
    if (typeof dateFormat === 'string') {
        if (instance && !stringFormatWarnShown.has(instance)) {
            stringFormatWarnShown.add(instance);
            (0, _console.warn)('The dateFormat option as a string is not supported. Use an Intl.DateTimeFormatOptions object instead.');
        }
        return value;
    }
    const date = (0, _dateTime.parseToLocalDate)(value);
    if (date === null) {
        return _constants.BAD_VALUE_TEXT;
    }
    const intlFormat = (0, _object.isObject)(dateFormat) ? dateFormat : DEFAULT_INTL_FORMAT;
    return new Intl.DateTimeFormat(locale, intlFormat).format(date);
}
/**
 * Handsontable renderer for date cells.
 *
 * @private
 * @param {Core} hotInstance The Handsontable instance.
 * @param {HTMLTableCellElement} TD The rendered cell element.
 * @param {number} row The visual row index.
 * @param {number} col The visual column index.
 * @param {number|string} prop The column property (passed when datasource is an array of objects).
 * @param {*} value The rendered value.
 * @param {object} cellProperties The cell meta object (see {@link Core#getCellMeta}).
 */ function _dateRenderer(hotInstance, TD, row, col, prop, value, cellProperties) {
    _textRenderer.textRenderer.apply(this, [
        hotInstance,
        TD,
        row,
        col,
        prop,
        value,
        cellProperties
    ]);
}
_dateRenderer.valueFormatter = valueFormatter;
_dateRenderer.RENDERER_TYPE = RENDERER_TYPE;
const dateRenderer = _dateRenderer;
