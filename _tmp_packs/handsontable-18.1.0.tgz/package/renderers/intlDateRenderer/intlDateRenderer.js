"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return RENDERER_TYPE;
    },
    get intlDateRenderer () {
        return intlDateRenderer;
    },
    get valueFormatter () {
        return _dateRenderer.valueFormatter;
    }
});
const _dateRenderer = require("../dateRenderer/dateRenderer");
const RENDERER_TYPE = 'intl-date';
/**
 *
 */ function _intlDateRenderer(hotInstance, TD, row, col, prop, value, cellProperties) {
    _dateRenderer.dateRenderer.apply(this, [
        hotInstance,
        TD,
        row,
        col,
        prop,
        value,
        cellProperties
    ]);
}
_intlDateRenderer.valueFormatter = _dateRenderer.valueFormatter;
_intlDateRenderer.RENDERER_TYPE = RENDERER_TYPE;
const intlDateRenderer = _intlDateRenderer;
