"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return _numericRenderer.RENDERER_TYPE;
    },
    get numericRenderer () {
        return _numericRenderer.numericRenderer;
    },
    get valueFormatter () {
        return _numericRenderer.valueFormatter;
    }
});
const _numericRenderer = require("./numericRenderer");
