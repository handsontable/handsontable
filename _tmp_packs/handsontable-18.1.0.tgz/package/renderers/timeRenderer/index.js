"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return _timeRenderer.RENDERER_TYPE;
    },
    get timeRenderer () {
        return _timeRenderer.timeRenderer;
    },
    get valueFormatter () {
        return _timeRenderer.valueFormatter;
    }
});
const _timeRenderer = require("./timeRenderer");
