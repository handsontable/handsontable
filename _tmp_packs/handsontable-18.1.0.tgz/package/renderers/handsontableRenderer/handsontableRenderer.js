"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return RENDERER_TYPE;
    },
    get handsontableRenderer () {
        return handsontableRenderer;
    }
});
const _autocompleteRenderer = require("../autocompleteRenderer");
const RENDERER_TYPE = 'handsontable';
function handsontableRenderer(hotInstance, TD, row, col, prop, value, cellProperties) {
    _autocompleteRenderer.autocompleteRenderer.apply(this, [
        hotInstance,
        TD,
        row,
        col,
        prop,
        value,
        cellProperties
    ]);
}
handsontableRenderer.RENDERER_TYPE = RENDERER_TYPE;
