"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return RENDERER_TYPE;
    },
    get dropdownRenderer () {
        return dropdownRenderer;
    }
});
const _autocompleteRenderer = require("../autocompleteRenderer");
const RENDERER_TYPE = 'dropdown';
function dropdownRenderer(hotInstance, TD, row, col, prop, value, cellProperties) {
    _autocompleteRenderer.autocompleteRenderer.apply(this, [
        hotInstance,
        TD,
        row,
        col,
        prop,
        value,
        cellProperties
    ]);
}
dropdownRenderer.RENDERER_TYPE = RENDERER_TYPE;
