"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return RENDERER_TYPE;
    },
    get checkboxRenderer () {
        return checkboxRenderer;
    }
});
const _eventManager = /*#__PURE__*/ _interop_require_default(require("../../eventManager"));
const _element = require("../../helpers/dom/element");
const _mixed = require("../../helpers/mixed");
const _string = require("../../helpers/string");
const _contexts = require("../../shortcuts/contexts");
const _hooks = require("../../core/hooks");
const _a11y = require("../../helpers/a11y");
const _constants = require("../../i18n/constants");
const _constants1 = require("../../helpers/constants");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const isListeningKeyDownEvent = new WeakMap();
const isCheckboxListenerAdded = new WeakMap();
const BAD_VALUE_CLASS = 'htBadValue';
const ATTR_ROW = 'data-row';
const ATTR_COLUMN = 'data-col';
const SHORTCUTS_GROUP = 'checkboxRenderer';
const RENDERER_TYPE = 'checkbox';
_hooks.Hooks.getSingleton().add('modifyAutoColumnSizeSeed', function(_bundleSeed, cellMeta, cellValue) {
    const { label, type, row, column, prop } = cellMeta;
    if (type !== RENDERER_TYPE || !label) {
        return;
    }
    const labelObj = label;
    const { value: labelValue, property: labelProperty } = labelObj;
    let labelText = cellValue;
    if (labelValue) {
        labelText = typeof labelValue === 'function' ? labelValue(row, column, prop, cellValue) : labelValue;
    } else if (labelProperty) {
        const labelData = this.getDataAtRowProp(row, String(labelProperty));
        labelText = labelData !== null ? labelData : cellValue;
    }
    return `${(0, _mixed.stringify)(labelText).length}`;
});
function checkboxRenderer(hotInstance, TD, row, col, prop, value, cellProperties) {
    const { rootDocument } = hotInstance;
    const ariaEnabled = hotInstance.getSettings().ariaTags;
    registerEvents(hotInstance);
    const input = createInput(rootDocument);
    let inputOrWrapper = input;
    const labelOptions = cellProperties.label;
    let badValue = false;
    if (typeof cellProperties.checkedTemplate === 'undefined') {
        cellProperties.checkedTemplate = true;
    }
    if (typeof cellProperties.uncheckedTemplate === 'undefined') {
        cellProperties.uncheckedTemplate = false;
    }
    (0, _element.empty)(TD); // TODO identify under what circumstances this line can be removed
    const locale = cellProperties.locale;
    applyCheckedState();
    applyLabelOptions();
    /**
   * Determine and apply the checked state of the input element based on the cell value.
   */ function applyCheckedState() {
        if (value === cellProperties.checkedTemplate || (0, _string.localeLowerCase)((0, _mixed.stringify)(value), locale) === (0, _string.localeLowerCase)((0, _mixed.stringify)(cellProperties.checkedTemplate), locale)) {
            input.checked = true;
        } else if (value === cellProperties.uncheckedTemplate || (0, _string.localeLowerCase)((0, _mixed.stringify)(value), locale) === (0, _string.localeLowerCase)((0, _mixed.stringify)(cellProperties.uncheckedTemplate), locale)) {
            input.checked = false;
        } else if ((0, _mixed.isEmpty)(value)) {
            (0, _element.addClass)(input, 'noValue');
        } else {
            input.style.display = 'none';
            (0, _element.addClass)(input, BAD_VALUE_CLASS);
            badValue = true;
        }
        (0, _element.setAttribute)(input, [
            [
                ATTR_ROW,
                row
            ],
            [
                ATTR_COLUMN,
                col
            ]
        ]);
        if (ariaEnabled) {
            (0, _element.setAttribute)(input, [
                (0, _a11y.A11Y_LABEL)(input.checked ? hotInstance.getTranslatedPhrase(_constants.CHECKBOX_CHECKED) : hotInstance.getTranslatedPhrase(_constants.CHECKBOX_UNCHECKED)),
                (0, _a11y.A11Y_CHECKED)(input.checked),
                (0, _a11y.A11Y_CHECKBOX)()
            ]);
        }
    }
    /**
   * Apply label options to the cell, creating and positioning the label element.
   */ function applyLabelOptions() {
        if (!badValue && labelOptions) {
            let labelText = '';
            if (labelOptions.value) {
                const labelFn = labelOptions.value;
                labelText = typeof labelOptions.value === 'function' ? String(labelFn(row, col, prop, value)) : String(labelOptions.value);
            } else if (labelOptions.property) {
                const labelValue = hotInstance.getDataAtRowProp(row, String(labelOptions.property));
                labelText = labelValue !== null ? String(labelValue) : '';
            }
            const label = createLabel(rootDocument, labelText, labelOptions.separated !== true);
            if (labelOptions.position === 'before') {
                if (labelOptions.separated) {
                    TD.appendChild(label);
                    TD.appendChild(input);
                } else {
                    label.appendChild(input);
                    inputOrWrapper = label;
                }
            } else if (!labelOptions.position || labelOptions.position === 'after') {
                if (labelOptions.separated) {
                    TD.appendChild(input);
                    TD.appendChild(label);
                } else {
                    label.insertBefore(input, label.firstChild);
                    inputOrWrapper = label;
                }
            }
        }
    }
    if (!labelOptions || labelOptions && !labelOptions.separated) {
        TD.appendChild(inputOrWrapper);
    }
    if (badValue) {
        TD.appendChild(rootDocument.createTextNode(_constants1.BAD_VALUE_TEXT));
    }
    if (!isListeningKeyDownEvent.has(hotInstance)) {
        isListeningKeyDownEvent.set(hotInstance, true);
        registerShortcuts();
    }
    /**
   * Register shortcuts responsible for toggling checkbox state.
   *
   * @private
   */ function registerShortcuts() {
        const shortcutManager = hotInstance.getShortcutManager();
        const gridContext = shortcutManager.getContext('grid');
        const config = {
            group: SHORTCUTS_GROUP,
            relativeToGroup: _contexts.EDITOR_EDIT_GROUP,
            position: 'before'
        };
        gridContext?.addShortcuts([
            {
                keys: [
                    [
                        'space'
                    ]
                ],
                callback: ()=>{
                    changeSelectedCheckboxesState();
                    return !areSelectedCheckboxCells(); // False blocks next action associated with the keyboard shortcut.
                },
                runOnlyIf: ()=>!!hotInstance.getSelectedRangeActive()?.highlight.isCell()
            },
            {
                keys: [
                    [
                        'enter'
                    ]
                ],
                callback: ()=>{
                    changeSelectedCheckboxesState();
                    return !areSelectedCheckboxCells(); // False blocks next action associated with the keyboard shortcut.
                },
                runOnlyIf: ()=>{
                    const range = hotInstance.getSelectedRangeActive();
                    return !!(hotInstance.getSettings().enterBeginsEditing && range?.highlight.isCell() && !hotInstance.selection.isMultiple());
                }
            },
            {
                keys: [
                    [
                        'delete'
                    ],
                    [
                        'backspace'
                    ]
                ],
                callback: ()=>{
                    changeSelectedCheckboxesState(true);
                    return !areSelectedCheckboxCells(); // False blocks next action associated with the keyboard shortcut.
                },
                runOnlyIf: ()=>!!hotInstance.getSelectedRangeActive()?.highlight.isCell()
            }
        ], config);
    }
    /**
   * Change checkbox checked property.
   *
   * @private
   * @param {boolean} [uncheckCheckbox=false] The new "checked" state for the checkbox elements.
   */ function changeSelectedCheckboxesState(uncheckCheckbox = false) {
        const selRange = hotInstance.getSelectedRange();
        const changesPerSubSelection = [];
        const nonCheckboxChanges = new Map();
        let changes = [];
        let changeCounter = 0;
        if (!selRange) {
            return;
        }
        for(let key = 0; key < selRange.length; key++){
            const { row: startRow, col: startColumn } = selRange[key].getTopStartCorner();
            const { row: endRow, col: endColumn } = selRange[key].getBottomEndCorner();
            if (startRow === null || startColumn === null || endRow === null || endColumn === null) {
                continue;
            }
            for(let visualRow = startRow; visualRow <= endRow; visualRow += 1){
                for(let visualColumn = startColumn; visualColumn <= endColumn; visualColumn += 1){
                    // The transient read keeps a toggle over a large selection (for example, a whole
                    // column) from permanently materializing one meta object per selected cell. The
                    // default-template writes below may land on a throwaway object - the render path
                    // re-applies the same defaults on every draw, and all reads in this loop happen on
                    // this same object.
                    const cachedCellProperties = hotInstance.getCellMetaTransient(visualRow, visualColumn);
                    /* eslint-disable no-continue */ if (cachedCellProperties.hidden) {
                        continue;
                    }
                    const templates = {
                        checkedTemplate: cachedCellProperties.checkedTemplate,
                        uncheckedTemplate: cachedCellProperties.uncheckedTemplate
                    };
                    // TODO: In the future it'd be better if non-checkbox changes were handled by the non-checkbox
                    //  `delete` keypress logic.
                    /* eslint-disable no-continue */ if (cachedCellProperties.type !== 'checkbox') {
                        if (uncheckCheckbox === true && !cachedCellProperties.readOnly) {
                            if (nonCheckboxChanges.has(changesPerSubSelection.length)) {
                                nonCheckboxChanges.set(changesPerSubSelection.length, [
                                    ...nonCheckboxChanges.get(changesPerSubSelection.length),
                                    [
                                        visualRow,
                                        visualColumn,
                                        null
                                    ]
                                ]);
                            } else {
                                nonCheckboxChanges.set(changesPerSubSelection.length, [
                                    [
                                        visualRow,
                                        visualColumn,
                                        null
                                    ]
                                ]);
                            }
                        }
                        continue;
                    }
                    /* eslint-disable no-continue */ if (cachedCellProperties.readOnly === true) {
                        continue;
                    }
                    if (typeof cachedCellProperties.checkedTemplate === 'undefined') {
                        cachedCellProperties.checkedTemplate = true;
                    }
                    if (typeof cachedCellProperties.uncheckedTemplate === 'undefined') {
                        cachedCellProperties.uncheckedTemplate = false;
                    }
                    const dataAtCell = hotInstance.getDataAtCell(visualRow, visualColumn);
                    if (uncheckCheckbox === false) {
                        if ([
                            cachedCellProperties.checkedTemplate,
                            String(cachedCellProperties.checkedTemplate)
                        ].includes(dataAtCell)) {
                            changes.push([
                                visualRow,
                                visualColumn,
                                cachedCellProperties.uncheckedTemplate,
                                templates
                            ]);
                        } else if ([
                            cachedCellProperties.uncheckedTemplate,
                            String(cachedCellProperties.uncheckedTemplate),
                            null,
                            undefined
                        ].includes(dataAtCell)) {
                            changes.push([
                                visualRow,
                                visualColumn,
                                cachedCellProperties.checkedTemplate,
                                templates
                            ]);
                        }
                    } else {
                        changes.push([
                            visualRow,
                            visualColumn,
                            cachedCellProperties.uncheckedTemplate,
                            templates
                        ]);
                    }
                    changeCounter += 1;
                }
            }
            changesPerSubSelection.push(changeCounter);
            changeCounter = 0;
        }
        if (!changes.every(([, , cellValue])=>cellValue === changes[0][2])) {
            changes = changes.map(([visualRow, visualColumn, , templates])=>[
                    visualRow,
                    visualColumn,
                    templates?.checkedTemplate
                ]);
        } else {
            changes = changes.map(([visualRow, visualColumn, cellValue])=>[
                    visualRow,
                    visualColumn,
                    cellValue
                ]);
        }
        if (changes.length > 0) {
            // TODO: This is workaround for handsontable/dev-handsontable#1747 not being a breaking change.
            // Technically, the changes don't need to be split into chunks when sent to `setDataAtCell`.
            const changesChunks = [];
            changesPerSubSelection.forEach((changesCount, sectionCount)=>{
                let changesChunk = changes.splice(0, changesCount);
                if (nonCheckboxChanges.size && nonCheckboxChanges.has(sectionCount)) {
                    const nonCheckboxChunk = nonCheckboxChanges.get(sectionCount) ?? [];
                    changesChunk = [
                        ...changesChunk,
                        ...nonCheckboxChunk
                    ];
                }
                changesChunks.push(changesChunk);
            });
            if (uncheckCheckbox) {
                const allChanges = [];
                changesChunks.forEach((changesChunk)=>{
                    changesChunk.forEach((change)=>{
                        allChanges.push(change);
                    });
                });
                if (allChanges.length > 0) {
                    hotInstance.setDataAtCell(allChanges);
                }
            } else {
                changesChunks.forEach((changesChunk)=>{
                    if (changesChunk.length > 0) {
                        hotInstance.setDataAtCell(changesChunk);
                    }
                });
            }
        }
    }
    /**
   * Check whether all selected cells are with checkbox type.
   *
   * @returns {boolean}
   * @private
   */ function areSelectedCheckboxCells() {
        const selRange = hotInstance.getSelectedRange();
        if (!selRange) {
            return;
        }
        for(let key = 0; key < selRange.length; key++){
            const topLeft = selRange[key].getTopStartCorner();
            const bottomRight = selRange[key].getBottomEndCorner();
            if (topLeft.row === null || topLeft.col === null || bottomRight.row === null || bottomRight.col === null) {
                continue;
            }
            for(let visualRow = topLeft.row; visualRow <= bottomRight.row; visualRow++){
                for(let visualColumn = topLeft.col; visualColumn <= bottomRight.col; visualColumn++){
                    const cellMeta = hotInstance.getCellMetaTransient(visualRow, visualColumn);
                    /* eslint-disable no-continue */ if (cellMeta.readOnly) {
                        continue;
                    }
                    const cell = hotInstance.getCell(visualRow, visualColumn);
                    if ((0, _element.isHTMLElement)(cell)) {
                        const checkboxes = cell.querySelectorAll('input[type=checkbox]');
                        if (checkboxes.length > 0) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
}
checkboxRenderer.RENDERER_TYPE = RENDERER_TYPE;
/**
 * Register checkbox listeners.
 *
 * @param {Core} instance The Handsontable instance.
 * @returns {EventManager}
 */ function registerEvents(instance) {
    let eventManager = isCheckboxListenerAdded.get(instance);
    if (!eventManager) {
        const { rootElement } = instance;
        eventManager = new _eventManager.default(instance);
        eventManager.addEventListener(rootElement, 'click', (event)=>onClick(event, instance));
        eventManager.addEventListener(rootElement, 'mouseup', (event)=>onMouseUp(event, instance));
        eventManager.addEventListener(rootElement, 'change', (event)=>onChange(event, instance));
        isCheckboxListenerAdded.set(instance, eventManager);
    }
    return eventManager;
}
/**
 * Create input element.
 *
 * @param {Document} rootDocument The document owner.
 * @returns {HTMLInputElement}
 */ function createInput(rootDocument) {
    const input = rootDocument.createElement('input');
    input.className = 'htCheckboxRendererInput';
    input.type = 'checkbox';
    input.setAttribute('tabindex', '-1');
    return input.cloneNode(false);
}
/**
 * Create label element.
 *
 * @param {Document} rootDocument The document owner.
 * @param {string} text The label text.
 * @param {boolean} fullWidth Determines whether label should have full width.
 * @returns {HTMLElement}
 */ function createLabel(rootDocument, text, fullWidth) {
    const label = rootDocument.createElement('label');
    label.className = `htCheckboxRendererLabel ${fullWidth ? 'fullWidth' : ''}`;
    const textNode = rootDocument.createTextNode(text);
    if (fullWidth) {
        const span = rootDocument.createElement('span');
        span.appendChild(textNode);
        label.appendChild(span);
    } else {
        label.appendChild(textNode);
    }
    return label.cloneNode(true);
}
/**
 * `mouseup` callback.
 *
 * @private
 * @param {Event} event `mouseup` event.
 * @param {Core} instance The Handsontable instance.
 */ function onMouseUp(event, instance) {
    const target = (0, _element.eventTargetEl)(event);
    if (!isCheckboxInput(target)) {
        return;
    }
    if (!target.hasAttribute(ATTR_ROW) || !target.hasAttribute(ATTR_COLUMN)) {
        return;
    }
    setTimeout(instance.listen, 10);
}
/**
 * `click` callback.
 *
 * @private
 * @param {MouseEvent} event `click` event.
 * @param {Core} instance The Handsontable instance.
 */ function onClick(event, instance) {
    const target = (0, _element.eventTargetEl)(event);
    if (!isCheckboxInput(target)) {
        return;
    }
    if (!target.hasAttribute(ATTR_ROW) || !target.hasAttribute(ATTR_COLUMN)) {
        return;
    }
    const row = Number.parseInt(target.getAttribute(ATTR_ROW), 10);
    const col = Number.parseInt(target.getAttribute(ATTR_COLUMN), 10);
    const cellProperties = instance.getCellMetaTransient(row, col);
    if (cellProperties.readOnly) {
        event.preventDefault();
    }
}
/**
 * `change` callback.
 *
 * @param {Event} event `change` event.
 * @param {Core} instance The Handsontable instance.
 */ function onChange(event, instance) {
    const target = (0, _element.eventTargetEl)(event);
    if (!isCheckboxInput(target)) {
        return;
    }
    if (!target.hasAttribute(ATTR_ROW) || !target.hasAttribute(ATTR_COLUMN)) {
        return;
    }
    const row = Number.parseInt(target.getAttribute(ATTR_ROW), 10);
    const col = Number.parseInt(target.getAttribute(ATTR_COLUMN), 10);
    const cellProperties = instance.getCellMetaTransient(row, col);
    if (!cellProperties.readOnly) {
        let newCheckboxValue = null;
        if (target.checked) {
            newCheckboxValue = cellProperties.uncheckedTemplate === undefined ? true : cellProperties.checkedTemplate;
        } else {
            newCheckboxValue = cellProperties.uncheckedTemplate === undefined ? false : cellProperties.uncheckedTemplate;
        }
        instance.setDataAtCell(row, col, newCheckboxValue);
    }
}
/**
 * Check if the provided element is the checkbox input.
 *
 * @private
 * @param {HTMLElement} element The element in question.
 * @returns {boolean}
 */ function isCheckboxInput(element) {
    return element.tagName === 'INPUT' && element.getAttribute('type') === 'checkbox';
}
