"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return RENDERER_TYPE;
    },
    get baseRenderer () {
        return baseRenderer;
    }
});
const _element = require("../../helpers/dom/element");
const _a11y = require("../../helpers/a11y");
const _mixed = require("../../helpers/mixed");
const RENDERER_TYPE = 'base';
const TEXT_ELLIPSIS_CLASS_NAME = 'htTextEllipsis';
function baseRenderer(hotInstance, TD, row, col, prop, value, cellProperties) {
    const ariaEnabled = cellProperties.ariaTags;
    const classesToAdd = [];
    const classesToRemove = [];
    const attributesToRemove = [];
    const attributesToAdd = [];
    // Indicates that the base renderer has been called and should not be called again in TableView.cellRenderer.
    cellProperties._isBaseRendererCalled = true;
    if (cellProperties.className) {
        (0, _element.addClass)(TD, cellProperties.className);
    }
    if (cellProperties.readOnly) {
        classesToAdd.push(cellProperties.readOnlyCellClassName);
        if (ariaEnabled) {
            attributesToAdd.push((0, _a11y.A11Y_READONLY)());
        }
    } else if (ariaEnabled) {
        attributesToRemove.push((0, _a11y.A11Y_READONLY)()[0]);
    }
    if (cellProperties.valid === false && cellProperties.invalidCellClassName) {
        classesToAdd.push(cellProperties.invalidCellClassName);
        if (ariaEnabled) {
            attributesToAdd.push((0, _a11y.A11Y_INVALID)());
        }
    } else {
        classesToRemove.push(cellProperties.invalidCellClassName);
        if (ariaEnabled) {
            attributesToRemove.push((0, _a11y.A11Y_INVALID)()[0]);
        }
    }
    if (cellProperties.wordWrap === false && cellProperties.noWordWrapClassName) {
        classesToAdd.push(cellProperties.noWordWrapClassName);
    }
    if ((0, _mixed.isEmpty)(value) && cellProperties.placeholder) {
        classesToAdd.push(cellProperties.placeholderCellClassName);
    }
    if (cellProperties.textEllipsis) {
        classesToAdd.push(TEXT_ELLIPSIS_CLASS_NAME);
    }
    (0, _element.removeClass)(TD, classesToRemove);
    (0, _element.addClass)(TD, classesToAdd);
    (0, _element.removeAttribute)(TD, attributesToRemove);
    (0, _element.setAttribute)(TD, attributesToAdd);
}
baseRenderer.RENDERER_TYPE = RENDERER_TYPE;
