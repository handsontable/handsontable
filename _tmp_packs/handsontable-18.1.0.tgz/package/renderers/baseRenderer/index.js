"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return _baseRenderer.RENDERER_TYPE;
    },
    get baseRenderer () {
        return _baseRenderer.baseRenderer;
    }
});
const _baseRenderer = require("./baseRenderer");
