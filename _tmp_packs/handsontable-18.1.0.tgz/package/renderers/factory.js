"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "rendererFactory", {
    enumerable: true,
    get: function() {
        return rendererFactory;
    }
});
const rendererFactory = (callback)=>{
    return (instance, td, row, column, prop, value, cellProperties)=>{
        return callback({
            instance,
            td,
            row,
            column,
            prop,
            value,
            cellProperties
        });
    };
};
