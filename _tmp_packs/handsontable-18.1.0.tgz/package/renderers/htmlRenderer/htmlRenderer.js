"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return RENDERER_TYPE;
    },
    get htmlRenderer () {
        return htmlRenderer;
    }
});
const _element = require("../../helpers/dom/element");
const RENDERER_TYPE = 'html';
function htmlRenderer(hotInstance, TD, row, col, prop, value, _cellProperties) {
    // The `html` cell type renders raw HTML on purpose, so pass `false` to write it directly without
    // emitting the missing-sanitizer warning. Sanitization for this cell type is the user's responsibility.
    (0, _element.fastInnerHTML)(TD, value === null || value === undefined ? '' : value, false);
}
htmlRenderer.RENDERER_TYPE = RENDERER_TYPE;
