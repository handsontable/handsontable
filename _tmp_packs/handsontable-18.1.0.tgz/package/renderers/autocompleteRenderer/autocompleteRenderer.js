"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get RENDERER_TYPE () {
        return RENDERER_TYPE;
    },
    get autocompleteRenderer () {
        return autocompleteRenderer;
    }
});
const _htmlRenderer = require("../htmlRenderer");
const _textRenderer = require("../textRenderer");
const _eventManager = /*#__PURE__*/ _interop_require_default(require("../../eventManager"));
const _element = require("../../helpers/dom/element");
const _a11y = require("../../helpers/a11y");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const RENDERER_TYPE = 'autocomplete';
function autocompleteRenderer(hotInstance, TD, row, col, prop, value, cellProperties) {
    const { rootDocument } = hotInstance;
    const rendererFunc = cellProperties.allowHtml ? _htmlRenderer.htmlRenderer : _textRenderer.textRenderer;
    const ARROW = rootDocument.createElement('DIV');
    const isAriaEnabled = hotInstance.getSettings().ariaTags;
    ARROW.className = 'htAutocompleteArrow';
    if (isAriaEnabled) {
        ARROW.setAttribute(...(0, _a11y.A11Y_HIDDEN)());
    }
    ARROW.appendChild(rootDocument.createTextNode(String.fromCharCode(9660)));
    rendererFunc.apply(this, [
        hotInstance,
        TD,
        row,
        col,
        prop,
        value,
        cellProperties
    ]);
    if (!TD.firstChild) {
        // otherwise empty fields appear borderless in demo/renderers.html (IE)
        TD.appendChild(rootDocument.createTextNode(String.fromCharCode(160))); // workaround for https://github.com/handsontable/handsontable/issues/1946
    // this is faster than innerHTML. See: https://github.com/handsontable/handsontable/wiki/JavaScript-&-DOM-performance-tips
    }
    TD.insertBefore(ARROW, TD.firstChild);
    (0, _element.addClass)(TD, 'htAutocomplete');
    if (!hotInstance.acArrowListener) {
        const eventManager = new _eventManager.default(hotInstance);
        // not very elegant but easy and fast
        hotInstance.acArrowListener = function(event) {
            if ((0, _element.hasClass)((0, _element.eventTargetEl)(event), 'htAutocompleteArrow')) {
                hotInstance.view._wt.getSetting('onCellDblClick', null, hotInstance._createCellCoords(row, col), TD);
            }
        };
        eventManager.addEventListener(hotInstance.rootElement, 'mousedown', hotInstance.acArrowListener);
        // We need to unbind the listener after the table has been destroyed
        hotInstance.addHookOnce('afterDestroy', ()=>{
            eventManager.destroy();
        });
    }
}
autocompleteRenderer.RENDERER_TYPE = RENDERER_TYPE;
