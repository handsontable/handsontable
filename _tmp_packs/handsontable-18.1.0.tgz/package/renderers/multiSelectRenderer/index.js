"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CHIP_CLASS () {
        return _multiSelectRenderer.CHIP_CLASS;
    },
    get RENDERER_TYPE () {
        return _multiSelectRenderer.RENDERER_TYPE;
    },
    get multiSelectRenderer () {
        return _multiSelectRenderer.multiSelectRenderer;
    }
});
const _multiSelectRenderer = require("./multiSelectRenderer");
