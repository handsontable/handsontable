"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createShortcutManager", {
    enumerable: true,
    get: function() {
        return _manager.createShortcutManager;
    }
});
const _manager = require("./manager");
