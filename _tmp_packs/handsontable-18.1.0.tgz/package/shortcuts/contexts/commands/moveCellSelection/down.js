"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "command", {
    enumerable: true,
    get: function() {
        return command;
    }
});
const command = {
    name: 'moveCellSelectionDown',
    callback ({ selection }) {
        selection.markSource('keyboard');
        selection.transformStart(1, 0);
        selection.markEndSource();
    }
};
