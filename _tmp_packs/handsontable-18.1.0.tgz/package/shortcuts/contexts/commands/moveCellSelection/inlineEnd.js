"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "command", {
    enumerable: true,
    get: function() {
        return command;
    }
});
const command = {
    name: 'moveCellSelectionInlineEnd',
    callback (hot, event) {
        const { selection } = hot;
        const settings = hot.getSettings();
        const selectedRanges = hot.getSelectedRange();
        const selectedRange = hot.getSelectedRangeActive();
        const tabMoves = typeof settings.tabMoves === 'function' ? settings.tabMoves(event) : settings.tabMoves;
        selection.markSource('keyboard');
        if ((selectedRanges?.some((range)=>selection.isMultiple(range)) || (selectedRanges?.length ?? 0) > 1) && !selectedRange?.isHeader() && hot.countRenderedCols() > 0 && hot.countRenderedRows() > 0) {
            selection.transformFocus(-(tabMoves?.row ?? 0), -(tabMoves?.col ?? 0));
        } else {
            selection.transformStart(-(tabMoves?.row ?? 0), -(tabMoves?.col ?? 0));
        }
        selection.markEndSource();
    }
};
