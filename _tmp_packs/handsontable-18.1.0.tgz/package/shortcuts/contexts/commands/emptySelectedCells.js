"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "command", {
    enumerable: true,
    get: function() {
        return command;
    }
});
const command = {
    name: 'emptySelectedCells',
    callback (hot) {
        hot.emptySelectedCells();
        hot._getEditorManager().prepareEditor();
    }
};
