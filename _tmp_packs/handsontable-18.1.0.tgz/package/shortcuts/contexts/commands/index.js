"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createKeyboardShortcutCommandsPool", {
    enumerable: true,
    get: function() {
        return createKeyboardShortcutCommandsPool;
    }
});
const _editor = require("./editor");
const _extendCellsSelection = require("./extendCellsSelection");
const _moveCellSelection = require("./moveCellSelection");
const _emptySelectedCells = require("./emptySelectedCells");
const _scrollToFocusedCell = require("./scrollToFocusedCell");
const _selectAllCells = require("./selectAllCells");
const _selectAllCellsAndHeaders = require("./selectAllCellsAndHeaders");
const _populateSelectedCellsData = require("./populateSelectedCellsData");
const _tabNavigation = require("./tabNavigation");
const allCommands = [
    ...(0, _editor.getAllCommands)(),
    ...(0, _extendCellsSelection.getAllCommands)(),
    ...(0, _moveCellSelection.getAllCommands)(),
    _emptySelectedCells.command,
    _scrollToFocusedCell.command,
    _selectAllCells.command,
    _selectAllCellsAndHeaders.command,
    _populateSelectedCellsData.command,
    _tabNavigation.command
];
function createKeyboardShortcutCommandsPool(hot) {
    const commands = {};
    allCommands.forEach(({ name, callback })=>{
        commands[name] = (...args)=>callback(hot, ...args);
    });
    return commands;
}
