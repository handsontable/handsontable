"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "command", {
    enumerable: true,
    get: function() {
        return command;
    }
});
const command = {
    name: 'extendCellsSelectionDown',
    callback (hot) {
        const { selection } = hot;
        const highlight = hot.getSelectedRangeActive()?.highlight;
        if (!selection.isSelectedByColumnHeader() && !selection.isSelectedByCorner() && (highlight?.isCell() || highlight?.isHeader() && selection.isSelectedByRowHeader())) {
            selection.markSource('keyboard');
            selection.transformEnd(1, 0);
            selection.markEndSource();
        }
    }
};
