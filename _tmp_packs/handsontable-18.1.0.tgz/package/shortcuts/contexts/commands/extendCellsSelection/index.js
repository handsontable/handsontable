"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "getAllCommands", {
    enumerable: true,
    get: function() {
        return getAllCommands;
    }
});
const _down = require("./down");
const _downByViewportHeight = require("./downByViewportHeight");
const _left = require("./left");
const _right = require("./right");
const _toColumns = require("./toColumns");
const _toMostBottom = require("./toMostBottom");
const _toMostInlineEnd = require("./toMostInlineEnd");
const _toMostInlineStart = require("./toMostInlineStart");
const _toMostLeft = require("./toMostLeft");
const _toMostRight = require("./toMostRight");
const _toMostTop = require("./toMostTop");
const _toRows = require("./toRows");
const _up = require("./up");
const _upByViewportHeight = require("./upByViewportHeight");
function getAllCommands() {
    return [
        _down.command,
        _downByViewportHeight.command,
        _left.command,
        _right.command,
        _toColumns.command,
        _toMostBottom.command,
        _toMostInlineEnd.command,
        _toMostInlineStart.command,
        _toMostLeft.command,
        _toMostRight.command,
        _toMostTop.command,
        _toRows.command,
        _up.command,
        _upByViewportHeight.command
    ];
}
