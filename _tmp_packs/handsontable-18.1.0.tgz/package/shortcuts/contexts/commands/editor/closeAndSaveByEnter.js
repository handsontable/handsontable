"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "command", {
    enumerable: true,
    get: function() {
        return command;
    }
});
const command = {
    name: 'editorCloseAndSaveByEnter',
    callback (hot, event) {
        const editorManager = hot._getEditorManager();
        editorManager.closeEditorAndSaveChanges(event.ctrlKey || event.metaKey);
        editorManager.moveSelectionAfterEnter(event);
    }
};
