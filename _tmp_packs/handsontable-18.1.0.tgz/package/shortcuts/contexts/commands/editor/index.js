"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "getAllCommands", {
    enumerable: true,
    get: function() {
        return getAllCommands;
    }
});
const _closeAndSave = require("./closeAndSave");
const _closeAndSaveByArrowKeys = require("./closeAndSaveByArrowKeys");
const _closeAndSaveByEnter = require("./closeAndSaveByEnter");
const _closeWithoutSaving = require("./closeWithoutSaving");
const _fastOpen = require("./fastOpen");
const _open = require("./open");
function getAllCommands() {
    return [
        _closeAndSave.command,
        _closeAndSaveByArrowKeys.command,
        _closeAndSaveByEnter.command,
        _closeWithoutSaving.command,
        _fastOpen.command,
        _open.command
    ];
}
