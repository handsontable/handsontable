"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "command", {
    enumerable: true,
    get: function() {
        return command;
    }
});
const command = {
    name: 'editorFastOpen',
    callback (hot, event) {
        const highlight = hot.getSelectedRangeActive()?.highlight;
        if (highlight?.isHeader()) {
            return;
        }
        hot._getEditorManager().openEditor(null, event, true);
    }
};
