"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "command", {
    enumerable: true,
    get: function() {
        return command;
    }
});
const command = {
    name: 'editorCloseAndSave',
    callback (hot) {
        const editorManager = hot._getEditorManager();
        editorManager.closeEditorAndSaveChanges();
    }
};
