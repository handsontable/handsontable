"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "command", {
    enumerable: true,
    get: function() {
        return command;
    }
});
const command = {
    name: 'editorCloseWithoutSaving',
    callback (hot) {
        const editorManager = hot._getEditorManager();
        editorManager.closeEditorAndRestoreOriginalValue(hot.getShortcutManager().isCtrlPressed());
        editorManager.activeEditor?.focus();
    }
};
