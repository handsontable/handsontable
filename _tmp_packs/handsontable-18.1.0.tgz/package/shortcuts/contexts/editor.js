"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "shortcutsEditorContext", {
    enumerable: true,
    get: function() {
        return shortcutsEditorContext;
    }
});
const _constants = require("./constants");
const _commands = require("./commands");
function shortcutsEditorContext(hot) {
    const context = hot.getShortcutManager().addContext(_constants.EDITOR_SCOPE);
    const commandsPool = (0, _commands.createKeyboardShortcutCommandsPool)(hot);
    const config = {
        group: _constants.EDITOR_EDIT_GROUP
    };
    context.addShortcuts([
        {
            keys: [
                [
                    'Enter'
                ],
                [
                    'Enter',
                    'Shift'
                ]
            ],
            callback: (event, keys)=>commandsPool.editorCloseAndSaveByEnter(event, keys)
        },
        {
            keys: [
                [
                    'Enter',
                    'Control/Meta'
                ],
                [
                    'Enter',
                    'Control/Meta',
                    'Shift'
                ]
            ],
            captureCtrl: true,
            callback: (event, keys)=>commandsPool.editorCloseAndSaveByEnter(event, keys)
        },
        {
            keys: [
                [
                    'Tab'
                ],
                [
                    'Tab',
                    'Shift'
                ],
                [
                    'PageDown'
                ],
                [
                    'PageUp'
                ]
            ],
            forwardToContext: hot.getShortcutManager().getContext(_constants.GRID_SCOPE),
            callback: (event, keys)=>commandsPool.editorCloseAndSave(event, keys)
        },
        {
            keys: [
                [
                    'ArrowDown'
                ],
                [
                    'ArrowUp'
                ],
                [
                    'ArrowLeft'
                ],
                [
                    'ArrowRight'
                ]
            ],
            preventDefault: false,
            callback: (event, keys)=>commandsPool.editorCloseAndSaveByArrowKeys(event, keys)
        },
        {
            keys: [
                [
                    'Escape'
                ],
                [
                    'Escape',
                    'Control/Meta'
                ]
            ],
            callback: ()=>commandsPool.editorCloseWithoutSaving()
        }
    ], config);
}
