/**
 * Group name for keyboard shortcuts that are active when the cell is selected.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EDITOR_EDIT_GROUP () {
        return EDITOR_EDIT_GROUP;
    },
    get EDITOR_SCOPE () {
        return EDITOR_SCOPE;
    },
    get GRID_GROUP () {
        return GRID_GROUP;
    },
    get GRID_SCOPE () {
        return GRID_SCOPE;
    },
    get GRID_TAB_NAVIGATION_GROUP () {
        return GRID_TAB_NAVIGATION_GROUP;
    }
});
const GRID_GROUP = 'gridDefault';
const GRID_SCOPE = 'grid';
const GRID_TAB_NAVIGATION_GROUP = 'grid.tabNavigation';
const EDITOR_EDIT_GROUP = 'editorManager.handlingEditor';
const EDITOR_SCOPE = 'editor';
