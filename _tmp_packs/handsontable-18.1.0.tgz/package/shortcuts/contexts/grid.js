"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "shortcutsGridContext", {
    enumerable: true,
    get: function() {
        return shortcutsGridContext;
    }
});
const _mixed = require("../../helpers/mixed");
const _constants = require("./constants");
const _commands = require("./commands");
function shortcutsGridContext(hot) {
    const context = hot.getShortcutManager().addContext(_constants.GRID_SCOPE);
    const commandsPool = (0, _commands.createKeyboardShortcutCommandsPool)(hot);
    const config = {
        runOnlyIf: ()=>{
            const { navigableHeaders } = hot.getSettings();
            return (0, _mixed.isDefined)(hot.getSelected()) && (navigableHeaders || !navigableHeaders && hot.countRenderedRows() > 0 && hot.countRenderedCols() > 0);
        },
        group: _constants.GRID_GROUP
    };
    context.addShortcuts([
        {
            keys: [
                [
                    'F2'
                ]
            ],
            callback: (event)=>commandsPool.editorFastOpen(event)
        },
        {
            keys: [
                [
                    'Enter'
                ],
                [
                    'Enter',
                    'Shift'
                ]
            ],
            callback: (event, keys)=>commandsPool.editorOpen(event, keys)
        },
        {
            keys: [
                [
                    'Backspace'
                ],
                [
                    'Delete'
                ]
            ],
            callback: ()=>commandsPool.emptySelectedCells()
        }
    ], {
        group: _constants.EDITOR_EDIT_GROUP,
        runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected())
    });
    context.addShortcuts([
        {
            keys: [
                [
                    'Control/Meta',
                    'A'
                ]
            ],
            callback: ()=>commandsPool.selectAllCells(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && !hot.getSelectedRangeActive()?.highlight.isHeader()
        },
        {
            keys: [
                [
                    'Control/Meta',
                    'A'
                ]
            ],
            callback: ()=>{},
            runOnlyIf: ()=>!!((0, _mixed.isDefined)(hot.getSelected()) && hot.getSelectedRangeActive()?.highlight.isHeader()),
            preventDefault: true
        },
        {
            keys: [
                [
                    'Control/Meta',
                    'Shift',
                    'Space'
                ]
            ],
            callback: ()=>commandsPool.selectAllCellsAndHeaders()
        },
        {
            keys: [
                [
                    'Control/Meta',
                    'Enter'
                ]
            ],
            callback: ()=>commandsPool.populateSelectedCellsData(),
            runOnlyIf: ()=>{
                return (0, _mixed.isDefined)(hot.getSelected()) && !hot.getSelectedRangeActive()?.highlight.isHeader() && (hot.getSelectedRangeActive()?.getCellsCount() ?? 0) > 1;
            }
        },
        {
            keys: [
                [
                    'Control',
                    'Space'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.extendCellsSelectionToColumns()
        },
        {
            keys: [
                [
                    'Shift',
                    'Space'
                ]
            ],
            stopPropagation: true,
            callback: ()=>commandsPool.extendCellsSelectionToRows()
        },
        {
            keys: [
                [
                    'ArrowUp'
                ]
            ],
            callback: ()=>commandsPool.moveCellSelectionUp()
        },
        {
            keys: [
                [
                    'ArrowUp',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.moveCellSelectionToMostTop()
        },
        {
            keys: [
                [
                    'ArrowUp',
                    'Shift'
                ]
            ],
            callback: ()=>commandsPool.extendCellsSelectionUp()
        },
        {
            keys: [
                [
                    'ArrowUp',
                    'Shift',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.extendCellsSelectionToMostTop(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && !(hot.selection.isSelectedByCorner() || hot.selection.isSelectedByColumnHeader())
        },
        {
            keys: [
                [
                    'ArrowDown'
                ]
            ],
            callback: ()=>commandsPool.moveCellSelectionDown()
        },
        {
            keys: [
                [
                    'ArrowDown',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.moveCellSelectionToMostBottom()
        },
        {
            keys: [
                [
                    'ArrowDown',
                    'Shift'
                ]
            ],
            callback: ()=>commandsPool.extendCellsSelectionDown()
        },
        {
            keys: [
                [
                    'ArrowDown',
                    'Shift',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.extendCellsSelectionToMostBottom(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && !(hot.selection.isSelectedByCorner() || hot.selection.isSelectedByColumnHeader())
        },
        {
            keys: [
                [
                    'ArrowLeft'
                ]
            ],
            callback: ()=>commandsPool.moveCellSelectionLeft()
        },
        {
            keys: [
                [
                    'ArrowLeft',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.moveCellSelectionToMostLeft()
        },
        {
            keys: [
                [
                    'ArrowLeft',
                    'Shift'
                ]
            ],
            callback: ()=>commandsPool.extendCellsSelectionLeft()
        },
        {
            keys: [
                [
                    'ArrowLeft',
                    'Shift',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.extendCellsSelectionToMostLeft(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && !(hot.selection.isSelectedByCorner() || hot.selection.isSelectedByRowHeader())
        },
        {
            keys: [
                [
                    'ArrowRight'
                ]
            ],
            callback: ()=>commandsPool.moveCellSelectionRight()
        },
        {
            keys: [
                [
                    'ArrowRight',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.moveCellSelectionToMostRight()
        },
        {
            keys: [
                [
                    'ArrowRight',
                    'Shift'
                ]
            ],
            callback: ()=>commandsPool.extendCellsSelectionRight()
        },
        {
            keys: [
                [
                    'ArrowRight',
                    'Shift',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.extendCellsSelectionToMostRight(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && !(hot.selection.isSelectedByCorner() || hot.selection.isSelectedByRowHeader())
        },
        {
            keys: [
                [
                    'Home'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.moveCellSelectionToMostInlineStart(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && hot.view.isMainTableNotFullyCoveredByOverlays()
        },
        {
            keys: [
                [
                    'Home',
                    'Shift'
                ]
            ],
            callback: ()=>commandsPool.extendCellsSelectionToMostInlineStart()
        },
        {
            keys: [
                [
                    'Home',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.moveCellSelectionToMostTopInlineStart(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && hot.view.isMainTableNotFullyCoveredByOverlays()
        },
        {
            keys: [
                [
                    'End'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.moveCellSelectionToMostInlineEnd(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && hot.view.isMainTableNotFullyCoveredByOverlays()
        },
        {
            keys: [
                [
                    'End',
                    'Shift'
                ]
            ],
            callback: ()=>commandsPool.extendCellsSelectionToMostInlineEnd()
        },
        {
            keys: [
                [
                    'End',
                    'Control/Meta'
                ]
            ],
            captureCtrl: true,
            callback: ()=>commandsPool.moveCellSelectionToMostBottomInlineEnd(),
            runOnlyIf: ()=>(0, _mixed.isDefined)(hot.getSelected()) && hot.view.isMainTableNotFullyCoveredByOverlays()
        },
        {
            keys: [
                [
                    'PageUp'
                ]
            ],
            callback: ()=>commandsPool.moveCellSelectionUpByViewportHight()
        },
        {
            keys: [
                [
                    'PageUp',
                    'Shift'
                ]
            ],
            callback: ()=>commandsPool.extendCellsSelectionUpByViewportHeight()
        },
        {
            keys: [
                [
                    'PageDown'
                ]
            ],
            callback: ()=>commandsPool.moveCellSelectionDownByViewportHeight()
        },
        {
            keys: [
                [
                    'PageDown',
                    'Shift'
                ]
            ],
            callback: ()=>commandsPool.extendCellsSelectionDownByViewportHeight()
        },
        {
            keys: [
                [
                    'Tab'
                ]
            ],
            preventDefault: false,
            callback: (event)=>commandsPool.moveCellSelectionInlineStart(event)
        },
        {
            keys: [
                [
                    'Shift',
                    'Tab'
                ]
            ],
            preventDefault: false,
            callback: (event)=>commandsPool.moveCellSelectionInlineEnd(event)
        },
        {
            keys: [
                [
                    'Control/Meta',
                    'Backspace'
                ]
            ],
            callback: ()=>commandsPool.scrollToFocusedCell()
        }
    ], config);
    const tabNavigationCommand = commandsPool.tabNavigation();
    context.addShortcuts([
        {
            keys: [
                [
                    'Tab'
                ],
                [
                    'Shift',
                    'Tab'
                ]
            ],
            preventDefault: false,
            stopPropagation: false,
            relativeToGroup: _constants.GRID_GROUP,
            group: _constants.GRID_TAB_NAVIGATION_GROUP,
            position: 'before',
            callback: (event)=>tabNavigationCommand.before(event)
        },
        {
            keys: [
                [
                    'Tab'
                ],
                [
                    'Shift',
                    'Tab'
                ]
            ],
            preventDefault: false,
            stopPropagation: false,
            relativeToGroup: _constants.GRID_GROUP,
            group: _constants.GRID_TAB_NAVIGATION_GROUP,
            callback: (event)=>tabNavigationCommand.after(event),
            position: 'after'
        }
    ]);
}
