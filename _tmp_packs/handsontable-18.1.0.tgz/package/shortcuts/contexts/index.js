"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "registerAllShortcutContexts", {
    enumerable: true,
    get: function() {
        return registerAllShortcutContexts;
    }
});
const _editor = require("./editor");
const _grid = require("./grid");
_export_star(require("./constants"), exports);
function _export_star(from, to) {
    Object.keys(from).forEach(function(k) {
        if (k !== "default" && !Object.prototype.hasOwnProperty.call(to, k)) {
            Object.defineProperty(to, k, {
                enumerable: true,
                get: function() {
                    return from[k];
                }
            });
        }
    });
    return from;
}
function registerAllShortcutContexts(hotInstance) {
    [
        _grid.shortcutsGridContext,
        _editor.shortcutsEditorContext
    ].forEach((context)=>context(hotInstance));
}
