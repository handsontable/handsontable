/**
 * @preserve
 * Authors: Handsoncode, Enrique Enciso
 * Last updated: Nov 18, 2022
 *
 * Description: Definition file for Spanish - Mexico language-country.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const dictionary = {
    languageCode: 'es-MX',
    [_constants.OK]: 'OK',
    [_constants.CANCEL]: 'Cancelar',
    [_constants.CONTEXTMENU_ITEMS_ROW_ABOVE]: 'Insertar fila arriba',
    [_constants.CONTEXTMENU_ITEMS_ROW_BELOW]: 'Insertar fila abajo',
    [_constants.CONTEXTMENU_ITEMS_INSERT_LEFT]: 'Insertar columna izquierda',
    [_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT]: 'Insertar columna derecha',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_ROW]: [
        'Eliminar fila',
        'Eliminar filas'
    ],
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COLUMN]: [
        'Eliminar columna',
        'Eliminar columnas'
    ],
    [_constants.CONTEXTMENU_ITEMS_UNDO]: 'Deshacer',
    [_constants.CONTEXTMENU_ITEMS_REDO]: 'Rehacer',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY]: 'Solo lectura',
    [_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN]: 'Limpiar columna',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT]: 'Alineación',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT]: 'Izquierda',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER]: 'Centro',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT]: 'Derecha',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY]: 'Justificar',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP]: 'Superior',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE]: 'Medio',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM]: 'Inferior',
    [_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN]: 'Congelar columna',
    [_constants.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN]: 'Descongelar columna',
    [_constants.CONTEXTMENU_ITEMS_BORDERS]: 'Bordes',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_TOP]: 'Superior',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_RIGHT]: 'Derecho',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM]: 'Inferior',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_LEFT]: 'Izquierdo',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_BORDERS]: 'Quitar borde(s)',
    [_constants.CONTEXTMENU_ITEMS_ADD_COMMENT]: 'Agregar comentario',
    [_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT]: 'Editar comentario',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COMMENT]: 'Borrar comentario',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT]: 'Comentario Solo de lectura',
    [_constants.CONTEXTMENU_ITEMS_MERGE_CELLS]: 'Unir celdas',
    [_constants.CONTEXTMENU_ITEMS_UNMERGE_CELLS]: 'Separar celdas',
    [_constants.CONTEXTMENU_ITEMS_COPY]: 'Copiar',
    [_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS]: [
        'Copiar con encabezado',
        'Copiar con encabezados'
    ],
    [_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS]: [
        'Copiar con encabezado de grupo',
        'Copiar con encabezados de grupos'
    ],
    [_constants.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY]: [
        'Copiar solo el encabezado',
        'Copiar solo los encabezados'
    ],
    [_constants.CONTEXTMENU_ITEMS_CUT]: 'Cortar',
    [_constants.CONTEXTMENU_ITEMS_EXPORT]: 'Exportar',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV]: 'A CSV',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX]: 'A Excel',
    [_constants.EXPORT_FILE_DIALOG_TITLE]: 'Exportando…',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD]: 'Insertar fila hija',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD]: 'Separar del padre',
    [_constants.CONTEXTMENU_ITEMS_HIDE_COLUMN]: [
        'Esconder columna',
        'Esconder columnas'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_COLUMN]: [
        'Mostrar columna',
        'Mostrar columnas'
    ],
    [_constants.CONTEXTMENU_ITEMS_HIDE_ROW]: [
        'Esconder fila',
        'Esconder filas'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_ROW]: [
        'Mostrar fila',
        'Mostrar filas'
    ],
    [_constants.FILTERS_CONDITIONS_NONE]: 'Ninguna',
    [_constants.FILTERS_CONDITIONS_EMPTY]: 'Está vacío',
    [_constants.FILTERS_CONDITIONS_NOT_EMPTY]: 'No está vacío',
    [_constants.FILTERS_CONDITIONS_EQUAL]: 'Es igual a',
    [_constants.FILTERS_CONDITIONS_NOT_EQUAL]: 'No es igual a',
    [_constants.FILTERS_CONDITIONS_BEGINS_WITH]: 'Comienza con',
    [_constants.FILTERS_CONDITIONS_ENDS_WITH]: 'Termina con',
    [_constants.FILTERS_CONDITIONS_CONTAINS]: 'Contiene',
    [_constants.FILTERS_CONDITIONS_NOT_CONTAIN]: 'No contiene',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN]: 'Mayor que',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL]: 'Mayor o igual que',
    [_constants.FILTERS_CONDITIONS_LESS_THAN]: 'Menor que',
    [_constants.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL]: 'Menor o igual que',
    [_constants.FILTERS_CONDITIONS_BETWEEN]: 'Es entre',
    [_constants.FILTERS_CONDITIONS_NOT_BETWEEN]: 'No es entre',
    [_constants.FILTERS_CONDITIONS_AFTER]: 'Después',
    [_constants.FILTERS_CONDITIONS_AFTER_OR_EQUAL]: 'Después o igual a',
    [_constants.FILTERS_CONDITIONS_BEFORE]: 'Antes',
    [_constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL]: 'Antes o igual a',
    [_constants.FILTERS_CONDITIONS_TODAY]: 'Hoy',
    [_constants.FILTERS_CONDITIONS_TOMORROW]: 'Mañana',
    [_constants.FILTERS_CONDITIONS_YESTERDAY]: 'Ayer',
    [_constants.FILTERS_VALUES_BLANK_CELLS]: 'Celdas vacías',
    [_constants.FILTERS_DIVS_FILTER_BY_CONDITION]: 'Filtrar por condición',
    [_constants.FILTERS_DIVS_FILTER_BY_VALUE]: 'Filtrar por valor',
    [_constants.FILTERS_LABELS_CONJUNCTION]: 'Y',
    [_constants.FILTERS_LABELS_DISJUNCTION]: 'O',
    [_constants.FILTERS_BUTTONS_SELECT_ALL]: 'Seleccionar todo',
    [_constants.FILTERS_BUTTONS_CLEAR]: 'Borrar',
    [_constants.FILTERS_BUTTONS_OK]: 'OK',
    [_constants.FILTERS_BUTTONS_CANCEL]: 'Cancelar',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SEARCH]: 'Buscar',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_VALUE]: 'Valor',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE]: 'Valor secundario',
    [_constants.PAGINATION_SECTION]: 'Paginación',
    [_constants.PAGINATION_PAGE_SIZE_SECTION]: 'Filas por página',
    [_constants.PAGINATION_PAGE_SIZE_AUTO]: 'Auto',
    [_constants.PAGINATION_COUNTER_SECTION]: '[start] - [end] de [total]',
    [_constants.PAGINATION_NAV_SECTION]: 'Página [currentPage] de [totalPages]',
    [_constants.PAGINATION_FIRST_PAGE]: 'Ir a la primera página',
    [_constants.PAGINATION_PREV_PAGE]: 'Ir a la página anterior',
    [_constants.PAGINATION_NEXT_PAGE]: 'Ir a la siguiente página',
    [_constants.PAGINATION_LAST_PAGE]: 'Ir a la última página',
    [_constants.LOADING_TITLE]: 'Cargando...',
    [_constants.NOTIFICATION_BUTTONS_CLOSE]: 'Cerrar',
    [_constants.EMPTY_DATA_STATE_TITLE]: 'No hay datos disponibles',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION]: 'No hay nada que mostrar aún.',
    [_constants.EMPTY_DATA_STATE_TITLE_FILTERS]: 'No se encontraron resultados',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS]: 'Parece que tus filtros actuales están ocultando todos los resultados.',
    [_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET]: 'Restablecer filtros',
    [_constants.EMPTY_DATA_STATE_TITLE_LOADING]: 'Cargando datos',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING]: 'Espere por favor.',
    [_constants.DATA_PROVIDER_ERRORS_FETCH]: 'No se pudieron cargar los datos',
    [_constants.DATA_PROVIDER_ERRORS_CREATE]: 'No se pudieron crear las filas',
    [_constants.DATA_PROVIDER_ERRORS_UPDATE]: 'No se pudieron actualizar las filas',
    [_constants.DATA_PROVIDER_ERRORS_REMOVE]: 'No se pudieron eliminar las filas',
    [_constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED]: 'La solicitud falló',
    [_constants.DATA_PROVIDER_BUTTONS_REFETCH]: 'Volver a cargar'
};
const _default = dictionary;
