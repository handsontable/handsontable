"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get arAR () {
        return _arAR.default;
    },
    get csCZ () {
        return _csCZ.default;
    },
    get deCH () {
        return _deCH.default;
    },
    get deDE () {
        return _deDE.default;
    },
    get enUS () {
        return _enUS.default;
    },
    get esMX () {
        return _esMX.default;
    },
    get faIR () {
        return _faIR.default;
    },
    get frFR () {
        return _frFR.default;
    },
    get hrHR () {
        return _hrHR.default;
    },
    get itIT () {
        return _itIT.default;
    },
    get jaJP () {
        return _jaJP.default;
    },
    get koKR () {
        return _koKR.default;
    },
    get lvLV () {
        return _lvLV.default;
    },
    get nbNO () {
        return _nbNO.default;
    },
    get nlNL () {
        return _nlNL.default;
    },
    get plPL () {
        return _plPL.default;
    },
    get ptBR () {
        return _ptBR.default;
    },
    get ruRU () {
        return _ruRU.default;
    },
    get srSP () {
        return _srSP.default;
    },
    get zhCN () {
        return _zhCN.default;
    },
    get zhTW () {
        return _zhTW.default;
    }
});
const _arAR = /*#__PURE__*/ _interop_require_default(require("./ar-AR"));
const _csCZ = /*#__PURE__*/ _interop_require_default(require("./cs-CZ"));
const _deCH = /*#__PURE__*/ _interop_require_default(require("./de-CH"));
const _deDE = /*#__PURE__*/ _interop_require_default(require("./de-DE"));
const _enUS = /*#__PURE__*/ _interop_require_default(require("./en-US"));
const _esMX = /*#__PURE__*/ _interop_require_default(require("./es-MX"));
const _faIR = /*#__PURE__*/ _interop_require_default(require("./fa-IR"));
const _frFR = /*#__PURE__*/ _interop_require_default(require("./fr-FR"));
const _hrHR = /*#__PURE__*/ _interop_require_default(require("./hr-HR"));
const _itIT = /*#__PURE__*/ _interop_require_default(require("./it-IT"));
const _jaJP = /*#__PURE__*/ _interop_require_default(require("./ja-JP"));
const _koKR = /*#__PURE__*/ _interop_require_default(require("./ko-KR"));
const _lvLV = /*#__PURE__*/ _interop_require_default(require("./lv-LV"));
const _nbNO = /*#__PURE__*/ _interop_require_default(require("./nb-NO"));
const _nlNL = /*#__PURE__*/ _interop_require_default(require("./nl-NL"));
const _plPL = /*#__PURE__*/ _interop_require_default(require("./pl-PL"));
const _ptBR = /*#__PURE__*/ _interop_require_default(require("./pt-BR"));
const _ruRU = /*#__PURE__*/ _interop_require_default(require("./ru-RU"));
const _srSP = /*#__PURE__*/ _interop_require_default(require("./sr-SP"));
const _zhCN = /*#__PURE__*/ _interop_require_default(require("./zh-CN"));
const _zhTW = /*#__PURE__*/ _interop_require_default(require("./zh-TW"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
