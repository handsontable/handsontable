/**
 * @preserve
 * Authors: Stefan Salzl, Thomas Senn
 * Last updated: Feb 05, 2018
 *
 * Description: Definition file for French - France language-country.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const dictionary = {
    languageCode: 'fr-FR',
    [_constants.OK]: 'OK',
    [_constants.CANCEL]: 'Annuler',
    [_constants.CONTEXTMENU_ITEMS_ROW_ABOVE]: 'Insérer une ligne en haut',
    [_constants.CONTEXTMENU_ITEMS_ROW_BELOW]: 'Insérer une ligne en bas',
    [_constants.CONTEXTMENU_ITEMS_INSERT_LEFT]: 'Insérer une colonne à gauche',
    [_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT]: 'Insérer une colonne à droite',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_ROW]: [
        'Supprimer une ligne',
        'Supprimer les lignes'
    ],
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COLUMN]: [
        'Supprimer une colonne',
        'Supprimer les colonnes'
    ],
    [_constants.CONTEXTMENU_ITEMS_UNDO]: 'Annuler',
    [_constants.CONTEXTMENU_ITEMS_REDO]: 'Rétablir',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY]: 'Lecture seule',
    [_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN]: 'Effacer la colonne',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT]: 'Alignement',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT]: 'Gauche',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER]: 'Centre',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT]: 'Droite',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY]: 'Justifié',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP]: 'En haut',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE]: 'Au milieu',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM]: 'En bas',
    [_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN]: 'Figer la colonne',
    [_constants.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN]: 'Libérer la colonne',
    [_constants.CONTEXTMENU_ITEMS_BORDERS]: 'Bordures',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_TOP]: 'Supérieure',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_RIGHT]: 'Droite',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM]: 'Inférieure',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_LEFT]: 'Gauche',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_BORDERS]: 'Pas de bordure',
    [_constants.CONTEXTMENU_ITEMS_ADD_COMMENT]: 'Ajouter commentaire',
    [_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT]: 'Modifier commentaire',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COMMENT]: 'Supprimer commentaire',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT]: 'Commentaire en lecture seule',
    [_constants.CONTEXTMENU_ITEMS_MERGE_CELLS]: 'Fusionner les cellules',
    [_constants.CONTEXTMENU_ITEMS_UNMERGE_CELLS]: 'Séparer les cellules',
    [_constants.CONTEXTMENU_ITEMS_COPY]: 'Copier',
    [_constants.CONTEXTMENU_ITEMS_CUT]: 'Couper',
    [_constants.CONTEXTMENU_ITEMS_EXPORT]: 'Exporter',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV]: 'En CSV',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX]: 'En Excel',
    [_constants.EXPORT_FILE_DIALOG_TITLE]: 'Exportation…',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD]: 'Insérer une sous-ligne',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD]: 'Détacher de la ligne précédente',
    [_constants.CONTEXTMENU_ITEMS_HIDE_COLUMN]: [
        'Masquer colonne',
        'Masquer les colonnes'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_COLUMN]: [
        'Afficher colonne',
        'Afficher les colonnes'
    ],
    [_constants.CONTEXTMENU_ITEMS_HIDE_ROW]: [
        'Masquer ligne',
        'Masquer les lignes'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_ROW]: [
        'Afficher ligne',
        'Afficher les lignes'
    ],
    [_constants.FILTERS_CONDITIONS_NONE]: 'Aucun',
    [_constants.FILTERS_CONDITIONS_EMPTY]: 'Est vide',
    [_constants.FILTERS_CONDITIONS_NOT_EMPTY]: 'N\'est pas vide',
    [_constants.FILTERS_CONDITIONS_EQUAL]: 'Egal à',
    [_constants.FILTERS_CONDITIONS_NOT_EQUAL]: 'Est différent de',
    [_constants.FILTERS_CONDITIONS_BEGINS_WITH]: 'Commence par',
    [_constants.FILTERS_CONDITIONS_ENDS_WITH]: 'Finit par',
    [_constants.FILTERS_CONDITIONS_CONTAINS]: 'Contient',
    [_constants.FILTERS_CONDITIONS_NOT_CONTAIN]: 'Ne contient pas',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN]: 'Supérieur à',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL]: 'Supérieur ou égal à',
    [_constants.FILTERS_CONDITIONS_LESS_THAN]: 'Inférieur à',
    [_constants.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL]: 'Inférieur ou égal à',
    [_constants.FILTERS_CONDITIONS_BETWEEN]: 'Est compris entre',
    [_constants.FILTERS_CONDITIONS_NOT_BETWEEN]: 'N\'est pas compris entre',
    [_constants.FILTERS_CONDITIONS_AFTER]: 'Après le',
    [_constants.FILTERS_CONDITIONS_AFTER_OR_EQUAL]: 'Après ou égal au',
    [_constants.FILTERS_CONDITIONS_BEFORE]: 'Avant le',
    [_constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL]: 'Avant ou égal au',
    [_constants.FILTERS_CONDITIONS_TODAY]: 'Aujourd\'hui',
    [_constants.FILTERS_CONDITIONS_TOMORROW]: 'Demain',
    [_constants.FILTERS_CONDITIONS_YESTERDAY]: 'Hier',
    [_constants.FILTERS_VALUES_BLANK_CELLS]: 'Cellules vides',
    [_constants.FILTERS_DIVS_FILTER_BY_CONDITION]: 'Filtrer par conditions',
    [_constants.FILTERS_DIVS_FILTER_BY_VALUE]: 'Filtrer par valeurs',
    [_constants.FILTERS_LABELS_CONJUNCTION]: 'Et',
    [_constants.FILTERS_LABELS_DISJUNCTION]: 'Ou',
    [_constants.FILTERS_BUTTONS_SELECT_ALL]: 'Tout sélectionner',
    [_constants.FILTERS_BUTTONS_CLEAR]: 'Effacer la sélection',
    [_constants.FILTERS_BUTTONS_OK]: 'OK',
    [_constants.FILTERS_BUTTONS_CANCEL]: 'Annuler',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SEARCH]: 'Chercher',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_VALUE]: 'Valeur',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE]: 'Valeur de remplacement',
    [_constants.PAGINATION_SECTION]: 'Pagination',
    [_constants.PAGINATION_PAGE_SIZE_SECTION]: 'Nombre de lignes',
    [_constants.PAGINATION_PAGE_SIZE_AUTO]: 'Auto',
    [_constants.PAGINATION_COUNTER_SECTION]: '[start] - [end] sur [total]',
    [_constants.PAGINATION_NAV_SECTION]: 'Page [currentPage] sur [totalPages]',
    [_constants.PAGINATION_FIRST_PAGE]: 'Aller à la première page',
    [_constants.PAGINATION_PREV_PAGE]: 'Aller à la page précédente',
    [_constants.PAGINATION_NEXT_PAGE]: 'Aller à la page suivante',
    [_constants.PAGINATION_LAST_PAGE]: 'Aller à la dernière page',
    [_constants.LOADING_TITLE]: 'Chargement...',
    [_constants.NOTIFICATION_BUTTONS_CLOSE]: 'Fermer',
    [_constants.EMPTY_DATA_STATE_TITLE]: 'Aucune donnée disponible',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION]: 'Il n\'y a rien à afficher pour le moment.',
    [_constants.EMPTY_DATA_STATE_TITLE_FILTERS]: 'Aucun résultat trouvé',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS]: 'Il semble que vos filtres actuels masquent tous les résultats.',
    [_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET]: 'Réinitialiser les filtres',
    [_constants.EMPTY_DATA_STATE_TITLE_LOADING]: 'Chargement des données',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING]: 'Veuillez patienter.',
    [_constants.DATA_PROVIDER_ERRORS_FETCH]: 'Impossible de charger les données',
    [_constants.DATA_PROVIDER_ERRORS_CREATE]: 'Impossible de créer les lignes',
    [_constants.DATA_PROVIDER_ERRORS_UPDATE]: 'Impossible de mettre à jour les lignes',
    [_constants.DATA_PROVIDER_ERRORS_REMOVE]: 'Impossible de supprimer les lignes',
    [_constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED]: 'La requête a échoué',
    [_constants.DATA_PROVIDER_BUTTONS_REFETCH]: 'Recharger'
};
const _default = dictionary;
