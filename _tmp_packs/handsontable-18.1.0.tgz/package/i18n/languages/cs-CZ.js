/**
 * @preserve
 * Authors: Ashus
 * Last updated: Mar 22, 2022
 *
 * Description: Definition file for Czech - Czechia language-country.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const dictionary = {
    languageCode: 'cs-CZ',
    [_constants.OK]: 'OK',
    [_constants.CANCEL]: 'Storno',
    [_constants.CONTEXTMENU_ITEMS_NO_ITEMS]: 'Žádné volby nejsou dostupné',
    [_constants.CONTEXTMENU_ITEMS_ROW_ABOVE]: 'Vložit řádek nad',
    [_constants.CONTEXTMENU_ITEMS_ROW_BELOW]: 'Vložit řádek pod',
    [_constants.CONTEXTMENU_ITEMS_INSERT_LEFT]: 'Vložit sloupec vlevo',
    [_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT]: 'Vložit sloupec vpravo',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_ROW]: [
        'Smazat řádek',
        'Smazat řádky'
    ],
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COLUMN]: [
        'Smazat sloupec',
        'Smazat sloupce'
    ],
    [_constants.CONTEXTMENU_ITEMS_UNDO]: 'Zpět',
    [_constants.CONTEXTMENU_ITEMS_REDO]: 'Znovu',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY]: 'Pouze pro čtení',
    [_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN]: 'Vymazat obsah sloupce',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT]: 'Zarovnat',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT]: 'Vlevo',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER]: 'Na střed',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT]: 'Vpravo',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY]: 'Do bloku',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP]: 'Nahoru',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE]: 'Na střed',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM]: 'Dolů',
    [_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN]: 'Zmrazit sloupec',
    [_constants.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN]: 'Zrušit zmrazení sloupce',
    [_constants.CONTEXTMENU_ITEMS_BORDERS]: 'Ohraničení',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_TOP]: 'Nahoře',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_RIGHT]: 'Vpravo',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM]: 'Dole',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_LEFT]: 'Vlevo',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_BORDERS]: 'Zrušit ohraničení',
    [_constants.CONTEXTMENU_ITEMS_ADD_COMMENT]: 'Přidat komentář',
    [_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT]: 'Upravit komentář',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COMMENT]: 'Vymazat komentář',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT]: 'Komenář pouze pro čtení',
    [_constants.CONTEXTMENU_ITEMS_MERGE_CELLS]: 'Sloučit buňky',
    [_constants.CONTEXTMENU_ITEMS_UNMERGE_CELLS]: 'Zrušit sloučení buněk',
    [_constants.CONTEXTMENU_ITEMS_COPY]: 'Kopírovat',
    [_constants.CONTEXTMENU_ITEMS_CUT]: 'Vyjmout',
    [_constants.CONTEXTMENU_ITEMS_EXPORT]: 'Exportovat',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV]: 'Do CSV',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX]: 'Do Excelu',
    [_constants.EXPORT_FILE_DIALOG_TITLE]: 'Exportuji…',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD]: 'Vložit podřízený řádek',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD]: 'Oddělit od nadřízeného',
    [_constants.CONTEXTMENU_ITEMS_HIDE_COLUMN]: [
        'Skrýt sloupec',
        'Skrýt sloupce'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_COLUMN]: [
        'Zobrazit sloupec',
        'Zobrazit sloupce'
    ],
    [_constants.CONTEXTMENU_ITEMS_HIDE_ROW]: [
        'Skrýt řádek',
        'Skrýt řádky'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_ROW]: [
        'Zobrazit řádek',
        'Zobrazit řádky'
    ],
    [_constants.FILTERS_CONDITIONS_NONE]: 'Žádné',
    [_constants.FILTERS_CONDITIONS_EMPTY]: 'Prázdné',
    [_constants.FILTERS_CONDITIONS_NOT_EMPTY]: 'Neprázdné',
    [_constants.FILTERS_CONDITIONS_EQUAL]: 'Rovná se',
    [_constants.FILTERS_CONDITIONS_NOT_EQUAL]: 'Nerovná se',
    [_constants.FILTERS_CONDITIONS_BEGINS_WITH]: 'Začíná na',
    [_constants.FILTERS_CONDITIONS_ENDS_WITH]: 'Končí na',
    [_constants.FILTERS_CONDITIONS_CONTAINS]: 'Obsahuje',
    [_constants.FILTERS_CONDITIONS_NOT_CONTAIN]: 'Neobsahuje',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN]: 'Větší než',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL]: 'Větší nebo se rovná',
    [_constants.FILTERS_CONDITIONS_LESS_THAN]: 'Menší než',
    [_constants.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL]: 'Menší nebo se rovná',
    [_constants.FILTERS_CONDITIONS_BETWEEN]: 'Je v rozsahu',
    [_constants.FILTERS_CONDITIONS_NOT_BETWEEN]: 'Není v rozsahu',
    [_constants.FILTERS_CONDITIONS_AFTER]: 'Po',
    [_constants.FILTERS_CONDITIONS_AFTER_OR_EQUAL]: 'Po nebo rovno',
    [_constants.FILTERS_CONDITIONS_BEFORE]: 'Před',
    [_constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL]: 'Před nebo rovno',
    [_constants.FILTERS_CONDITIONS_TODAY]: 'Dnes',
    [_constants.FILTERS_CONDITIONS_TOMORROW]: 'Zítra',
    [_constants.FILTERS_CONDITIONS_YESTERDAY]: 'Včera',
    [_constants.FILTERS_VALUES_BLANK_CELLS]: 'Prádné buňky',
    [_constants.FILTERS_DIVS_FILTER_BY_CONDITION]: 'Filtrovat dle stavu',
    [_constants.FILTERS_DIVS_FILTER_BY_VALUE]: 'Filtrovat dle hodnoty',
    [_constants.FILTERS_LABELS_CONJUNCTION]: 'A',
    [_constants.FILTERS_LABELS_DISJUNCTION]: 'Nebo',
    [_constants.FILTERS_BUTTONS_SELECT_ALL]: 'Vybrat vše',
    [_constants.FILTERS_BUTTONS_CLEAR]: 'Smazat',
    [_constants.FILTERS_BUTTONS_OK]: 'OK',
    [_constants.FILTERS_BUTTONS_CANCEL]: 'Storno',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SEARCH]: 'Hledat',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_VALUE]: 'Hodnota',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE]: 'Druhá hodnota',
    [_constants.PAGINATION_SECTION]: 'Stránkování',
    [_constants.PAGINATION_PAGE_SIZE_SECTION]: 'Počet řádků',
    [_constants.PAGINATION_PAGE_SIZE_AUTO]: 'Auto',
    [_constants.PAGINATION_COUNTER_SECTION]: '[start] - [end] z [total]',
    [_constants.PAGINATION_NAV_SECTION]: 'Stránka [currentPage] z [totalPages]',
    [_constants.PAGINATION_FIRST_PAGE]: 'Přejít na první stránku',
    [_constants.PAGINATION_PREV_PAGE]: 'Přejít na předchozí stránku',
    [_constants.PAGINATION_NEXT_PAGE]: 'Přejít na další stránku',
    [_constants.PAGINATION_LAST_PAGE]: 'Přejít na poslední stránku',
    [_constants.LOADING_TITLE]: 'Načítání...',
    [_constants.NOTIFICATION_BUTTONS_CLOSE]: 'Zavřít',
    [_constants.EMPTY_DATA_STATE_TITLE]: 'Žádná data nejsou k dispozici',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION]: 'Zatím není co zobrazit.',
    [_constants.EMPTY_DATA_STATE_TITLE_FILTERS]: 'Nebyly nalezeny žádné výsledky',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS]: 'Vypadá to, že vaše současné filtry skrývají všechny výsledky.',
    [_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET]: 'Resetovat filtry',
    [_constants.EMPTY_DATA_STATE_TITLE_LOADING]: 'Načítání dat',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING]: 'Čekejte prosím.',
    [_constants.DATA_PROVIDER_ERRORS_FETCH]: 'Data se nepodařilo načíst',
    [_constants.DATA_PROVIDER_ERRORS_CREATE]: 'Řádky se nepodařilo vytvořit',
    [_constants.DATA_PROVIDER_ERRORS_UPDATE]: 'Řádky se nepodařilo aktualizovat',
    [_constants.DATA_PROVIDER_ERRORS_REMOVE]: 'Řádky se nepodařilo odstranit',
    [_constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED]: 'Požadavek selhal',
    [_constants.DATA_PROVIDER_BUTTONS_REFETCH]: 'Znovu načíst'
};
const _default = dictionary;
