/**
 * @preserve
 * Authors: Handsoncode
 * Last updated: Feb 9, 2022
 *
 * Description: Definition file for Arabic - Without a specific country.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const dictionary = {
    languageCode: 'ar-AR',
    languageDirection: 'rtl',
    [_constants.OK]: 'موافق',
    [_constants.CANCEL]: 'إلغاء',
    [_constants.CONTEXTMENU_ITEMS_NO_ITEMS]: 'لا توجد خيارات متوفرة',
    [_constants.CONTEXTMENU_ITEMS_ROW_ABOVE]: 'إدراج صف للأعلى',
    [_constants.CONTEXTMENU_ITEMS_ROW_BELOW]: 'إدراج صف للأسفل',
    [_constants.CONTEXTMENU_ITEMS_INSERT_LEFT]: 'إدراج عمود لليسار',
    [_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT]: 'إدراج عمود لليمين',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_ROW]: [
        'احدف الصف',
        'احذف الصفوف'
    ],
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COLUMN]: [
        'احدف العمود',
        'احدف الأعمدة'
    ],
    [_constants.CONTEXTMENU_ITEMS_UNDO]: 'تراجع',
    [_constants.CONTEXTMENU_ITEMS_REDO]: 'إلغاء التراجع',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY]: 'للقراءة فقط',
    [_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN]: 'افرغ العمود',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT]: 'المحاذاة',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT]: 'يسار',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER]: 'وسط',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT]: 'يمين',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY]: 'بالتساوي',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP]: 'أعلى',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE]: 'متوسط',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM]: 'أسفل',
    [_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN]: 'تجميد العمود',
    [_constants.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN]: 'إلغاء تجميد العمود',
    [_constants.CONTEXTMENU_ITEMS_BORDERS]: 'الحدود',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_TOP]: 'أعلى',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_RIGHT]: 'يمين',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM]: 'أسفل',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_LEFT]: 'يسار',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_BORDERS]: 'أحذف الحد(ود)',
    [_constants.CONTEXTMENU_ITEMS_ADD_COMMENT]: 'أضف تعليقاً',
    [_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT]: 'تعديل التعليق',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COMMENT]: 'احذف التعليق',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT]: 'تعليق للقراءة فقط',
    [_constants.CONTEXTMENU_ITEMS_MERGE_CELLS]: 'ادمج الخلايا',
    [_constants.CONTEXTMENU_ITEMS_UNMERGE_CELLS]: 'إلغاء دمج الخلايا',
    [_constants.CONTEXTMENU_ITEMS_COPY]: 'نسخ',
    [_constants.CONTEXTMENU_ITEMS_CUT]: 'قص',
    [_constants.CONTEXTMENU_ITEMS_EXPORT]: 'تصدير',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV]: 'إلى CSV',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX]: 'إلى Excel',
    [_constants.EXPORT_FILE_DIALOG_TITLE]: 'جارٍ التصدير…',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD]: 'أدخل صفاً فرعياً',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD]: 'افصل عن الصف الأصلي',
    [_constants.CONTEXTMENU_ITEMS_HIDE_COLUMN]: [
        'إخفاء العمود',
        'إخفاء الأعمدة'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_COLUMN]: [
        'إظهار العمود',
        'إظهار الأعمدة'
    ],
    [_constants.CONTEXTMENU_ITEMS_HIDE_ROW]: [
        'إخفاء السطر',
        'إخفاء السطور'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_ROW]: [
        'إظهار السطر',
        'إظهار السطور'
    ],
    [_constants.FILTERS_CONDITIONS_NONE]: 'بلا',
    [_constants.FILTERS_CONDITIONS_EMPTY]: 'فارغ',
    [_constants.FILTERS_CONDITIONS_NOT_EMPTY]: 'غير فارغ',
    [_constants.FILTERS_CONDITIONS_EQUAL]: 'يساوي',
    [_constants.FILTERS_CONDITIONS_NOT_EQUAL]: 'لا يساوي',
    [_constants.FILTERS_CONDITIONS_BEGINS_WITH]: 'يبداً بـ',
    [_constants.FILTERS_CONDITIONS_ENDS_WITH]: 'ينتهي بـ',
    [_constants.FILTERS_CONDITIONS_CONTAINS]: 'يحتوي',
    [_constants.FILTERS_CONDITIONS_NOT_CONTAIN]: 'لا يحتوي',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN]: 'أكبر من',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL]: 'أكبر أو يساوي',
    [_constants.FILTERS_CONDITIONS_LESS_THAN]: 'أصغر',
    [_constants.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL]: 'أصغر أو يساوي',
    [_constants.FILTERS_CONDITIONS_BETWEEN]: 'بين',
    [_constants.FILTERS_CONDITIONS_NOT_BETWEEN]: 'خارج المجال',
    [_constants.FILTERS_CONDITIONS_AFTER]: 'بعد',
    [_constants.FILTERS_CONDITIONS_AFTER_OR_EQUAL]: 'بعد أو يساوي',
    [_constants.FILTERS_CONDITIONS_BEFORE]: 'قبل',
    [_constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL]: 'قبل أو يساوي',
    [_constants.FILTERS_CONDITIONS_TODAY]: 'اليوم',
    [_constants.FILTERS_CONDITIONS_TOMORROW]: 'غداً',
    [_constants.FILTERS_CONDITIONS_YESTERDAY]: 'البارحة',
    [_constants.FILTERS_VALUES_BLANK_CELLS]: 'خلايا فارغة',
    [_constants.FILTERS_DIVS_FILTER_BY_CONDITION]: 'تصفية حسب الشرط',
    [_constants.FILTERS_DIVS_FILTER_BY_VALUE]: 'تصفية حسب القيمة',
    [_constants.FILTERS_LABELS_CONJUNCTION]: 'و',
    [_constants.FILTERS_LABELS_DISJUNCTION]: 'أو',
    [_constants.FILTERS_BUTTONS_SELECT_ALL]: 'اختيار الكل',
    [_constants.FILTERS_BUTTONS_CLEAR]: 'إلغاء',
    [_constants.FILTERS_BUTTONS_OK]: 'موافق',
    [_constants.FILTERS_BUTTONS_CANCEL]: 'إلغاء',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SEARCH]: 'البحث',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_VALUE]: 'القيمة',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE]: 'القيمة الثانية',
    [_constants.PAGINATION_SECTION]: 'ترقيم الصفحات',
    [_constants.PAGINATION_PAGE_SIZE_SECTION]: 'عدد الصفوف',
    [_constants.PAGINATION_PAGE_SIZE_AUTO]: 'تلقائي',
    [_constants.PAGINATION_COUNTER_SECTION]: '[start] - [end] من [total]',
    [_constants.PAGINATION_NAV_SECTION]: 'صفحة [currentPage] من [totalPages]',
    [_constants.PAGINATION_FIRST_PAGE]: 'الانتقال إلى الصفحة الأولى',
    [_constants.PAGINATION_PREV_PAGE]: 'الانتقال إلى الصفحة السابقة',
    [_constants.PAGINATION_NEXT_PAGE]: 'الانتقال إلى الصفحة التالية',
    [_constants.PAGINATION_LAST_PAGE]: 'الانتقال إلى الصفحة الأخيرة',
    [_constants.LOADING_TITLE]: 'جاري التحميل...',
    [_constants.NOTIFICATION_BUTTONS_CLOSE]: 'إغلاق',
    [_constants.EMPTY_DATA_STATE_TITLE]: 'لا توجد بيانات متاحة',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION]: 'لا يوجد شيء للعرض بعد.',
    [_constants.EMPTY_DATA_STATE_TITLE_FILTERS]: 'لم يتم العثور على نتائج',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS]: 'يبدو أن المرشحات الحالية تخفي جميع النتائج.',
    [_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET]: 'إعادة تعيين المرشحات',
    [_constants.EMPTY_DATA_STATE_TITLE_LOADING]: 'جارٍ تحميل البيانات',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING]: 'يرجى الانتظار.',
    [_constants.DATA_PROVIDER_ERRORS_FETCH]: 'تعذر تحميل البيانات',
    [_constants.DATA_PROVIDER_ERRORS_CREATE]: 'تعذر إنشاء الصفوف',
    [_constants.DATA_PROVIDER_ERRORS_UPDATE]: 'تعذر تحديث الصفوف',
    [_constants.DATA_PROVIDER_ERRORS_REMOVE]: 'تعذر إزالة الصفوف',
    [_constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED]: 'فشل الطلب',
    [_constants.DATA_PROVIDER_BUTTONS_REFETCH]: 'إعادة التحميل'
};
const _default = dictionary;
