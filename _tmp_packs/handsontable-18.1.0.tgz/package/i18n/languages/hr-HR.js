/**
 * @preserve
 * Authors: Domagoj Lončarić & Ante Živković
 * Last updated: Jan 31, 2024
 *
 * Description: Definition file for Croatian - Croatia language-country.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const dictionary = {
    languageCode: 'hr-HR',
    [_constants.OK]: 'U redu',
    [_constants.CANCEL]: 'Odustani',
    [_constants.CONTEXTMENU_ITEMS_NO_ITEMS]: 'Nema dostupnih mogućnosti',
    [_constants.CONTEXTMENU_ITEMS_ROW_ABOVE]: 'Umetni redak iznad',
    [_constants.CONTEXTMENU_ITEMS_ROW_BELOW]: 'Umetni redak ispod',
    [_constants.CONTEXTMENU_ITEMS_INSERT_LEFT]: 'Umetni stupac lijevo',
    [_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT]: 'Umetni stupac desno',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_ROW]: [
        'Ukloni redak',
        'Ukloni retke'
    ],
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COLUMN]: [
        'Ukloni stupac',
        'Ukloni stupce'
    ],
    [_constants.CONTEXTMENU_ITEMS_UNDO]: 'Poništi',
    [_constants.CONTEXTMENU_ITEMS_REDO]: 'Ponovi',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY]: 'Samo za čitanje',
    [_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN]: 'Očisti stupac',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT]: 'Poravnanje',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT]: 'Lijevo',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER]: 'Centar',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT]: 'Desno',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY]: 'Obostrano',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP]: 'Gore',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE]: 'Sredina',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM]: 'Dolje',
    [_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN]: 'Zamrzni stupac',
    [_constants.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN]: 'Odmrzni stupac',
    [_constants.CONTEXTMENU_ITEMS_BORDERS]: 'Granice',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_TOP]: 'Gore',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_RIGHT]: 'Desno',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM]: 'Dolje',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_LEFT]: 'Lijevo',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_BORDERS]: 'Ukloni granicu(e)',
    [_constants.CONTEXTMENU_ITEMS_ADD_COMMENT]: 'Dodaj komentar',
    [_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT]: 'Uredi komentar',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COMMENT]: 'Izbriši komentar',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT]: 'Komentar samo za čitanje',
    [_constants.CONTEXTMENU_ITEMS_MERGE_CELLS]: 'Spoji čelije',
    [_constants.CONTEXTMENU_ITEMS_UNMERGE_CELLS]: 'Razdijeli čelije',
    [_constants.CONTEXTMENU_ITEMS_COPY]: 'Kopiraj',
    [_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS]: [
        'Kopiraj sa zaglavljem',
        'Kopiraj sa zaglavljima'
    ],
    [_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS]: [
        'Kopiraj sa grupnim zaglavljem',
        'Kopiraj sa grupnim zaglavljima'
    ],
    [_constants.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY]: [
        'Kopiraj samo zaglavlje',
        'Kopiraj samo zaglavlja'
    ],
    [_constants.CONTEXTMENU_ITEMS_CUT]: 'Izreži',
    [_constants.CONTEXTMENU_ITEMS_EXPORT]: 'Izvezi',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV]: 'Kao CSV',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX]: 'Kao Excel',
    [_constants.EXPORT_FILE_DIALOG_TITLE]: 'Izvoz…',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD]: 'Umetni ugniježđeni redak',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD]: 'Odvoji ugniježđeni redak',
    [_constants.CONTEXTMENU_ITEMS_HIDE_COLUMN]: [
        'Sakrij stupac',
        'Sakrij stupce'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_COLUMN]: [
        'Prikaži stupac',
        'Prikaži stupce'
    ],
    [_constants.CONTEXTMENU_ITEMS_HIDE_ROW]: [
        'Sakrij redak',
        'Sakrij retke'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_ROW]: [
        'Prikaži redak',
        'Prikaži retke'
    ],
    [_constants.FILTERS_CONDITIONS_NONE]: 'Ništa',
    [_constants.FILTERS_CONDITIONS_EMPTY]: 'Prazno',
    [_constants.FILTERS_CONDITIONS_NOT_EMPTY]: 'Nije prazno',
    [_constants.FILTERS_CONDITIONS_EQUAL]: 'Jednako',
    [_constants.FILTERS_CONDITIONS_NOT_EQUAL]: 'Nije jednako',
    [_constants.FILTERS_CONDITIONS_BEGINS_WITH]: 'Počinje s',
    [_constants.FILTERS_CONDITIONS_ENDS_WITH]: 'Završava s',
    [_constants.FILTERS_CONDITIONS_CONTAINS]: 'Sadrži',
    [_constants.FILTERS_CONDITIONS_NOT_CONTAIN]: 'Ne sadrži',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN]: 'Veće od',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL]: 'Veće ili jednako od',
    [_constants.FILTERS_CONDITIONS_LESS_THAN]: 'Manje od',
    [_constants.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL]: 'Manje ili jednako od',
    [_constants.FILTERS_CONDITIONS_BETWEEN]: 'Između',
    [_constants.FILTERS_CONDITIONS_NOT_BETWEEN]: 'Nije između',
    [_constants.FILTERS_CONDITIONS_AFTER]: 'Nakon',
    [_constants.FILTERS_CONDITIONS_AFTER_OR_EQUAL]: 'Nakon ili jednako',
    [_constants.FILTERS_CONDITIONS_BEFORE]: 'Prije',
    [_constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL]: 'Prije ili jednako',
    [_constants.FILTERS_CONDITIONS_TODAY]: 'Danas',
    [_constants.FILTERS_CONDITIONS_TOMORROW]: 'Sutra',
    [_constants.FILTERS_CONDITIONS_YESTERDAY]: 'Jučer',
    [_constants.FILTERS_VALUES_BLANK_CELLS]: 'Prazna polja',
    [_constants.FILTERS_DIVS_FILTER_BY_CONDITION]: 'Filtriraj po uvjetu',
    [_constants.FILTERS_DIVS_FILTER_BY_VALUE]: 'Filtriraj po vrijednosti',
    [_constants.FILTERS_LABELS_CONJUNCTION]: 'I',
    [_constants.FILTERS_LABELS_DISJUNCTION]: 'Ili',
    [_constants.FILTERS_BUTTONS_SELECT_ALL]: 'Odaberi sve',
    [_constants.FILTERS_BUTTONS_CLEAR]: 'Očisti',
    [_constants.FILTERS_BUTTONS_OK]: 'U redu',
    [_constants.FILTERS_BUTTONS_CANCEL]: 'Odustani',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SEARCH]: 'Pretraži',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_VALUE]: 'Vrijednost',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE]: 'Druga vrijednost',
    [_constants.PAGINATION_SECTION]: 'Paginacija',
    [_constants.PAGINATION_PAGE_SIZE_SECTION]: 'Broj redaka',
    [_constants.PAGINATION_PAGE_SIZE_AUTO]: 'Auto',
    [_constants.PAGINATION_COUNTER_SECTION]: '[start] - [end] od [total]',
    [_constants.PAGINATION_NAV_SECTION]: 'Stranica [currentPage] od [totalPages]',
    [_constants.PAGINATION_FIRST_PAGE]: 'Idi na prvu stranicu',
    [_constants.PAGINATION_PREV_PAGE]: 'Idi na prethodnu stranicu',
    [_constants.PAGINATION_NEXT_PAGE]: 'Idi na sljedeću stranicu',
    [_constants.PAGINATION_LAST_PAGE]: 'Idi na posljednju stranicu',
    [_constants.CHECKBOX_CHECKED]: 'Označeno',
    [_constants.CHECKBOX_UNCHECKED]: 'Nije označeno',
    [_constants.LOADING_TITLE]: 'Učitavanje...',
    [_constants.NOTIFICATION_BUTTONS_CLOSE]: 'Zatvori',
    [_constants.EMPTY_DATA_STATE_TITLE]: 'Nema dostupnih podataka',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION]: 'Još nema ništa za prikaz.',
    [_constants.EMPTY_DATA_STATE_TITLE_FILTERS]: 'Nema pronađenih rezultata',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS]: 'Čini se da vaši trenutni filtri skrivaju sve rezultate.',
    [_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET]: 'Resetiraj filtre',
    [_constants.EMPTY_DATA_STATE_TITLE_LOADING]: 'Učitavanje podataka',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING]: 'Pričekajte.',
    [_constants.DATA_PROVIDER_ERRORS_FETCH]: 'Nije moguće učitati podatke',
    [_constants.DATA_PROVIDER_ERRORS_CREATE]: 'Nije moguće stvoriti retke',
    [_constants.DATA_PROVIDER_ERRORS_UPDATE]: 'Nije moguće ažurirati retke',
    [_constants.DATA_PROVIDER_ERRORS_REMOVE]: 'Nije moguće ukloniti retke',
    [_constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED]: 'Zahtjev nije uspio',
    [_constants.DATA_PROVIDER_BUTTONS_REFETCH]: 'Ponovno učitaj'
};
const _default = dictionary;
