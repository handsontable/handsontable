/**
 * @preserve
 * Authors: Handsoncode
 * Last updated: Nov 15, 2017
 *
 * Description: Definition file for English - United States language-country.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const dictionary = {
    languageCode: 'en-US',
    [_constants.OK]: 'OK',
    [_constants.CANCEL]: 'Cancel',
    [_constants.CONTEXTMENU_ITEMS_NO_ITEMS]: 'No available options',
    [_constants.CONTEXTMENU_ITEMS_ROW_ABOVE]: 'Insert row above',
    [_constants.CONTEXTMENU_ITEMS_ROW_BELOW]: 'Insert row below',
    [_constants.CONTEXTMENU_ITEMS_INSERT_LEFT]: 'Insert column left',
    [_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT]: 'Insert column right',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_ROW]: [
        'Remove row',
        'Remove rows'
    ],
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COLUMN]: [
        'Remove column',
        'Remove columns'
    ],
    [_constants.CONTEXTMENU_ITEMS_UNDO]: 'Undo',
    [_constants.CONTEXTMENU_ITEMS_REDO]: 'Redo',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY]: 'Read only',
    [_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN]: 'Clear column',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT]: 'Alignment',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT]: 'Left',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER]: 'Center',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT]: 'Right',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY]: 'Justify',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP]: 'Top',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE]: 'Middle',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM]: 'Bottom',
    [_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN]: 'Freeze column',
    [_constants.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN]: 'Unfreeze column',
    [_constants.CONTEXTMENU_ITEMS_BORDERS]: 'Borders',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_TOP]: 'Top',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_RIGHT]: 'Right',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM]: 'Bottom',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_LEFT]: 'Left',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_BORDERS]: 'Remove border(s)',
    [_constants.CONTEXTMENU_ITEMS_ADD_COMMENT]: 'Add comment',
    [_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT]: 'Edit comment',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COMMENT]: 'Delete comment',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT]: 'Read-only comment',
    [_constants.CONTEXTMENU_ITEMS_MERGE_CELLS]: 'Merge cells',
    [_constants.CONTEXTMENU_ITEMS_UNMERGE_CELLS]: 'Unmerge cells',
    [_constants.CONTEXTMENU_ITEMS_COPY]: 'Copy',
    [_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS]: [
        'Copy with header',
        'Copy with headers'
    ],
    [_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS]: [
        'Copy with group header',
        'Copy with group headers'
    ],
    [_constants.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY]: [
        'Copy header only',
        'Copy headers only'
    ],
    [_constants.CONTEXTMENU_ITEMS_CUT]: 'Cut',
    [_constants.CONTEXTMENU_ITEMS_EXPORT]: 'Export',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV]: 'To CSV',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX]: 'To Excel',
    [_constants.EXPORT_FILE_DIALOG_TITLE]: 'Exporting…',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD]: 'Insert child row',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD]: 'Detach from parent',
    [_constants.CONTEXTMENU_ITEMS_HIDE_COLUMN]: [
        'Hide column',
        'Hide columns'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_COLUMN]: [
        'Show column',
        'Show columns'
    ],
    [_constants.CONTEXTMENU_ITEMS_HIDE_ROW]: [
        'Hide row',
        'Hide rows'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_ROW]: [
        'Show row',
        'Show rows'
    ],
    [_constants.FILTERS_CONDITIONS_NONE]: 'None',
    [_constants.FILTERS_CONDITIONS_EMPTY]: 'Is empty',
    [_constants.FILTERS_CONDITIONS_NOT_EMPTY]: 'Is not empty',
    [_constants.FILTERS_CONDITIONS_EQUAL]: 'Is equal to',
    [_constants.FILTERS_CONDITIONS_NOT_EQUAL]: 'Is not equal to',
    [_constants.FILTERS_CONDITIONS_BEGINS_WITH]: 'Begins with',
    [_constants.FILTERS_CONDITIONS_ENDS_WITH]: 'Ends with',
    [_constants.FILTERS_CONDITIONS_CONTAINS]: 'Contains',
    [_constants.FILTERS_CONDITIONS_NOT_CONTAIN]: 'Does not contain',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN]: 'Greater than',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL]: 'Greater than or equal to',
    [_constants.FILTERS_CONDITIONS_LESS_THAN]: 'Less than',
    [_constants.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL]: 'Less than or equal to',
    [_constants.FILTERS_CONDITIONS_BETWEEN]: 'Is between',
    [_constants.FILTERS_CONDITIONS_NOT_BETWEEN]: 'Is not between',
    [_constants.FILTERS_CONDITIONS_AFTER]: 'After',
    [_constants.FILTERS_CONDITIONS_AFTER_OR_EQUAL]: 'After or equal to',
    [_constants.FILTERS_CONDITIONS_BEFORE]: 'Before',
    [_constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL]: 'Before or equal to',
    [_constants.FILTERS_CONDITIONS_TODAY]: 'Today',
    [_constants.FILTERS_CONDITIONS_TOMORROW]: 'Tomorrow',
    [_constants.FILTERS_CONDITIONS_YESTERDAY]: 'Yesterday',
    [_constants.FILTERS_VALUES_BLANK_CELLS]: 'Blank cells',
    [_constants.FILTERS_DIVS_FILTER_BY_CONDITION]: 'Filter by condition',
    [_constants.FILTERS_DIVS_FILTER_BY_VALUE]: 'Filter by value',
    [_constants.FILTERS_LABELS_CONJUNCTION]: 'And',
    [_constants.FILTERS_LABELS_DISJUNCTION]: 'Or',
    [_constants.FILTERS_BUTTONS_SELECT_ALL]: 'Select all',
    [_constants.FILTERS_BUTTONS_CLEAR]: 'Clear',
    [_constants.FILTERS_BUTTONS_OK]: 'OK',
    [_constants.FILTERS_BUTTONS_CANCEL]: 'Cancel',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SEARCH]: 'Search',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_VALUE]: 'Value',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE]: 'Second value',
    [_constants.PAGINATION_SECTION]: 'Pagination',
    [_constants.PAGINATION_PAGE_SIZE_SECTION]: 'Page size',
    [_constants.PAGINATION_PAGE_SIZE_AUTO]: 'Auto',
    [_constants.PAGINATION_COUNTER_SECTION]: '[start] - [end] of [total]',
    [_constants.PAGINATION_NAV_SECTION]: 'Page [currentPage] of [totalPages]',
    [_constants.PAGINATION_FIRST_PAGE]: 'Go to first page',
    [_constants.PAGINATION_PREV_PAGE]: 'Go to previous page',
    [_constants.PAGINATION_NEXT_PAGE]: 'Go to next page',
    [_constants.PAGINATION_LAST_PAGE]: 'Go to last page',
    [_constants.CHECKBOX_CHECKED]: 'Checked',
    [_constants.CHECKBOX_UNCHECKED]: 'Unchecked',
    [_constants.LOADING_TITLE]: 'Loading...',
    [_constants.NOTIFICATION_BUTTONS_CLOSE]: 'Close',
    [_constants.EMPTY_DATA_STATE_TITLE]: 'No data available',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION]: 'There’s nothing to display yet.',
    [_constants.EMPTY_DATA_STATE_TITLE_FILTERS]: 'No results found',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS]: 'It looks like your current filters are hiding all results.',
    [_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET]: 'Reset filters',
    [_constants.EMPTY_DATA_STATE_TITLE_LOADING]: 'Loading data',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING]: 'Please wait.',
    [_constants.DATA_PROVIDER_ERRORS_FETCH]: 'Could not load data',
    [_constants.DATA_PROVIDER_ERRORS_CREATE]: 'Could not create rows',
    [_constants.DATA_PROVIDER_ERRORS_UPDATE]: 'Could not update rows',
    [_constants.DATA_PROVIDER_ERRORS_REMOVE]: 'Could not remove rows',
    [_constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED]: 'Request failed',
    [_constants.DATA_PROVIDER_BUTTONS_REFETCH]: 'Refetch'
};
const _default = dictionary;
