/**
 * @preserve
 * Authors: Ali Almasi
 * Last updated: Jan 19, 2025
 *
 * Description: Definition file for Farsi - Iran language-country.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const dictionary = {
    languageCode: 'fa-IR',
    languageDirection: 'rtl',
    [_constants.OK]: 'تایید',
    [_constants.CANCEL]: 'لغو',
    [_constants.CONTEXTMENU_ITEMS_NO_ITEMS]: 'هیچ گزینه ای در دسترس نیست',
    [_constants.CONTEXTMENU_ITEMS_ROW_ABOVE]: 'درج ردیف در بالا',
    [_constants.CONTEXTMENU_ITEMS_ROW_BELOW]: 'درج ردیف در پایین',
    [_constants.CONTEXTMENU_ITEMS_INSERT_LEFT]: 'درج ستون در چپ',
    [_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT]: 'درج ستون در راست',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_ROW]: [
        'حذف ردیف',
        'حذف ردیف ها'
    ],
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COLUMN]: [
        'حذف ستون',
        'حذف ستون ها'
    ],
    [_constants.CONTEXTMENU_ITEMS_UNDO]: 'واگرد',
    [_constants.CONTEXTMENU_ITEMS_REDO]: 'بازگردانی',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY]: 'فقط خواندنی',
    [_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN]: 'پاک کردن ستون',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT]: 'تراز',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT]: 'چپ',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER]: 'وسط',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT]: 'راست',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY]: 'میزان',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP]: 'بالا',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE]: 'میانه',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM]: 'پایین',
    [_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN]: 'انجماد ستون',
    [_constants.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN]: 'باز کردن ستون',
    [_constants.CONTEXTMENU_ITEMS_BORDERS]: 'مرز ها',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_TOP]: 'بالا',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_RIGHT]: 'راست',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM]: 'پایین',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_LEFT]: 'چپ',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_BORDERS]: 'حذف مرز (ها)',
    [_constants.CONTEXTMENU_ITEMS_ADD_COMMENT]: 'افزودن کامنت',
    [_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT]: 'تغییر کامنت',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COMMENT]: 'حذف کامنت',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT]: 'فقط خواندنی کردن کامنت',
    [_constants.CONTEXTMENU_ITEMS_MERGE_CELLS]: 'ادغام سلول ها',
    [_constants.CONTEXTMENU_ITEMS_UNMERGE_CELLS]: 'جدا کردن سلول ها',
    [_constants.CONTEXTMENU_ITEMS_COPY]: 'کپی',
    [_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS]: [
        'کپی با سر ستون',
        'کپی با سرستون ها'
    ],
    [_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS]: [
        'کپی با سرستون گروه',
        'کپی با سرستون گروه ها'
    ],
    [_constants.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY]: [
        'فقط کپی سرستون',
        'فقط کپی سرستون ها'
    ],
    [_constants.CONTEXTMENU_ITEMS_CUT]: 'بریدن',
    [_constants.CONTEXTMENU_ITEMS_EXPORT]: 'خروجی',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV]: 'به CSV',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX]: 'به Excel',
    [_constants.EXPORT_FILE_DIALOG_TITLE]: 'در حال صدور…',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD]: 'درج زیر ردیف',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD]: 'جدا کردن از سرردیف',
    [_constants.CONTEXTMENU_ITEMS_HIDE_COLUMN]: [
        'پنهان کردن ستون',
        'پنهان کردن ستون ها'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_COLUMN]: [
        'نمایش ستون',
        'نمایش ستون ها'
    ],
    [_constants.CONTEXTMENU_ITEMS_HIDE_ROW]: [
        'پنهان کردن ردیف',
        'پنهان کردن ردیف ها'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_ROW]: [
        'نمایش ردیف',
        'نمایش ردیف ها'
    ],
    [_constants.FILTERS_CONDITIONS_NONE]: 'هیچ',
    [_constants.FILTERS_CONDITIONS_EMPTY]: 'خالی است',
    [_constants.FILTERS_CONDITIONS_NOT_EMPTY]: 'خالی نیست',
    [_constants.FILTERS_CONDITIONS_EQUAL]: 'برابر است با',
    [_constants.FILTERS_CONDITIONS_NOT_EQUAL]: 'برابر نیست با',
    [_constants.FILTERS_CONDITIONS_BEGINS_WITH]: 'شروع می شود با',
    [_constants.FILTERS_CONDITIONS_ENDS_WITH]: 'پایان می یابد با',
    [_constants.FILTERS_CONDITIONS_CONTAINS]: 'شامل می شود',
    [_constants.FILTERS_CONDITIONS_NOT_CONTAIN]: 'شامل نمی شود',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN]: 'بزرگ تر',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL]: 'بزرگتر مساوی',
    [_constants.FILTERS_CONDITIONS_LESS_THAN]: 'کوچکتر',
    [_constants.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL]: 'کوچکتر مساوی',
    [_constants.FILTERS_CONDITIONS_BETWEEN]: 'در میان است',
    [_constants.FILTERS_CONDITIONS_NOT_BETWEEN]: 'در میان نیست',
    [_constants.FILTERS_CONDITIONS_AFTER]: 'بعد',
    [_constants.FILTERS_CONDITIONS_AFTER_OR_EQUAL]: 'بعد یا مساوی',
    [_constants.FILTERS_CONDITIONS_BEFORE]: 'قبل',
    [_constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL]: 'قبل یا مساوی',
    [_constants.FILTERS_CONDITIONS_TODAY]: 'امروز',
    [_constants.FILTERS_CONDITIONS_TOMORROW]: 'فردا',
    [_constants.FILTERS_CONDITIONS_YESTERDAY]: 'دیروز',
    [_constants.FILTERS_VALUES_BLANK_CELLS]: 'سلول های خالی',
    [_constants.FILTERS_DIVS_FILTER_BY_CONDITION]: 'فیلتر بر اساس شرایط',
    [_constants.FILTERS_DIVS_FILTER_BY_VALUE]: 'فیلتر بر اساس مقدار',
    [_constants.FILTERS_LABELS_CONJUNCTION]: 'و',
    [_constants.FILTERS_LABELS_DISJUNCTION]: 'یا',
    [_constants.FILTERS_BUTTONS_SELECT_ALL]: 'انتخاب همه',
    [_constants.FILTERS_BUTTONS_CLEAR]: 'پاک کردن',
    [_constants.FILTERS_BUTTONS_OK]: 'تایید',
    [_constants.FILTERS_BUTTONS_CANCEL]: 'لغو',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SEARCH]: 'جستجو',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_VALUE]: 'مقدار',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE]: 'مقدار دوم',
    [_constants.PAGINATION_SECTION]: 'صفحه‌بندی',
    [_constants.PAGINATION_PAGE_SIZE_SECTION]: 'تعداد سطرها',
    [_constants.PAGINATION_PAGE_SIZE_AUTO]: 'خودکار',
    [_constants.PAGINATION_COUNTER_SECTION]: '[start] - [end] از [total]',
    [_constants.PAGINATION_NAV_SECTION]: 'صفحه [currentPage] از [totalPages]',
    [_constants.PAGINATION_FIRST_PAGE]: 'به اولین صفحه بروید',
    [_constants.PAGINATION_PREV_PAGE]: 'به صفحه قبلی بروید',
    [_constants.PAGINATION_NEXT_PAGE]: 'به صفحه بعدی بروید',
    [_constants.PAGINATION_LAST_PAGE]: 'به آخرین صفحه بروید',
    [_constants.CHECKBOX_CHECKED]: 'چک شده',
    [_constants.CHECKBOX_UNCHECKED]: 'چک نشده',
    [_constants.LOADING_TITLE]: 'در حال بارگذاری...',
    [_constants.NOTIFICATION_BUTTONS_CLOSE]: 'بستن',
    [_constants.EMPTY_DATA_STATE_TITLE]: 'هیچ داده‌ای در دسترس نیست',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION]: 'هنوز چیزی برای نمایش وجود ندارد.',
    [_constants.EMPTY_DATA_STATE_TITLE_FILTERS]: 'هیچ نتیجه‌ای یافت نشد',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS]: 'به نظر می‌رسد فیلترهای فعلی شما همه نتایج را پنهان می‌کنند.',
    [_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET]: 'بازنشانی فیلترها',
    [_constants.EMPTY_DATA_STATE_TITLE_LOADING]: 'در حال بارگذاری داده‌ها',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING]: 'لطفاً صبر کنید.',
    [_constants.DATA_PROVIDER_ERRORS_FETCH]: 'بارگذاری داده‌ها ناموفق بود',
    [_constants.DATA_PROVIDER_ERRORS_CREATE]: 'ایجاد ردیف‌ها ناموفق بود',
    [_constants.DATA_PROVIDER_ERRORS_UPDATE]: 'به‌روزرسانی ردیف‌ها ناموفق بود',
    [_constants.DATA_PROVIDER_ERRORS_REMOVE]: 'حذف ردیف‌ها ناموفق بود',
    [_constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED]: 'درخواست ناموفق بود',
    [_constants.DATA_PROVIDER_BUTTONS_REFETCH]: 'بارگذاری مجدد'
};
const _default = dictionary;
