/**
 * @preserve
 * Authors: Stefan Salzl
 * Last updated: Jan 08, 2018
 *
 * Description: Definition file for German - Switzerland language-country.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const dictionary = {
    languageCode: 'de-CH',
    [_constants.OK]: 'OK',
    [_constants.CANCEL]: 'Abbrechen',
    [_constants.CONTEXTMENU_ITEMS_ROW_ABOVE]: 'Zeile einfügen oberhalb',
    [_constants.CONTEXTMENU_ITEMS_ROW_BELOW]: 'Zeile einfügen unterhalb',
    [_constants.CONTEXTMENU_ITEMS_INSERT_LEFT]: 'Spalte einfügen links',
    [_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT]: 'Spalte einfügen rechts',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_ROW]: [
        'Zeile löschen',
        'Zeilen löschen'
    ],
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COLUMN]: [
        'Spalte löschen',
        'Spalten löschen'
    ],
    [_constants.CONTEXTMENU_ITEMS_UNDO]: 'Rückgangig',
    [_constants.CONTEXTMENU_ITEMS_REDO]: 'Wiederholen',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY]: 'Nur Lesezugriff',
    [_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN]: 'Spalteninhalt löschen',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT]: 'Ausrichtung',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT]: 'Linksbündig',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER]: 'Zentriert',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT]: 'Rechtsbündig',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY]: 'Blocksatz',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP]: 'Oben',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE]: 'Mitte',
    [_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM]: 'Unten',
    [_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN]: 'Spalte fixieren',
    [_constants.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN]: 'Spaltenfixierung aufheben',
    [_constants.CONTEXTMENU_ITEMS_BORDERS]: 'Rahmen',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_TOP]: 'Oben',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_RIGHT]: 'Rechts',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM]: 'Unten',
    [_constants.CONTEXTMENU_ITEMS_BORDERS_LEFT]: 'Links',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_BORDERS]: 'Kein Rahmen',
    [_constants.CONTEXTMENU_ITEMS_ADD_COMMENT]: 'Kommentar hinzufügen',
    [_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT]: 'Kommentar bearbeiten',
    [_constants.CONTEXTMENU_ITEMS_REMOVE_COMMENT]: 'Kommentar löschen',
    [_constants.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT]: 'Schreibschutz Kommentar',
    [_constants.CONTEXTMENU_ITEMS_MERGE_CELLS]: 'Zellen verbinden',
    [_constants.CONTEXTMENU_ITEMS_UNMERGE_CELLS]: 'Zellen teilen',
    [_constants.CONTEXTMENU_ITEMS_COPY]: 'Kopieren',
    [_constants.CONTEXTMENU_ITEMS_CUT]: 'Ausschneiden',
    [_constants.CONTEXTMENU_ITEMS_EXPORT]: 'Exportieren',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV]: 'Als CSV',
    [_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX]: 'Als Excel',
    [_constants.EXPORT_FILE_DIALOG_TITLE]: 'Wird exportiert…',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD]: 'Nachfolgerzeile einfügen',
    [_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD]: 'Von Vorgängerzeile abkoppeln',
    [_constants.CONTEXTMENU_ITEMS_HIDE_COLUMN]: [
        'Spalte ausblenden',
        'Spalten ausblenden'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_COLUMN]: [
        'Spalte einblenden',
        'Spalten einblenden'
    ],
    [_constants.CONTEXTMENU_ITEMS_HIDE_ROW]: [
        'Zeile ausblenden',
        'Zeilen ausblenden'
    ],
    [_constants.CONTEXTMENU_ITEMS_SHOW_ROW]: [
        'Zeile einblenden',
        'Zeilen einblenden'
    ],
    [_constants.FILTERS_CONDITIONS_NONE]: 'Kein Filter',
    [_constants.FILTERS_CONDITIONS_EMPTY]: 'Ist leer',
    [_constants.FILTERS_CONDITIONS_NOT_EMPTY]: 'Ist nicht leer',
    [_constants.FILTERS_CONDITIONS_EQUAL]: 'Ist gleich',
    [_constants.FILTERS_CONDITIONS_NOT_EQUAL]: 'Ist ungleich',
    [_constants.FILTERS_CONDITIONS_BEGINS_WITH]: 'Beginnt mit',
    [_constants.FILTERS_CONDITIONS_ENDS_WITH]: 'Endet mit',
    [_constants.FILTERS_CONDITIONS_CONTAINS]: 'Enthält',
    [_constants.FILTERS_CONDITIONS_NOT_CONTAIN]: 'Enthält nicht',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN]: 'Grösser als',
    [_constants.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL]: 'Grösser gleich',
    [_constants.FILTERS_CONDITIONS_LESS_THAN]: 'Kleiner als',
    [_constants.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL]: 'Kleiner gleich',
    [_constants.FILTERS_CONDITIONS_BETWEEN]: 'Zwischen',
    [_constants.FILTERS_CONDITIONS_NOT_BETWEEN]: 'Ausserhalb',
    [_constants.FILTERS_CONDITIONS_AFTER]: 'Nach',
    [_constants.FILTERS_CONDITIONS_AFTER_OR_EQUAL]: 'Nach oder gleich',
    [_constants.FILTERS_CONDITIONS_BEFORE]: 'Vor',
    [_constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL]: 'Vor oder gleich',
    [_constants.FILTERS_CONDITIONS_TODAY]: 'Heute',
    [_constants.FILTERS_CONDITIONS_TOMORROW]: 'Morgen',
    [_constants.FILTERS_CONDITIONS_YESTERDAY]: 'Gestern',
    [_constants.FILTERS_VALUES_BLANK_CELLS]: 'Leere Zellen',
    [_constants.FILTERS_DIVS_FILTER_BY_CONDITION]: 'Per Bedingung filtern',
    [_constants.FILTERS_DIVS_FILTER_BY_VALUE]: 'Nach Zahlen filtern',
    [_constants.FILTERS_LABELS_CONJUNCTION]: 'Und',
    [_constants.FILTERS_LABELS_DISJUNCTION]: 'Oder',
    [_constants.FILTERS_BUTTONS_SELECT_ALL]: 'Alles auswählen',
    [_constants.FILTERS_BUTTONS_CLEAR]: 'Auswahl aufheben',
    [_constants.FILTERS_BUTTONS_OK]: 'OK',
    [_constants.FILTERS_BUTTONS_CANCEL]: 'Abbrechen',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SEARCH]: 'Suchen',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_VALUE]: 'Wert',
    [_constants.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE]: 'Alternativwert',
    [_constants.PAGINATION_SECTION]: 'Seitennavigation',
    [_constants.PAGINATION_PAGE_SIZE_SECTION]: 'Anzahl Zeilen',
    [_constants.PAGINATION_PAGE_SIZE_AUTO]: 'Auto',
    [_constants.PAGINATION_COUNTER_SECTION]: '[start] - [end] von [total]',
    [_constants.PAGINATION_NAV_SECTION]: 'Seite [currentPage] von [totalPages]',
    [_constants.PAGINATION_FIRST_PAGE]: 'Zur ersten Seite wechseln',
    [_constants.PAGINATION_PREV_PAGE]: 'Zur vorherigen Seite wechseln',
    [_constants.PAGINATION_NEXT_PAGE]: 'Zur nächsten Seite wechseln',
    [_constants.PAGINATION_LAST_PAGE]: 'Zur letzten Seite wechseln',
    [_constants.LOADING_TITLE]: 'Lädt...',
    [_constants.NOTIFICATION_BUTTONS_CLOSE]: 'Schließen',
    [_constants.EMPTY_DATA_STATE_TITLE]: 'Keine Daten verfügbar',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION]: 'Es gibt noch nichts anzuzeigen.',
    [_constants.EMPTY_DATA_STATE_TITLE_FILTERS]: 'Keine Ergebnisse gefunden',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS]: 'Es scheint, als würden Ihre aktuellen Filter alle Ergebnisse ausblenden.',
    [_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET]: 'Filter zurücksetzen',
    [_constants.EMPTY_DATA_STATE_TITLE_LOADING]: 'Daten werden geladen',
    [_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING]: 'Bitte warten.',
    [_constants.DATA_PROVIDER_ERRORS_FETCH]: 'Daten konnten nicht geladen werden',
    [_constants.DATA_PROVIDER_ERRORS_CREATE]: 'Zeilen konnten nicht erstellt werden',
    [_constants.DATA_PROVIDER_ERRORS_UPDATE]: 'Zeilen konnten nicht aktualisiert werden',
    [_constants.DATA_PROVIDER_ERRORS_REMOVE]: 'Zeilen konnten nicht entfernt werden',
    [_constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED]: 'Anfrage fehlgeschlagen',
    [_constants.DATA_PROVIDER_BUTTONS_REFETCH]: 'Neu laden'
};
const _default = dictionary;
