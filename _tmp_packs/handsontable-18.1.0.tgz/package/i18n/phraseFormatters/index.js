"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get getAll () {
        return getAll;
    },
    get getPhraseFormatters () {
        return getAll;
    },
    get register () {
        return register;
    },
    get registerPhraseFormatter () {
        return register;
    }
});
const _staticRegister = require("./../../utils/staticRegister");
const _pluralize = /*#__PURE__*/ _interop_require_default(require("./pluralize"));
const _substituteVariables = /*#__PURE__*/ _interop_require_default(require("./substituteVariables"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const { register: registerGloballyPhraseFormatter, getValues: getGlobalPhraseFormatters } = (0, _staticRegister.staticRegister)('phraseFormatters');
function register(name, formatterFn) {
    registerGloballyPhraseFormatter(name, formatterFn);
}
function getAll() {
    return getGlobalPhraseFormatters();
}
register('pluralize', _pluralize.default);
register('substitute', _substituteVariables.default);
