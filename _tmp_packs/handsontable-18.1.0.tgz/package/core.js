"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, /**
 * Handsontable constructor.
 *
 * @core
 * @class Core
 * @description
 *
 * The `Handsontable` class (known as the `Core`) lets you modify the grid's behavior by using Handsontable's public API methods.
 *
 * ::: only-for react
 * To use these methods, associate a Handsontable instance with your instance
 * of the [`HotTable` component](@/guides/getting-started/installation/installation.md#_4-use-the-hottable-component),
 * by using React's `ref` feature (read more on the [Instance methods](@/guides/getting-started/react-methods/react-methods.md) page).
 * :::
 *
 * ::: only-for angular
 * To use these methods, associate a Handsontable instance with your instance
 * of the [`HotTable` component](@/guides/getting-started/installation/installation.md#5-use-the-hottable-component),
 * by using `@ViewChild` decorator (read more on the [Instance access](@/guides/getting-started/angular-hot-instance/angular-hot-instance.md) page).
 * :::
 *
 * ## How to call a method
 *
 * ::: only-for javascript
 * ```js
 * // create a Handsontable instance
 * const hot = new Handsontable(document.getElementById('example'), options);
 *
 * // call a method
 * hot.setDataAtCell(0, 0, 'new value');
 * ```
 * :::
 *
 * ::: only-for react
 * ```jsx
 * import { useRef } from 'react';
 *
 * const hotTableComponent = useRef(null);
 *
 * <HotTable
 *   // associate your `HotTable` component with a Handsontable instance
 *   ref={hotTableComponent}
 *   settings={options}
 * />
 *
 * // access the Handsontable instance, under the `.current.hotInstance` property
 * // call a method
 * hotTableComponent.current.hotInstance.setDataAtCell(0, 0, 'new value');
 * ```
 * :::
 *
 * ::: only-for angular
 * ```ts
 * import { Component, ViewChild, AfterViewInit } from "@angular/core";
 * import {
 *   GridSettings,
 *   HotTableComponent,
 *   HotTableModule,
 * } from "@handsontable/angular-wrapper";
 *
 * `@Component`({
 *   standalone: true,
 *   imports: [HotTableModule],
 *   template: ` <div>
 *     <hot-table [settings]="gridSettings" />
 *   </div>`,
 * })
 * export class ExampleComponent implements AfterViewInit {
 *   `@ViewChild`(HotTableComponent, { static: false })
 *   readonly hotTable!: HotTableComponent;
 *
 *   readonly gridSettings = <GridSettings>{
 *     columns: [{}],
 *   };
 *
 *   ngAfterViewInit(): void {
 *     // Access the Handsontable instance
 *     // Call a method
 *     this.hotTable?.hotInstance?.setDataAtCell(0, 0, "new value");
 *   }
 * }
 * ```
 * :::
 *
 * @param {HTMLElement} rootContainer The element to which the Handsontable instance is injected.
 * @param {object} userSettings The user defined options.
 * @param {boolean} [rootInstanceSymbol=false] Indicates if the instance is root of all later instances created.
 */ "default", {
    enumerable: true,
    get: function() {
        return Core;
    }
});
const _element = require("./helpers/dom/element");
const _function = require("./helpers/function");
const _mixed = require("./helpers/mixed");
const _browser = require("./helpers/browser");
const _editorManager = /*#__PURE__*/ _interop_require_default(require("./editorManager"));
const _eventManager = /*#__PURE__*/ _interop_require_default(require("./eventManager"));
const _object = require("./helpers/object");
const _array = require("./helpers/array");
const _parseTable = require("./utils/parseTable");
const _staticRegister = require("./utils/staticRegister");
const _registry = require("./plugins/registry");
const _registry1 = require("./renderers/registry");
const _registry2 = require("./editors/registry");
const _registry3 = require("./validators/registry");
const _string = require("./helpers/string");
const _number = require("./helpers/number");
const _tableView = /*#__PURE__*/ _interop_require_default(require("./tableView"));
const _data = require("./helpers/data");
const _translations = require("./translations");
const _rootInstance = require("./utils/rootInstance");
const _src = require("./3rdparty/walkontable/src");
const _registry4 = require("./i18n/registry");
const _utils = require("./i18n/utils");
const _selection = require("./selection");
const _dataMap = require("./dataMap");
const _index = require("./core/index");
const _focusManager = require("./focusManager");
const _uniqueMap = require("./utils/dataStructures/uniqueMap");
const _shortcuts = require("./shortcuts");
const _contexts = require("./shortcuts/contexts");
const _themes = require("./helpers/themes");
const _stylesHandler = require("./utils/stylesHandler");
const _console = require("./helpers/console");
const _errors = require("./helpers/errors");
const _a11yAnnouncer = require("./utils/a11yAnnouncer");
const _licenseNotification = require("./utils/licenseNotification");
const _licenseBranding = require("./utils/licenseBranding");
const _valueAccessors = require("./utils/valueAccessors");
const _engine = require("./themes/engine");
const _layout = require("./core/layout");
const _themes1 = require("./themes");
const _dataMap1 = /*#__PURE__*/ _interop_require_default(require("./dataMap/dataMap"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
let activeGuid = null;
/**
 * Normalizes an array of `[index, amount]` pairs by merging overlapping or adjacent groups
 * into the smallest set of non-overlapping groups, sorted in ascending order.
 *
 * @param {number[][]} indexes Array of `[index, amount]` pairs to normalize.
 * @returns {number[][]} Normalized array of `[index, amount]` pairs.
 */ function normalizeIndexesGroup(indexes) {
    if (indexes.length === 0) {
        return [];
    }
    const sortedIndexes = [
        ...indexes
    ];
    // Sort the indexes in ascending order.
    sortedIndexes.sort(([indexA], [indexB])=>{
        if (indexA === indexB) {
            return 0;
        }
        return indexA > indexB ? 1 : -1;
    });
    // Normalize the {index, amount} groups into bigger groups.
    const normalizedIndexes = (0, _array.arrayReduce)(sortedIndexes, (acc, [groupIndex, groupAmount])=>{
        const previousItem = acc[acc.length - 1];
        const [prevIndex, prevAmount] = previousItem;
        const prevLastIndex = prevIndex + prevAmount;
        if (groupIndex <= prevLastIndex) {
            const amountToAdd = Math.max(groupAmount - (prevLastIndex - groupIndex), 0);
            previousItem[1] += amountToAdd;
        } else {
            acc.push([
                groupIndex,
                groupAmount
            ]);
        }
        return acc;
    }, [
        sortedIndexes[0]
    ]);
    return normalizedIndexes;
}
/**
 * Keeps the collection of the all Handsontable instances created on the same page. The
 * list is then used to trigger the "afterUnlisten" hook when the "listen()" method was
 * called on another instance.
 *
 * @type {Map<string, Core>}
 */ const foreignHotInstances = new Map();
/**
 * Configuration options removed from the public API, with the version that removed them.
 * Configuring one prints a one-time warning; the value is ignored.
 *
 * `persistentState` says 17.0.0, not 18.0.0: #12015 removed the plugin, its option, and its hooks
 * in 17.0.0, and no published 17.x or 18.x package carries them. The 18.0.0 changelog entry for
 * #12727 describes deleting a copy that the TypeScript conversion re-created on `develop` after
 * 17.1.0 and that never shipped.
 *
 * `datePickerConfig` is deliberately absent: `DateEditor#prepare` already warns about it, and it
 * also sees the per-cell forms that `warnAboutRemovedOptions` cannot.
 *
 * @type {ReadonlyArray<RemovedOption>}
 */ const REMOVED_OPTIONS = [
    {
        name: 'persistentState',
        version: '17.0.0',
        migrationUrl: 'https://handsontable.com/docs/javascript-data-grid/changelog-17/'
    },
    {
        name: 'correctFormat',
        version: '18.0.0',
        migrationUrl: 'https://handsontable.com/docs/javascript-data-grid/migration-from-17.1-to-18.0/'
    }
];
/**
 * Warns once per removed option found anywhere in the passed settings.
 *
 * Scans the top level, every entry of an array-form `columns`, and every entry of the declarative
 * `cell` array, because the removed options are not all global: `correctFormat` is a cell option,
 * so `columns: [{ correctFormat: true }]` and `cell: [{ row, col, correctFormat: true }]` are its
 * common forms, and a top-level-only check would leave those callers with a clean console and
 * silently dropped date auto-correction.
 *
 * The remaining per-cell forms - a `cells` function, or meta set through `setCellMeta` - stay
 * uncovered. Reaching them means inspecting resolved meta for every cell on every render, which
 * costs more than the warning is worth.
 *
 * @param {object} settings Settings object passed to `updateSettings`.
 */ function warnAboutRemovedOptions(settings) {
    const columns = Array.isArray(settings.columns) ? settings.columns : [];
    const cells = Array.isArray(settings.cell) ? settings.cell : [];
    const scopes = [
        settings,
        ...columns,
        ...cells
    ];
    REMOVED_OPTIONS.forEach(({ name, version, migrationUrl })=>{
        const isUsed = scopes.some((scope)=>(0, _object.isObject)(scope) && (0, _mixed.isDefined)(scope[name]));
        if (isUsed) {
            (0, _console.removedWarnOnce)(`Core.removedOption.${name}`, `The "${name}" setting was removed in Handsontable ${version} and is ignored. ` + `See ${migrationUrl} for the migration path.`);
        }
    });
}
function Core(rootContainer, userSettings, rootInstanceSymbol = false) {
    let instance = this;
    const eventManager = new _eventManager.default(instance);
    let datamap;
    let dataSource;
    let grid;
    let editorManager;
    let focusGridManager;
    let viewportScroller;
    let firstRun = true;
    // Guards the "colorScheme/density need the theme engine" warning so it is logged once per
    // instance instead of on every `updateSettings()` call that carries the options.
    let themeOverridesWarningShown = false;
    // Set only when the table is initialized while invisible (see the `init` method). Kept in the closure, not on
    // the instance, because `destroy` nulls every instance property before it could be read there.
    let visibilityObserver = null;
    const mergedUserSettings = {
        ...userSettings.initialState,
        ...userSettings
    };
    if ((0, _rootInstance.hasValidParameter)(rootInstanceSymbol)) {
        (0, _rootInstance.registerAsRootInstance)(this);
    }
    /**
   * Reference to the root container.
   *
   * @private
   * @type {HTMLElement}
   */ this.rootContainer = rootContainer;
    /**
   * Reference to the wrapper element.
   *
   * @private
   * @type {HTMLElement}
   */ this.rootWrapperElement = null;
    /**
   * Reference to the grid element.
   *
   * @private
   * @type {HTMLElement}
   */ this.rootGridElement = null;
    /**
   * Reference to the grid content element. Wraps the grid (table) together with the grid focus-scope
   * tab-catchers, so siblings of this element inside `ht-grid` (e.g. the empty-data-state) stay
   * outside the grid focus scope.
   *
   * @private
   * @type {HTMLElement}
   */ this.rootGridContentElement = null;
    /**
   * Reference to the top slot element. A wrapper slot rendered above the grid for plugin UI
   * (for example toolbars). Ordered through the layout manager.
   *
   * @private
   * @type {HTMLElement}
   */ this.rootSlotTopElement = null;
    /**
   * Reference to the bottom slot element (pagination, license notification).
   *
   * @private
   * @type {HTMLElement}
   */ this.rootSlotBottomElement = null;
    /**
   * Reference to the overlays element (dialog). Note: the empty-data-state lives inside the grid
   * element (`ht-grid`), not here.
   *
   * @private
   * @type {HTMLElement}
   */ this.rootOverlaysElement = null;
    /**
   * Reference to the portal element.
   *
   * @private
   * @type {HTMLElement}
   */ this.rootPortalElement = null;
    // TODO: check if references to DOM elements should be move to UI layer (Walkontable)
    /**
   * Reference to the container element.
   *
   * @private
   * @type {HTMLElement}
   */ this.rootElement = (0, _rootInstance.isRootInstance)(this) ? rootContainer.ownerDocument.createElement('div') : rootContainer;
    /**
   * The nearest document over container.
   *
   * @private
   * @type {Document}
   */ this.rootDocument = rootContainer.ownerDocument;
    /**
   * Window object over container's document.
   *
   * @private
   * @type {Window}
   */ this.rootWindow = this.rootDocument.defaultView;
    if ((0, _rootInstance.isRootInstance)(this)) {
        this.rootWrapperElement = this.rootDocument.createElement('div');
        this.rootSlotTopElement = this.rootDocument.createElement('div');
        this.rootGridElement = this.rootDocument.createElement('div');
        this.rootGridContentElement = this.rootDocument.createElement('div');
        this.rootOverlaysElement = this.rootDocument.createElement('div');
        this.rootSlotBottomElement = this.rootDocument.createElement('div');
        this.rootPortalElement = this.rootDocument.createElement('div');
        (0, _element.addClass)(this.rootElement, [
            'ht-wrapper',
            'handsontable'
        ]);
        (0, _element.addClass)(this.rootWrapperElement, 'ht-root-wrapper');
        if ((0, _element.isShadowRoot)(this.rootContainer.getRootNode())) {
            (0, _element.addClass)(this.rootWrapperElement, 'ht-shadow-dom');
        }
        (0, _element.addClass)(this.rootSlotTopElement, 'ht-slot-top');
        (0, _element.addClass)(this.rootGridElement, 'ht-grid');
        (0, _element.addClass)(this.rootGridContentElement, 'ht-grid-content');
        (0, _element.addClass)(this.rootOverlaysElement, 'ht-overlay');
        (0, _element.addClass)(this.rootSlotBottomElement, 'ht-slot-bottom');
        this.rootGridContentElement.appendChild(this.rootElement);
        this.rootGridElement.appendChild(this.rootGridContentElement);
        this.rootWrapperElement.appendChild(this.rootSlotTopElement);
        this.rootWrapperElement.appendChild(this.rootGridElement);
        this.rootWrapperElement.appendChild(this.rootSlotBottomElement);
        this.rootWrapperElement.appendChild(this.rootOverlaysElement);
        this.rootContainer.appendChild(this.rootWrapperElement);
        this.rootWrapperElement.__hotInstance = this;
        (0, _element.addClass)(this.rootPortalElement, 'ht-portal');
        this.rootDocument.body.appendChild(this.rootPortalElement);
    }
    /**
   * A boolean to tell if the Handsontable has been fully destroyed. This is set to `true`
   * after `afterDestroy` hook is called.
   *
   * @memberof Core#
   * @member isDestroyed
   * @type {boolean}
   */ this.isDestroyed = false;
    /**
   * The counter determines how many times the render suspending was called. It allows
   * tracking the nested suspending calls. For each render suspend resuming call the
   * counter is decremented. The value equal to 0 means the render suspending feature
   * is disabled.
   *
   * @private
   * @type {number}
   */ this.renderSuspendedCounter = 0;
    /**
   * The counter determines how many times the execution suspending was called. It allows
   * tracking the nested suspending calls. For each execution suspend resuming call the
   * counter is decremented. The value equal to 0 means the execution suspending feature
   * is disabled.
   *
   * @private
   * @type {number}
   */ this.executionSuspendedCounter = 0;
    const layoutDirection = mergedUserSettings?.layoutDirection ?? 'inherit';
    const rootElementDirection = [
        'rtl',
        'ltr'
    ].includes(layoutDirection) ? layoutDirection : this.rootWindow.getComputedStyle(this.rootElement).direction;
    this.rootElement.setAttribute('dir', rootElementDirection);
    this.rootWrapperElement?.setAttribute('dir', rootElementDirection);
    /**
   * Checks if the grid is rendered using the right-to-left layout direction.
   *
   * @since 12.0.0
   * @memberof Core#
   * @function isRtl
   * @returns {boolean} True if RTL.
   */ this.isRtl = function() {
        return rootElementDirection === 'rtl';
    };
    /**
   * Checks if the grid is rendered using the left-to-right layout direction.
   *
   * @since 12.0.0
   * @memberof Core#
   * @function isLtr
   * @returns {boolean} True if LTR.
   */ this.isLtr = function() {
        return !instance.isRtl();
    };
    /**
   * Returns 1 for LTR; -1 for RTL. Useful for calculations.
   *
   * @since 12.0.0
   * @memberof Core#
   * @function getDirectionFactor
   * @returns {number} Returns 1 for LTR; -1 for RTL.
   */ this.getDirectionFactor = function() {
        return instance.isLtr() ? 1 : -1;
    };
    /**
   * Styles handler instance.
   *
   * @private
   * @type {StylesHandler}
   */ this.stylesHandler = new _stylesHandler.StylesHandler({
        hot: instance,
        rootElement: instance.rootElement,
        rootDocument: instance.rootDocument,
        onThemeChange: (themeName)=>{
            if ((0, _rootInstance.isRootInstance)(this)) {
                (0, _element.removeClass)(this.rootWrapperElement, /ht-theme-.*/g);
                (0, _element.removeClass)(this.rootPortalElement, /ht-theme-.*/g);
                if (themeName) {
                    (0, _element.addClass)(this.rootWrapperElement, themeName);
                    (0, _element.addClass)(this.rootPortalElement, themeName);
                    if (!getComputedStyle(this.rootWrapperElement).getPropertyValue('--ht-line-height')) {
                        (0, _console.warn)(`The "${themeName}" theme is enabled, but its stylesheets are missing` + ' or not imported correctly. Import the correct CSS files in order to use that theme.');
                    }
                }
                this.view?._wt?.selectionManager?.refreshAllBorderHandleStyles();
            }
        },
        injectCoreCss: typeof userSettings?.injectCoreCss === 'boolean' ? userSettings.injectCoreCss : true
    });
    /**
   * ThemeManager instance.
   *
   * @private
   * @type {ThemeManager|null}
   */ this.themeManager = null;
    mergedUserSettings.language = (0, _registry4.getValidLanguageCode)(mergedUserSettings.language);
    const settingsWithoutHooks = Object.fromEntries(Object.entries(mergedUserSettings).filter(([key])=>{
        return !(_index.Hooks.getSingleton().isRegistered(key) || _index.Hooks.getSingleton().isDeprecated(key));
    }));
    const metaManager = new _dataMap.MetaManager(instance, settingsWithoutHooks, [
        _dataMap.DynamicCellMetaMod,
        _dataMap.ExtendMetaPropertiesMod
    ]);
    const tableMeta = metaManager.getTableMeta();
    const globalMeta = metaManager.getGlobalMeta();
    const pluginsRegistry = (0, _uniqueMap.createUniqueMap)();
    this.container = this.rootDocument.createElement('div');
    this.rootElement.insertBefore(this.container, this.rootElement.firstChild);
    this.guid = `ht_${(0, _string.randomString)()}`; // this is the namespace for global events
    foreignHotInstances.set(this.guid, this);
    /**
   * Instance of index mapper which is responsible for managing the column indexes.
   *
   * @memberof Core#
   * @member columnIndexMapper
   * @type {IndexMapper}
   */ this.columnIndexMapper = new _translations.IndexMapper();
    /**
   * Instance of index mapper which is responsible for managing the row indexes.
   *
   * @memberof Core#
   * @member rowIndexMapper
   * @type {IndexMapper}
   */ this.rowIndexMapper = new _translations.IndexMapper();
    this.columnIndexMapper.addLocalHook('indexesSequenceChange', (source)=>{
        instance.runHooks('afterColumnSequenceChange', source);
    });
    this.rowIndexMapper.addLocalHook('indexesSequenceChange', (source)=>{
        instance.runHooks('afterRowSequenceChange', source);
    });
    eventManager.addEventListener(this.rootDocument.documentElement, 'compositionstart', (event)=>{
        instance.runHooks('beforeCompositionStart', event);
    });
    dataSource = new _dataMap.DataSource(instance);
    const moduleRegisterer = (0, _staticRegister.staticRegister)(this.guid);
    moduleRegisterer.register('cellRangeMapper', new _index.CellRangeToRenderableMapper({
        rowIndexMapper: this.rowIndexMapper,
        columnIndexMapper: this.columnIndexMapper
    }));
    if (!this.rootElement.id || this.rootElement.id.substring(0, 3) === 'ht_') {
        this.rootElement.id = this.guid; // if root element does not have an id, assign a random id
    }
    const visualToRenderableCoords = (coords)=>{
        const { row: visualRow, col: visualColumn } = coords;
        return instance._createCellCoords(// We just store indexes for rows and columns without headers.
        visualRow >= 0 ? instance.rowIndexMapper.getRenderableFromVisualIndex(visualRow) : visualRow, visualColumn >= 0 ? instance.columnIndexMapper.getRenderableFromVisualIndex(visualColumn) : visualColumn);
    };
    const renderableToVisualCoords = (coords)=>{
        const { row: renderableRow, col: renderableColumn } = coords;
        return instance._createCellCoords(// We just store indexes for rows and columns without headers.
        renderableRow >= 0 ? instance.rowIndexMapper.getVisualFromRenderableIndex(renderableRow) : renderableRow, renderableColumn >= 0 ? instance.columnIndexMapper.getVisualFromRenderableIndex(renderableColumn) : renderableColumn // eslint-disable-line max-len
        );
    };
    const findFirstNonHiddenRenderableRow = (visualRowFrom, visualRowTo)=>{
        const dir = visualRowTo > visualRowFrom ? 1 : -1;
        const minIndex = Math.min(visualRowFrom, visualRowTo);
        const maxIndex = Math.max(visualRowFrom, visualRowTo);
        const rowIndex = instance.rowIndexMapper.getNearestNotHiddenIndex(visualRowFrom, dir);
        if (rowIndex === null || dir === 1 && rowIndex > maxIndex || dir === -1 && rowIndex < minIndex) {
            return null;
        }
        return rowIndex >= 0 ? instance.rowIndexMapper.getRenderableFromVisualIndex(rowIndex) : rowIndex;
    };
    const findFirstNonHiddenRenderableColumn = (visualColumnFrom, visualColumnTo)=>{
        const dir = visualColumnTo > visualColumnFrom ? 1 : -1;
        const minIndex = Math.min(visualColumnFrom, visualColumnTo);
        const maxIndex = Math.max(visualColumnFrom, visualColumnTo);
        const columnIndex = instance.columnIndexMapper.getNearestNotHiddenIndex(visualColumnFrom, dir);
        if (columnIndex === null || dir === 1 && columnIndex > maxIndex || dir === -1 && columnIndex < minIndex) {
            return null;
        }
        return columnIndex >= 0 ? instance.columnIndexMapper.getRenderableFromVisualIndex(columnIndex) : columnIndex;
    };
    let selection = new _selection.Selection(tableMeta, {
        rowIndexMapper: instance.rowIndexMapper,
        columnIndexMapper: instance.columnIndexMapper,
        countCols: ()=>instance.countCols(),
        countRows: ()=>instance.countRows(),
        propToCol: (prop)=>datamap.propToCol(prop),
        isEditorOpened: ()=>{
            const editor = instance.getActiveEditor();
            return editor ? editor.isOpened() : false;
        },
        isPluginEnabled: (pluginName)=>instance.getPlugin(pluginName)?.enabled === true,
        countRenderableColumns: ()=>instance.view.countRenderableColumns(),
        countRenderableRows: ()=>instance.view.countRenderableRows(),
        countRowHeaders: ()=>instance.countRowHeaders(),
        countColHeaders: ()=>instance.countColHeaders(),
        countRenderableRowsInRange: (rowStart, rowEnd)=>instance.view.countRenderableRowsInRange(rowStart, rowEnd),
        countRenderableColumnsInRange: (columnStart, columnEnd)=>instance.view.countRenderableColumnsInRange(columnStart, columnEnd),
        getShortcutManager: ()=>instance.getShortcutManager(),
        createCellCoords: (row, column)=>instance._createCellCoords(row, column),
        createCellRange: (highlight, from, to)=>instance._createCellRange(highlight, from, to),
        visualToRenderableCoords,
        renderableToVisualCoords,
        findFirstNonHiddenRenderableRow,
        findFirstNonHiddenRenderableColumn,
        isDisabledCellSelection: (visualRow, visualColumn)=>{
            if (visualRow < 0 || visualColumn < 0) {
                return instance.getSettings().disableVisualSelection;
            }
            return instance.getCellMeta(visualRow, visualColumn).disableVisualSelection;
        }
    });
    this.selection = selection;
    const onIndexMapperCacheUpdate = ({ hiddenIndexesChanged })=>{
        this.forceFullRender = true;
        if (hiddenIndexesChanged) {
            this.selection.commit();
        }
    };
    this.columnIndexMapper.addLocalHook('cacheUpdated', (indexesChangesState)=>{
        onIndexMapperCacheUpdate(indexesChangesState);
        this.runHooks('afterColumnSequenceCacheUpdate', indexesChangesState);
    });
    this.rowIndexMapper.addLocalHook('cacheUpdated', (indexesChangesState)=>{
        onIndexMapperCacheUpdate(indexesChangesState);
        this.runHooks('afterRowSequenceCacheUpdate', indexesChangesState);
    });
    this.selection.addLocalHook('afterSetRangeEnd', (cellCoords, isLastSelectionLayer)=>{
        const preventScrolling = (0, _object.createObjectPropListener)(false);
        const selectionRange = this.selection.getSelectedRange();
        const { from, to } = selectionRange.current();
        const selectionLayerLevel = selectionRange.size() - 1;
        this.runHooks('afterSelection', from.row, from.col, to.row, to.col, preventScrolling, selectionLayerLevel);
        this.runHooks('afterSelectionByProp', from.row, instance.colToProp(from.col), to.row, instance.colToProp(to.col), preventScrolling, selectionLayerLevel);
        const selectionSource = selection.getSelectionSource();
        const ignoreScrollSources = [
            'loadData',
            'updateData',
            'deselect',
            'shift'
        ];
        if (isLastSelectionLayer && !ignoreScrollSources.includes(selectionSource) && (!preventScrolling.isTouched() || preventScrolling.isTouched() && !preventScrolling.value)) {
            viewportScroller.scrollTo(cellCoords);
        }
        const isSelectedByRowHeader = selection.isSelectedByRowHeader();
        const isSelectedByColumnHeader = selection.isSelectedByColumnHeader();
        // @TODO: These CSS classes are no longer needed anymore. They are used only as a indicator of the selected
        // rows/columns in the MergedCells plugin (via border.js#L520 in the walkontable module). After fixing
        // the Border class this should be removed.
        if (isSelectedByRowHeader && isSelectedByColumnHeader) {
            (0, _element.addClass)(this.rootElement, [
                'ht__selection--rows',
                'ht__selection--columns'
            ]);
        } else if (isSelectedByRowHeader) {
            (0, _element.removeClass)(this.rootElement, 'ht__selection--columns');
            (0, _element.addClass)(this.rootElement, 'ht__selection--rows');
        } else if (isSelectedByColumnHeader) {
            (0, _element.removeClass)(this.rootElement, 'ht__selection--rows');
            (0, _element.addClass)(this.rootElement, 'ht__selection--columns');
        } else {
            (0, _element.removeClass)(this.rootElement, [
                'ht__selection--rows',
                'ht__selection--columns'
            ]);
        }
        if (![
            'shift',
            'refresh',
            'loadData',
            'updateData',
            'deselect'
        ].includes(selectionSource)) {
            editorManager.closeEditor();
        }
        if (![
            'refresh',
            'loadData',
            'updateData',
            'deselect'
        ].includes(selectionSource)) {
            instance.view.render();
            editorManager.prepareEditor();
        }
    });
    this.selection.addLocalHook('beforeSetFocus', (cellCoords)=>{
        this.runHooks('beforeSelectionFocusSet', cellCoords.row, cellCoords.col);
    });
    this.selection.addLocalHook('afterSetFocus', (cellCoords)=>{
        const preventScrolling = (0, _object.createObjectPropListener)(false);
        this.runHooks('afterSelectionFocusSet', cellCoords.row, cellCoords.col, preventScrolling);
        if (!preventScrolling.isTouched() || preventScrolling.isTouched() && !preventScrolling.value) {
            viewportScroller.scrollTo(cellCoords);
        }
        editorManager.closeEditor();
        instance.view.render();
        editorManager.prepareEditor();
    });
    this.selection.addLocalHook('afterSelectionFinished', (cellRanges)=>{
        const selectionLayerLevel = cellRanges.length - 1;
        const { from, to } = cellRanges[selectionLayerLevel];
        this.runHooks('afterSelectionEnd', from.row, from.col, to.row, to.col, selectionLayerLevel);
        this.runHooks('afterSelectionEndByProp', from.row, instance.colToProp(from.col), to.row, instance.colToProp(to.col), selectionLayerLevel);
        if ([
            'refresh',
            'deselect'
        ].includes(selection.getSelectionSource())) {
            instance.view.render();
            editorManager.prepareEditor();
        }
    });
    this.selection.addLocalHook('afterIsMultipleSelection', (isMultiple)=>{
        const changedIsMultiple = this.runHooks('afterIsMultipleSelection', isMultiple.value);
        if (isMultiple.value) {
            isMultiple.value = changedIsMultiple;
        }
    });
    this.selection.addLocalHook('afterDeselect', ()=>{
        editorManager.closeEditor();
        instance.view.render();
        (0, _element.removeClass)(this.rootElement, [
            'ht__selection--rows',
            'ht__selection--columns'
        ]);
        this.runHooks('afterDeselect');
    });
    this.selection.addLocalHook('beforeHighlightSet', ()=>instance.runHooks('beforeSelectionHighlightSet')).addLocalHook('beforeSetRangeStart', (...args)=>instance.runHooks('beforeSetRangeStart', ...args)).addLocalHook('beforeSetRangeStartOnly', (...args)=>instance.runHooks('beforeSetRangeStartOnly', ...args)).addLocalHook('beforeSetRangeEnd', (...args)=>instance.runHooks('beforeSetRangeEnd', ...args)).addLocalHook('beforeSelectColumns', (...args)=>instance.runHooks('beforeSelectColumns', ...args)).addLocalHook('afterSelectColumns', (...args)=>instance.runHooks('afterSelectColumns', ...args)).addLocalHook('beforeSelectRows', (...args)=>instance.runHooks('beforeSelectRows', ...args)).addLocalHook('afterSelectRows', (...args)=>instance.runHooks('afterSelectRows', ...args)).addLocalHook('beforeSelectAll', (...args)=>instance.runHooks('beforeSelectAll', ...args)).addLocalHook('afterSelectAll', (...args)=>instance.runHooks('afterSelectAll', ...args)).addLocalHook('beforeModifyTransformStart', (...args)=>instance.runHooks('modifyTransformStart', ...args)).addLocalHook('afterModifyTransformStart', (...args)=>instance.runHooks('afterModifyTransformStart', ...args)).addLocalHook('beforeModifyTransformFocus', (...args)=>instance.runHooks('modifyTransformFocus', ...args)).addLocalHook('afterModifyTransformFocus', (...args)=>instance.runHooks('afterModifyTransformFocus', ...args)).addLocalHook('beforeModifyTransformEnd', (...args)=>instance.runHooks('modifyTransformEnd', ...args)).addLocalHook('afterModifyTransformEnd', (...args)=>instance.runHooks('afterModifyTransformEnd', ...args)).addLocalHook('beforeRowWrap', (...args)=>instance.runHooks('beforeRowWrap', ...args)).addLocalHook('beforeColumnWrap', (...args)=>instance.runHooks('beforeColumnWrap', ...args)).addLocalHook('insertRowRequire', (totalRows)=>instance.alter('insert_row_above', totalRows, 1, 'auto')).addLocalHook('insertColRequire', (totalCols)=>instance.alter('insert_col_start', totalCols, 1, 'auto'));
    grid = {
        /**
     * Inserts or removes rows and columns.
     *
     * @private
     * @param {string} action Possible values: "insert_row_above", "insert_row_below", "insert_col_start", "insert_col_end",
     *                        "remove_row", "remove_col".
     * @param {number|Array} index Row or column visual index which from the alter action will be triggered.
     *                             Alter actions such as "remove_row" and "remove_col" support array indexes in the
     *                             format `[[index, amount], [index, amount]...]` this can be used to remove
     *                             non-consecutive columns or rows in one call.
     * @param {number} [amount=1] Amount of rows or columns to remove.
     * @param {string} [source] Optional. Source indicator passed to related hooks.
     * @param {boolean} [keepEmptyRows] Optional. Flag for skipping the post-alter empty row and column adjustment.
     */ alter (action, index, amount = 1, source, keepEmptyRows) {
            const skipAlter = instance.runHooks('beforeAlter', action, index, amount, source, keepEmptyRows);
            if (skipAlter === false) {
                return;
            }
            /* eslint-disable no-case-declarations */ switch(action){
                case 'insert_row_below':
                case 'insert_row_above':
                    const numberOfSourceRows = instance.countSourceRows();
                    if (tableMeta.maxRows === numberOfSourceRows) {
                        return;
                    }
                    // `above` is the default behavior for creating new rows
                    const insertRowMode = action === 'insert_row_below' ? 'below' : 'above';
                    // Calling the `insert_row_above` action adds a new row at the beginning of the data set.
                    const defaultRowIndex = insertRowMode === 'below' ? numberOfSourceRows : 0;
                    const rowIndex = typeof index === 'number' ? index : defaultRowIndex;
                    const { delta: rowDelta, startPhysicalIndex: startRowPhysicalIndex } = datamap.createRow(rowIndex, amount, {
                        source,
                        mode: insertRowMode
                    });
                    selection.shiftRows(instance.toVisualRow(startRowPhysicalIndex), rowDelta);
                    break;
                case 'insert_col_start':
                case 'insert_col_end':
                    // "start" is a default behavior for creating new columns
                    const insertColumnMode = action === 'insert_col_end' ? 'end' : 'start';
                    // Calling the `insert_col_start` action adds a new column to the left of the data set.
                    const defaultColIndex = insertColumnMode === 'end' ? instance.countSourceCols() : 0;
                    const colIndex = typeof index === 'number' ? index : defaultColIndex;
                    const { delta: colDelta, startPhysicalIndex: startColumnPhysicalIndex } = datamap.createCol(colIndex, amount, {
                        source,
                        mode: insertColumnMode
                    });
                    if (colDelta) {
                        if (Array.isArray(tableMeta.colHeaders)) {
                            const spliceArray = [
                                instance.toVisualColumn(startColumnPhysicalIndex),
                                0
                            ];
                            spliceArray.length += colDelta; // inserts empty (undefined) elements at the end of an array
                            Array.prototype.splice.apply(tableMeta.colHeaders, spliceArray); // inserts empty (undefined) elements into the colHeader array
                        }
                        selection.shiftColumns(instance.toVisualColumn(startColumnPhysicalIndex), colDelta);
                    }
                    break;
                case 'remove_row':
                    const removeRow = (indexes)=>{
                        let offset = 0;
                        // Normalize the {index, amount} groups into bigger groups.
                        (0, _array.arrayEach)(indexes, ([groupIndex, groupAmount])=>{
                            const calcIndex = (0, _mixed.isEmpty)(groupIndex) ? instance.countRows() - 1 : Math.max(groupIndex - offset, 0);
                            // If the 'index' is an integer decrease it by 'offset' otherwise pass it through to make the value
                            // compatible with datamap.removeCol method.
                            if (Number.isInteger(groupIndex)) {
                                groupIndex = Math.max(groupIndex - offset, 0);
                            }
                            const totalRowsBefore = instance.countRows();
                            // TODO: for datamap.removeRow index should be passed as it is (with undefined and null values). If not, the logic
                            // inside the datamap.removeRow breaks the removing functionality.
                            const wasRemoved = datamap.removeRow(groupIndex, groupAmount, source);
                            if (!wasRemoved) {
                                return;
                            }
                            if (selection.isSelected()) {
                                const { row } = instance.getSelectedRangeActive().highlight;
                                if (row >= groupIndex && row <= groupIndex + groupAmount - 1) {
                                    editorManager.closeEditor(true);
                                }
                            }
                            const totalRows = instance.countRows();
                            const fixedRowsTop = tableMeta.fixedRowsTop;
                            if (fixedRowsTop >= calcIndex + 1) {
                                tableMeta.fixedRowsTop -= Math.min(groupAmount, fixedRowsTop - calcIndex);
                            }
                            const fixedRowsBottom = tableMeta.fixedRowsBottom;
                            if (fixedRowsBottom) {
                                // Count how many of the removed rows belonged to the bottom fixed rows. Those rows occupied
                                // the `[totalRowsBefore - fixedRowsBottom, totalRowsBefore - 1]` range, so the boundary has
                                // to be compared with the row count from *before* the removal. Rows removed above that
                                // range keep the setting untouched (DEV-2551).
                                const removedRowsCount = totalRowsBefore - totalRows;
                                // With no index passed, `datamap.removeRow` takes the rows from the end, so the removal
                                // starts that many rows before the last one. `calcIndex` points at the last row then, not
                                // at the first removed one.
                                const firstRemovedRowIndex = Number.isInteger(groupIndex) ? calcIndex : Math.max(totalRowsBefore - removedRowsCount, 0);
                                const firstFixedRowIndex = totalRowsBefore - fixedRowsBottom;
                                const lastRemovedRowIndex = Math.min(firstRemovedRowIndex + removedRowsCount - 1, totalRowsBefore - 1);
                                const removedFixedRowsCount = lastRemovedRowIndex - Math.max(firstRemovedRowIndex, firstFixedRowIndex) + 1;
                                if (removedFixedRowsCount > 0) {
                                    tableMeta.fixedRowsBottom -= Math.min(removedFixedRowsCount, fixedRowsBottom);
                                }
                            }
                            if (totalRows === 0) {
                                selection.deselect();
                            } else if (source === 'ContextMenu.removeRow') {
                                const selectionRange = selection.getSelectedRange();
                                const lastSelection = selectionRange.pop();
                                selectionRange.clear().set(lastSelection.from).current().setTo(lastSelection.to);
                                selection.refresh();
                            } else {
                                selection.shiftRows(groupIndex, -groupAmount);
                            }
                            offset += groupAmount;
                        });
                    };
                    if (Array.isArray(index)) {
                        removeRow(normalizeIndexesGroup(index));
                    } else {
                        removeRow([
                            [
                                index,
                                amount
                            ]
                        ]);
                    }
                    break;
                case 'remove_col':
                    const removeCol = (indexes)=>{
                        let offset = 0;
                        // Normalize the {index, amount} groups into bigger groups.
                        (0, _array.arrayEach)(indexes, ([groupIndex, groupAmount])=>{
                            const calcIndex = (0, _mixed.isEmpty)(groupIndex) ? instance.countCols() - 1 : Math.max(groupIndex - offset, 0);
                            let physicalColumnIndex = instance.toPhysicalColumn(calcIndex);
                            // If the 'index' is an integer decrease it by 'offset' otherwise pass it through to make the value
                            // compatible with datamap.removeCol method.
                            if (Number.isInteger(groupIndex)) {
                                groupIndex = Math.max(groupIndex - offset, 0);
                            }
                            // TODO: for datamap.removeCol index should be passed as it is (with undefined and null values). If not, the logic
                            // inside the datamap.removeCol breaks the removing functionality.
                            const wasRemoved = datamap.removeCol(groupIndex, groupAmount, source);
                            if (!wasRemoved) {
                                return;
                            }
                            if (selection.isSelected()) {
                                const { col } = instance.getSelectedRangeActive().highlight;
                                if (col >= groupIndex && col <= groupIndex + groupAmount - 1) {
                                    editorManager.closeEditor(true);
                                }
                            }
                            const totalColumns = instance.countCols();
                            if (totalColumns === 0) {
                                selection.deselect();
                            } else if (source === 'ContextMenu.removeColumn') {
                                const selectionRange = selection.getSelectedRange();
                                const lastSelection = selectionRange.pop();
                                selectionRange.clear().set(lastSelection.from).current().setTo(lastSelection.to);
                                selection.refresh();
                            } else {
                                selection.shiftColumns(groupIndex, -groupAmount);
                            }
                            const fixedColumnsStart = tableMeta.fixedColumnsStart;
                            if (fixedColumnsStart >= calcIndex + 1) {
                                // Since 12.0.0, the "fixedColumnsLeft" is replaced with the "fixedColumnsStart" option.
                                // However, keeping the old name still in effect. When both option names are used together,
                                // the error is thrown. To prevent that, the engine needs to modify the original option key
                                // to bypass the validation.
                                tableMeta._fixedColumnsStart -= Math.min(groupAmount, fixedColumnsStart - calcIndex);
                            }
                            if (Array.isArray(tableMeta.colHeaders)) {
                                if (typeof physicalColumnIndex === 'undefined') {
                                    physicalColumnIndex = -1;
                                }
                                tableMeta.colHeaders.splice(physicalColumnIndex, groupAmount);
                            }
                            offset += groupAmount;
                        });
                    };
                    if (Array.isArray(index)) {
                        removeCol(normalizeIndexesGroup(index));
                    } else {
                        removeCol([
                            [
                                index,
                                amount
                            ]
                        ]);
                    }
                    break;
                default:
                    (0, _errors.throwWithCause)(`There is no such action "${action}"`);
            }
            if (!keepEmptyRows) {
                grid.adjustRowsAndCols(); // makes sure that we did not add rows that will be removed in next refresh
            }
            instance.view.adjustElementsSize();
            instance.view.render();
        },
        /**
     * Makes sure there are empty rows at the bottom of the table.
     *
     * @private
     */ adjustRowsAndCols () {
            const minRows = tableMeta.minRows;
            const minSpareRows = tableMeta.minSpareRows;
            const minCols = tableMeta.minCols;
            const minSpareCols = tableMeta.minSpareCols;
            if (minRows) {
                // should I add empty rows to data source to meet minRows?
                const nrOfRows = instance.countRows();
                if (nrOfRows < minRows) {
                    // The synchronization with cell meta is not desired here. For `minRows` option,
                    // we don't want to touch/shift cell meta objects.
                    datamap.createRow(nrOfRows, minRows - nrOfRows, {
                        source: 'auto'
                    });
                }
            }
            if (minSpareRows) {
                const emptyRows = instance.countEmptyRows(true);
                // should I add empty rows to meet minSpareRows?
                if (emptyRows < minSpareRows) {
                    const emptyRowsMissing = minSpareRows - emptyRows;
                    const rowsToCreate = Math.min(emptyRowsMissing, tableMeta.maxRows - instance.countSourceRows());
                    // The synchronization with cell meta is not desired here. For `minSpareRows` option,
                    // we don't want to touch/shift cell meta objects.
                    datamap.createRow(instance.countRows(), rowsToCreate, {
                        source: 'auto'
                    });
                }
            }
            {
                let emptyCols = 0;
                const canCreateSpareCols = minSpareCols > 0 && !tableMeta.columns && instance.dataType === 'array';
                // Count trailing empty columns, but only when the `minSpareCols` branch below can consume
                // the result, and never beyond `minSpareCols` itself. Verifying that a column is empty
                // scans every row of that column, and this method runs after every change batch - an
                // uncapped count (the previous `countEmptyCols(true)` call) paid O(empty columns * rows)
                // per edit and also ran when only `minCols` was set, where the result was never used.
                if (canCreateSpareCols) {
                    for(let visualIndex = instance.countCols() - 1; visualIndex >= 0; visualIndex--){
                        if (!instance.isEmptyCol(visualIndex)) {
                            break;
                        }
                        emptyCols += 1;
                        if (emptyCols >= minSpareCols) {
                            break;
                        }
                    }
                }
                let nrOfColumns = instance.countCols();
                // should I add empty cols to meet minCols?
                if (minCols && !tableMeta.columns && nrOfColumns < minCols) {
                    // The synchronization with cell meta is not desired here. For `minCols` option,
                    // we don't want to touch/shift cell meta objects.
                    const colsToCreate = minCols - nrOfColumns;
                    emptyCols += colsToCreate;
                    datamap.createCol(nrOfColumns, colsToCreate, {
                        source: 'auto'
                    });
                }
                // should I add empty cols to meet minSpareCols?
                if (canCreateSpareCols && emptyCols < minSpareCols) {
                    nrOfColumns = instance.countCols();
                    const emptyColsMissing = minSpareCols - emptyCols;
                    const colsToCreate = Math.min(emptyColsMissing, tableMeta.maxCols - nrOfColumns);
                    // The synchronization with cell meta is not desired here. For `minSpareCols` option,
                    // we don't want to touch/shift cell meta objects.
                    datamap.createCol(nrOfColumns, colsToCreate, {
                        source: 'auto'
                    });
                }
            }
        },
        /**
     * Populate the data from the provided 2d array from the given cell coordinates.
     *
     * @private
     * @param {object} start Start selection position. Visual indexes.
     * @param {Array} input 2d data array.
     * @param {object} [end] End selection position (only for drag-down mode). Visual indexes.
     * @param {string} [source="populateFromArray"] Source information string.
     * @param {string} [method="overwrite"] Populate method. Possible options: `shift_down`, `shift_right`, `overwrite`.
     * @returns {object|undefined} Ending td in pasted area (only if any cell was changed).
     */ populateFromArray (start, input, end, source, method) {
            let r;
            let rlen;
            let c;
            let clen;
            const setData = [];
            const current = {};
            const newDataByColumns = [];
            const startRow = start.row;
            const startColumn = start.col;
            rlen = input.length;
            if (rlen === 0) {
                return false;
            }
            let columnsPopulationEnd = 0;
            let rowsPopulationEnd = 0;
            if ((0, _object.isObject)(end)) {
                columnsPopulationEnd = end.col - startColumn + 1;
                rowsPopulationEnd = end.row - startRow + 1;
            }
            // insert data with specified pasteMode method
            switch(method){
                case 'shift_down':
                    // translate data from a list of rows to a list of columns
                    const populatedDataByColumns = (0, _array.pivot)(input);
                    const numberOfDataColumns = populatedDataByColumns.length;
                    // method's argument can extend the range of data population (data would be repeated)
                    const numberOfColumnsToPopulate = Math.max(numberOfDataColumns, columnsPopulationEnd);
                    const pushedDownDataByRows = instance.getData().slice(startRow);
                    // translate data from a list of rows to a list of columns
                    const pushedDownDataByColumns = (0, _array.pivot)(pushedDownDataByRows).slice(startColumn, startColumn + numberOfColumnsToPopulate);
                    for(c = 0; c < numberOfColumnsToPopulate; c += 1){
                        if (c < numberOfDataColumns) {
                            for(r = 0, rlen = populatedDataByColumns[c].length; r < rowsPopulationEnd - rlen; r += 1){
                                // repeating data for rows
                                populatedDataByColumns[c].push(populatedDataByColumns[c][r % rlen]);
                            }
                            if (c < pushedDownDataByColumns.length) {
                                newDataByColumns.push(populatedDataByColumns[c].concat(pushedDownDataByColumns[c]));
                            } else {
                                // if before data population, there was no data in the column
                                // we fill the required rows' newly-created cells with `null` values
                                newDataByColumns.push(populatedDataByColumns[c].concat(new Array(pushedDownDataByRows.length).fill(null)));
                            }
                        } else {
                            // Repeating data for columns.
                            newDataByColumns.push(populatedDataByColumns[c % numberOfDataColumns].concat(pushedDownDataByColumns[c]));
                        }
                    }
                    instance.populateFromArray(startRow, startColumn, (0, _array.pivot)(newDataByColumns));
                    break;
                case 'shift_right':
                    const numberOfDataRows = input.length;
                    // method's argument can extend the range of data population (data would be repeated)
                    const numberOfRowsToPopulate = Math.max(numberOfDataRows, rowsPopulationEnd);
                    const pushedRightDataByRows = instance.getData().slice(startRow).map((rowData)=>rowData.slice(startColumn));
                    for(r = 0; r < numberOfRowsToPopulate; r += 1){
                        if (r < numberOfDataRows) {
                            for(c = 0, clen = input[r].length; c < columnsPopulationEnd - clen; c += 1){
                                // repeating data for rows
                                input[r].push(input[r][c % clen]);
                            }
                            if (r < pushedRightDataByRows.length) {
                                for(let i = 0; i < pushedRightDataByRows[r].length; i += 1){
                                    input[r].push(pushedRightDataByRows[r][i]);
                                }
                            } else {
                                // if before data population, there was no data in the row
                                // we fill the required columns' newly-created cells with `null` values
                                input[r].push(...new Array(pushedRightDataByRows[0].length).fill(null));
                            }
                        } else {
                            // Repeating data for columns.
                            input.push(input[r % rlen].slice(0, numberOfRowsToPopulate).concat(pushedRightDataByRows[r]));
                        }
                    }
                    instance.populateFromArray(startRow, startColumn, input);
                    break;
                case 'overwrite':
                default:
                    // overwrite and other not specified options
                    current.row = start.row;
                    current.col = start.col;
                    let skippedRow = 0;
                    let skippedColumn = 0;
                    let pushData = true;
                    let cellMeta;
                    const isAutofillSource = source === 'Autofill.fill' || source === 'autofill.fill';
                    const getInputValue = function getInputValue(row, col = null) {
                        const rowValue = input[row % input.length];
                        if (col !== null) {
                            return rowValue[col % rowValue.length];
                        }
                        return rowValue;
                    };
                    const rowInputLength = input.length;
                    const rowSelectionLength = end ? end.row - start.row + 1 : 0;
                    if (end) {
                        rlen = rowSelectionLength;
                    } else {
                        rlen = Math.max(rowInputLength, rowSelectionLength);
                    }
                    for(r = 0; r < rlen; r++){
                        if (end && current.row > end.row && rowSelectionLength > rowInputLength || !tableMeta.allowInsertRow && current.row > instance.countRows() - 1 || current.row >= tableMeta.maxRows) {
                            break;
                        }
                        const visualRow = r - skippedRow;
                        const sourceRow = isAutofillSource ? r : visualRow;
                        const colInputLength = getInputValue(sourceRow).length;
                        const colSelectionLength = end ? end.col - start.col + 1 : 0;
                        if (end) {
                            clen = colSelectionLength;
                        } else {
                            clen = Math.max(colInputLength, colSelectionLength);
                        }
                        current.col = start.col;
                        // The transient read keeps a bulk paste/fill from permanently materializing one meta
                        // object per target cell - this loop only reads (`skipRowOnPaste`, `skipColumnOnPaste`,
                        // `readOnly`, `valueSetter`, `parsePastedValue`); the write itself goes through the
                        // data layer.
                        cellMeta = instance.getCellMetaTransient(current.row, current.col);
                        if ((source === 'CopyPaste.paste' || source === 'Autofill.fill' || source === 'autofill.fill') && cellMeta.skipRowOnPaste) {
                            skippedRow += 1;
                            current.row += 1;
                            if (source === 'CopyPaste.paste') {
                                rlen += 1;
                            }
                            continue;
                        }
                        skippedColumn = 0;
                        for(c = 0; c < clen; c++){
                            if (end && current.col > end.col && colSelectionLength > colInputLength || !tableMeta.allowInsertColumn && current.col > instance.countCols() - 1 || current.col >= tableMeta.maxCols) {
                                break;
                            }
                            cellMeta = instance.getCellMetaTransient(current.row, current.col);
                            if ((source === 'CopyPaste.paste' || source === 'Autofill.fill' || source === 'autofill.fill') && cellMeta.skipColumnOnPaste) {
                                skippedColumn += 1;
                                current.col += 1;
                                if (source === 'CopyPaste.paste') {
                                    clen += 1;
                                }
                                continue;
                            }
                            if (cellMeta.readOnly && source !== 'UndoRedo.undo') {
                                current.col += 1;
                                continue;
                            }
                            const visualColumn = c - skippedColumn;
                            const sourceColumn = isAutofillSource ? c : visualColumn;
                            const hasValueSetter = !!cellMeta.valueSetter;
                            let value = getInputValue(sourceRow, sourceColumn);
                            let orgValue = instance.getSourceDataAtCell(current.row, current.col) ?? null;
                            if (value !== null && typeof value === 'object') {
                                // when 'value' is array and 'orgValue' is null, set 'orgValue' to
                                // an empty array so that the null value can be compared to 'value'
                                // as an empty value for the array context
                                if (Array.isArray(value) && orgValue === null) {
                                    orgValue = [];
                                }
                                if (!hasValueSetter && (typeof orgValue !== 'object' || orgValue === null)) {
                                    pushData = false;
                                    // Enabling `parsePastedValue` relaxes schema validation, so object-based values can be pasted
                                    // into non-object-based cells
                                    if (cellMeta.parsePastedValue && source === 'CopyPaste.paste') {
                                        pushData = true;
                                    }
                                    // Editor saves always accept the new value regardless of the original cell type (#3234)
                                    if (source === 'edit') {
                                        pushData = true;
                                        value = (0, _object.deepClone)(value);
                                    }
                                } else if (orgValue !== null) {
                                    const orgValueSchema = (0, _object.duckSchema)(Array.isArray(orgValue) ? orgValue : orgValue[0] || orgValue);
                                    const valueSchema = (0, _object.duckSchema)(Array.isArray(value) ? value : value[0] || value);
                                    // Allow overwriting values with the same object-based schema or any array-based schema.
                                    if (hasValueSetter || // If the cell has a value setter, we don't know the value schema (it's dynamic)
                                    source === 'edit' || // Editor saves always accept the new value regardless of schema (#3234)
                                    (0, _object.isObjectEqual)(orgValueSchema, valueSchema) || Array.isArray(orgValueSchema) && Array.isArray(valueSchema)) {
                                        value = (0, _object.deepClone)(value);
                                    } else {
                                        pushData = false;
                                    }
                                }
                            } else if (!hasValueSetter && orgValue !== null && typeof orgValue === 'object') {
                                pushData = false;
                            }
                            if (pushData) {
                                setData.push([
                                    current.row,
                                    current.col,
                                    value
                                ]);
                            }
                            pushData = true;
                            current.col += 1;
                        }
                        current.row += 1;
                    }
                    instance.setDataAtCell(setData, null, null, source || 'populateFromArray');
                    break;
            }
        }
    };
    /**
   * Internal function to set `language` key of settings.
   *
   * @private
   * @param {string} languageCode Language code for specific language i.e. 'en-US', 'pt-BR', 'de-DE'.
   * @fires Hooks#afterLanguageChange
   */ function setLanguage(languageCode) {
        const normalizedLanguageCode = (0, _utils.normalizeLanguageCode)(languageCode);
        if ((0, _registry4.hasLanguageDictionary)(normalizedLanguageCode)) {
            instance.runHooks('beforeLanguageChange', normalizedLanguageCode);
            globalMeta.language = normalizedLanguageCode;
            instance.runHooks('afterLanguageChange', normalizedLanguageCode);
        } else {
            (0, _utils.warnUserAboutLanguageRegistration)(languageCode);
        }
    }
    /**
   * Internal function to set `className` or `tableClassName`, depending on the key from the settings object.
   *
   * @private
   * @param {string} className `className` or `tableClassName` from the key in the settings object.
   * @param {string|string[]} classSettings String or array of strings. Contains class name(s) from settings object.
   */ function setClassName(className, classSettings) {
        const element = className === 'className' ? instance.rootElement : instance.table;
        if (firstRun) {
            if (classSettings !== undefined) {
                (0, _element.addClass)(element, classSettings);
            }
        } else {
            let globalMetaSettingsArray = [];
            let settingsArray = [];
            if (globalMeta[className]) {
                const globalMetaValue = globalMeta[className];
                globalMetaSettingsArray = Array.isArray(globalMetaValue) ? globalMetaValue : (0, _array.stringToArray)(String(globalMetaValue));
            }
            if (classSettings) {
                settingsArray = Array.isArray(classSettings) ? classSettings : (0, _array.stringToArray)(classSettings);
            }
            const classNameToRemove = (0, _array.getDifferenceOfArrays)(globalMetaSettingsArray, settingsArray);
            const classNameToAdd = (0, _array.getDifferenceOfArrays)(settingsArray, globalMetaSettingsArray);
            if (classNameToRemove.length) {
                (0, _element.removeClass)(element, classNameToRemove);
            }
            if (classNameToAdd.length) {
                (0, _element.addClass)(element, classNameToAdd);
            }
        }
        globalMeta[className] = classSettings;
    }
    this.init = function() {
        const theme = tableMeta.theme;
        const themeName = tableMeta.themeName;
        const rootContainerThemeClassName = (0, _themes.getThemeClassName)(instance.rootContainer);
        if ((0, _rootInstance.isRootInstance)(instance) && !rootContainerThemeClassName && ((0, _object.isObject)(theme) || !theme && !themeName)) {
            initializeThemeManager(theme, readStoredThemeOverrides());
        }
        dataSource.setData(tableMeta.data);
        instance.runHooks('beforeInit');
        if ((0, _browser.isMobileBrowser)() || (0, _browser.isIpadOS)()) {
            (0, _element.addClass)(instance.rootElement, 'mobile');
        }
        this.updateSettings(mergedUserSettings, true);
        this.view = new _tableView.default(this);
        editorManager = _editorManager.default.getInstance(instance, tableMeta, selection);
        viewportScroller = (0, _index.createViewportScroller)(instance);
        focusGridManager.init();
        if ((0, _rootInstance.isRootInstance)(this)) {
            (0, _a11yAnnouncer.install)(instance.rootPortalElement);
            (0, _licenseNotification.initLicenseNotification)(instance);
            (0, _licenseBranding.initLicenseBranding)(instance);
            // Keep the edge slots (top, bottom) as wide as the table so their content
            // (toolbars, pagination, license notification) aligns with the grid.
            const lastEdgeWidths = {
                top: -1,
                bottom: -1
            };
            const syncEdgeSlotsWidth = ()=>{
                if (instance.isDestroyed) {
                    return;
                }
                const { view } = instance;
                if (!view) {
                    return;
                }
                let width = view.isHorizontallyScrollableByWindow() ? view.getTotalTableWidth() : view.getWorkspaceWidth();
                if (width === 0 && instance.rootWrapperElement) {
                    width = instance.rootWrapperElement.offsetWidth;
                }
                // Only write when the value actually changes — avoids a reflow → dimension-refresh
                // → re-sync feedback loop, and needless layout writes during volatile renders.
                if (instance.rootSlotBottomElement && width !== lastEdgeWidths.bottom) {
                    lastEdgeWidths.bottom = width;
                    instance.rootSlotBottomElement.style.width = `${width}px`;
                }
                if (instance.rootSlotTopElement && width !== lastEdgeWidths.top) {
                    lastEdgeWidths.top = width;
                    instance.rootSlotTopElement.style.width = `${width}px`;
                }
            };
            this.addHook('afterRender', syncEdgeSlotsWidth);
        }
        instance.runHooks('init');
        this.render();
        // Run the logic only if it's the table's initialization and the root element is not visible.
        if (!!firstRun && instance.rootElement.offsetParent === null) {
            visibilityObserver = (0, _element.observeVisibilityChangeOnce)(instance.rootElement, ()=>{
                // A delivery carries the state from the moment its snapshot was taken, so it can arrive after the
                // instance is gone even though `destroy` disconnects the observer.
                if (!instance || instance.isDestroyed || !instance.view) {
                    return;
                }
                // Update the spreader size cache before rendering.
                instance.view._wt.wtOverlays.updateLastSpreaderSize();
                instance.view.adjustElementsSize();
                instance.render();
            });
        }
        if (typeof firstRun === 'object') {
            instance.runHooks('afterChange', firstRun[0], firstRun[1]);
            firstRun = false;
        }
        instance.runHooks('afterInit');
    };
    /**
   * Reads the per-instance color scheme and density overrides from a settings object.
   *
   * Only the keys actually present are returned, so a missing key keeps the value already applied
   * instead of resetting it to the theme default.
   *
   * @param {object} settings - The settings object to read the overrides from.
   * @returns {object} The theme overrides object.
   */ function readThemeOverrides(settings) {
        const overrides = {};
        if ((0, _object.hasOwnProperty)(settings, 'colorScheme')) {
            overrides.colorScheme = settings.colorScheme;
        }
        if ((0, _object.hasOwnProperty)(settings, 'density')) {
            overrides.density = settings.density;
        }
        return overrides;
    }
    /**
   * Reads the color scheme and density currently configured on this instance.
   *
   * Unlike `readThemeOverrides()`, this reads the effective values rather than only the keys that
   * one payload carries. `updateSettings()` stores grid options on the global meta, which the table
   * meta inherits through its prototype, so an own-property check would miss them. Use this when
   * rebuilding a ThemeManager, which has to pick up options set by an earlier call.
   *
   * @returns {object} The theme overrides object.
   */ function readStoredThemeOverrides() {
        return {
            colorScheme: tableMeta.colorScheme,
            density: tableMeta.density
        };
    }
    /**
   * Applies the `colorScheme` and `density` options to the ThemeManager of this instance.
   *
   * The options are per-instance overrides, so the shared theme object stays untouched and other
   * grids using the same theme keep their own look.
   *
   * @param {object} settings - The settings object that may carry the overrides.
   * @param {boolean} init - `true` when called during initialization. The initial styles are
   * injected by the ThemeManager constructor, so nothing has to be refreshed in that case.
   * @returns {boolean} `true` when the overrides changed and `afterSetTheme` still has to run.
   */ function applyThemeOverrides(settings, init) {
        const overrides = readThemeOverrides(settings);
        if (!(0, _object.hasOwnProperty)(overrides, 'colorScheme') && !(0, _object.hasOwnProperty)(overrides, 'density')) {
            return false;
        }
        if (!instance.themeManager) {
            // Only complain when a value is actually asked for. Clearing the options is documented, and a
            // framework wrapper re-sends every prop on each render, so warning on key presence alone
            // would fill the console for grids that never used these options.
            const isValueRequested = !(0, _engine.isThemeOverrideEmpty)(overrides.colorScheme) || !(0, _engine.isThemeOverrideEmpty)(overrides.density);
            if (isValueRequested && !themeOverridesWarningShown) {
                themeOverridesWarningShown = true;
                (0, _console.warn)('The `colorScheme` and `density` options require the theme engine, so they have no ' + 'effect when the theme is enabled by a CSS class name. Pass a theme config object or a ' + '`ThemeBuilder` instance to the `theme` option, or remove the `ht-theme-*` class from ' + 'the container element to use the default theme.');
            }
            return false;
        }
        const hasChanged = instance.themeManager.setOverrides(overrides);
        if (!hasChanged || init) {
            return false;
        }
        // Clear the cache here so the render at the end of `updateSettings` measures the new sizes.
        // Rendering here as well would paint once with stale meta and then immediately paint again.
        instance.stylesHandler.clearCache();
        return true;
    }
    /**
   * Initializes the ThemeManager with the given theme configuration.
   *
   * @param {object|boolean} theme - The theme configuration object or `true` to use the default theme.
   * @param {object} [overrides] - The per-instance color scheme and density overrides.
   */ function initializeThemeManager(theme, overrides) {
        let themeObject;
        // Tear the previous manager down first. Without this its `<style>` node stays in the wrapper,
        // and because a new manager prepends its own node the orphan ends up LATER in source order —
        // so at the same specificity the orphan's override rules win and the grid can never change or
        // reset a `colorScheme` or `density` that was set at construction time.
        instance.themeManager?.destroy();
        if (typeof theme === 'undefined') {
            if ((0, _themes1.hasTheme)('main')) {
                themeObject = (0, _themes1.getTheme)('main');
            } else {
                themeObject = (0, _themes1.registerTheme)(_themes1.mainTheme);
            }
            themeObject = (0, _themes1.getTheme)('main');
        } else if (typeof theme.getThemeConfig !== 'function') {
            themeObject = (0, _themes1.registerTheme)(theme);
        } else {
            themeObject = theme;
        }
        instance.themeManager = (0, _engine.createThemeManager)({
            hot: instance,
            themeObject,
            overrides
        });
    }
    /**
   * @ignore
   * @returns {object}
   */ function ValidatorsQueue() {
        let resolved = false;
        return {
            validatorsInQueue: 0,
            valid: true,
            addValidatorToQueue () {
                this.validatorsInQueue += 1;
                resolved = false;
            },
            removeValidatorFormQueue () {
                this.validatorsInQueue = this.validatorsInQueue - 1 < 0 ? 0 : this.validatorsInQueue - 1;
                this.checkIfQueueIsEmpty();
            },
            onQueueEmpty (_valid) {},
            checkIfQueueIsEmpty () {
                if (this.validatorsInQueue === 0 && resolved === false) {
                    resolved = true;
                    this.onQueueEmpty(this.valid);
                }
            }
        };
    }
    /**
   * @ignore
   * @param {Array} changes List of changes in format `[visualRow, prop, oldValue, newValue]`.
   * @param {BaseEditor|undefined} activeEditor Current editor instance.
   * @returns {boolean} `true` when the active, opened editor points to a changed cell.
   */ function doesChangeAffectOpenedEditor(changes, activeEditor) {
        if (!activeEditor?.isOpened()) {
            return false;
        }
        return (0, _data.hasChangeForCell)(changes, activeEditor.row, activeEditor.prop);
    }
    /**
   * @ignore
   * @param {Array} changes The 2D array containing information about each of the edited cells.
   * @param {string} source The string that identifies source of validation.
   * @param {Function} callback The callback function fot async validation.
   */ function validateChanges(changes, source, callback) {
        if (!changes.length) {
            callback();
            return;
        }
        const activeEditor = instance.getActiveEditor();
        const waitingForValidator = ValidatorsQueue();
        let shouldBeCanceled = true;
        // Track value corrections applied by validators via setDataAtCell during the validation window.
        // Without this, a corrected value written by a nested setDataAtCell call gets overwritten when
        // applyChanges() runs on the original changes array. The hook is removed before applyChanges()
        // runs (in onQueueEmpty), so it does not capture the parent apply itself.
        //
        // Source filtering is structurally required: each nested validateChanges() call registers its
        // own onAfterChange hook. Without filtering, when the parent applyChanges() fires afterChange,
        // the nested hook would intercept it and corrupt the nested changes array. Filtering to sources
        // that end with 'Validator' ensures only corrections emitted by validators are captured, never
        // values applied by applyChanges(). Custom validators that correct values must follow this
        // convention by passing a source ending in 'Validator' to their setDataAtCell call.
        const applyValidatorCorrection = ([changedRow, changedProp, , correctedValue])=>{
            const idx = changes.findIndex(([row, prop])=>row === changedRow && prop === changedProp);
            if (idx !== -1) {
                changes[idx][3] = correctedValue;
            }
        };
        const onAfterChange = (afterChanges, afterSource)=>{
            if (typeof afterSource !== 'string' || !afterSource.endsWith('Validator')) {
                return;
            }
            afterChanges?.forEach(applyValidatorCorrection);
        };
        instance.addHook('afterChange', onAfterChange);
        waitingForValidator.onQueueEmpty = ()=>{
            instance.removeHook('afterChange', onAfterChange);
            if (activeEditor && shouldBeCanceled && activeEditor._closeAfterDataChange && doesChangeAffectOpenedEditor(changes, activeEditor)) {
                activeEditor.cancelChanges();
            }
            callback(); // called when async validators are resolved and beforeChange was not async
        };
        for(let i = changes.length - 1; i >= 0; i--){
            const [row, prop, , newValue] = changes[i];
            const visualCol = datamap.propToCol(prop);
            let cellProperties;
            if (Number.isInteger(visualCol)) {
                // The transient read keeps a bulk change set from permanently materializing one meta
                // object per changed cell while the validator is looked up. Cells that DO have a
                // validator switch to the eagerly stored meta object below - validation writes its
                // `valid` result on the meta, and that result must survive on the stored object.
                cellProperties = instance.getCellMetaTransient(row, visualCol);
                if (instance.getCellValidator(cellProperties)) {
                    cellProperties = instance.getCellMeta(row, visualCol);
                }
            } else {
                // If there's no requested visual column, we can use the table meta as the cell properties when retrieving
                // the cell validator.
                cellProperties = {
                    ...Object.getPrototypeOf(tableMeta),
                    ...tableMeta
                };
            }
            if (instance.getCellValidator(cellProperties)) {
                /* eslint-disable no-loop-func */ waitingForValidator.addValidatorToQueue();
                instance.validateCell(newValue, cellProperties, function(index, cellPropertiesReference) {
                    return function(result) {
                        if (typeof result !== 'boolean') {
                            (0, _errors.throwWithCause)('Validation error: result is not boolean');
                        }
                        if (result === false && cellPropertiesReference.allowInvalid === false) {
                            shouldBeCanceled = false;
                            // cancel the change
                            changes.splice(index, 1);
                            // we cancelled the change, so cell value is still valid
                            cellPropertiesReference.valid = true;
                        }
                        waitingForValidator.removeValidatorFormQueue();
                    };
                }(i, cellProperties), source);
            }
        }
        waitingForValidator.checkIfQueueIsEmpty();
    }
    /**
   * Internal function to apply changes. Called after validateChanges.
   *
   * @private
   * @param {Array} changes Array in form of [row, prop, oldValue, newValue].
   * @param {string} source String that identifies how this change will be described in changes array (useful in {@link Hooks#afterChange} or {@link Hooks#beforeChange} callbacks).
   * @fires Hooks#beforeChangeRender
   * @fires Hooks#afterChange
   */ function applyChanges(changes, source) {
        for(let i = changes.length - 1; i >= 0; i--){
            let skipThisChange = false;
            if (changes[i] === null) {
                changes.splice(i, 1);
                continue;
            }
            if ((changes[i][2] === null || changes[i][2] === undefined) && (changes[i][3] === null || changes[i][3] === undefined)) {
                continue;
            }
            if (tableMeta.allowInsertRow) {
                // Create the whole missing range in one call - one index-mapper insert and one hook
                // round instead of one per row. Creating row by row made a paste reaching far below
                // the last row quadratic in the gap size. The loop re-checks the count so a partial
                // creation (e.g. a `maxRows` clamp) is detected and the change is skipped.
                while(changes[i][0] > instance.countRows() - 1){
                    const missingRows = changes[i][0] - (instance.countRows() - 1);
                    const { delta: numberOfCreatedRows } = datamap.createRow(undefined, missingRows, {
                        source: 'auto'
                    });
                    if (numberOfCreatedRows === 0) {
                        skipThisChange = true;
                        break;
                    }
                }
            }
            if (instance.dataType === 'array' && (!tableMeta.columns || tableMeta.columns.length === 0) && tableMeta.allowInsertColumn) {
                while(Number(datamap.propToCol(changes[i][1])) > instance.countCols() - 1){
                    const missingColumns = Number(datamap.propToCol(changes[i][1])) - (instance.countCols() - 1);
                    const { delta: numberOfCreatedColumns } = datamap.createCol(undefined, missingColumns, {
                        source: 'auto'
                    });
                    if (numberOfCreatedColumns === 0) {
                        skipThisChange = true;
                        break;
                    }
                }
            }
            if (skipThisChange) {
                continue;
            }
            datamap.set(changes[i][0], changes[i][1], changes[i][3]);
        }
        const hasChanges = changes.length > 0;
        const activeEditor = editorManager.getActiveEditor();
        const closeEditorAfterDataChange = activeEditor?._closeAfterDataChange;
        const isOpenedEditorAffectedByChanges = doesChangeAffectOpenedEditor(changes, activeEditor);
        if (hasChanges) {
            grid.adjustRowsAndCols();
            instance.runHooks('beforeChangeRender', changes, source);
            if (activeEditor?.isOpened() && closeEditorAfterDataChange && isOpenedEditorAffectedByChanges) {
                editorManager.closeEditor();
            }
            instance.view.adjustElementsSize();
            instance.render();
            if (activeEditor?.isOpened() && closeEditorAfterDataChange && isOpenedEditorAffectedByChanges || !activeEditor?.isOpened()) {
                editorManager.prepareEditor();
            }
            instance.runHooks('afterChange', changes, source || 'edit');
            if (activeEditor && activeEditor.refreshValue !== undefined && (!activeEditor.isOpened() || isOpenedEditorAffectedByChanges)) {
                activeEditor.refreshValue();
            }
        } else {
            instance.render();
        }
    }
    /**
   * Creates and returns the CellCoords object.
   *
   * @private
   * @memberof Core#
   * @function _createCellCoords
   * @param {number} row The row index.
   * @param {number} column The column index.
   * @returns {CellCoords}
   */ this._createCellCoords = function(row, column) {
        const view = instance.view;
        return view._wt.createCellCoords(row, column);
    };
    /**
   * Creates and returns the CellRange object.
   *
   * @private
   * @memberof Core#
   * @function _createCellRange
   * @param {CellCoords} highlight Defines the border around a cell where selection was started and to edit the cell
   *                               when you press Enter. The highlight cannot point to headers (negative values).
   * @param {CellCoords} from Initial coordinates.
   * @param {CellCoords} to Final coordinates.
   * @returns {CellRange}
   */ this._createCellRange = function(highlight, from, to) {
        const view = instance.view;
        return view._wt.createCellRange(highlight, from, to);
    };
    /**
   * Validate a single cell.
   *
   * @memberof Core#
   * @function validateCell
   * @param {string|number} value The value to validate.
   * @param {object} cellProperties The cell meta which corresponds with the value.
   * @param {Function} callback The callback function.
   * @param {string} source The string that identifies source of the validation.
   */ this.validateCell = function(value, cellProperties, callback, source) {
        let validator = instance.getCellValidator(cellProperties);
        // the `canBeValidated = false` argument suggests, that the cell passes validation by default.
        /**
     * @private
     * @function done
     * @param {boolean} valid Indicates if the validation was successful.
     * @param {boolean} [canBeValidated=true] Flag which controls the validation process.
     */ function done(valid, canBeValidated = true) {
            // Fixes GH#3903
            if (!canBeValidated || cellProperties.hidden === true) {
                callback(valid);
                return;
            }
            const col = cellProperties.visualCol;
            const row = cellProperties.visualRow;
            const td = instance.getCell(row, col, true);
            if (td && td.nodeName !== 'TH') {
                const renderableRow = instance.rowIndexMapper.getRenderableFromVisualIndex(row);
                const renderableColumn = instance.columnIndexMapper.getRenderableFromVisualIndex(col);
                instance.view._wt.getSetting('cellRenderer', renderableRow, renderableColumn, td);
            }
            callback(valid);
        }
        if ((0, _mixed.isRegExp)(validator)) {
            validator = function(expression) {
                return function(cellValue, validatorCallback) {
                    validatorCallback(expression.test(cellValue));
                };
            }(validator);
        }
        if ((0, _function.isFunction)(validator)) {
            // When the column data accessor is a function, cellProperties.prop holds the accessor
            // function itself — not a usable column reference. Fall back to the visual column index
            // so hook listeners always receive a number or a property string, never a function.
            const colArg = (0, _function.isFunction)(cellProperties.prop) ? cellProperties.visualCol : cellProperties.prop;
            value = instance.runHooks('beforeValidate', value, cellProperties.visualRow, colArg, source);
            // To provide consistent behavior, validation should be always asynchronous
            instance._registerMicrotask(()=>{
                validator.call(cellProperties, value, (valid)=>{
                    if (!instance) {
                        return;
                    }
                    valid = instance.runHooks('afterValidate', valid, value, cellProperties.visualRow, colArg, source);
                    cellProperties.valid = valid;
                    done(valid);
                    instance.runHooks('postAfterValidate', valid, value, cellProperties.visualRow, colArg, source);
                });
            });
        } else {
            // resolve callback even if validator function was not found
            instance._registerMicrotask(()=>{
                cellProperties.valid = true;
                done(cellProperties.valid, false);
            });
        }
    };
    /**
   * @ignore
   * @param {number} row The visual row index.
   * @param {string|number} propOrCol The visual prop or column index.
   * @param {*} value The cell value.
   * @returns {Array}
   */ function setDataInputToArray(row, propOrCol, value) {
        if (Array.isArray(row)) {
            return row;
        }
        return [
            [
                row,
                propOrCol,
                value
            ]
        ];
    }
    /**
   * Process changes prepared for applying to the dataset (unifying list of changes, closing an editor - when needed,
   * calling a hook).
   *
   * @private
   * @param {Array} changes Array of changes in format `[[row, col, value],...]`.
   * @param {string} [source] String that identifies how this change will be described in the changes array (useful in afterChange or beforeChange callback). Set to 'edit' if left empty.
   * @returns {Array} List of changes finally applied to the dataset.
   */ function processChanges(changes, source) {
        const beforeChangeResult = instance.runHooks('beforeChange', changes, source || 'edit');
        // The `beforeChange` hook could add a `null` for purpose of cancelling some dataset's change.
        const filteredChanges = changes.filter((change)=>change !== null);
        if (beforeChangeResult === false || filteredChanges.length === 0) {
            instance.getActiveEditor()?.cancelChanges();
            return [];
        }
        for(let i = filteredChanges.length - 1; i >= 0; i--){
            const [row, prop, , newValue] = filteredChanges[i];
            const visualColumn = datamap.propToCol(prop);
            let cellProperties;
            if (Number.isInteger(visualColumn)) {
                // The transient read keeps a bulk change set (paste, fill, checkbox toggle over a large
                // selection) from permanently materializing one meta object per changed cell - the meta
                // is only read here (`valueSetter`).
                cellProperties = instance.getCellMetaTransient(row, visualColumn);
            } else {
                // If there's no requested visual column, we can use the table meta as the cell properties
                cellProperties = {
                    ...Object.getPrototypeOf(tableMeta),
                    ...tableMeta
                };
            }
            filteredChanges[i][3] = (0, _valueAccessors.getValueSetterValue)(newValue, cellProperties);
        }
        return filteredChanges;
    }
    /**
   * @description
   * Set new value to a cell. To change many cells at once (recommended way), pass an array of `changes` in format
   * `[[row, col, value],...]` as the first argument.
   *
   * @memberof Core#
   * @function setDataAtCell
   * @param {number|Array} row Visual row index or array of changes in format `[[row, col, value],...]`.
   * @param {number} [column] Visual column index.
   * @param {string} [value] New value.
   * @param {string} [source] String that identifies how this change will be described in the changes array (useful in {@link Hooks#afterChange} or {@link Hooks#beforeChange} callbacks). Set to 'edit' if left empty.
   * @fires Hooks#beforeChange
   * @fires Hooks#afterChange
   */ this.setDataAtCell = function(row, column, value, source) {
        const input = setDataInputToArray(row, column, value);
        const changes = [];
        let changeSource = source;
        let i;
        let ilen;
        let prop;
        for(i = 0, ilen = input.length; i < ilen; i++){
            const [visualRow, visualColumn, newValue] = input[i];
            if (typeof input[i] !== 'object') {
                (0, _errors.throwWithCause)('Method `setDataAtCell` accepts row number or changes array of arrays as its first parameter');
            }
            if (typeof input[i][1] !== 'number') {
                // eslint-disable-next-line max-len
                (0, _errors.throwWithCause)('Method `setDataAtCell` accepts row and column number as its parameters. If you want to use object property name, use method `setDataAtRowProp`');
            }
            // setDataAtCell validates that column is numeric above (throws if not number).
            const visualColumnIndex = typeof visualColumn === 'number' ? visualColumn : 0;
            if (visualColumnIndex >= this.countCols()) {
                prop = visualColumnIndex;
            } else {
                prop = datamap.colToProp(visualColumnIndex);
            }
            changes.push([
                visualRow,
                prop,
                dataSource.getAtCell(this.toPhysicalRow(visualRow), visualColumn),
                newValue
            ]);
        }
        if (!changeSource && typeof row === 'object') {
            changeSource = column;
        }
        const processedChanges = processChanges(changes, changeSource);
        instance.runHooks('afterSetDataAtCell', processedChanges, changeSource);
        validateChanges(processedChanges, changeSource, ()=>{
            applyChanges(processedChanges, changeSource);
        });
    };
    /**
   * @description
   * Set new value to a cell. To change many cells at once (recommended way), pass an array of `changes` in format
   * `[[row, prop, value],...]` as the first argument.
   *
   * @memberof Core#
   * @function setDataAtRowProp
   * @param {number|Array} row Visual row index or array of changes in format `[[row, prop, value], ...]`.
   * @param {string} prop Property name or the source string (e.g. `'first.name'` or `'0'`).
   * @param {string} value Value to be set.
   * @param {string} [source] String that identifies how this change will be described in changes array (useful in {@link Hooks#afterChange} or {@link Hooks#beforeChange} callbacks).
   * @fires Hooks#beforeChange
   * @fires Hooks#afterChange
   */ this.setDataAtRowProp = function(row, prop, value, source) {
        const input = setDataInputToArray(row, prop, value);
        const changes = [];
        let changeSource = source;
        let i;
        let ilen;
        for(i = 0, ilen = input.length; i < ilen; i++){
            const [visualRow, inputProp, newValue] = input[i];
            changes.push([
                visualRow,
                inputProp,
                dataSource.getAtCell(this.toPhysicalRow(visualRow), inputProp),
                newValue
            ]);
        }
        // TODO: I don't think `prop` should be used as `changeSource` here, but removing it would be a breaking change.
        // We should remove it with the next major release.
        if (!changeSource && typeof row === 'object') {
            changeSource = prop;
        }
        const processedChanges = processChanges(changes, changeSource);
        instance.runHooks('afterSetDataAtRowProp', processedChanges, changeSource);
        validateChanges(processedChanges, changeSource, ()=>{
            applyChanges(processedChanges, changeSource);
        });
    };
    /**
   * Listen to the keyboard input on document body. This allows Handsontable to capture keyboard events and respond
   * in the right way.
   *
   * @memberof Core#
   * @function listen
   * @fires Hooks#afterListen
   */ this.listen = function() {
        if (instance && !instance.isListening()) {
            foreignHotInstances.forEach((foreignHot)=>{
                if (instance !== foreignHot) {
                    foreignHot.unlisten();
                }
            });
            activeGuid = instance.guid;
            instance.runHooks('afterListen');
        }
    };
    /**
   * Stop listening to keyboard input on the document body. Calling this method makes the Handsontable inactive for
   * any keyboard events.
   *
   * @memberof Core#
   * @function unlisten
   */ this.unlisten = function() {
        if (this.isListening()) {
            activeGuid = null;
            instance.runHooks('afterUnlisten');
        }
    };
    /**
   * Returns `true` if the current Handsontable instance is listening to keyboard input on document body.
   *
   * @memberof Core#
   * @function isListening
   * @returns {boolean} `true` if the instance is listening, `false` otherwise.
   */ this.isListening = function() {
        return activeGuid === instance.guid;
    };
    /**
   * Destroys the current editor, render the table and prepares the editor of the newly selected cell.
   *
   * @memberof Core#
   * @function destroyEditor
   * @param {boolean} [revertOriginal=false] If `true`, the previous value will be restored. Otherwise, the edited value will be saved.
   * @param {boolean} [prepareEditorIfNeeded=true] If `true`, the editor under the selected cell will be prepared to open.
   */ this.destroyEditor = function(revertOriginal = false, prepareEditorIfNeeded = true) {
        editorManager.closeEditor(revertOriginal);
        instance.view.render();
        if (prepareEditorIfNeeded && selection.isSelected()) {
            editorManager.prepareEditor();
        }
    };
    /**
   * Populates cells at position with 2D input array (e.g. `[[1, 2], [3, 4]]`). Use `endRow`, `endCol` when you
   * want to cut input when a certain row is reached.
   *
   * The `populateFromArray()` method can't change [`readOnly`](@/api/options.md#readonly) cells.
   *
   * Optional `method` argument has the same effect as pasteMode option (see {@link Options#pasteMode}).
   *
   * @memberof Core#
   * @function populateFromArray
   * @param {number} row Start visual row index.
   * @param {number} column Start visual column index.
   * @param {Array} input 2d array.
   * @param {number} [endRow] End visual row index (use when you want to cut input when certain row is reached).
   * @param {number} [endCol] End visual column index (use when you want to cut input when certain column is reached).
   * @param {string} [source=populateFromArray] Used to identify this call in the resulting events (beforeChange, afterChange).
   * @param {string} [method=overwrite] Populate method, possible values: `'shift_down'`, `'shift_right'`, `'overwrite'`.
   * @returns {object|undefined} Ending td in pasted area (only if any cell was changed).
   */ this.populateFromArray = function(row, column, input, endRow, endCol, source, method) {
        if (!(typeof input === 'object' && typeof input[0] === 'object')) {
            (0, _errors.throwWithCause)('populateFromArray parameter `input` must be an array of arrays'); // API changed in 0.9-beta2, let's check if you use it correctly
        }
        const c = typeof endRow === 'number' ? instance._createCellCoords(endRow, endCol) : undefined;
        return grid.populateFromArray(instance._createCellCoords(row, column), input, c, source, method);
    };
    /**
   * Adds/removes data from the column. This method works the same as Array.splice for arrays.
   *
   * @memberof Core#
   * @function spliceCol
   * @param {number} column Index of the column in which do you want to do splice.
   * @param {number} index Index at which to start changing the array. If negative, will begin that many elements from the end.
   * @param {number} amount An integer indicating the number of old array elements to remove. If amount is 0, no elements are removed.
   * @param {...number} [elements] The elements to add to the array. If you don't specify any elements, spliceCol simply removes elements from the array.
   * @returns {Array} Returns removed portion of columns.
   */ this.spliceCol = function(column, index, amount, ...elements) {
        return datamap.spliceCol(column, index, amount, ...elements);
    };
    /**
   * Adds/removes data from the row. This method works the same as Array.splice for arrays.
   *
   * @memberof Core#
   * @function spliceRow
   * @param {number} row Index of column in which do you want to do splice.
   * @param {number} index Index at which to start changing the array. If negative, will begin that many elements from the end.
   * @param {number} amount An integer indicating the number of old array elements to remove. If amount is 0, no elements are removed.
   * @param {...number} [elements] The elements to add to the array. If you don't specify any elements, spliceCol simply removes elements from the array.
   * @returns {Array} Returns removed portion of rows.
   */ this.spliceRow = function(row, index, amount, ...elements) {
        return datamap.spliceRow(row, index, amount, ...elements);
    };
    /**
   * Returns indexes of the currently selected cells as an array of arrays `[[startRow, startCol, endRow, endCol],...]`.
   *
   * Start row and start column are the coordinates of the active cell (where the selection was started).
   *
   * The version 0.36.0 adds a non-consecutive selection feature. Since this version, the method returns an array of arrays.
   * Additionally to collect the coordinates of the currently selected area (as it was previously done by the method)
   * you need to use `getSelectedLast` method.
   *
   * @memberof Core#
   * @function getSelected
   * @returns {Array[]|undefined} An array of arrays of the selection's coordinates.
   */ this.getSelected = function() {
        if (selection.isSelected()) {
            return (0, _array.arrayMap)(selection.getSelectedRange().ranges, ({ from, to })=>[
                    from.row,
                    from.col,
                    to.row,
                    to.col
                ]);
        }
    };
    /**
   * Returns the last coordinates applied to the table as a an array `[startRow, startCol, endRow, endCol]`.
   *
   * @since 0.36.0
   * @memberof Core#
   * @function getSelectedLast
   * @returns {Array|undefined} An array of the selection's coordinates.
   */ this.getSelectedLast = function() {
        const selected = instance.getSelected();
        let result;
        if (selected && selected.length > 0) {
            result = selected[selected.length - 1];
        }
        return result;
    };
    /**
   * Returns the range coordinates of the active selection layer as an array. Active selection layer is the layer that
   * has visible focus highlight.
   *
   * @memberof Core#
   * @function getSelectedActive
   * @since 16.1.0
   * @returns {number[]|undefined} Selected range as an array of coordinates or `undefined` if there is no selection.
   */ this.getSelectedActive = function() {
        const activeRange = instance.getSelectedRangeActive();
        if (!activeRange) {
            return;
        }
        const { from, to } = activeRange;
        return [
            from.row,
            from.col,
            to.row,
            to.col
        ];
    };
    /**
   * Returns the current selection as an array of CellRange objects.
   *
   * The version 0.36.0 adds a non-consecutive selection feature. Since this version, the method returns an array of arrays.
   * Additionally to collect the coordinates of the active selected area (as it was previously done by the method)
   * you need to use `getSelectedRangeActive()` method.
   *
   * @memberof Core#
   * @function getSelectedRange
   * @returns {CellRange[]|undefined} Selected range object or `undefined` if there is no selection.
   */ this.getSelectedRange = function() {
        if (selection.isSelected()) {
            return Array.from(selection.getSelectedRange());
        }
    };
    /**
   * Returns the last coordinates applied to the table as a CellRange object.
   *
   * @memberof Core#
   * @function getSelectedRangeLast
   * @since 0.36.0
   * @returns {CellRange|undefined} Selected range object or `undefined` if there is no selection.
   */ this.getSelectedRangeLast = function() {
        const selectedRange = instance.getSelectedRange();
        let result;
        if (selectedRange && selectedRange.length > 0) {
            result = selectedRange[selectedRange.length - 1];
        }
        return result;
    };
    /**
   * Returns the range coordinates of the active selection layer. Active selection layer is the layer that
   * has visible focus highlight.
   *
   * @memberof Core#
   * @function getSelectedRangeActive
   * @since 16.1.0
   * @returns {CellRange|undefined} Selected range object or `undefined` if there is no selection.
   */ this.getSelectedRangeActive = function() {
        return selection.getActiveSelectedRange();
    };
    /**
   * Returns the index of the active selection layer. Active selection layer is the layer that
   * has visible focus highlight.
   *
   * @memberof Core#
   * @function getActiveSelectionLayerIndex
   * @since 16.1.0
   * @returns {number} The index of the active selection layer. `0` to `N` where `0` is the last (oldest) layer and `N` is the first (newest) layer.
   */ this.getActiveSelectionLayerIndex = function() {
        return selection.getActiveSelectionLayerIndex();
    };
    /**
   * Erases content from cells that have been selected in the table.
   *
   * @memberof Core#
   * @function emptySelectedCells
   * @param {string} [source] String that identifies how this change will be described in the changes array (useful in {@link Hooks#afterChange} or {@link Hooks#beforeChange} callbacks). Set to 'edit' if left empty.
   * @since 0.36.0
   * @fires Hooks#beforeChange
   * @fires Hooks#afterChange
   */ this.emptySelectedCells = function(source) {
        if (!selection.isSelected() || this.countRows() === 0 || this.countCols() === 0) {
            return;
        }
        const changes = [];
        (0, _array.arrayEach)(selection.getSelectedRange(), (cellRange)=>{
            if (cellRange.isSingleHeader()) {
                return;
            }
            const topStart = cellRange.getTopStartCorner();
            const bottomEnd = cellRange.getBottomEndCorner();
            const fromRow = Math.max(topStart.row, 0);
            const toRow = Math.min(bottomEnd.row, this.countRows() - 1);
            const fromColumn = Math.max(topStart.col, 0);
            const toColumn = Math.min(bottomEnd.col, this.countCols() - 1);
            if (fromRow > toRow || fromColumn > toColumn) {
                return;
            }
            const collectEmptyCellChanges = (row)=>{
                (0, _number.rangeEach)(fromColumn, toColumn, (column)=>{
                    // The transient read keeps clearing a large selection from permanently materializing
                    // one meta object per cell - only `readOnly` is read here.
                    if (!this.getCellMetaTransient(row, column).readOnly) {
                        changes.push([
                            row,
                            column,
                            null
                        ]);
                    }
                });
            };
            (0, _number.rangeEach)(fromRow, toRow, collectEmptyCellChanges);
        });
        if (changes.length > 0) {
            this.setDataAtCell(changes, source);
        }
    };
    /**
   * Checks if the table rendering process was suspended. See explanation in {@link Core#suspendRender}.
   *
   * @memberof Core#
   * @function isRenderSuspended
   * @since 8.3.0
   * @returns {boolean}
   */ this.isRenderSuspended = function() {
        return this.renderSuspendedCounter > 0;
    };
    /**
   * Suspends the rendering process. It's helpful to wrap the table render
   * cycles triggered by API calls or UI actions (or both) and call the "render"
   * once in the end. As a result, it improves the performance of wrapped operations.
   * When the table is in the suspend state, most operations will have no visual
   * effect until the rendering state is resumed. Resuming the state automatically
   * invokes the table rendering. To make sure that after executing all operations,
   * the table will be rendered, it's highly recommended to use the {@link Core#batchRender}
   * method or {@link Core#batch}, which additionally aggregates the logic execution
   * that happens behind the table.
   *
   * The method is intended to be used by advanced users. Suspending the rendering
   * process could cause visual glitches when wrongly implemented.
   *
   * Every [`suspendRender()`](@/api/core.md#suspendrender) call needs to correspond with one [`resumeRender()`](@/api/core.md#resumerender) call.
   * For example, if you call [`suspendRender()`](@/api/core.md#suspendrender) 5 times, you need to call [`resumeRender()`](@/api/core.md#resumerender) 5 times as well.
   *
   * @memberof Core#
   * @function suspendRender
   * @since 8.3.0
   * @example
   * ```js
   * hot.suspendRender();
   * hot.alter('insert_row_above', 5, 45);
   * hot.alter('insert_col_start', 10, 40);
   * hot.setDataAtCell(1, 1, 'John');
   * hot.setDataAtCell(2, 2, 'Mark');
   * hot.setDataAtCell(3, 3, 'Ann');
   * hot.setDataAtCell(4, 4, 'Sophia');
   * hot.setDataAtCell(5, 5, 'Mia');
   * hot.selectCell(0, 0);
   * hot.resumeRender(); // It re-renders the table internally
   * ```
   */ this.suspendRender = function() {
        this.renderSuspendedCounter += 1;
    };
    /**
   * Resumes the rendering process. In combination with the {@link Core#suspendRender}
   * method it allows aggregating the table render cycles triggered by API calls or UI
   * actions (or both) and calls the "render" once in the end. When the table is in
   * the suspend state, most operations will have no visual effect until the rendering
   * state is resumed. Resuming the state automatically invokes the table rendering.
   *
   * The method is intended to be used by advanced users. Suspending the rendering
   * process could cause visual glitches when wrongly implemented.
   *
   * Every [`suspendRender()`](@/api/core.md#suspendrender) call needs to correspond with one [`resumeRender()`](@/api/core.md#resumerender) call.
   * For example, if you call [`suspendRender()`](@/api/core.md#suspendrender) 5 times, you need to call [`resumeRender()`](@/api/core.md#resumerender) 5 times as well.
   *
   * @memberof Core#
   * @function resumeRender
   * @since 8.3.0
   * @example
   * ```js
   * hot.suspendRender();
   * hot.alter('insert_row_above', 5, 45);
   * hot.alter('insert_col_start', 10, 40);
   * hot.setDataAtCell(1, 1, 'John');
   * hot.setDataAtCell(2, 2, 'Mark');
   * hot.setDataAtCell(3, 3, 'Ann');
   * hot.setDataAtCell(4, 4, 'Sophia');
   * hot.setDataAtCell(5, 5, 'Mia');
   * hot.selectCell(0, 0);
   * hot.resumeRender(); // It re-renders the table internally
   * ```
   */ this.resumeRender = function() {
        const nextValue = this.renderSuspendedCounter - 1;
        this.renderSuspendedCounter = Math.max(nextValue, 0);
        if (!this.isRenderSuspended() && nextValue === this.renderSuspendedCounter) {
            instance.view.render();
        }
    };
    /**
   * Rerender the table. Calling this method starts the process of recalculating, redrawing and applying the changes
   * to the DOM. While rendering the table all cell renderers are recalled.
   *
   * Calling this method manually is not recommended. Handsontable tries to render itself by choosing the most
   * optimal moments in its lifecycle. After [setCellMeta()](@/api/core.md#setcellmeta) changes visual cell
   * properties, call this method to apply them, or wrap multiple calls in [batch()](@/api/core.md#batch).
   *
   * @memberof Core#
   * @function render
   */ this.render = function() {
        if (this.view) {
            // used when data was changed or when all cells need to be re-rendered (slow render)
            this.forceFullRender = true;
            if (!this.isRenderSuspended()) {
                instance.view.render();
            }
        }
    };
    /**
   * The method aggregates multi-line API calls into a callback and postpones the
   * table rendering process. After the execution of the operations, the table is
   * rendered once. As a result, it improves the performance of wrapped operations.
   * Without batching, a similar case could trigger multiple table render calls.
   *
   * @memberof Core#
   * @function batchRender
   * @param {Function} wrappedOperations Batched operations wrapped in a function.
   * @returns {*} Returns result from the wrappedOperations callback.
   * @since 8.3.0
   * @example
   * ```js
   * hot.batchRender(() => {
   *   hot.alter('insert_row_above', 5, 45);
   *   hot.alter('insert_col_start', 10, 40);
   *   hot.setDataAtCell(1, 1, 'John');
   *   hot.setDataAtCell(2, 2, 'Mark');
   *   hot.setDataAtCell(3, 3, 'Ann');
   *   hot.setDataAtCell(4, 4, 'Sophia');
   *   hot.setDataAtCell(5, 5, 'Mia');
   *   hot.selectCell(0, 0);
   *   // The table will be rendered once after executing the callback
   * });
   * ```
   */ this.batchRender = function(wrappedOperations) {
        instance.suspendRender();
        const result = wrappedOperations();
        instance.resumeRender();
        return result;
    };
    /**
   * Checks if the table indexes recalculation process was suspended. See explanation
   * in {@link Core#suspendExecution}.
   *
   * @memberof Core#
   * @function isExecutionSuspended
   * @since 8.3.0
   * @returns {boolean}
   */ this.isExecutionSuspended = function() {
        return this.executionSuspendedCounter > 0;
    };
    /**
   * Suspends the execution process. It's helpful to wrap the table logic changes
   * such as index changes into one call after which the cache is updated. As a result,
   * it improves the performance of wrapped operations.
   *
   * The method is intended to be used by advanced users. Suspending the execution
   * process could cause visual glitches caused by not updated the internal table cache.
   *
   * @memberof Core#
   * @function suspendExecution
   * @since 8.3.0
   * @example
   * ```js
   * hot.suspendExecution();
   * const filters = hot.getPlugin('filters');
   *
   * filters.addCondition(2, 'contains', ['3']);
   * filters.filter();
   * hot.getPlugin('columnSorting').sort({ column: 1, sortOrder: 'desc' });
   * hot.resumeExecution(); // It updates the cache internally
   * ```
   */ this.suspendExecution = function() {
        this.executionSuspendedCounter += 1;
        this.columnIndexMapper.suspendOperations();
        this.rowIndexMapper.suspendOperations();
    };
    /**
   * Resumes the execution process. In combination with the {@link Core#suspendExecution}
   * method it allows aggregating the table logic changes after which the cache is
   * updated. Resuming the state automatically invokes the table cache updating process.
   *
   * The method is intended to be used by advanced users. Suspending the execution
   * process could cause visual glitches caused by not updated the internal table cache.
   *
   * @memberof Core#
   * @function resumeExecution
   * @param {boolean} [forceFlushChanges=false] If `true`, the table internal data cache
   * is recalculated after the execution of the batched operations. For nested
   * {@link Core#batchExecution} calls, it can be desire to recalculate the table
   * after each batch.
   * @since 8.3.0
   * @example
   * ```js
   * hot.suspendExecution();
   * const filters = hot.getPlugin('filters');
   *
   * filters.addCondition(2, 'contains', ['3']);
   * filters.filter();
   * hot.getPlugin('columnSorting').sort({ column: 1, sortOrder: 'desc' });
   * hot.resumeExecution(); // It updates the cache internally
   * ```
   */ this.resumeExecution = function(forceFlushChanges = false) {
        const nextValue = this.executionSuspendedCounter - 1;
        this.executionSuspendedCounter = Math.max(nextValue, 0);
        if (!this.isExecutionSuspended() && nextValue === this.executionSuspendedCounter || forceFlushChanges) {
            this.columnIndexMapper.resumeOperations();
            this.rowIndexMapper.resumeOperations();
        }
    };
    /**
   * The method aggregates multi-line API calls into a callback and postpones the
   * table execution process. After the execution of the operations, the internal table
   * cache is recalculated once. As a result, it improves the performance of wrapped
   * operations. Without batching, a similar case could trigger multiple table cache rebuilds.
   *
   * @memberof Core#
   * @function batchExecution
   * @param {Function} wrappedOperations Batched operations wrapped in a function.
   * @param {boolean} [forceFlushChanges=false] If `true`, the table internal data cache
   * is recalculated after the execution of the batched operations. For nested calls,
   * it can be a desire to recalculate the table after each batch.
   * @returns {*} Returns result from the wrappedOperations callback.
   * @since 8.3.0
   * @example
   * ```js
   * hot.batchExecution(() => {
   *   const filters = hot.getPlugin('filters');
   *
   *   filters.addCondition(2, 'contains', ['3']);
   *   filters.filter();
   *   hot.getPlugin('columnSorting').sort({ column: 1, sortOrder: 'desc' });
   *   // The table cache will be recalculated once after executing the callback
   * });
   * ```
   */ this.batchExecution = function(wrappedOperations, forceFlushChanges = false) {
        instance.suspendExecution();
        const result = wrappedOperations();
        instance.resumeExecution(forceFlushChanges);
        return result;
    };
    /**
   * It batches the rendering process and index recalculations. The method aggregates
   * multi-line API calls into a callback and postpones the table rendering process
   * as well aggregates the table logic changes such as index changes into one call
   * after which the cache is updated. After the execution of the operations, the
   * table is rendered, and the cache is updated once. As a result, it improves the
   * performance of wrapped operations.
   *
   * @memberof Core#
   * @function batch
   * @param {Function} wrappedOperations Batched operations wrapped in a function.
   * @returns {*} Returns result from the wrappedOperations callback.
   * @since 8.3.0
   * @example
   * ```js
   * hot.batch(() => {
   *   hot.alter('insert_row_above', 5, 45);
   *   hot.alter('insert_col_start', 10, 40);
   *   hot.setDataAtCell(1, 1, 'x');
   *   hot.setDataAtCell(2, 2, 'c');
   *   hot.setDataAtCell(3, 3, 'v');
   *   hot.setDataAtCell(4, 4, 'b');
   *   hot.setDataAtCell(5, 5, 'n');
   *   hot.selectCell(0, 0);
   *
   *   const filters = hot.getPlugin('filters');
   *
   *   filters.addCondition(2, 'contains', ['3']);
   *   filters.filter();
   *   hot.getPlugin('columnSorting').sort({ column: 1, sortOrder: 'desc' });
   *   // The table will be re-rendered and cache will be recalculated once after executing the callback
   * });
   * ```
   */ this.batch = function(wrappedOperations) {
        instance.suspendRender();
        instance.suspendExecution();
        const result = wrappedOperations();
        instance.resumeExecution();
        instance.resumeRender();
        return result;
    };
    /**
   * Updates dimensions of the table. The method compares previous dimensions with the current ones and updates accordingly.
   *
   * @memberof Core#
   * @function refreshDimensions
   * @fires Hooks#beforeRefreshDimensions
   * @fires Hooks#afterRefreshDimensions
   */ this.refreshDimensions = function() {
        if (!instance.view) {
            return;
        }
        const view = instance.view;
        const { width: lastWidth, height: lastHeight } = view.getLastSize();
        const { width, height } = instance.rootElement.getBoundingClientRect();
        const isSizeChanged = width !== lastWidth || height !== lastHeight;
        const isResizeBlocked = instance.runHooks('beforeRefreshDimensions', {
            width: lastWidth,
            height: lastHeight
        }, {
            width,
            height
        }, isSizeChanged) === false;
        if (isResizeBlocked) {
            return;
        }
        if (isSizeChanged || view._wt.wtOverlays.scrollableElement === instance.rootWindow) {
            view.setLastSize(width, height);
            view.adjustElementsSize();
            instance.render();
        }
        instance.runHooks('afterRefreshDimensions', {
            width: lastWidth,
            height: lastHeight
        }, {
            width,
            height
        }, isSizeChanged);
    };
    /**
   * The `updateData()` method replaces Handsontable's [`data`](@/api/options.md#data) with a new dataset.
   *
   * The `updateData()` method:
   * - Keeps cells' states (e.g. cells' [formatting](@/guides/cell-features/formatting-cells/formatting-cells.md) and cells' [`readOnly`](@/api/options.md#readonly) states)
   * - Keeps rows' states (e.g. row order)
   * - Keeps columns' states (e.g. column order)
   *
   * To replace Handsontable's [`data`](@/api/options.md#data) and reset states, use the [`loadData()`](#loaddata) method.
   *
   * Read more:
   * - [Binding to data](@/guides/getting-started/binding-to-data/binding-to-data.md)
   * - [Saving data](@/guides/getting-started/saving-data/saving-data.md)
   *
   * @memberof Core#
   * @function updateData
   * @since 11.1.0
   * @param {Array} data An [array of arrays](@/guides/getting-started/binding-to-data/binding-to-data.md#array-of-arrays), or an [array of objects](@/guides/getting-started/binding-to-data/binding-to-data.md#array-of-objects), that contains Handsontable's data.
   * @param {string} [source] The source of the `updateData()` call.
   * @fires Hooks#beforeUpdateData
   * @fires Hooks#afterUpdateData
   * @fires Hooks#afterChange
   */ this.updateData = function(data, source) {
        (0, _dataMap.replaceData)(data, (newDataMap)=>{
            datamap = newDataMap;
        }, (newDataMap)=>{
            datamap = newDataMap;
            instance.columnIndexMapper.fitToLength(this.getInitialColumnCount());
            instance.rowIndexMapper.fitToLength(this.countSourceRows());
            grid.adjustRowsAndCols();
            selection.markSource('updateData');
            selection.refresh();
            selection.markEndSource();
        }, {
            hotInstance: instance,
            dataMap: datamap,
            dataSource,
            internalSource: 'updateData',
            source,
            metaManager,
            firstRun
        });
    };
    /**
   * The `loadData()` method replaces Handsontable's [`data`](@/api/options.md#data) with a new dataset.
   *
   * Additionally, the `loadData()` method:
   * - Resets cells' states (e.g. cells' [formatting](@/guides/cell-features/formatting-cells/formatting-cells.md) and cells' [`readOnly`](@/api/options.md#readonly) states)
   * - Resets rows' states (e.g. row order)
   * - Resets columns' states (e.g. column order)
   *
   * To replace Handsontable's [`data`](@/api/options.md#data) without resetting states, use the [`updateData()`](#updatedata) method.
   *
   * Read more:
   * - [Binding to data](@/guides/getting-started/binding-to-data/binding-to-data.md)
   * - [Saving data](@/guides/getting-started/saving-data/saving-data.md)
   *
   * @memberof Core#
   * @function loadData
   * @param {Array} data An [array of arrays](@/guides/getting-started/binding-to-data/binding-to-data.md#array-of-arrays), or an [array of objects](@/guides/getting-started/binding-to-data/binding-to-data.md#array-of-objects), that contains Handsontable's data.
   * @param {string} [source] The source of the `loadData()` call.
   * @fires Hooks#beforeLoadData
   * @fires Hooks#afterLoadData
   * @fires Hooks#afterChange
   */ this.loadData = function(data, source) {
        (0, _dataMap.replaceData)(data, (newDataMap)=>{
            datamap = newDataMap;
        }, ()=>{
            metaManager.clearCellsCache();
            instance.initIndexMappers();
            grid.adjustRowsAndCols();
            selection.markSource('loadData');
            selection.refresh();
            selection.markEndSource();
            if (firstRun) {
                firstRun = [
                    null,
                    'loadData'
                ];
            }
        }, {
            hotInstance: instance,
            dataMap: datamap,
            dataSource,
            internalSource: 'loadData',
            source,
            metaManager,
            firstRun
        });
    };
    /**
   * Gets the initial column count, calculated based on the `columns` setting.
   *
   * @private
   * @returns {number} The calculated number of columns.
   */ this.getInitialColumnCount = function() {
        const columnsSettings = tableMeta.columns;
        let finalNrOfColumns = 0;
        // We will check number of columns when the `columns` property was defined as an array. Columns option may
        // narrow down or expand displayed dataset in that case.
        if (Array.isArray(columnsSettings)) {
            finalNrOfColumns = columnsSettings.length;
        } else if ((0, _function.isFunction)(columnsSettings)) {
            if (instance.dataType === 'array') {
                const nrOfSourceColumns = instance.countSourceCols();
                for(let columnIndex = 0; columnIndex < nrOfSourceColumns; columnIndex += 1){
                    if (columnsSettings(columnIndex)) {
                        finalNrOfColumns += 1;
                    }
                }
            // Extended dataset by the `columns` property? Moved code right from the refactored `countCols` method.
            } else if (instance.dataType === 'object' || instance.dataType === 'function') {
                finalNrOfColumns = datamap.colToPropCache.length;
            }
        // In some cases we need to check columns length from the schema, i.e. `data` may be empty.
        } else if ((0, _mixed.isDefined)(tableMeta.dataSchema)) {
            const schema = datamap.getSchema();
            // Schema may be defined as an array of objects. Each object will define column.
            finalNrOfColumns = Array.isArray(schema) ? schema.length : (0, _object.deepObjectSize)(schema);
        } else {
            // We init index mappers by length of source data to provide indexes also for skipped indexes.
            finalNrOfColumns = instance.countSourceCols();
        }
        return finalNrOfColumns;
    };
    /**
   * Init index mapper which manage indexes assigned to the data.
   *
   * @private
   */ this.initIndexMappers = function() {
        this.columnIndexMapper.initToLength(this.getInitialColumnCount());
        this.rowIndexMapper.initToLength(this.countSourceRows());
    };
    /**
   * Returns the current visual data as a 2D array.
   *
   * Unlike the source data (which may be an array of objects), `getData()` always
   * returns an array of arrays regardless of the original data format. The returned
   * data reflects the current visual state of the grid: rows and columns are in their
   * current visual order, after any sorting, filtering, or reordering.
   *
   * To retrieve the data in its original source format, use the {@link Core#getSourceData} method instead.
   *
   * Optionally you can provide a cell range by defining `row`, `column`, `row2`, `column2`
   * to get only a fragment of the data.
   *
   * @memberof Core#
   * @function getData
   * @param {number} [row] From visual row index.
   * @param {number} [column] From visual column index.
   * @param {number} [row2] To visual row index.
   * @param {number} [column2] To visual column index.
   * @returns {Array[]} A 2D array of cell values in the current visual order.
   * @example
   * ```js
   * // Get all data (in order how it is rendered in the table).
   * hot.getData();
   * // Get data fragment (from top-left 0, 0 to bottom-right 3, 3).
   * hot.getData(3, 3);
   * // Get data fragment (from top-left 2, 1 to bottom-right 3, 3).
   * hot.getData(2, 1, 3, 3);
   * ```
   */ this.getData = function(row, column, row2, column2) {
        if ((0, _mixed.isUndefined)(row)) {
            return datamap.getAll();
        }
        return datamap.getRange(instance._createCellCoords(row, column), instance._createCellCoords(row2, column2), _dataMap1.default.DESTINATION_RENDERER);
    };
    /**
   * Returns a string value of the selected range. Each column is separated by tab, each row is separated by a new
   * line character.
   *
   * @memberof Core#
   * @function getCopyableText
   * @param {number} startRow From visual row index.
   * @param {number} startCol From visual column index.
   * @param {number} endRow To visual row index.
   * @param {number} endCol To visual column index.
   * @returns {string}
   */ this.getCopyableText = function(startRow, startCol, endRow, endCol) {
        return datamap.getCopyableText(instance._createCellCoords(startRow, startCol), instance._createCellCoords(endRow, endCol));
    };
    /**
   * Returns the data's copyable value at specified `row` and `column` index.
   *
   * @memberof Core#
   * @function getCopyableData
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @returns {string}
   */ this.getCopyableData = function(row, column) {
        return datamap.getCopyable(row, datamap.colToProp(column));
    };
    /**
   * Returns the source data's copyable value at specified `row` and `column` index.
   *
   * @memberof Core#
   * @function getCopyableSourceData
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @since 16.1.0
   * @returns {string}
   */ this.getCopyableSourceData = function(row, column) {
        return dataSource.getCopyable(row, datamap.colToProp(column));
    };
    /**
   * Returns schema provided by constructor settings. If it doesn't exist then it returns the schema based on the data
   * structure in the first row.
   *
   * @memberof Core#
   * @function getSchema
   * @returns {object} Schema object.
   */ this.getSchema = function() {
        return datamap.getSchema();
    };
    /**
   * Use it if you need to change configuration after initialization. The `settings` argument is an object containing the changed
   * settings, declared the same way as in the initial settings object.
   *
   * __Note__, that although the `updateSettings` method doesn't overwrite the previously declared settings, it might reset
   * the settings made post-initialization. (for example - ignore changes made using the columnResize feature).
   *
   * Passing `columns` inside the `settings` object resets the states corresponding to rows and columns
   * (for example, row/column sequence, column width, row height, frozen columns etc.). Passing `data` does not reset these states.
   *
   * After initialization, passing `data` calls [`updateData()`](@/api/core.md#updatedata) internally.
   * The resulting [`beforeUpdateData`](@/api/hooks.md#beforeupdatedata) and
   * [`afterUpdateData`](@/api/hooks.md#afterupdatedata) hooks receive `"updateSettings"` as their
   * `source`, while [`afterChange`](@/api/hooks.md#afterchange) receives `null` as its `changes`
   * argument and `"updateData"` as its `source`. If you call `updateSettings` with `data` inside
   * `afterChange`, check the hook's `source` to prevent an infinite loop.
   *
   * Cell meta set imperatively through [[setCellMeta]] (for example, by the user or the context menu) is preserved across
   * `updateSettings`, even when `settings` includes `cell`, `cells`, or `columns`. On a direct conflict, a value re-stated
   * through the declarative `cell` option takes precedence over the preserved imperative value.
   *
   * Cell meta set imperatively through [[setCellMeta]] (for example, by the user or the context menu) is preserved across
   * `updateSettings`, even when `settings` includes `cell`, `cells`, or `columns`. On a direct conflict, a value re-stated
   * through the declarative `cell` option takes precedence over the preserved imperative value.
   *
   * When [[Hooks#hasExternalDataSource]] is true, Handsontable clears and rebinds the placeholder dataset only during
   * initialization or when `settings` includes `data` or `dataProvider`. Other keys alone (for example `height`) do not clear loaded rows.
   * If only `columns` changes, the column map is rebuilt without clearing rows.
   *
   * @memberof Core#
   * @function updateSettings
   * @param {object} settings A settings object (see {@link Options}). Only provide the settings that are changed, not the whole settings object that was used for initialization.
   * @param {boolean} [init=false] Internally used during initialization.
   * @example
   * ```js
   * hot.updateSettings({
   *    contextMenu: true,
   *    colHeaders: true,
   *    fixedRowsTop: 2
   * });
   * ```
   * @fires Hooks#afterCellMetaReset
   * @fires Hooks#afterUpdateSettings
   */ this.updateSettings = function(settings, init = false) {
        const dataUpdateFunction = (firstRun ? instance.loadData : instance.updateData).bind(this);
        let i;
        let j;
        if ((0, _mixed.isDefined)(settings.rows)) {
            (0, _errors.throwWithCause)('The "rows" setting is no longer supported. Do you mean startRows, minRows or maxRows?');
        }
        if ((0, _mixed.isDefined)(settings.cols)) {
            (0, _errors.throwWithCause)('The "cols" setting is no longer supported. Do you mean startCols, minCols or maxCols?');
        }
        if ((0, _mixed.isDefined)(settings.ganttChart)) {
            (0, _errors.throwWithCause)('Since 8.0.0 the "ganttChart" setting is no longer supported.');
        }
        warnAboutRemovedOptions(settings);
        // The `columns` option (or the state its function form reads) may change in this call - drop
        // getColHeader's index translation cache so it rebuilds against the updated settings.
        columnsSettingIndexes = null;
        if ((0, _mixed.isDefined)(settings.rowHeights) && (0, _mixed.isDefined)(settings.minRowHeights)) {
            (0, _console.warn)('Both `rowHeights` and `minRowHeights` are defined in your configuration. ' + 'As one is the alias of the other, only one of them can be used at a time. ' + '`rowHeights` will be used as the row height configuration.');
        }
        // eslint-disable-next-line no-restricted-syntax
        for(i in settings){
            if (i === 'data' || i === 'language') {
            // Do nothing. loadData and language change will be triggered later
            } else if (i === 'className') {
                setClassName('className', settings.className);
            } else if (i === 'tableClassName' && instance.table) {
                setClassName('tableClassName', settings.tableClassName);
                instance.view._wt.wtOverlays.syncOverlayTableClassNames();
            } else if (_index.Hooks.getSingleton().isRegistered(i) || _index.Hooks.getSingleton().isDeprecated(i)) {
                const hook = settings[i];
                if ((0, _function.isFunction)(hook)) {
                    _index.Hooks.getSingleton().addAsFixed(i, hook, instance);
                    tableMeta[i] = hook;
                } else if (Array.isArray(hook)) {
                    _index.Hooks.getSingleton().add(i, hook, instance);
                    tableMeta[i] = hook;
                }
            } else if (!init && (0, _object.hasOwnProperty)(settings, i)) {
                globalMeta[i] = settings[i];
            }
        }
        const rootContainerThemeClassName = (0, _themes.getThemeClassName)(instance.rootContainer);
        const themeNameOptionExists = (0, _object.hasOwnProperty)(settings, 'themeName');
        const themeOptionExists = (0, _object.hasOwnProperty)(settings, 'theme');
        if (themeNameOptionExists && themeOptionExists) {
            (0, _console.warn)('Both `theme` and `themeName` are defined in your configuration. ' + 'These options are aliases and cannot be used together. ' + 'The `themeName` option will be ignored.');
        }
        // Update the theme via the `theme` or `themeName` option as a string or undefined.
        if (init) {
            let themeName;
            if (themeOptionExists && typeof settings.theme === 'string') {
                themeName = settings.theme;
            } else if (themeNameOptionExists && typeof settings.themeName === 'string' && settings.themeName && !themeOptionExists) {
                themeName = settings.themeName;
                tableMeta.theme = settings.themeName;
                tableMeta.themeName = undefined;
            } else if (rootContainerThemeClassName) {
                themeName = rootContainerThemeClassName;
            } else if (instance.themeManager) {
                themeName = instance.themeManager.getClassName();
            }
            instance.useTheme(themeName ?? null);
        } else {
            const currentThemeName = instance.getCurrentThemeName();
            // Use `theme` option if it's a string and differs from current theme (takes priority over `themeName`).
            if (themeOptionExists && typeof settings.theme === 'string' && currentThemeName !== settings.theme) {
                // `destroy()`, not `unmount()`. Unmounting removes the style node but leaves the manager
                // subscribed to the shared theme object, so the next theme change re-injects its scoped
                // rules and the grid gets stuck on whatever override the dead manager still holds.
                instance.themeManager?.destroy();
                instance.useTheme(settings.theme);
            // Use `themeName` option if `theme` is not provided and the name differs from current theme.
            } else if (themeNameOptionExists && !themeOptionExists && currentThemeName !== settings.themeName) {
                // `destroy()`, not `unmount()`. Unmounting removes the style node but leaves the manager
                // subscribed to the shared theme object, so the next theme change re-injects its scoped
                // rules and the grid gets stuck on whatever override the dead manager still holds.
                instance.themeManager?.destroy();
                tableMeta.theme = settings.themeName;
                tableMeta.themeName = undefined;
                instance.useTheme(settings.themeName);
            // Initialize or update the themeManager when theme is an object.
            } else if ((0, _rootInstance.isRootInstance)(instance) && !rootContainerThemeClassName && (0, _object.isObject)(settings.theme)) {
                if (instance.themeManager === null) {
                    // Read the overrides from `tableMeta`, not from this payload. The options may have been
                    // set by an earlier call, and the manager being rebuilt here starts with none of them.
                    initializeThemeManager(settings.theme, readStoredThemeOverrides());
                    instance.useTheme(instance.themeManager.getClassName());
                } else {
                    let themeObject;
                    if (typeof settings.theme.getThemeConfig !== 'function') {
                        themeObject = (0, _themes1.registerTheme)(settings.theme);
                    } else {
                        themeObject = settings.theme;
                    }
                    instance.themeManager.update(themeObject);
                    instance.useTheme(instance.themeManager.getClassName());
                }
            }
        }
        const themeOverridesChanged = applyThemeOverrides(settings, init);
        // Load data or create data map
        if (instance.runHooks('hasExternalDataSource') === true) {
            // When dataProvider is a complete server-backed config, ignore static data, the plugin loads rows.
            if (settings.data) {
                (0, _console.warn)('The "data" setting is ignored when "hasExternalDataSource" returns `true`.');
            }
            // Replace the in-memory placeholder only when the update touches init, `data`, or `dataProvider`. Otherwise
            // `updateData([], …)` would empty the grid without a refetch, because DataProvider runs `updatePlugin` only when
            // `dataProvider` is present in this payload.
            const shouldSyncExternalPlaceholderData = init || (0, _object.hasOwnProperty)(settings, 'data') || (0, _object.hasOwnProperty)(settings, 'dataProvider');
            if (shouldSyncExternalPlaceholderData) {
                dataUpdateFunction([], 'updateSettings');
            } else if (settings.columns !== undefined) {
                datamap.createMap();
                instance.initIndexMappers();
            }
        } else if (settings.data === undefined && tableMeta.data === undefined) {
            dataUpdateFunction(null, 'updateSettings'); // data source created just now
        } else if (settings.data !== undefined) {
            dataUpdateFunction(settings.data, 'updateSettings'); // data source given as option
        } else if (settings.columns !== undefined) {
            datamap.createMap();
            // The `column` property has changed - dataset may be expanded or narrowed down. The `loadData` do the same.
            instance.initIndexMappers();
        }
        if (!firstRun && settings.language) {
            setLanguage(settings.language);
        }
        const clen = instance.countCols();
        const columnSetting = tableMeta.columns;
        // Clear cell meta cache. Cell meta set imperatively through `setCellMeta` (for example, by the
        // user or the context menu) is snapshotted beforehand and replayed afterward, so that it
        // survives the clear instead of being discarded (see GitHub issue #4446).
        if (settings.cell !== undefined || settings.cells !== undefined || settings.columns !== undefined) {
            const userDefinedCellMetas = metaManager.getUserDefinedCellMetas();
            metaManager.clearCache();
            // Replay before the column and `cell` option re-application, so that a value re-stated through
            // the declarative `cell` option still wins on a direct conflict (preserving legacy behavior).
            userDefinedCellMetas.forEach(({ physicalRow, physicalColumn, key, value })=>{
                metaManager.setCellMeta(physicalRow, physicalColumn, key, value);
            });
        }
        if (clen > 0) {
            for(i = 0, j = 0; i < clen; i++){
                // Use settings provided by user
                if (columnSetting) {
                    const column = (0, _function.isFunction)(columnSetting) ? columnSetting(i) : columnSetting[j];
                    if (column) {
                        metaManager.updateColumnMeta(j, column);
                    }
                }
                j += 1;
            }
        }
        if ((0, _mixed.isDefined)(settings.cell)) {
            // The `cell` option is declarative - it is re-applied from settings on every `updateSettings`
            // call. Recording is disabled so these writes are not tracked as user-defined (and a key
            // re-stated here de-marks any imperative value), keeping `updateSettings({ cell: [] })` able
            // to remove previously declared entries.
            metaManager.disableUserDefinedMetaRecording();
            try {
                settings.cell.forEach((cell)=>{
                    instance.setCellMetaObject(cell.row, cell.col, cell);
                });
            } finally{
                metaManager.enableUserDefinedMetaRecording();
            }
        }
        instance.runHooks('afterCellMetaReset');
        // for the first run, we need to run the source data warnings after cell meta initialization
        // otherwise there is no access to `sourceDataValidator` function
        if (firstRun) {
            (0, _dataMap.runSourceDataValidators)(instance, 'init');
        }
        let currentHeight = instance.rootElement.style.height;
        if (currentHeight !== '') {
            currentHeight = parseInt(instance.rootElement.style.height, 10);
        }
        if (init) {
            const initialStyle = instance.rootElement.getAttribute('style');
            if (initialStyle) {
                instance.rootElement.dataset.initialstyle = instance.rootElement.getAttribute('style') ?? '';
            }
        }
        let height = settings.height;
        if (typeof settings.height !== 'undefined') {
            if ((0, _function.isFunction)(height)) {
                height = height();
            }
            height = instance.runHooks('beforeHeightChange', height);
            if (height === null) {
                const initialStyle = instance.rootElement.dataset.initialstyle;
                if (initialStyle && (initialStyle.indexOf('height') > -1 || initialStyle.indexOf('overflow') > -1)) {
                    instance.rootElement.setAttribute('style', initialStyle);
                } else {
                    instance.rootElement.style.height = '';
                    instance.rootElement.style.overflow = '';
                }
            } else if (height !== undefined) {
                instance.rootElement.style.height = isNaN(height) ? `${height}` : `${height}px`;
                instance.rootElement.style.overflow = 'clip';
            }
        }
        if (typeof settings.width !== 'undefined') {
            let width = settings.width;
            if ((0, _function.isFunction)(width)) {
                width = width();
            }
            width = instance.runHooks('beforeWidthChange', width);
            instance.rootElement.style.width = isNaN(width) ? `${width}` : `${width}px`;
        }
        // When height is absent the table uses window scroll, so the `overflow: clip` shorthand from the
        // height block is not applied. Set overflowX: clip to prevent the inner table from visually
        // overflowing a constrained width. Read the effective values from the DOM (after both height and
        // width blocks ran) so partial updateSettings calls see the correct state.
        // When height IS set, the height block's `overflow: clip` shorthand handles both axes — leave
        // overflowX untouched to avoid breaking that shorthand.
        // Only clip for a definite width. A relative width (`100%`, other percentages, viewport units,
        // or a `calc()` that mixes them in) fills its container, and content wider than that scrolls
        // with the window — matching the long-standing behavior where the page gains a horizontal
        // scrollbar and every column stays reachable. Clipping those would silently hide the off-width
        // columns with no scrollbar. A definite width (`px`, `em`, `rem`, and other absolute lengths)
        // establishes a fixed box the table must not visually overflow, so it is clipped.
        // Browser compatibility: `overflow-x: clip` requires Safari 16+. On Safari 14.1–15.x it silently
        // falls back to `visible` (graceful degradation — pre-existing behavior, not a new regression).
        if (typeof settings.height !== 'undefined' || typeof settings.width !== 'undefined') {
            const effectiveHeight = instance.rootElement.style.height;
            const effectiveWidth = instance.rootElement.style.width;
            // Relative: percentages and viewport units resolve against an ancestor, so a `%` or a viewport
            // unit (`vw`/`vh`/`vmin`/`vmax`, and dynamic `dvh`/`svh`/`lvh` via the `vh` match) anywhere —
            // including inside `calc()` — marks the width as container-driven. No word boundaries: the unit
            // is preceded by digits (`100vw`), which are word characters, so `\bv` would never match.
            const isRelativeWidth = /%|v(?:w|h|min|max)/i.test(effectiveWidth);
            const isDefiniteWidth = effectiveWidth !== '' && effectiveWidth !== 'auto' && !isRelativeWidth;
            if (!effectiveHeight) {
                const currentOverflowX = instance.rootElement.style.overflowX;
                // Only manage the overflow-x we own (`clip`) or that is unset. Preserve a user-defined
                // overflow (e.g. `overflow: hidden` restored from the initial style) so it is not stomped
                // by `clip`. Unlike `hidden`, `clip` creates no block formatting context and allows no
                // programmatic scroll.
                if (currentOverflowX === '' || currentOverflowX === 'clip') {
                    instance.rootElement.style.overflowX = isDefiniteWidth ? 'clip' : '';
                }
            }
        }
        if (!init) {
            if (instance.view) {
                instance.view._wt.wtViewport.resetHasOversizedColumnHeadersMarked();
                instance.view._wt.exportSettingsAsClassNames();
                instance.view.invalidateIndexSizesCache();
            }
            selection.updateHighlightClassNames();
            instance.runHooks('afterUpdateSettings', settings);
        }
        grid.adjustRowsAndCols();
        if (instance.view && !firstRun) {
            instance.render();
            instance.view._wt.wtOverlays.adjustElementsSize();
        }
        // Fired after the render above, so a listener reading cell sizes sees the new density. The
        // manager can be gone by now: an `afterUpdateSettings` listener is free to move the grid to a
        // class-name theme, which tears the engine down.
        if (themeOverridesChanged && instance.themeManager) {
            instance.runHooks('afterSetTheme', instance.themeManager.getClassName(), false);
        }
        if (!init && instance.view && (currentHeight === '' || height === '' || height === undefined) && currentHeight !== height) {
            instance.view._wt.wtOverlays.updateMainScrollableElements();
        }
        if ((0, _rootInstance.isRootInstance)(instance)) {
            layoutManager?.applyConfig(tableMeta.layout);
        }
    };
    /**
   * Gets the value of the currently focused cell.
   *
   * For column headers and row headers, returns `null`.
   *
   * @memberof Core#
   * @function getValue
   * @returns {*} The value of the focused cell.
   */ this.getValue = function() {
        const activeSelection = instance.getSelectedRangeActive();
        if (tableMeta.getValue) {
            if ((0, _function.isFunction)(tableMeta.getValue)) {
                return tableMeta.getValue.call(instance);
            } else if (activeSelection && typeof tableMeta.getValue === 'string') {
                const rowIndex = activeSelection.highlight.row ?? 0;
                const rowData = instance.getData()[rowIndex];
                return rowData[tableMeta.getValue];
            }
        } else if (activeSelection) {
            return instance.getDataAtCell(activeSelection.highlight.row, activeSelection.highlight.col);
        }
        return null;
    };
    /**
   * Returns the current global grid settings object.
   *
   * The returned object contains the settings passed to the constructor or the most recent
   * `updateSettings()` call. It reflects the
   * [grid-level](@/guides/getting-started/configuration-options/configuration-options.md#set-grid-options)
   * configuration only.
   *
   * It does not include merged per-cell or per-column values. Configuration options cascade from
   * grid to column to cell (see
   * [Cascading configuration](@/guides/getting-started/configuration-options/configuration-options.md#cascading-configuration)).
   * To read the effective value for a specific cell, use [[getCellMeta]]. To read column-level meta, use [[getColumnMeta]].
   *
   * @memberof Core#
   * @function getSettings
   * @returns {TableMeta} Object containing the current global grid settings.
   * @example
   * ```js
   * const hot = new Handsontable(container, {
   *   readOnly: false,
   *   columns: (index) => ({
   *     readOnly: index === 2 || index === 8,
   *   }),
   * });
   *
   * // returns `false` (global grid-level setting)
   * hot.getSettings().readOnly;
   *
   * // returns `true` for column 2 (merged column and cell meta)
   * hot.getCellMeta(0, 2).readOnly;
   * ```
   */ this.getSettings = function() {
        return tableMeta;
    };
    /**
   * Clears the data from the table (the table settings remain intact) and clears the current selection.
   *
   * @memberof Core#
   * @function clear
   */ this.clear = function() {
        this.selectAll();
        this.emptySelectedCells();
        this.deselectCell();
    };
    /**
   * The `alter()` method lets you alter the grid's structure
   * by adding or removing rows and columns at specified positions.
   *
   * ::: tip
   * If you use an array of objects in your [`data`](@/api/options.md#data), the column-related actions won't work.
   * :::
   *
   * ```js
   * // above row 10 (by visual index), insert 1 new row
   * hot.alter('insert_row_above', 10);
   * ```
   *
   *  | Action               | With `index` | Without `index` |
   *  | -------------------- | ------------ | --------------- |
   *  | `'insert_row_above'` | Inserts rows above the `index` row. | Inserts rows above the first row. |
   *  | `'insert_row_below'` | Inserts rows below the `index` row. | Inserts rows below the last row. |
   *  | `'remove_row'`       | Removes rows, starting from the `index` row. | Removes rows, starting from the last row. |
   *  | `'insert_col_start'` | Inserts columns before the `index` column. | Inserts columns before the first column. |
   *  | `'insert_col_end'`   | Inserts columns after the `index` column. | Inserts columns after the last column. |
   *  | `'remove_col'`       | Removes columns, starting from the `index` column. | Removes columns, starting from the last column. |
   *
   * Additional information about `'insert_col_start'` and `'insert_col_end'`:
   * - Their behavior depends on your [`layoutDirection`](@/api/options.md#layoutdirection).
   * - If the provided `index` is higher than the actual number of columns, Handsontable doesn't generate
   * the columns missing in between. Instead, the new columns are inserted next to the last column.
   *
   * @memberof Core#
   * @function alter
   * @param {string} action Available operations:
   * <ul>
   *    <li> `'insert_row_above'` </li>
   *    <li> `'insert_row_below'` </li>
   *    <li> `'remove_row'` </li> </li>
   *    <li> `'insert_col_start'` </li>
   *    <li> `'insert_col_end'` </li>
   *    <li> `'remove_col'` </li>
   * </ul>
   * @param {number|number[]} [index] A visual index of the row/column before or after which the new row/column will be
   *                                inserted or removed. Can also be an array of arrays, in format `[[index, amount],...]`.
   * @param {number} [amount] The amount of rows or columns to be inserted or removed (default: `1`).
   * @param {string} [source] Source indicator passed to related hooks.
   * @param {boolean} [keepEmptyRows] If set to `true`, skips the automatic adjustment that normally adds empty rows
   *                                  or columns after the operation to satisfy `minRows`, `minSpareRows`,
   *                                  `minCols`, or `minSpareCols`.
   * @example
   * ```js
   * // above row 10 (by visual index), insert 1 new row
   * hot.alter('insert_row_above', 10);
   *
   * // below row 10 (by visual index), insert 3 new rows
   * hot.alter('insert_row_below', 10, 3);
   *
   * // in the LTR layout direction: to the left of column 10 (by visual index), insert 3 new columns
   * // in the RTL layout direction: to the right of column 10 (by visual index), insert 3 new columns
   * hot.alter('insert_col_start', 10, 3);
   *
   * // in the LTR layout direction: to the right of column 10 (by visual index), insert 1 new column
   * // in the RTL layout direction: to the left of column 10 (by visual index), insert 1 new column
   * hot.alter('insert_col_end', 10);
   *
   * // remove 2 rows, starting from row 10 (by visual index)
   * hot.alter('remove_row', 10, 2);
   *
   * // remove 2 columns, starting from column 3 (by visual index)
   * hot.alter('remove_col', 3, 2);
   *
   * // remove 3 rows, starting from row 1 (by visual index)
   * // remove 2 rows, starting from row 5 (by visual index)
   * hot.alter('remove_row', [[1, 3], [5, 2]]);
   *
   * // pass a custom source string to hooks
   * hot.addHook('afterCreateRow', (index, amount, source) => {
   *   if (source === 'inventory-import') {
   *     // Run logic only for rows created by the inventory import.
   *   }
   * });
   * hot.alter('insert_row_above', 0, 1, 'inventory-import');
   *
   * // remove a row without immediately adding empty rows required by `minRows` or `minSpareRows`
   * hot.alter('remove_row', 4, 1, 'inventory-cleanup', true);
   * ```
   */ this.alter = function(action, index, amount, source, keepEmptyRows) {
        grid.alter(action, index, amount, source, keepEmptyRows);
    };
    /**
   * Returns a TD element for the given `row` and `column` arguments, if it is rendered on screen.
   * Returns `null` if the TD is not rendered on screen (probably because that part of the table is not visible).
   *
   * @memberof Core#
   * @function getCell
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {boolean} [topmost=false] If set to `true`, it returns the TD element from the topmost overlay. For example,
   * if the wanted cell is in the range of fixed rows, it will return a TD element from the `top` overlay.
   * @returns {HTMLTableCellElement|null} The cell's TD element.
   */ this.getCell = function(row, column, topmost = false) {
        let renderableColumnIndex = column; // Handling also column headers.
        let renderableRowIndex = row; // Handling also row headers.
        if (column >= 0) {
            if (instance.columnIndexMapper.isHidden(instance.toPhysicalColumn(column))) {
                return null;
            }
            renderableColumnIndex = instance.columnIndexMapper.getRenderableFromVisualIndex(column);
        }
        if (row >= 0) {
            if (instance.rowIndexMapper.isHidden(instance.toPhysicalRow(row))) {
                return null;
            }
            renderableRowIndex = instance.rowIndexMapper.getRenderableFromVisualIndex(row);
        }
        if (renderableRowIndex === null || renderableColumnIndex === null || renderableRowIndex === undefined || renderableColumnIndex === undefined) {
            return null;
        }
        return instance.view.getCellAtCoords(instance._createCellCoords(renderableRowIndex, renderableColumnIndex), topmost);
    };
    /**
   * Returns the coordinates of the cell, provided as a HTML table cell element.
   *
   * @memberof Core#
   * @function getCoords
   * @param {HTMLTableCellElement} element The HTML Element representing the cell.
   * @returns {CellCoords|null} Visual coordinates object.
   * @example
   * ```js
   * hot.getCoords(hot.getCell(1, 1));
   * // it returns CellCoords object instance with props row: 1 and col: 1.
   * ```
   */ this.getCoords = function(element) {
        const renderableCoords = instance.view._wt.wtTable.getCoords(element);
        if (renderableCoords === null) {
            return null;
        }
        const { row: renderableRow, col: renderableColumn } = renderableCoords;
        let visualRow = renderableRow;
        let visualColumn = renderableColumn;
        if (renderableRow !== null && renderableRow >= 0) {
            visualRow = instance.rowIndexMapper.getVisualFromRenderableIndex(renderableRow);
        }
        if (renderableColumn !== null && renderableColumn >= 0) {
            visualColumn = instance.columnIndexMapper.getVisualFromRenderableIndex(renderableColumn);
        }
        return instance._createCellCoords(visualRow, visualColumn);
    };
    /**
   * Returns the property name that corresponds with the given column index.
   * If the data source is an array of arrays, it returns the columns index.
   *
   * @memberof Core#
   * @function colToProp
   * @param {number} column Visual column index.
   * @returns {string|number} Column property or physical column index.
   */ this.colToProp = function(column) {
        return datamap.colToProp(column);
    };
    /**
   * Returns column index that corresponds with the given property.
   *
   * @memberof Core#
   * @function propToCol
   * @param {string|number} prop Property name or physical column index.
   * @returns {number} Visual column index.
   */ this.propToCol = function(prop) {
        return datamap.propToCol(prop);
    };
    /**
   * Translate physical row index into visual.
   *
   * This method is useful when you want to retrieve visual row index which can be reordered, moved or trimmed
   * based on a physical index.
   *
   * @memberof Core#
   * @function toVisualRow
   * @param {number} row Physical row index.
   * @returns {number} Returns visual row index.
   */ this.toVisualRow = (row)=>instance.rowIndexMapper.getVisualFromPhysicalIndex(row);
    /**
   * Translate physical column index into visual.
   *
   * This method is useful when you want to retrieve visual column index which can be reordered, moved or trimmed
   * based on a physical index.
   *
   * @memberof Core#
   * @function toVisualColumn
   * @param {number} column Physical column index.
   * @returns {number} Returns visual column index.
   */ this.toVisualColumn = (column)=>instance.columnIndexMapper.getVisualFromPhysicalIndex(column);
    /**
   * Translate visual row index into physical.
   *
   * This method is useful when you want to retrieve physical row index based on a visual index which can be
   * reordered, moved or trimmed.
   *
   * @memberof Core#
   * @function toPhysicalRow
   * @param {number} row Visual row index.
   * @returns {number} Returns physical row index.
   */ this.toPhysicalRow = (row)=>instance.rowIndexMapper.getPhysicalFromVisualIndex(row);
    /**
   * Translate visual column index into physical.
   *
   * This method is useful when you want to retrieve physical column index based on a visual index which can be
   * reordered, moved or trimmed.
   *
   * @memberof Core#
   * @function toPhysicalColumn
   * @param {number} column Visual column index.
   * @returns {number} Returns physical column index.
   */ this.toPhysicalColumn = (column)=>instance.columnIndexMapper.getPhysicalFromVisualIndex(column);
    /**
   * @description
   * Returns the cell value at `row`, `column`.
   *
   * __Note__: If data is reordered, sorted or trimmed, the currently visible order will be used.
   *
   * @memberof Core#
   * @function getDataAtCell
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @returns {*} Data at cell.
   */ this.getDataAtCell = function(row, column) {
        return datamap.get(row, datamap.colToProp(column));
    };
    /**
   * Returns value at visual `row` and `prop` indexes.
   *
   * __Note__: If data is reordered, sorted or trimmed, the currently visible order will be used.
   *
   * @memberof Core#
   * @function getDataAtRowProp
   * @param {number} row Visual row index.
   * @param {string} prop Property name.
   * @returns {*} Cell value.
   */ this.getDataAtRowProp = function(row, prop) {
        return datamap.get(row, prop);
    };
    /**
   * @description
   * Returns array of column values from the data source.
   *
   * __Note__: If columns were reordered or sorted, the currently visible order will be used.
   *
   * @memberof Core#
   * @function getDataAtCol
   * @param {number} column Visual column index.
   * @returns {Array} Array of cell values.
   */ this.getDataAtCol = function(column) {
        const columnData = [];
        const dataByRows = datamap.getRange(instance._createCellCoords(0, column), instance._createCellCoords(tableMeta.data.length - 1, column), _dataMap1.default.DESTINATION_RENDERER);
        for(let i = 0; i < dataByRows.length; i += 1){
            for(let j = 0; j < dataByRows[i].length; j += 1){
                columnData.push(dataByRows[i][j]);
            }
        }
        return columnData;
    };
    /**
   * Given the object property name (e.g. `'first.name'` or `'0'`), returns an array of column's values from the table data.
   * You can also provide a column index as the first argument.
   *
   * @memberof Core#
   * @function getDataAtProp
   * @param {string|number} prop Property name or physical column index.
   * @returns {Array} Array of cell values.
   */ // TODO: Getting data from `datamap` should work on visual indexes.
    this.getDataAtProp = function(prop) {
        const columnData = [];
        const dataByRows = datamap.getRange(instance._createCellCoords(0, datamap.propToCol(prop)), instance._createCellCoords(tableMeta.data.length - 1, datamap.propToCol(prop)), _dataMap1.default.DESTINATION_RENDERER);
        for(let i = 0; i < dataByRows.length; i += 1){
            for(let j = 0; j < dataByRows[i].length; j += 1){
                columnData.push(dataByRows[i][j]);
            }
        }
        return columnData;
    };
    /**
   * Returns a clone of the source data object.
   * Optionally you can provide a cell range by using the `row`, `column`, `row2`, `column2` arguments, to get only a
   * fragment of the table data.
   *
   * __Note__: This method does not participate in data transformation. If the visual data of the table is reordered,
   * sorted or trimmed only physical indexes are correct.
   *
   * __Note__: This method may return incorrect values for cells that contain
   * [formulas](@/guides/formulas/formula-calculation/formula-calculation.md). This is because `getSourceData()`
   * operates on source data ([physical indexes](@/api/indexMapper.md)),
   * whereas formulas operate on visual data (visual indexes).
   *
   * @memberof Core#
   * @function getSourceData
   * @param {number} [row] From physical row index.
   * @param {number} [column] From physical column index (or visual index, if data type is an array of objects).
   * @param {number} [row2] To physical row index.
   * @param {number} [column2] To physical column index (or visual index, if data type is an array of objects).
   * @returns {Array[]|object[]} The table data.
   */ this.getSourceData = function(row, column, row2, column2) {
        let data;
        if (row === undefined) {
            data = dataSource.getData();
        } else {
            data = dataSource.getByRange(instance._createCellCoords(row, column ?? null), instance._createCellCoords(row2 ?? null, column2 ?? null));
        }
        return data;
    };
    /**
   * Returns the source data object as an arrays of arrays format even when source data was provided in another format.
   * Optionally you can provide a cell range by using the `row`, `column`, `row2`, `column2` arguments, to get only a
   * fragment of the table data.
   *
   * __Note__: This method does not participate in data transformation. If the visual data of the table is reordered,
   * sorted or trimmed only physical indexes are correct.
   *
   * @memberof Core#
   * @function getSourceDataArray
   * @param {number} [row] From physical row index.
   * @param {number} [column] From physical column index (or visual index, if data type is an array of objects).
   * @param {number} [row2] To physical row index.
   * @param {number} [column2] To physical column index (or visual index, if data type is an array of objects).
   * @returns {Array} An array of arrays.
   */ this.getSourceDataArray = function(row, column, row2, column2) {
        let data;
        if (row === undefined) {
            data = dataSource.getData(true);
        } else {
            data = dataSource.getByRange(instance._createCellCoords(row, column ?? null), instance._createCellCoords(row2 ?? null, column2 ?? null), true);
        }
        return data;
    };
    /**
   * Returns an array of column values from the data source.
   *
   * @memberof Core#
   * @function getSourceDataAtCol
   * @param {number} column Visual column index.
   * @returns {Array} Array of the column's cell values.
   */ // TODO: Getting data from `sourceData` should work always on physical indexes.
    this.getSourceDataAtCol = function(column) {
        return dataSource.getAtColumn(column);
    };
    /**
   * Set the provided value in the source data set at the provided coordinates.
   *
   * @memberof Core#
   * @function setSourceDataAtCell
   * @param {number|Array} row Physical row index or array of changes in format `[[row, prop, value], ...]`.
   * @param {number|string} column Physical column index / prop name.
   * @param {*} value The value to be set at the provided coordinates.
   * @param {string} [source] Source of the change as a string.
   */ this.setSourceDataAtCell = function(row, column, value, source) {
        const input = setDataInputToArray(row, column, value);
        const isThereAnySetSourceListener = instance.hasHook('afterSetSourceDataAtCell');
        const changesForHook = [];
        const getCellProperties = (changeRow, changeProp)=>{
            const visualRow = instance.toVisualRow(changeRow);
            const visualColumn = instance.toVisualColumn(changeProp);
            if (Number.isInteger(visualColumn)) {
                // The transient read keeps a bulk source-data write from permanently materializing one
                // meta object per changed cell - the meta only feeds the `valueSetter` and the
                // source-data validator, both read-only.
                return instance.getCellMetaTransient(visualRow, visualColumn);
            }
            // If there's no requested visual column, we can use the table meta as the cell properties.
            // The snapshot lacks the per-cell coordinate properties, but every consumer here reads
            // settings-level keys only.
            return {
                ...Object.getPrototypeOf(tableMeta),
                ...tableMeta
            };
        };
        if (isThereAnySetSourceListener) {
            (0, _array.arrayEach)(input, ([changeRow, changeProp, changeValue])=>{
                const newValue = (0, _valueAccessors.getValueSetterValue)(changeValue, getCellProperties(changeRow, changeProp));
                changesForHook.push([
                    changeRow,
                    changeProp,
                    dataSource.getAtCell(changeRow, changeProp),
                    newValue
                ]);
            });
        }
        (0, _array.arrayEach)(input, ([changeRow, changeProp, changeValue])=>{
            const cellMeta = getCellProperties(changeRow, changeProp);
            const newValue = (0, _valueAccessors.getValueSetterValue)(changeValue, cellMeta);
            if ((0, _dataMap.runSourceDataValidator)(newValue, cellMeta, source ?? 'setSourceDataAtCell')) {
                // changeProp is a physical column index for array-based data sources.
                dataSource.setAtCell(changeRow, changeProp, newValue);
            }
        });
        if (isThereAnySetSourceListener) {
            this.runHooks('afterSetSourceDataAtCell', changesForHook, source);
        }
        this.render();
        const activeEditor = instance.getActiveEditor();
        if (activeEditor && (0, _mixed.isDefined)(activeEditor.refreshValue)) {
            activeEditor.refreshValue();
        }
    };
    /**
   * Returns a single row of the data (array or object, depending on what data format you use).
   *
   * __Note__: This method does not participate in data transformation. If the visual data of the table is reordered,
   * sorted or trimmed only physical indexes are correct.
   *
   * @memberof Core#
   * @function getSourceDataAtRow
   * @param {number} row Physical row index.
   * @returns {Array|object} Single row of data.
   */ this.getSourceDataAtRow = function(row) {
        return dataSource.getAtRow(row);
    };
    /**
   * Returns a single value from the data source.
   *
   * @memberof Core#
   * @function getSourceDataAtCell
   * @param {number} row Physical row index.
   * @param {number} column Visual column index.
   * @returns {*} Cell data.
   */ // TODO: Getting data from `sourceData` should work always on physical indexes.
    this.getSourceDataAtCell = function(row, column) {
        return dataSource.getAtCell(row, column);
    };
    /**
   * @description
   * Returns a single row of the data.
   *
   * __Note__: If rows were reordered, sorted or trimmed, the currently visible order will be used.
   *
   * @memberof Core#
   * @function getDataAtRow
   * @param {number} row Visual row index.
   * @returns {Array} Array of row's cell data.
   */ this.getDataAtRow = function(row) {
        const data = datamap.getRange(instance._createCellCoords(row, 0), instance._createCellCoords(row, this.countCols() - 1), _dataMap1.default.DESTINATION_RENDERER);
        return data[0] || [];
    };
    /**
   * @description
   * Returns a data type defined in the Handsontable settings under the `type` key ({@link Options#type}).
   * If there are cells with different types in the selected range, it returns `'mixed'`.
   *
   * __Note__: If data is reordered, sorted or trimmed, the currently visible order will be used.
   *
   * @memberof Core#
   * @function getDataType
   * @param {number} rowFrom From visual row index.
   * @param {number} columnFrom From visual column index.
   * @param {number} rowTo To visual row index.
   * @param {number} columnTo To visual column index.
   * @returns {string} Cell type (e.q: `'mixed'`, `'text'`, `'numeric'`, `'autocomplete'`).
   */ this.getDataType = function(rowFrom, columnFrom, rowTo, columnTo) {
        const coords = rowFrom === undefined ? [
            0,
            0,
            instance.countRows(),
            instance.countCols()
        ] : [
            rowFrom,
            columnFrom,
            rowTo,
            columnTo
        ];
        const [rowStart, columnStart] = coords;
        let [, , rowEnd, columnEnd] = coords;
        let previousType = null;
        let currentType = null;
        if (rowEnd === undefined) {
            rowEnd = rowStart;
        }
        if (columnEnd === undefined) {
            columnEnd = columnStart;
        }
        let type = 'mixed';
        (0, _number.rangeEach)(Math.max(Math.min(rowStart, rowEnd), 0), Math.max(rowStart, rowEnd), (row)=>{
            let isTypeEqual = true;
            (0, _number.rangeEach)(Math.max(Math.min(columnStart, columnEnd), 0), Math.max(columnStart, columnEnd), (column)=>{
                const cellType = instance.getCellMetaTransient(row, column);
                currentType = cellType.type ?? null;
                if (previousType) {
                    isTypeEqual = previousType === currentType;
                } else {
                    previousType = currentType;
                }
                return isTypeEqual;
            });
            type = isTypeEqual ? currentType ?? 'mixed' : 'mixed';
            return isTypeEqual;
        });
        return type;
    };
    /**
   * Remove a property defined by the `key` argument from the cell meta object for the provided `row` and `column` coordinates.
   *
   * @memberof Core#
   * @function removeCellMeta
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {string} key Property name.
   * @fires Hooks#beforeRemoveCellMeta
   * @fires Hooks#afterRemoveCellMeta
   */ this.removeCellMeta = function(row, column, key) {
        const [physicalRow, physicalColumn] = [
            instance.toPhysicalRow(row),
            instance.toPhysicalColumn(column)
        ];
        let cachedValue = metaManager.getCellMetaKeyValue(physicalRow, physicalColumn, key);
        const hookResult = instance.runHooks('beforeRemoveCellMeta', row, column, key, cachedValue);
        if (hookResult !== false) {
            metaManager.removeCellMeta(physicalRow, physicalColumn, key);
            instance.runHooks('afterRemoveCellMeta', row, column, key, cachedValue);
        }
        cachedValue = null;
    };
    /**
   * Removes or adds one or more rows of the cell meta objects to the cell meta collections.
   *
   * @since 0.30.0
   * @memberof Core#
   * @function spliceCellsMeta
   * @param {number} visualIndex A visual index that specifies at what position to add/remove items.
   * @param {number} [deleteAmount=0] The number of items to be removed. If set to 0, no cell meta objects will be removed.
   * @param {...object} [cellMetaRows] The new cell meta row objects to be added to the cell meta collection.
   */ this.spliceCellsMeta = function(visualIndex, deleteAmount = 0, ...cellMetaRows) {
        if (cellMetaRows.length > 0 && !Array.isArray(cellMetaRows[0])) {
            (0, _errors.throwWithCause)('The 3rd argument (cellMetaRows) has to be passed as an array of cell meta objects array.');
        }
        if (deleteAmount > 0) {
            metaManager.removeRow(instance.toPhysicalRow(visualIndex), deleteAmount);
        }
        if (cellMetaRows.length > 0) {
            (0, _array.arrayEach)(cellMetaRows.reverse(), (cellMetaRow)=>{
                metaManager.createRow(instance.toPhysicalRow(visualIndex));
                (0, _array.arrayEach)(cellMetaRow, (cellMeta, columnIndex)=>{
                    this.setCellMetaObject(visualIndex, columnIndex, cellMeta);
                });
            });
        }
        instance.render();
    };
    /**
   * Set cell meta data object defined by `prop` to the corresponding params `row` and `column`.
   *
   * @memberof Core#
   * @function setCellMetaObject
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {object} prop Meta object.
   */ this.setCellMetaObject = function(row, column, prop) {
        if (typeof prop === 'object') {
            (0, _object.objectEach)(prop, (value, key)=>{
                this.setCellMeta(row, column, key, value);
            });
        }
    };
    /**
   * Writes a configuration-derived cell meta value declaratively. The value is applied to the cell meta
   * (so it is retained while the cell is released from the viewport by the meta eviction), but is NOT
   * recorded as user-defined, so an `updateSettings` cache reset clears it and it is re-applied from the
   * current configuration - exactly like the `cell` option. Used by built-in plugins that derive cell
   * meta from their own configuration (for example ColumnSummary) and re-apply it on each update.
   *
   * Unlike the public `setCellMeta`, this does NOT fire `beforeSetCellMeta`/`afterSetCellMeta` and is
   * not vetoable: the write is plugin-internal render state the user never requested, so it must not
   * surface through public hooks or be blocked by a `beforeSetCellMeta` veto. This matches the direct
   * meta-object write these plugins used before the viewport meta eviction was introduced.
   *
   * Internal API: deliberately NOT declared on the public `HotInstance` type (`core/types.ts`), so it
   * is not exposed to third-party code or the published `.d.ts`. Built-in consumers reach it through a
   * local internal type (see `HotInstanceInternal` in the ColumnSummary plugin). Do not add it to
   * `HotInstance` - that would turn an implementation detail into a supported public API.
   *
   * @private
   * @memberof Core#
   * @function _setCellMetaDeclarative
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {string} key The property name to set.
   * @param {*} value The value to write.
   */ this._setCellMetaDeclarative = function(row, column, key, value) {
        let physicalRow = row;
        let physicalColumn = column;
        if (row < instance.countRows()) {
            physicalRow = instance.toPhysicalRow(row);
        }
        if (column < instance.countCols()) {
            physicalColumn = instance.toPhysicalColumn(column);
        }
        metaManager.disableUserDefinedMetaRecording();
        try {
            metaManager.setCellMeta(physicalRow, physicalColumn, key, value);
        } finally{
            metaManager.enableUserDefinedMetaRecording();
        }
    };
    /**
   * Sets a property defined by the `key` property to the meta object of a cell corresponding to params `row` and `column`.
   *
   * This method updates internal cell metadata only. It does not repaint the grid. To reflect visual changes (such as
   * `className`, `type`, or `readOnly`), call [render()](@/api/core.md#render) afterward, or wrap multiple calls in
   * [batch()](@/api/core.md#batch).
   *
   * @memberof Core#
   * @function setCellMeta
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {string} key Property name.
   * @param {string} value Property value.
   * @fires Hooks#beforeSetCellMeta
   * @fires Hooks#afterSetCellMeta
   */ this.setCellMeta = function(row, column, key, value) {
        const allowSetCellMeta = instance.runHooks('beforeSetCellMeta', row, column, key, value);
        if (allowSetCellMeta === false) {
            return;
        }
        let physicalRow = row;
        let physicalColumn = column;
        if (row < instance.countRows()) {
            physicalRow = instance.toPhysicalRow(row);
        }
        if (column < instance.countCols()) {
            physicalColumn = instance.toPhysicalColumn(column);
        }
        metaManager.setCellMeta(physicalRow, physicalColumn, key, value);
        instance.runHooks('afterSetCellMeta', row, column, key, value);
    };
    /**
   * Get all the cells meta settings at least once generated in the table (in order of cell initialization).
   *
   * @memberof Core#
   * @function getCellsMeta
   * @returns {Array} Returns an array of ColumnSettings object instances.
   */ this.getCellsMeta = function() {
        return metaManager.getCellsMeta();
    };
    /**
   * Returns the cell properties object for the given `row` and `column` coordinates.
   *
   * The returned object reflects the effective cell configuration after
   * [cascading configuration](@/guides/getting-started/configuration-options/configuration-options.md#cascading-configuration)
   * (grid, column, and cell levels). To read global grid settings only, use [[getSettings]].
   * To read column-level meta, use [[getColumnMeta]].
   *
   * @memberof Core#
   * @function getCellMeta
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {object} options Execution options for the `getCellMeta` method.
   * @param {boolean} [options.skipMetaExtension=false] If `true`, skips extending the cell meta object. This means, the `cells` function, as well as the `afterGetCellMeta` and `beforeGetCellMeta` hooks, will not be called.
   * @returns {object} The cell properties object.
   * @fires Hooks#beforeGetCellMeta
   * @fires Hooks#afterGetCellMeta
   */ this.getCellMeta = function(row, column, options = {
        skipMetaExtension: false
    }) {
        let physicalRow = instance.toPhysicalRow(row);
        let physicalColumn = instance.toPhysicalColumn(column);
        if (physicalRow === null) {
            physicalRow = row;
        }
        if (physicalColumn === null) {
            physicalColumn = column;
        }
        return metaManager.getCellMeta(physicalRow, physicalColumn, {
            visualRow: row,
            visualColumn: column,
            ...options
        });
    };
    /**
   * Returns the cell properties object for the given `row` and `column` coordinates without
   * retaining it in the cell meta cache.
   *
   * Like [[getCellMeta]], the returned object reflects the effective cell configuration after
   * [cascading configuration](@/guides/getting-started/configuration-options/configuration-options.md#cascading-configuration)
   * and dynamic extension (the `cells` function and the `beforeGetCellMeta`/`afterGetCellMeta`
   * hooks run). Unlike `getCellMeta`, when the cell has no stored meta object the extension runs
   * on a temporary object that is not saved, so scanning many cells (for example, a whole column
   * or the entire dataset) does not permanently allocate one meta object per visited cell. Cells
   * that already carry stored meta (for example, written by [[setCellMeta]] or the `cell` option)
   * return their stored object, exactly as `getCellMeta` would.
   *
   * Use this method for read-only bulk scans. Do not write to the returned object - for cells
   * without stored meta the write lands on the temporary object and is lost; use `setCellMeta`
   * to persist values.
   *
   * @memberof Core#
   * @function getCellMetaTransient
   * @since 18.1.0
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @returns {object} The cell properties object.
   * @fires Hooks#beforeGetCellMeta
   * @fires Hooks#afterGetCellMeta
   */ this.getCellMetaTransient = function(row, column) {
        let physicalRow = instance.toPhysicalRow(row);
        let physicalColumn = instance.toPhysicalColumn(column);
        if (physicalRow === null) {
            physicalRow = row;
        }
        if (physicalColumn === null) {
            physicalColumn = column;
        }
        return metaManager.getCellMetaTransient(physicalRow, physicalColumn, {
            visualRow: row,
            visualColumn: column
        });
    };
    /**
   * Returns the meta information for the provided column.
   *
   * The returned object reflects the column-level configuration after
   * [cascading configuration](@/guides/getting-started/configuration-options/configuration-options.md#cascading-configuration)
   * (grid and column levels). To read global grid settings only, use [[getSettings]].
   * To read the effective configuration for a specific cell, use [[getCellMeta]].
   *
   * @since 14.5.0
   * @memberof Core#
   * @function getColumnMeta
   * @param {number} column Visual column index.
   * @returns {object}
   */ this.getColumnMeta = function(column) {
        return metaManager.getColumnMeta(instance.toPhysicalColumn(column));
    };
    /**
   * Returns an array of cell meta objects for specified physical row index.
   *
   * @memberof Core#
   * @function getCellMetaAtRow
   * @param {number} row Physical row index.
   * @returns {Array}
   */ this.getCellMetaAtRow = function(row) {
        return metaManager.getCellsMetaAtRow(row);
    };
    /**
   * Checks if your [data format](@/guides/getting-started/binding-to-data/binding-to-data.md#compatible-data-types)
   * and [configuration options](@/guides/getting-started/configuration-options/configuration-options.md)
   * allow for changing the number of columns.
   *
   * Returns `false` when your data is an array of objects,
   * or when you use the [`columns`](@/api/options.md#columns) option.
   * Otherwise, returns `true`.
   *
   * @memberof Core#
   * @function isColumnModificationAllowed
   * @returns {boolean}
   */ this.isColumnModificationAllowed = function() {
        return !(instance.dataType === 'object' || tableMeta.columns);
    };
    /**
   * Returns the cell renderer function by given `row` and `column` arguments.
   *
   * @memberof Core#
   * @function getCellRenderer
   * @param {number|object} rowOrMeta Visual row index or cell meta object (see {@link Core#getCellMeta}).
   * @param {number} column Visual column index.
   * @returns {Function} Returns the renderer function.
   * @example
   * ```js
   * // Get cell renderer using `row` and `column` coordinates.
   * hot.getCellRenderer(1, 1);
   * // Get cell renderer using cell meta object.
   * hot.getCellRenderer(hot.getCellMeta(1, 1));
   * ```
   */ this.getCellRenderer = function(rowOrMeta, column) {
        const cellRenderer = typeof rowOrMeta === 'number' ? instance.getCellMeta(rowOrMeta, column).renderer : rowOrMeta.renderer;
        if (typeof cellRenderer === 'string') {
            return (0, _registry1.getRenderer)(cellRenderer);
        }
        return (0, _mixed.isUndefined)(cellRenderer) ? (0, _registry1.getRenderer)('text') : cellRenderer;
    };
    /**
   * Returns the cell editor class by the provided `row` and `column` arguments.
   *
   * @memberof Core#
   * @function getCellEditor
   * @param {number} rowOrMeta Visual row index or cell meta object (see {@link Core#getCellMeta}).
   * @param {number} column Visual column index.
   * @returns {Function|boolean} Returns the editor class or `false` is cell editor is disabled.
   * @example
   * ```js
   * // Get cell editor class using `row` and `column` coordinates.
   * hot.getCellEditor(1, 1);
   * // Get cell editor class using cell meta object.
   * hot.getCellEditor(hot.getCellMeta(1, 1));
   * ```
   */ this.getCellEditor = function(rowOrMeta, column) {
        const cellEditor = typeof rowOrMeta === 'number' ? instance.getCellMeta(rowOrMeta, column).editor : rowOrMeta.editor;
        if (typeof cellEditor === 'string') {
            return (0, _registry2.getEditor)(cellEditor);
        }
        return (0, _mixed.isUndefined)(cellEditor) ? (0, _registry2.getEditor)('text') : cellEditor;
    };
    /**
   * Returns the cell validator by `row` and `column`.
   *
   * @memberof Core#
   * @function getCellValidator
   * @param {number|object} rowOrMeta Visual row index or cell meta object (see {@link Core#getCellMeta}).
   * @param {number} column Visual column index.
   * @returns {Function|RegExp|undefined} The validator function.
   * @example
   * ```js
   * // Get cell validator using `row` and `column` coordinates.
   * hot.getCellValidator(1, 1);
   * // Get cell validator using cell meta object.
   * hot.getCellValidator(hot.getCellMeta(1, 1));
   * ```
   */ this.getCellValidator = function(rowOrMeta, column) {
        const cellValidator = typeof rowOrMeta === 'number' ? instance.getCellMeta(rowOrMeta, column).validator : rowOrMeta.validator;
        if (typeof cellValidator === 'string') {
            return (0, _registry3.getValidator)(cellValidator);
        }
        return cellValidator;
    };
    /**
   * Validates every cell in the data set,
   * using a [validator function](@/guides/cell-functions/cell-validator/cell-validator.md) configured for each cell.
   *
   * Doesn't validate cells that are currently [trimmed](@/guides/rows/row-trimming/row-trimming.md),
   * [hidden](@/guides/rows/row-hiding/row-hiding.md), or [filtered](@/guides/columns/column-filter/column-filter.md),
   * as such cells are not included in the data set until you bring them back again.
   *
   * After the validation, the `callback` function is fired, with the `valid` argument set to:
   * - `true` for valid cells
   * - `false` for invalid cells
   *
   * @memberof Core#
   * @function validateCells
   * @param {Function} [callback] The callback function.
   * @example
   * ```js
   * hot.validateCells((valid) => {
   *   if (valid) {
   *     // ... code for validated cells
   *   }
   * })
   * ```
   */ this.validateCells = function(callback) {
        this._validateCells(callback);
    };
    /**
   * Validates rows using their validator functions and calls callback when finished.
   *
   * If one of the cells is invalid, the callback will be fired with `'valid'` arguments as `false` - otherwise it
   *  would equal `true`.
   *
   * @memberof Core#
   * @function validateRows
   * @param {Array} [rows] Array of validation target visual row indexes.
   * @param {Function} [callback] The callback function.
   * @example
   * ```js
   * hot.validateRows([3, 4, 5], (valid) => {
   *   if (valid) {
   *     // ... code for validated rows
   *   }
   * })
   * ```
   */ this.validateRows = function(rows, callback) {
        if (!Array.isArray(rows)) {
            (0, _errors.throwWithCause)('validateRows parameter `rows` must be an array');
        }
        this._validateCells(callback, rows);
    };
    /**
   * Validates columns using their validator functions and calls callback when finished.
   *
   * If one of the cells is invalid, the callback will be fired with `'valid'` arguments as `false` - otherwise it
   *  would equal `true`.
   *
   * @memberof Core#
   * @function validateColumns
   * @param {Array} [columns] Array of validation target visual columns indexes.
   * @param {Function} [callback] The callback function.
   * @example
   * ```js
   * hot.validateColumns([3, 4, 5], (valid) => {
   *   if (valid) {
   *     // ... code for validated columns
   *   }
   * })
   * ```
   */ this.validateColumns = function(columns, callback) {
        if (!Array.isArray(columns)) {
            (0, _errors.throwWithCause)('validateColumns parameter `columns` must be an array');
        }
        this._validateCells(callback, undefined, columns);
    };
    /**
   * Validates all cells using their validator functions and calls callback when finished.
   *
   * If one of the cells is invalid, the callback will be fired with `'valid'` arguments as `false` - otherwise it would equal `true`.
   *
   * Private use intended.
   *
   * @private
   * @memberof Core#
   * @function _validateCells
   * @param {Function} [callback] The callback function.
   * @param {Array} [rows] An array of validation target visual row indexes.
   * @param {Array} [columns] An array of validation target visual column indexes.
   */ this._validateCells = function(callback, rows, columns) {
        const waitingForValidator = ValidatorsQueue();
        if (callback) {
            waitingForValidator.onQueueEmpty = callback;
        }
        let i = instance.countRows() - 1;
        while(i >= 0){
            if (rows !== undefined && rows.indexOf(i) === -1) {
                i -= 1;
                continue;
            }
            let j = instance.countCols() - 1;
            while(j >= 0){
                if (columns !== undefined && columns.indexOf(j) === -1) {
                    j -= 1;
                    continue;
                }
                waitingForValidator.addValidatorToQueue();
                // The transient read keeps a bulk validation from permanently materializing one meta
                // object per validated cell (O(rows x columns) retention). Cells with stored meta -
                // including every currently rendered cell - still receive their `valid` result on the
                // stored object, because the transient read returns the stored object for them.
                const row = i;
                const column = j;
                const cellMeta = instance.getCellMetaTransient(row, column);
                instance.validateCell(instance.getDataAtCell(row, column), cellMeta, (result)=>{
                    if (typeof result !== 'boolean') {
                        (0, _errors.throwWithCause)('Validation error: result is not boolean');
                    }
                    if (result === false) {
                        waitingForValidator.valid = false;
                        // A failed result written on a throwaway object would be lost - persist it on the
                        // stored meta (a DIRECT write, exactly like the edit-path validation flow; NOT
                        // `setCellMeta`, which would mark the property as user-persisted and change
                        // updateSettings/eviction semantics). Only failures materialize, so retention stays
                        // O(invalid cells); the eviction pass already keeps `valid === false` cells.
                        instance.getCellMeta(row, column, {
                            skipMetaExtension: true
                        }).valid = false;
                    }
                    waitingForValidator.removeValidatorFormQueue();
                }, 'validateCells');
                j -= 1;
            }
            i -= 1;
        }
        waitingForValidator.checkIfQueueIsEmpty();
    };
    /**
   * Returns an array of row headers' values (if they are enabled). If param `row` was given, it returns the header of the given row as a string.
   *
   * @memberof Core#
   * @function getRowHeader
   * @param {number} [row] Visual row index.
   * @fires Hooks#modifyRowHeader
   * @returns {Array|string|number} Array of header values / single header value.
   */ this.getRowHeader = function(row) {
        let rowHeader = tableMeta.rowHeaders;
        let physicalRow = row;
        if (physicalRow !== undefined) {
            physicalRow = instance.runHooks('modifyRowHeader', physicalRow);
        }
        if (physicalRow === undefined) {
            const headers = [];
            (0, _number.rangeEach)(instance.countRows() - 1, (i)=>{
                headers.push(instance.getRowHeader(i));
            });
            rowHeader = headers;
        } else if (Array.isArray(rowHeader) && rowHeader[physicalRow] !== undefined) {
            rowHeader = rowHeader[physicalRow];
        } else if ((0, _function.isFunction)(rowHeader)) {
            rowHeader = rowHeader(physicalRow);
        } else if (rowHeader && typeof rowHeader !== 'string' && typeof rowHeader !== 'number') {
            rowHeader = physicalRow + 1;
        }
        return rowHeader;
    };
    /**
   * Returns information about if this table is configured to display row headers.
   *
   * @memberof Core#
   * @function hasRowHeaders
   * @returns {boolean} `true` if the instance has the row headers enabled, `false` otherwise.
   */ this.hasRowHeaders = function() {
        return !!tableMeta.rowHeaders;
    };
    /**
   * Returns information about if this table is configured to display column headers.
   *
   * @memberof Core#
   * @function hasColHeaders
   * @returns {boolean} `true` if the instance has the column headers enabled, `false` otherwise.
   */ this.hasColHeaders = function() {
        if (tableMeta.colHeaders !== undefined && tableMeta.colHeaders !== null) {
            return !!tableMeta.colHeaders;
        }
        for(let i = 0, ilen = instance.countCols(); i < ilen; i++){
            if (instance.getColHeader(i)) {
                return true;
            }
        }
        return false;
    };
    /**
   * Caches the index translation that `getColHeader` derives from the `columns` option when that
   * option is a function: the source column indexes for which `columns(index)` returns a truthy
   * settings object. Only the membership array is cached — titles are still read live from the
   * `columns` function. Rebuilt when the function reference or the column count changes; cleared
   * by `updateSettings`.
   */ let columnsSettingIndexes = null;
    /**
   * Gets the values of column headers (if column headers are [enabled](@/api/options.md#colheaders)).
   *
   * To get an array with the values of all
   * [bottom-most](@/guides/cell-features/clipboard/clipboard.md#copy-with-headers) column headers,
   * call `getColHeader()` with no arguments.
   *
   * To get the value of the bottom-most header of a specific column, use the `column` parameter.
   *
   * To get the value of a [specific-level](@/guides/columns/column-groups/column-groups.md) header
   * of a specific column, use the `column` and `headerLevel` parameters.
   *
   * Read more:
   * - [Guides: Column groups](@/guides/columns/column-groups/column-groups.md)
   * - [Options: `colHeaders`](@/api/options.md#colheaders)
   * - [Guides: Copy with headers](@/guides/cell-features/clipboard/clipboard.md#copy-with-headers)
   *
   * ```js
   * // get the contents of all bottom-most column headers
   * hot.getColHeader();
   *
   * // get the contents of the bottom-most header of a specific column
   * hot.getColHeader(5);
   *
   * // get the contents of a specific column header at a specific level
   * hot.getColHeader(5, -2);
   * ```
   *
   * @memberof Core#
   * @function getColHeader
   * @param {number} [column] A visual column index.
   * @param {number} [headerLevel=-1] (Since 12.3.0) Header level index. Accepts positive (0 to n)
   *                                  and negative (-1 to -n) values. For positive values, 0 points to the
   *                                  topmost header. For negative values, -1 points to the bottom-most
   *                                  header (the header closest to the cells).
   * @fires Hooks#modifyColHeader
   * @fires Hooks#modifyColumnHeaderValue
   * @returns {Array|string|number} Column header values.
   */ this.getColHeader = function(column, headerLevel = -1) {
        const columnIndex = instance.runHooks('modifyColHeader', column);
        if (columnIndex === undefined) {
            const out = [];
            const ilen = instance.countCols();
            for(let i = 0; i < ilen; i++){
                out.push(instance.getColHeader(i));
            }
            return out;
        }
        let result = tableMeta.colHeaders;
        const columns = tableMeta.columns;
        const columnsFn = typeof columns === 'function' ? columns : null;
        const physicalColumn = instance.toPhysicalColumn(columnIndex);
        let columnSettings = null;
        if (columnsFn !== null) {
            const columnsLen = instance.countCols();
            if (columnsSettingIndexes === null || columnsSettingIndexes.columns !== columnsFn || columnsSettingIndexes.columnsLen !== columnsLen) {
                const indexes = [];
                for(let index = 0; index < columnsLen; index++){
                    if (columnsFn(index)) {
                        indexes.push(index);
                    }
                }
                columnsSettingIndexes = {
                    columns: columnsFn,
                    columnsLen,
                    indexes
                };
            }
            columnSettings = columnsFn(columnsSettingIndexes.indexes[physicalColumn]) ?? null;
        }
        if (tableMeta.colHeaders === false) {
            result = null;
        } else if (columnSettings && columnSettings.title) {
            result = columnSettings.title;
        } else if (columns && !(0, _function.isFunction)(columns) && columns[physicalColumn] && columns[physicalColumn].title) {
            result = columns[physicalColumn].title;
        } else if (Array.isArray(tableMeta.colHeaders) && tableMeta.colHeaders[physicalColumn] !== undefined) {
            result = tableMeta.colHeaders[physicalColumn];
        } else if ((0, _function.isFunction)(tableMeta.colHeaders)) {
            result = tableMeta.colHeaders(physicalColumn);
        } else if (tableMeta.colHeaders && typeof tableMeta.colHeaders !== 'string' && typeof tableMeta.colHeaders !== 'number') {
            result = (0, _data.spreadsheetColumnLabel)(columnIndex); // see #1458
        }
        result = instance.runHooks('modifyColumnHeaderValue', result, column, headerLevel);
        return result;
    };
    /**
   * Return column width from settings (no guessing). Private use intended.
   *
   * @private
   * @memberof Core#
   * @function _getColWidthFromSettings
   * @param {number} col Visual col index.
   * @returns {number}
   */ this._getColWidthFromSettings = function(col) {
        let width;
        // We currently don't support cell meta objects for headers (negative values)
        if (col >= 0) {
            const cellProperties = instance.getCellMeta(0, col);
            width = cellProperties.width;
        }
        if (width === undefined || width === tableMeta.width) {
            width = tableMeta.colWidths;
        }
        if (width !== undefined && width !== null) {
            switch(typeof width){
                case 'object':
                    width = width[col];
                    break;
                case 'function':
                    width = width(col);
                    break;
                default:
                    break;
            }
            if (typeof width === 'string') {
                width = Number.parseInt(width, 10);
            }
        }
        return width;
    };
    /**
   * Returns the width of the requested column.
   *
   * @memberof Core#
   * @function getColWidth
   * @param {number} column Visual column index.
   * @param {string} [source] The source of the call.
   * @returns {number} Column width.
   * @fires Hooks#modifyColWidth
   */ this.getColWidth = function(column, source) {
        let width = instance._getColWidthFromSettings(column);
        width = instance.runHooks('modifyColWidth', width, column, source);
        if (width === undefined) {
            width = _src.DEFAULT_COLUMN_WIDTH;
        }
        return width;
    };
    /**
   * Return row height from settings (no guessing). Private use intended.
   *
   * @private
   * @memberof Core#
   * @function _getRowHeightFromSettings
   * @param {number} row Visual row index.
   * @returns {number}
   */ this._getRowHeightFromSettings = function(row) {
        const defaultRowHeight = instance.stylesHandler.getDefaultRowHeight(row);
        let height = tableMeta.rowHeights ?? tableMeta.minRowHeights;
        if (height !== undefined && height !== null) {
            switch(typeof height){
                case 'object':
                    height = height[row];
                    break;
                case 'function':
                    height = height(row);
                    break;
                default:
                    break;
            }
            if (typeof height === 'string') {
                height = Number.parseInt(height, 10);
            }
        }
        const numHeight = height;
        const numDefaultRowHeight = defaultRowHeight;
        return numHeight !== undefined && numHeight !== null && numDefaultRowHeight !== null && numHeight < numDefaultRowHeight ? numDefaultRowHeight : numHeight;
    };
    /**
   * Returns a row's height, as recognized by Handsontable.
   *
   * Depending on your configuration, the method returns (in order of priority):
   *   1. The row height set by the [`ManualRowResize`](@/api/manualRowResize.md) plugin
   *     (if the plugin is enabled).
   *   2. The row height set by the [`rowHeights`](@/api/options.md#rowheights) configuration option
   *     (if the option is set).
   *   3. The row height as measured in the DOM by the [`AutoRowSize`](@/api/autoRowSize.md) plugin
   *     (if the plugin is enabled).
   *   4. `undefined`, if neither [`ManualRowResize`](@/api/manualRowResize.md),
   *     nor [`rowHeights`](@/api/options.md#rowheights),
   *     nor [`AutoRowSize`](@/api/autoRowSize.md) is used.
   *
   * The height returned includes 1 px of the row's bottom border.
   *
   * Mind that this method is different from the
   * [`getRowHeight()`](@/api/autoRowSize.md#getrowheight) method
   * of the [`AutoRowSize`](@/api/autoRowSize.md) plugin.
   *
   * @memberof Core#
   * @function getRowHeight
   * @param {number} row A visual row index.
   * @param {string} [source] The source of the call.
   * @returns {number|undefined} The height of the specified row, in pixels.
   * @fires Hooks#modifyRowHeight
   */ this.getRowHeight = function(row, source) {
        let height = instance._getRowHeightFromSettings(row);
        height = instance.runHooks('modifyRowHeight', height, row, source);
        return height;
    };
    /**
   * Returns the total number of rows in the data source.
   *
   * @memberof Core#
   * @function countSourceRows
   * @returns {number} Total number of rows.
   */ this.countSourceRows = function() {
        return dataSource.countRows();
    };
    /**
   * Returns the total number of columns in the data source. It will take value either from schema, columns settings or the first row from the data set. Unlike [countCols()](@/api/core.md#countcols), this value is not affected by the columns configuration option.
   *
   * @memberof Core#
   * @function countSourceCols
   * @returns {number} Total number of columns.
   */ this.countSourceCols = function() {
        return dataSource.countFirstRowKeys();
    };
    /**
   * Returns the total number of visual rows in the table.
   *
   * @memberof Core#
   * @function countRows
   * @returns {number} Total number of rows.
   */ this.countRows = function() {
        return datamap.getLength();
    };
    /**
   * Returns the total number of rendered columns. If the columns option is defined, it returns the number of columns set in that configuration, not the number of columns in the data source.
   *
   * @memberof Core#
   * @function countCols
   * @returns {number} Total number of columns.
   */ this.countCols = function() {
        const maxCols = tableMeta.maxCols;
        const dataLen = instance.columnIndexMapper.getNotTrimmedIndexesLength();
        return Math.min(maxCols, dataLen);
    };
    /**
   * Returns the number of rendered rows including rows that are partially or fully rendered
   * outside the table viewport.
   *
   * @memberof Core#
   * @function countRenderedRows
   * @returns {number} Returns -1 if table is not visible.
   */ this.countRenderedRows = function() {
        const view = instance.view;
        return view?._wt.drawn ? view._wt.wtTable.getRenderedRowsCount() : -1;
    };
    /**
   * Returns the number of rendered rows that are only visible in the table viewport.
   * The rows that are partially visible are not counted.
   *
   * @memberof Core#
   * @function countVisibleRows
   * @returns {number} Number of visible rows or -1.
   */ this.countVisibleRows = function() {
        const view = instance.view;
        return view?._wt.drawn ? view._wt.wtTable.getVisibleRowsCount() : -1;
    };
    /**
   * Returns the number of rendered rows including columns that are partially or fully rendered
   * outside the table viewport.
   *
   * @memberof Core#
   * @function countRenderedCols
   * @returns {number} Returns -1 if table is not visible.
   */ this.countRenderedCols = function() {
        const view = instance.view;
        return view?._wt.drawn ? view._wt.wtTable.getRenderedColumnsCount() : -1;
    };
    /**
   * Returns the number of rendered columns that are only visible in the table viewport.
   * The columns that are partially visible are not counted.
   *
   * @memberof Core#
   * @function countVisibleCols
   * @returns {number} Number of visible columns or -1.
   */ this.countVisibleCols = function() {
        const view = instance.view;
        return view?._wt.drawn ? view._wt.wtTable.getVisibleColumnsCount() : -1;
    };
    /**
   * Returns the number of rendered row headers.
   *
   * @since 14.0.0
   * @memberof Core#
   * @function countRowHeaders
   * @returns {number} Number of row headers.
   */ this.countRowHeaders = function() {
        const view = instance.view;
        return view ? view.getRowHeadersCount() : 0;
    };
    /**
   * Returns the number of rendered column headers.
   *
   * @since 14.0.0
   * @memberof Core#
   * @function countColHeaders
   * @returns {number} Number of column headers.
   */ this.countColHeaders = function() {
        const view = instance.view;
        return view ? view.getColumnHeadersCount() : 0;
    };
    /**
   * Returns the number of empty rows. If the optional ending parameter is `true`, returns the
   * number of empty rows at the bottom of the table.
   *
   * @memberof Core#
   * @function countEmptyRows
   * @param {boolean} [ending=false] If `true`, will only count empty rows at the end of the data source.
   * @returns {number} Count empty rows.
   */ this.countEmptyRows = function(ending = false) {
        let emptyRows = 0;
        (0, _number.rangeEachReverse)(instance.countRows() - 1, (visualIndex)=>{
            if (instance.isEmptyRow(visualIndex)) {
                emptyRows += 1;
            } else if (ending === true) {
                return false;
            }
        });
        return emptyRows;
    };
    /**
   * Returns the number of empty columns. If the optional ending parameter is `true`, returns the number of empty
   * columns at right hand edge of the table.
   *
   * @memberof Core#
   * @function countEmptyCols
   * @param {boolean} [ending=false] If `true`, will only count empty columns at the end of the data source row.
   * @returns {number} Count empty cols.
   */ this.countEmptyCols = function(ending = false) {
        let emptyColumns = 0;
        (0, _number.rangeEachReverse)(instance.countCols() - 1, (visualIndex)=>{
            if (instance.isEmptyCol(visualIndex)) {
                emptyColumns += 1;
            } else if (ending === true) {
                return false;
            }
        });
        return emptyColumns;
    };
    /**
   * Check if all cells in the row declared by the `row` argument are empty.
   *
   * @memberof Core#
   * @function isEmptyRow
   * @param {number} row Visual row index.
   * @returns {boolean} `true` if the row at the given `row` is empty, `false` otherwise.
   */ this.isEmptyRow = function(row) {
        return tableMeta.isEmptyRow.call(instance, row);
    };
    /**
   * Check if all cells in the the column declared by the `column` argument are empty.
   *
   * @memberof Core#
   * @function isEmptyCol
   * @param {number} column Column index.
   * @returns {boolean} `true` if the column at the given `col` is empty, `false` otherwise.
   */ this.isEmptyCol = function(column) {
        return tableMeta.isEmptyCol.call(instance, column);
    };
    /**
   * Select a single cell, or a single range of adjacent cells.
   *
   * To select a cell, pass its visual row and column indexes, for example: `selectCell(2, 4)`.
   *
   * To select a range, pass the visual indexes of the first and last cell in the range, for example: `selectCell(2, 4, 3, 5)`.
   *
   * If your columns have properties, you can pass those properties' values instead of column indexes, for example: `selectCell(2, 'first_name')`.
   *
   * By default, `selectCell()` also:
   *  - Scrolls the viewport to the newly-selected cells.
   *  - Switches the keyboard focus to Handsontable (by calling Handsontable's [`listen()`](#listen) method).
   *
   * @example
   * ```js
   * // select a single cell
   * hot.selectCell(2, 4);
   *
   * // select a range of cells
   * hot.selectCell(2, 4, 3, 5);
   *
   * // select a single cell, using a column property
   * hot.selectCell(2, 'first_name');
   *
   * // select a range of cells, using column properties
   * hot.selectCell(2, 'first_name', 3, 'last_name');
   *
   * // select a range of cells, without scrolling to them
   * hot.selectCell(2, 4, 3, 5, false);
   *
   * // select a range of cells, without switching the keyboard focus to Handsontable
   * hot.selectCell(2, 4, 3, 5, null, false);
   * ```
   *
   * @memberof Core#
   * @function selectCell
   * @param {number} row A visual row index.
   * @param {number|string} column A visual column index (`number`), or a column property's value (`string`).
   * @param {number} [endRow] If selecting a range: the visual row index of the last cell in the range.
   * @param {number|string} [endColumn] If selecting a range: the visual column index (or a column property's value) of the last cell in the range.
   * @param {boolean} [scrollToCell=true] If `true`, scrolls the viewport to the newly-selected cells. If `false`, keeps the previous viewport.
   * @param {boolean} [changeListener=true] If `true`, switches the keyboard focus to Handsontable. If `false`, keeps the
   * previous keyboard focus. If an element outside Handsontable (such as a custom input) currently owns the browser
   * focus, it remains focused after the call.
   * @returns {boolean} `true`: the selection was successful, `false`: the selection failed.
   */ this.selectCell = function(row, column, endRow, endColumn, scrollToCell = true, changeListener = true) {
        if ((0, _mixed.isUndefined)(row) || (0, _mixed.isUndefined)(column)) {
            return false;
        }
        const rowNum = row === null || row === undefined || Number.isNaN(Number(row)) ? 0 : Number(row);
        const col = column === null || column === undefined || typeof column === 'number' && Number.isNaN(column) ? 0 : column;
        const coords = [
            [
                rowNum,
                col,
                (0, _mixed.isUndefined)(endRow) ? undefined : endRow,
                (0, _mixed.isUndefined)(endColumn) ? undefined : endColumn
            ]
        ];
        return instance.selectCells(coords, scrollToCell, changeListener);
    };
    /**
   * Select multiple cells or ranges of cells, adjacent or non-adjacent.
   *
   * You can pass one of the below:
   * - An array of arrays (which matches the output of Handsontable's [`getSelected()`](#getselected) method).
   * - An array of [`CellRange`](@/api/cellRange.md) objects (which matches the output of Handsontable's [`getSelectedRange()`](#getselectedrange) method).
   *
   * To select multiple cells, pass the visual row and column indexes of each cell, for example: `hot.selectCells([[1, 1], [5, 5]])`.
   *
   * To select multiple ranges, pass the visual indexes of the first and last cell in each range, for example: `hot.selectCells([[1, 1, 2, 2], [6, 2, 0, 2]])`.
   *
   * If your columns have properties, you can pass those properties' values instead of column indexes, for example: `hot.selectCells([[1, 'first_name'], [5, 'last_name']])`.
   *
   * By default, `selectCell()` also:
   *  - Scrolls the viewport to the newly-selected cells.
   *  - Switches the keyboard focus to Handsontable (by calling Handsontable's [`listen()`](#listen) method).
   *
   * @example
   * ```js
   * // select non-adjacent cells
   * hot.selectCells([[1, 1], [5, 5], [10, 10]]);
   *
   * // select non-adjacent ranges of cells
   * hot.selectCells([[1, 1, 2, 2], [10, 10, 20, 20]]);
   *
   * // select cells and ranges of cells
   * hot.selectCells([[1, 1, 2, 2], [3, 3], [6, 2, 0, 2]]);
   *
   * // select cells, using column properties
   * hot.selectCells([[1, 'id', 2, 'first_name'], [3, 'full_name'], [6, 'last_name', 0, 'first_name']]);
   *
   * // select multiple ranges, using an array of `CellRange` objects
   * const selected = hot.getSelectedRange();
   *
   * selected[0].from.row = 0;
   * selected[0].from.col = 0;
   * selected[0].to.row = 5;
   * selected[0].to.col = 5;
   *
   * selected[1].from.row = 10;
   * selected[1].from.col = 10;
   * selected[1].to.row = 20;
   * selected[1].to.col = 20;
   *
   * hot.selectCells(selected);
   * ```
   *
   * @memberof Core#
   * @since 0.38.0
   * @function selectCells
   * @param {Array[]|CellRange[]} coords Visual coordinates,
   * passed either as an array of arrays (`[[rowStart, columnStart, rowEnd, columnEnd], ...]`)
   * or as an array of [`CellRange`](@/api/cellRange.md) objects.
   * @param {boolean} [scrollToCell=true] If `true`, scrolls the viewport to the newly-selected cells. If `false`, keeps the previous viewport.
   * @param {boolean} [changeListener=true] If `true`, switches the keyboard focus to Handsontable. If `false`, keeps the
   * previous keyboard focus. If an element outside Handsontable (such as a custom input) currently owns the browser
   * focus, it remains focused after the call.
   * @returns {boolean} `true`: the selection was successful, `false`: the selection failed.
   */ this.selectCells = function(coords = [
        []
    ], scrollToCell = true, changeListener = true) {
        if (scrollToCell === false) {
            viewportScroller.suspend();
        }
        if (changeListener === false) {
            focusGridManager.suspend();
        }
        let wasSelected;
        try {
            wasSelected = selection.selectCells(coords);
        } finally{
            // Always release the suspended state even if `selection.selectCells` throws on malformed
            // coordinates. Otherwise the flags would leak across subsequent calls.
            viewportScroller.resume();
            focusGridManager.resume();
        }
        if (wasSelected && changeListener) {
            instance.listen();
        }
        return wasSelected;
    };
    /**
   * Select column specified by `startColumn` visual index, column property or a range of columns finishing at `endColumn`.
   *
   * @example
   * ```js
   * // Select column using visual index.
   * hot.selectColumns(1);
   * // Select column using column property.
   * hot.selectColumns('id');
   * // Select range of columns using visual indexes.
   * hot.selectColumns(1, 4);
   * // Select range of columns using visual indexes and mark the first header as highlighted.
   * hot.selectColumns(1, 2, -1);
   * // Select range of columns using visual indexes and mark the second cell as highlighted.
   * hot.selectColumns(2, 1, 1);
   * // Select range of columns using visual indexes and move the focus position somewhere in the middle of the range.
   * hot.selectColumns(2, 5, { row: 2, col: 3 });
   * // Select range of columns using column properties.
   * hot.selectColumns('id', 'last_name');
   * ```
   *
   * @memberof Core#
   * @since 0.38.0
   * @function selectColumns
   * @param {number | string} startColumn The visual column index or column property from which the selection starts.
   * @param {number | string} [endColumn=startColumn] The visual column index or column property to which the selection finishes. If `endColumn`
   * is not defined the column defined by `startColumn` will be selected.
   * @param {number | { row: number, col: number } | CellCoords} [focusPosition=0] The argument allows changing the cell/header focus
   * position. The value can take visual row index from -N to N, where negative values point to the headers and positive
   * values point to the cell range. An object with `row` and `col` properties also can be passed to change the focus
   * position horizontally.
   * @returns {boolean} `true` if selection was successful, `false` otherwise.
   */ this.selectColumns = function(startColumn, endColumn = startColumn, focusPosition) {
        return selection.selectColumns(startColumn, endColumn, focusPosition);
    };
    /**
   * Select row specified by `startRow` visual index or a range of rows finishing at `endRow`.
   *
   * @example
   * ```js
   * // Select row using visual index.
   * hot.selectRows(1);
   * // select a range of rows, using visual indexes.
   * hot.selectRows(1, 4);
   * // select a range of rows, using visual indexes, and mark the header as highlighted.
   * hot.selectRows(1, 2, -1);
   * // Select range of rows using visual indexes and mark the second cell as highlighted.
   * hot.selectRows(2, 1, 1);
   * // Select range of rows using visual indexes and move the focus position somewhere in the middle of the range.
   * hot.selectRows(2, 5, { row: 2, col: 3 });
   * ```
   *
   * @memberof Core#
   * @since 0.38.0
   * @function selectRows
   * @param {number} startRow The visual row index from which the selection starts.
   * @param {number} [endRow=startRow] The visual row index to which the selection finishes. If `endRow`
   * is not defined the row defined by `startRow` will be selected.
   * @param {number | { row: number, col: number } | CellCoords} [focusPosition=0] The argument allows changing the cell/header focus
   * position. The value can take visual row index from -N to N, where negative values point to the headers and positive
   * values point to the cell range. An object with `row` and `col` properties also can be passed to change the focus
   * position vertically.
   * @returns {boolean} `true` if selection was successful, `false` otherwise.
   */ this.selectRows = function(startRow, endRow = startRow, focusPosition) {
        return selection.selectRows(startRow, endRow, focusPosition);
    };
    /**
   * Deselects the current cell selection on the table.
   *
   * @memberof Core#
   * @function deselectCell
   */ this.deselectCell = function() {
        selection.deselect();
    };
    /**
   * Select all cells in the table excluding headers and corner elements.
   *
   * The previous selection is overwritten.
   *
   * ```js
   * // Select all cells in the table along with row headers, including all headers and the corner cell.
   * // Doesn't select column headers and corner elements.
   * hot.selectAll();
   *
   * // Select all cells in the table, including row headers but excluding the corner cell and column headers.
   * hot.selectAll(true, false);
   *
   * // Select all cells in the table, including all headers and the corner cell, but move the focus.
   * // highlight to position 2, 1
   * hot.selectAll(-2, -1, {
   *    focusPosition: { row: 2, col: 1 }
   * });
   *
   * // Select all cells in the table, without headers and corner elements.
   * hot.selectAll(false);
   * ```
   *
   * @since 0.38.2
   * @memberof Core#
   * @function selectAll
   * @param {boolean} [includeRowHeaders=false] If `true`, includes the row headers in the selection.
   * @param {boolean} [includeColumnHeaders=false] If `true`, includes the column headers in the selection.
   *
   * @param {object} [options] Additional object with options. Since 14.0.0.
   * @param {{row: number, col: number} | boolean} [options.focusPosition] The argument allows changing the cell/header
   * focus position. The value takes an object with a `row` and `col` properties from -N to N, where
   * negative values point to the headers and positive values point to the cell range. If `false`, the focus
   * position won't be changed. When the {@link Options#navigableHeaders} option is disabled (the default), a
   * `focusPosition` that points to a header is relocated to the nearest cell in the data set. Example:
   * ```js
   * hot.selectAll(0, 0, {
   * focusPosition: { row: 0, col: 1 },
   * disableHeadersHighlight: true
   * })
   * ```
   *
   * @param {boolean} [options.disableHeadersHighlight] If `true`, disables highlighting the headers even when
   * the logical coordinates points on them. This only suppresses the highlight shown on headers of a fully-selected
   * row or column. It doesn't affect the focus indicator on the individual cell or header that holds the focus,
   * which stays visible even when {@link Options#navigableHeaders} moves the focus onto a header.
   */ this.selectAll = function(includeRowHeaders = true, includeColumnHeaders = includeRowHeaders, options) {
        viewportScroller.skipNextScrollCycle();
        selection.selectAll(includeRowHeaders, includeColumnHeaders, options);
    };
    const getIndexToScroll = (indexMapper, visualIndex)=>{
        // Looking for a visual index on the right and then (when not found) on the left.
        return indexMapper.getNearestNotHiddenIndex(visualIndex, 1, true);
    };
    /**
   * Resolves renderable row and column indexes for scrolling, accounting for hidden indexes.
   *
   * @param {number|undefined} row Visual row index.
   * @param {number|undefined} col Visual column index.
   * @returns {{renderableRow: number|undefined, renderableColumn: number|undefined}|false} Resolved
   *   renderable indexes, or `false` when scrolling target is not reachable.
   */ const resolveRenderableScrollTarget = (row, col)=>{
        const isValidRowGrid = row !== undefined && Number.isInteger(row) && row >= 0;
        const isValidColumnGrid = col !== undefined && Number.isInteger(col) && col >= 0;
        const visualRowToScroll = isValidRowGrid ? getIndexToScroll(instance.rowIndexMapper, row) : undefined;
        const visualColumnToScroll = isValidColumnGrid ? getIndexToScroll(instance.columnIndexMapper, col) : undefined;
        if (visualRowToScroll === null || visualColumnToScroll === null) {
            return false;
        }
        const renderableRow = isValidRowGrid ? instance.rowIndexMapper.getRenderableFromVisualIndex(visualRowToScroll) ?? undefined : row;
        const renderableColumn = isValidColumnGrid ? instance.columnIndexMapper.getRenderableFromVisualIndex(visualColumnToScroll) ?? undefined : col;
        return {
            renderableRow,
            renderableColumn
        };
    };
    /**
   * Scroll viewport to coordinates specified by the `row` and/or `col` object properties.
   *
   * The object-based signature was introduced in v14.0.0. The positional arguments form is retained
   * for backward compatibility.
   *
   * ```js
   * // scroll the viewport to the visual row index (leave the horizontal scroll untouched)
   * hot.scrollViewportTo({ row: 50 });
   *
   * // scroll the viewport to the passed coordinates so that the cell at 50, 50 will be snapped to
   * // the bottom-end table's edge.
   * hot.scrollViewportTo({
   *   row: 50,
   *   col: 50,
   *   verticalSnap: 'bottom',
   *   horizontalSnap: 'end',
   * }, () => {
   *   // callback function executed after the viewport is scrolled
   * });
   *
   * // scroll the viewport using the backward-compatible positional arguments form
   * hot.scrollViewportTo(50, 50, true, true);
   * ```
   *
   * @memberof Core#
   * @function scrollViewportTo
   * @param {object} options A dictionary containing the following parameters:
   * @param {number} [options.row] Specifies the number of visual rows along the Y axis to scroll the viewport.
   * @param {number} [options.col] Specifies the number of visual columns along the X axis to scroll the viewport.
   * @param {'top' | 'bottom'} [options.verticalSnap] Determines to which edge of the table the viewport will be scrolled based on the passed coordinates.
   * This option is a string which must take one of the following values:
   * - `top`: The viewport will be scrolled to a row in such a way that it will be positioned on the top of the viewport;
   * - `bottom`: The viewport will be scrolled to a row in such a way that it will be positioned on the bottom of the viewport;
   * - If the property is not defined the vertical auto-snapping is enabled. Depending on where the viewport is scrolled from, a row will
   * be positioned at the top or bottom of the viewport.
   * @param {'start' | 'end'} [options.horizontalSnap] Determines to which edge of the table the viewport will be scrolled based on the passed coordinates.
   * This option is a string which must take one of the following values:
   * - `start`: The viewport will be scrolled to a column in such a way that it will be positioned on the start (left edge or right, if the layout direction is set to `rtl`) of the viewport;
   * - `end`: The viewport will be scrolled to a column in such a way that it will be positioned on the end (right edge or left, if the layout direction is set to `rtl`) of the viewport;
   * - If the property is not defined the horizontal auto-snapping is enabled. Depending on where the viewport is scrolled from, a column will
   * be positioned at the start or end of the viewport.
   * @param {boolean} [options.considerHiddenIndexes=true] If `true`, we handle visual indexes, otherwise we handle only indexes which
   * may be rendered when they are in the viewport (we don't consider hidden indexes as they aren't rendered).
   * @param {Function} [callback] The callback function to call after the viewport is scrolled.
   * @returns {boolean} `true` if viewport was scrolled, `false` otherwise.
   */ this.scrollViewportTo = function(options, callback) {
        // Support for backward compatibility arguments: (row, col, snapToBottom, snapToRight, considerHiddenIndexes)
        if (typeof options === 'number') {
            /* eslint-disable prefer-rest-params, @typescript-eslint/no-unsafe-assignment */ options = {
                row: arguments[0],
                col: arguments[1],
                verticalSnap: arguments[2] ? 'bottom' : 'top',
                horizontalSnap: arguments[3] ? 'end' : 'start',
                considerHiddenIndexes: arguments[4] ?? true
            };
        /* eslint-enable prefer-rest-params, @typescript-eslint/no-unsafe-assignment */ }
        const { row, col, considerHiddenIndexes } = options ?? {};
        let renderableRow = row;
        let renderableColumn = col;
        if ((0, _function.isFunction)(callback)) {
            this.addHookOnce('afterScroll', callback);
        }
        if (considerHiddenIndexes === undefined || considerHiddenIndexes) {
            const resolved = resolveRenderableScrollTarget(row, col);
            if (resolved === false) {
                return false;
            }
            renderableRow = resolved.renderableRow;
            renderableColumn = resolved.renderableColumn;
        }
        const isRowInteger = Number.isInteger(renderableRow);
        const isColumnInteger = Number.isInteger(renderableColumn);
        let isScrolled = false;
        if (isRowInteger && renderableRow >= 0 && isColumnInteger && renderableColumn >= 0) {
            isScrolled = instance.view.scrollViewport(instance._createCellCoords(renderableRow, renderableColumn), options.horizontalSnap, options.verticalSnap);
        } else if (isRowInteger && renderableRow >= 0 && (isColumnInteger && renderableColumn < 0 || !isColumnInteger)) {
            isScrolled = instance.view.scrollViewportVertically(renderableRow, options.verticalSnap);
        } else if (isColumnInteger && renderableColumn >= 0 && (isRowInteger && renderableRow < 0 || !isRowInteger)) {
            isScrolled = instance.view.scrollViewportHorizontally(renderableColumn, options.horizontalSnap);
        }
        if ((0, _function.isFunction)(callback)) {
            if (isScrolled) {
                // fast render triggers `afterScroll` hook
                this.view.render();
            } else {
                this.removeHook('afterScroll', callback);
                this._registerMicrotask(()=>callback());
            }
        }
        return isScrolled;
    };
    /**
   * Scrolls the viewport to coordinates specified by the currently focused cell.
   *
   * @since 14.0.0
   * @memberof Core#
   * @fires Hooks#afterScroll
   * @function scrollToFocusedCell
   * @param {Function} [callback] The callback function to call after the viewport is scrolled.
   * @returns {boolean} `true` if the viewport was scrolled, `false` otherwise.
   */ this.scrollToFocusedCell = function(callback) {
        if (!instance.selection.isSelected()) {
            return false;
        }
        if ((0, _function.isFunction)(callback)) {
            instance.addHookOnce('afterScroll', callback);
        }
        const { highlight } = instance.getSelectedRangeActive();
        const isScrolled = instance.scrollViewportTo(highlight.toObject());
        if (isScrolled) {
            // fast render triggers `afterScroll` hook
            instance.view.render();
        } else if ((0, _function.isFunction)(callback)) {
            instance.removeHook('afterScroll', callback);
            instance._registerMicrotask(()=>callback());
        }
        return isScrolled;
    };
    /**
   * Removes the table from the DOM and destroys the instance of the Handsontable.
   *
   * @memberof Core#
   * @function destroy
   * @fires Hooks#afterDestroy
   */ this.destroy = function() {
        instance._clearTimeouts();
        instance._clearMicrotasks();
        // Drop the hidden-init visibility observer before the teardown below nulls the instance. Otherwise a
        // delivery queued while the table was becoming visible runs its callback on a destroyed instance.
        visibilityObserver?.disconnect();
        visibilityObserver = null;
        if (instance.view) {
            instance.view.destroy();
        }
        if (dataSource) {
            dataSource.destroy();
        }
        dataSource = null;
        if ((0, _rootInstance.isRootInstance)(this)) {
            (0, _a11yAnnouncer.uninstall)();
            this.getFocusScopeManager().destroy();
            layoutManager?.destroy();
            instance.themeManager?.destroy();
        }
        this.getShortcutManager().destroy();
        moduleRegisterer.clear();
        metaManager.clearCache();
        foreignHotInstances.delete(this.guid);
        eventManager.destroy();
        if (editorManager) {
            editorManager.destroy();
        }
        if (instance.rootContainer) {
            (0, _element.empty)(instance.rootContainer);
        }
        if (instance.rootPortalElement) {
            instance.rootPortalElement.remove();
        }
        // The plugin's `destroy` method is called as a consequence and it should handle
        // unregistration of plugin's maps. Some unregistered maps reset the cache.
        instance.batchExecution(()=>{
            instance.rowIndexMapper.destroy();
            instance.columnIndexMapper.destroy();
            pluginsRegistry.getItems().forEach(([, plugin])=>{
                plugin.destroy();
            });
            pluginsRegistry.clear();
            instance.runHooks('afterDestroy');
        }, true);
        _index.Hooks.getSingleton().destroy(instance);
        (0, _object.objectEach)(instance, (property, key, obj)=>{
            // replace instance methods with post mortem
            if ((0, _function.isFunction)(property)) {
                obj[key] = postMortem(key);
            } else if (key !== 'guid') {
                // replace instance properties with null (restores memory)
                // it should not be necessary but this prevents a memory leak side effects that show itself in Jasmine tests
                obj[key] = null;
            }
        });
        instance.isDestroyed = true;
        // replace private properties with null (restores memory)
        // it should not be necessary but this prevents a memory leak side effects that show itself in Jasmine tests
        if (datamap) {
            datamap.destroy();
        }
        datamap = null;
        grid = null;
        selection = null;
        editorManager = null;
        instance = null;
    };
    /**
   * Replacement for all methods after the Handsontable was destroyed.
   *
   * @private
   * @param {string} method The method name.
   * @returns {Function}
   */ function postMortem(method) {
        return ()=>{
            (0, _errors.throwWithCause)(`The "${method}" method cannot be called because this Handsontable instance has been destroyed`);
        };
    }
    /**
   * Returns the active editor class instance.
   *
   * The active editor is the editor instance associated with the currently selected cell.
   * An editor becomes active when a cell is selected and the editor is prepared (but not
   * necessarily open). If no cell is selected, the method returns `undefined`.
   *
   * @memberof Core#
   * @function getActiveEditor
   * @returns {BaseEditor | undefined} The active editor instance, or `undefined` if no cell is selected.
   */ this.getActiveEditor = function() {
        // During the first `afterLoadData` hook (fired from `loadData` inside `init`),
        // `editorManager` has not been assigned yet. Guard so callers (e.g.
        // `setSourceDataAtCell`) invoked from that hook do not crash.
        return editorManager?.getActiveEditor();
    };
    /**
   * Returns the first rendered row in the DOM (usually, it is not visible in the table's viewport).
   *
   * When the {@link MergeCells} plugin is enabled with its default `virtualized: false` setting, a merged
   * cell that crosses the viewport edge extends the rendered row range, so this method can return a row
   * index further from the viewport than usual. For the actual visible viewport, use
   * {@link Core#getFirstFullyVisibleRow} or {@link Core#getFirstPartiallyVisibleRow}.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getFirstRenderedVisibleRow
   * @returns {number | null}
   */ this.getFirstRenderedVisibleRow = function() {
        return instance.view.getFirstRenderedVisibleRow();
    };
    /**
   * Returns the last rendered row in the DOM (usually, it is not visible in the table's viewport).
   *
   * When the {@link MergeCells} plugin is enabled with its default `virtualized: false` setting, a merged
   * cell that crosses the viewport edge extends the rendered row range, so this method can return a row
   * index further from the viewport than usual. For the actual visible viewport, use
   * {@link Core#getLastFullyVisibleRow} or {@link Core#getLastPartiallyVisibleRow}.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getLastRenderedVisibleRow
   * @returns {number | null}
   */ this.getLastRenderedVisibleRow = function() {
        return instance.view.getLastRenderedVisibleRow();
    };
    /**
   * Returns the first rendered column in the DOM (usually, it is not visible in the table's viewport).
   *
   * When the {@link MergeCells} plugin is enabled with its default `virtualized: false` setting, a merged
   * cell that crosses the viewport edge extends the rendered column range, so this method can return a
   * column index further from the viewport than usual. For the actual visible viewport, use
   * {@link Core#getFirstFullyVisibleColumn} or {@link Core#getFirstPartiallyVisibleColumn}.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getFirstRenderedVisibleColumn
   * @returns {number | null}
   */ this.getFirstRenderedVisibleColumn = function() {
        return instance.view.getFirstRenderedVisibleColumn();
    };
    /**
   * Returns the last rendered column in the DOM (usually, it is not visible in the table's viewport).
   *
   * When the {@link MergeCells} plugin is enabled with its default `virtualized: false` setting, a merged
   * cell that crosses the viewport edge extends the rendered column range, so this method can return a
   * column index further from the viewport than usual. For the actual visible viewport, use
   * {@link Core#getLastFullyVisibleColumn} or {@link Core#getLastPartiallyVisibleColumn}.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getLastRenderedVisibleColumn
   * @returns {number | null}
   */ this.getLastRenderedVisibleColumn = function() {
        return instance.view.getLastRenderedVisibleColumn();
    };
    /**
   * Returns the first fully visible row in the table viewport. When the table has overlays the method returns
   * the first row of the main table that is not overlapped by overlay.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getFirstFullyVisibleRow
   * @returns {number | null}
   */ this.getFirstFullyVisibleRow = function() {
        return instance.view.getFirstFullyVisibleRow();
    };
    /**
   * Returns the last fully visible row in the table viewport. When the table has overlays the method returns
   * the first row of the main table that is not overlapped by overlay.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getLastFullyVisibleRow
   * @returns {number | null}
   */ this.getLastFullyVisibleRow = function() {
        return instance.view.getLastFullyVisibleRow();
    };
    /**
   * Returns the first fully visible column in the table viewport. When the table has overlays the method returns
   * the first row of the main table that is not overlapped by overlay.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getFirstFullyVisibleColumn
   * @returns {number | null}
   */ this.getFirstFullyVisibleColumn = function() {
        return instance.view.getFirstFullyVisibleColumn();
    };
    /**
   * Returns the last fully visible column in the table viewport. When the table has overlays the method returns
   * the first row of the main table that is not overlapped by overlay.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getLastFullyVisibleColumn
   * @returns {number | null}
   */ this.getLastFullyVisibleColumn = function() {
        return instance.view.getLastFullyVisibleColumn();
    };
    /**
   * Returns the first partially visible row in the table viewport. When the table has overlays the method returns
   * the first row of the main table that is not overlapped by overlay.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getFirstPartiallyVisibleRow
   * @returns {number | null}
   */ this.getFirstPartiallyVisibleRow = function() {
        return instance.view.getFirstPartiallyVisibleRow();
    };
    /**
   * Returns the last partially visible row in the table viewport. When the table has overlays the method returns
   * the first row of the main table that is not overlapped by overlay.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getLastPartiallyVisibleRow
   * @returns {number | null}
   */ this.getLastPartiallyVisibleRow = function() {
        return instance.view.getLastPartiallyVisibleRow();
    };
    /**
   * Returns the first partially visible column in the table viewport. When the table has overlays the method returns
   * the first row of the main table that is not overlapped by overlay.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getFirstPartiallyVisibleColumn
   * @returns {number | null}
   */ this.getFirstPartiallyVisibleColumn = function() {
        return instance.view.getFirstPartiallyVisibleColumn();
    };
    /**
   * Returns the last partially visible column in the table viewport. When the table has overlays the method returns
   * the first row of the main table that is not overlapped by overlay.
   *
   * @since 14.6.0
   * @memberof Core#
   * @function getLastPartiallyVisibleColumn
   * @returns {number | null}
   */ this.getLastPartiallyVisibleColumn = function() {
        return instance.view.getLastPartiallyVisibleColumn();
    };
    /**
   * Returns plugin instance by provided its name.
   *
   * @memberof Core#
   * @function getPlugin
   * @param {string} pluginName The plugin name.
   * @returns {BasePlugin|undefined} The plugin instance or undefined if there is no plugin.
   */ this.getPlugin = function(pluginName) {
        return pluginsRegistry.getItem((0, _string.toUpperCaseFirst)(pluginName));
    };
    /**
   * Returns name of the passed plugin.
   *
   * @private
   * @memberof Core#
   * @param {BasePlugin} plugin The plugin instance.
   * @returns {string}
   */ this.getPluginName = function(plugin) {
        return pluginsRegistry.getId(plugin);
    };
    /**
   * Returns the Handsontable instance.
   *
   * @memberof Core#
   * @function getInstance
   * @returns {Handsontable} The Handsontable instance.
   */ this.getInstance = function() {
        return instance;
    };
    /**
   * Adds listener to the specified hook name (only for this Handsontable instance).
   *
   * @memberof Core#
   * @function addHook
   * @see Hooks#add
   * @param {string} key Hook name (see {@link Hooks}).
   * @param {Function|Array} callback Function or array of functions.
   * @param {number} [orderIndex] Order index of the callback.
   *                              If > 0, the callback will be added after the others, for example, with an index of 1, the callback will be added before the ones with an index of 2, 3, etc., but after the ones with an index of 0 and lower.
   *                              If < 0, the callback will be added before the others, for example, with an index of -1, the callback will be added after the ones with an index of -2, -3, etc., but before the ones with an index of 0 and higher.
   *                              If 0 or no order index is provided, the callback will be added between the "negative" and "positive" indexes.
   * @example
   * ```js
   * hot.addHook('beforeInit', myCallback);
   * ```
   */ this.addHook = function(key, callback, orderIndex) {
        _index.Hooks.getSingleton().add(key, callback, instance, orderIndex);
    };
    /**
   * Check if for a specified hook name there are added listeners (only for this Handsontable instance). All available
   * hooks you will find {@link Hooks}.
   *
   * @memberof Core#
   * @function hasHook
   * @see Hooks#has
   * @param {string} key Hook name.
   * @returns {boolean}
   *
   * @example
   * ```js
   * const hasBeforeInitListeners = hot.hasHook('beforeInit');
   * ```
   */ this.hasHook = function(key) {
        return _index.Hooks.getSingleton().has(key, instance) || _index.Hooks.getSingleton().has(key);
    };
    /**
   * Adds listener to specified hook name (only for this Handsontable instance). After the listener is triggered,
   * it will be automatically removed.
   *
   * @memberof Core#
   * @function addHookOnce
   * @see Hooks#once
   * @param {string} key Hook name (see {@link Hooks}).
   * @param {Function|Array} callback Function or array of functions.
   * @param {number} [orderIndex] Order index of the callback.
   *                              If > 0, the callback will be added after the others, for example, with an index of 1, the callback will be added before the ones with an index of 2, 3, etc., but after the ones with an index of 0 and lower.
   *                              If < 0, the callback will be added before the others, for example, with an index of -1, the callback will be added after the ones with an index of -2, -3, etc., but before the ones with an index of 0 and higher.
   *                              If 0 or no order index is provided, the callback will be added between the "negative" and "positive" indexes.
   * @example
   * ```js
   * hot.addHookOnce('beforeInit', myCallback);
   * ```
   */ this.addHookOnce = function(key, callback, orderIndex) {
        _index.Hooks.getSingleton().once(key, callback, instance, orderIndex);
    };
    /**
   * Removes the hook listener previously registered with {@link Core#addHook}.
   *
   * @memberof Core#
   * @function removeHook
   * @see Hooks#remove
   * @param {string} key Hook name.
   * @param {Function} callback Reference to the function which has been registered using {@link Core#addHook}.
   *
   * @example
   * ```js
   * hot.removeHook('beforeInit', myCallback);
   * ```
   */ this.removeHook = function(key, callback) {
        _index.Hooks.getSingleton().remove(key, callback, instance);
    };
    /**
   * Run the callbacks for the hook provided in the `key` argument using the parameters given in the other arguments.
   *
   * @memberof Core#
   * @function runHooks
   * @see Hooks#run
   * @param {string} key Hook name.
   * @param {*} [p1] Argument passed to the callback.
   * @param {*} [p2] Argument passed to the callback.
   * @param {*} [p3] Argument passed to the callback.
   * @param {*} [p4] Argument passed to the callback.
   * @param {*} [p5] Argument passed to the callback.
   * @param {*} [p6] Argument passed to the callback.
   * @returns {*}
   *
   * @example
   * ```js
   * // Run built-in hook
   * hot.runHooks('beforeInit');
   * // Run custom hook
   * hot.runHooks('customAction', 10, 'foo');
   * ```
   */ this.runHooks = function(key, p1, p2, p3, p4, p5, p6) {
        return _index.Hooks.getSingleton().run(instance, key, p1, p2, p3, p4, p5, p6);
    };
    /**
   * Get language phrase for specified dictionary key.
   *
   * @memberof Core#
   * @function getTranslatedPhrase
   * @since 0.35.0
   * @param {string} dictionaryKey Constant which is dictionary key.
   * @param {*} extraArguments Arguments which will be handled by formatters.
   * @returns {string}
   */ this.getTranslatedPhrase = function(dictionaryKey, extraArguments) {
        return (0, _registry4.getTranslatedPhrase)(tableMeta.language, dictionaryKey, extraArguments);
    };
    /**
   * Converts instance into outerHTML of HTMLTableElement.
   *
   * @memberof Core#
   * @function toHTML
   * @since 7.1.0
   * @returns {string}
   */ this.toHTML = ()=>(0, _parseTable.instanceToHTML)(this);
    /**
   * Converts instance into HTMLTableElement.
   *
   * @memberof Core#
   * @function toTableElement
   * @since 7.1.0
   * @returns {HTMLTableElement}
   */ this.toTableElement = ()=>{
        const rootDocument = instance.rootDocument;
        const tempElement = rootDocument.createElement('div');
        tempElement.insertAdjacentHTML('afterbegin', (0, _parseTable.instanceToHTML)(instance));
        return tempElement.firstElementChild;
    };
    this.timeouts = [];
    /**
   * Use the theme specified by the provided name.
   *
   * @memberof Core#
   * @function useTheme
   * @since 15.0.0
   * @param {string|boolean|undefined} themeName The name of the theme to use.
   */ this.useTheme = (themeName)=>{
        const isFirstRun = !!firstRun;
        this.stylesHandler.useTheme(themeName ?? undefined);
        const validThemeName = this.stylesHandler.getThemeName();
        if (!isFirstRun && validThemeName) {
            if ((0, _themes.getThemeClassName)(this.rootContainer)) {
                (0, _element.removeClass)(this.rootContainer, /ht-theme-.*/g);
                (0, _element.addClass)(this.rootContainer, validThemeName);
            }
            instance.render();
            instance.scrollViewportTo(0, 0);
        }
        this.runHooks('afterSetTheme', validThemeName, isFirstRun);
    };
    /**
   * Gets the name of the currently used theme.
   *
   * @memberof Core#
   * @function getCurrentThemeName
   * @since 15.0.0
   * @returns {string|undefined} The name of the currently used theme.
   */ this.getCurrentThemeName = ()=>{
        return instance.stylesHandler.getThemeName() ?? null;
    };
    /**
   * Gets the table's root container element height.
   *
   * @memberof Core#
   * @function getTableHeight
   * @since 16.0.0
   * @returns {number}
   */ this.getTableHeight = ()=>{
        return instance.rootElement.offsetHeight;
    };
    /**
   * Gets the table's root container element width.
   *
   * @memberof Core#
   * @function getTableWidth
   * @since 16.0.0
   * @returns {number}
   */ this.getTableWidth = ()=>{
        return instance.rootElement.offsetWidth;
    };
    /**
   * Sets timeout. Purpose of this method is to clear all known timeouts when `destroy` method is called.
   *
   * @param {number|Function} handle Handler returned from setTimeout or function to execute (it will be automatically wraped
   *                                 by setTimeout function).
   * @param {number} [delay=0] If first argument is passed as a function this argument set delay of the execution of that function.
   * @returns {number} The timeout handle (usable with `clearTimeout`).
   * @private
   */ this._registerTimeout = function(handle, delay = 0) {
        let handleFunc = handle;
        if (typeof handleFunc === 'function') {
            handleFunc = setTimeout(handleFunc, delay);
        }
        this.timeouts.push(handleFunc);
        return handleFunc;
    };
    /**
   * Clears all known timeouts.
   *
   * @private
   */ this._clearTimeouts = function() {
        (0, _array.arrayEach)(this.timeouts, (handler)=>{
            clearTimeout(handler);
        });
    };
    this.microtasks = [];
    /**
   * Registers a microtask callback.
   *
   * @param {Function} callback Function to be delayed in execution.
   * @private
   */ this._registerMicrotask = function(callback) {
        const entry = {
            cancelled: false
        };
        this.microtasks.push(entry);
        this.rootWindow.queueMicrotask(()=>{
            if (!entry.cancelled) {
                callback();
            }
        });
    };
    /**
   * Clears all known microtasks (prevents pending callbacks from running).
   *
   * @private
   */ this._clearMicrotasks = function() {
        (0, _array.arrayEach)(this.microtasks, (entry)=>{
            entry.cancelled = true;
        });
        this.microtasks.length = 0;
    };
    /**
   * Gets the instance of the EditorManager.
   *
   * @private
   * @returns {EditorManager}
   */ this._getEditorManager = function() {
        return editorManager;
    };
    /**
   * Gets the instance of the DataSource.
   *
   * @private
   * @returns {DataSource}
   */ this._getDataSource = function() {
        return dataSource;
    };
    /**
   * Gets the instance of the MetaManager.
   *
   * @private
   * @returns {MetaManager}
   */ this._getMetaManager = function() {
        return metaManager;
    };
    const shortcutManager = (0, _shortcuts.createShortcutManager)({
        handleEvent (_event, scope) {
            if (scope === 'global') {
                return true;
            }
            return instance.isListening();
        },
        beforeKeyDown: (event)=>{
            return instance.runHooks('beforeKeyDown', event);
        },
        afterKeyDown: (event)=>{
            if (this.isDestroyed) {
                return;
            }
            instance.runHooks('afterDocumentKeyDown', event);
        },
        ownerWindow: this.rootWindow
    });
    this.addHook('beforeOnCellMouseDown', (event)=>{
        // Releasing keys as some browser/system shortcuts break events sequence (thus the `keyup` event isn't triggered).
        if (event.ctrlKey === false && event.metaKey === false) {
            shortcutManager.releasePressedKeys();
        }
    });
    /**
   * Returns instance of a manager responsible for handling shortcuts stored in some contexts. It run actions after
   * pressing key combination in active Handsontable instance.
   *
   * @memberof Core#
   * @since 12.0.0
   * @function getShortcutManager
   * @returns {ShortcutManager} Instance of {@link ShortcutManager}
   */ this.getShortcutManager = function() {
        return shortcutManager;
    };
    focusGridManager = new _focusManager.FocusGridManager(instance);
    const focusScopeManager = (0, _rootInstance.isRootInstance)(this) ? (0, _focusManager.createFocusScopeManager)(instance) : null;
    const layoutManager = (0, _rootInstance.isRootInstance)(this) ? new _layout.LayoutManager({
        top: instance.rootSlotTopElement,
        bottom: instance.rootSlotBottomElement
    }) : null;
    /**
   * Return the Focus Manager responsible for managing the browser's focus in the table.
   *
   * @memberof Core#
   * @since 14.0.0
   * @function getFocusManager
   * @returns {FocusManager}
   */ this.getFocusManager = function() {
        return focusGridManager;
    };
    /**
   * Returns the Focus Scope Manager. The module allows to register focus scopes for different parts of the grid
   * e.g. for dialogs, pagination, and other plugins that have own UI elements and need separate context.
   *
   * @memberof Core#
   * @since 16.2.0
   * @function getFocusScopeManager
   * @returns {FocusScopeManager} Instance of {@link FocusScopeManager}
   *
   * @example
   * ```js
   * hot.getFocusScopeManager().registerScope('myPluginName', containerElement, {
   *   shortcutsContextName: 'plugin:myPluginName',
   *   onActivate: (focusSource) => {
   *     // Focus the internal focusable element within the plugin UI element
   *     // depends on the activation focus source.
   *   },
   * });
   * ```
   */ this.getFocusScopeManager = function() {
        if (!(0, _rootInstance.isRootInstance)(instance)) {
            (0, _errors.throwWithCause)('The FocusScopeManager is only available for the main Handsontable instance.');
        }
        return focusScopeManager;
    };
    /**
   * Returns the Layout Manager. The module manages the order of plugin UI elements within the
   * user-orderable wrapper slots (`top`, `bottom`). Use it to add or remove custom UI and
   * order it via weights or the `layout` setting. Only available for the main instance.
   *
   * @memberof Core#
   * @since 18.0.0
   * @function getLayoutManager
   * @returns {LayoutManager} Instance of {@link LayoutManager}
   *
   * @example
   * ```js
   * hot.getLayoutManager().register('myToolbar', toolbarElement, { side: 'top', weight: 100 });
   * ```
   */ this.getLayoutManager = function() {
        if (!(0, _rootInstance.isRootInstance)(instance)) {
            (0, _errors.throwWithCause)('The LayoutManager is only available for the main Handsontable instance.');
        }
        return layoutManager;
    };
    const theme = mergedUserSettings.theme;
    const themeName = mergedUserSettings.themeName;
    const rootContainerThemeClassName = (0, _themes.getThemeClassName)(instance.rootContainer);
    if ((0, _rootInstance.isRootInstance)(instance) && !rootContainerThemeClassName && ((0, _object.isObject)(theme) || !theme && !themeName)) {
        initializeThemeManager(theme, readThemeOverrides(mergedUserSettings));
    }
    (0, _registry.getPluginsNames)().forEach((pluginName)=>{
        const PluginClass = (0, _registry.getPlugin)(pluginName);
        if (PluginClass) {
            pluginsRegistry.addItem(pluginName, new PluginClass(this));
        }
    });
    (0, _contexts.registerAllShortcutContexts)(instance);
    if ((0, _rootInstance.isRootInstance)(this)) {
        (0, _focusManager.registerAllFocusScopes)(instance);
    }
    shortcutManager.setActiveContextName('grid');
    _index.Hooks.getSingleton().run(instance, 'construct');
}
