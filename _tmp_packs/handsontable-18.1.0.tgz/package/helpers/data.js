"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get cloneRow () {
        return cloneRow;
    },
    get countFirstRowKeys () {
        return countFirstRowKeys;
    },
    get createEmptySpreadsheetData () {
        return createEmptySpreadsheetData;
    },
    get createSpreadsheetData () {
        return createSpreadsheetData;
    },
    get createSpreadsheetObjectData () {
        return createSpreadsheetObjectData;
    },
    get dataRowToChangesArray () {
        return dataRowToChangesArray;
    },
    get hasChangeForCell () {
        return hasChangeForCell;
    },
    get isArrayOfArrays () {
        return isArrayOfArrays;
    },
    get isArrayOfObjects () {
        return isArrayOfObjects;
    },
    get spreadsheetColumnIndex () {
        return spreadsheetColumnIndex;
    },
    get spreadsheetColumnLabel () {
        return spreadsheetColumnLabel;
    }
});
const _object = require("./object");
const COLUMN_LABEL_BASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const COLUMN_LABEL_BASE_LENGTH = COLUMN_LABEL_BASE.length;
function spreadsheetColumnLabel(index) {
    let dividend = index + 1;
    let columnLabel = '';
    let modulo;
    while(dividend > 0){
        modulo = (dividend - 1) % COLUMN_LABEL_BASE_LENGTH;
        columnLabel = String.fromCharCode(65 + modulo) + columnLabel;
        dividend = parseInt(String((dividend - modulo) / COLUMN_LABEL_BASE_LENGTH), 10);
    }
    return columnLabel;
}
function spreadsheetColumnIndex(label) {
    let result = 0;
    if (label) {
        for(let i = 0, j = label.length - 1; i < label.length; i += 1, j -= 1){
            result += COLUMN_LABEL_BASE_LENGTH ** j * (COLUMN_LABEL_BASE.indexOf(label[i]) + 1);
        }
    }
    result -= 1;
    return result;
}
function createSpreadsheetData(rows = 100, columns = 4) {
    const _rows = [];
    let i;
    let j;
    for(i = 0; i < rows; i++){
        const row = [];
        for(j = 0; j < columns; j++){
            row.push(spreadsheetColumnLabel(j) + (i + 1));
        }
        _rows.push(row);
    }
    return _rows;
}
function createSpreadsheetObjectData(rows = 100, colCount = 4) {
    const _rows = [];
    let i;
    let j;
    for(i = 0; i < rows; i++){
        const row = {};
        for(j = 0; j < colCount; j++){
            row[`prop${j}`] = spreadsheetColumnLabel(j) + (i + 1);
        }
        _rows.push(row);
    }
    return _rows;
}
function createEmptySpreadsheetData(rows, columns) {
    const data = [];
    let row;
    for(let i = 0; i < rows; i++){
        row = [];
        for(let j = 0; j < columns; j++){
            row.push('');
        }
        data.push(row);
    }
    return data;
}
function dataRowToChangesArray(dataRow, rowOffset = 0) {
    let dataRows = dataRow;
    const changesArray = [];
    if (!Array.isArray(dataRow) || !Array.isArray(dataRow[0])) {
        dataRows = [
            dataRow
        ];
    }
    dataRows.forEach((row, rowIndex)=>{
        if (Array.isArray(row)) {
            row.forEach((value, column)=>{
                changesArray.push([
                    rowIndex + rowOffset,
                    column,
                    value
                ]);
            });
        } else {
            Object.keys(row).forEach((propName)=>{
                changesArray.push([
                    rowIndex + rowOffset,
                    propName,
                    row[propName]
                ]);
            });
        }
    });
    return changesArray;
}
function hasChangeForCell(changes, visualRow, prop) {
    return changes.some(([changeRow, changeProp])=>changeRow === visualRow && changeProp === prop);
}
function countFirstRowKeys(data) {
    let result = 0;
    if (Array.isArray(data)) {
        if (data[0] && Array.isArray(data[0])) {
            result = data[0].length;
        } else if (data[0] && (0, _object.isObject)(data[0])) {
            result = (0, _object.deepObjectSize)(data[0]);
        }
    }
    return result;
}
function isArrayOfArrays(data) {
    return !!(Array.isArray(data) && data.length && data.every((el)=>Array.isArray(el)));
}
function isArrayOfObjects(data) {
    return !!(Array.isArray(data) && data.length && data.every((el)=>typeof el === 'object' && !Array.isArray(el) && el !== null));
}
function cloneRow(row) {
    if (Array.isArray(row)) {
        return row.slice();
    }
    if (row !== null && typeof row === 'object') {
        return {
            ...row
        };
    }
    return row;
}
