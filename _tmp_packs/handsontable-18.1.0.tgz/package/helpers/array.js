/**
 * @param {Array} arr An array to process.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get arrayAvg () {
        return arrayAvg;
    },
    get arrayEach () {
        return arrayEach;
    },
    get arrayFilter () {
        return arrayFilter;
    },
    get arrayFlatten () {
        return arrayFlatten;
    },
    get arrayMap () {
        return arrayMap;
    },
    get arrayMax () {
        return arrayMax;
    },
    get arrayMin () {
        return arrayMin;
    },
    get arrayReduce () {
        return arrayReduce;
    },
    get arraySum () {
        return arraySum;
    },
    get arrayToString () {
        return arrayToString;
    },
    get arrayUnique () {
        return arrayUnique;
    },
    get extendArray () {
        return extendArray;
    },
    get getDifferenceOfArrays () {
        return getDifferenceOfArrays;
    },
    get getIntersectionOfArrays () {
        return getIntersectionOfArrays;
    },
    get getUnionOfArrays () {
        return getUnionOfArrays;
    },
    get insertValuesInPlace () {
        return insertValuesInPlace;
    },
    get pivot () {
        return pivot;
    },
    get removeIndexesInPlace () {
        return removeIndexesInPlace;
    },
    get stringToArray () {
        return stringToArray;
    },
    get to2dArray () {
        return to2dArray;
    }
});
function to2dArray(arr) {
    const ilen = arr.length;
    let i = 0;
    while(i < ilen){
        arr[i] = [
            arr[i]
        ];
        i += 1;
    }
}
function extendArray(arr, extension) {
    const ilen = extension.length;
    let i = 0;
    while(i < ilen){
        arr.push(extension[i]);
        i += 1;
    }
}
function pivot(arr) {
    const pivotedArr = [];
    if (!arr || arr.length === 0 || !arr[0] || arr[0].length === 0) {
        return pivotedArr;
    }
    const rowCount = arr.length;
    const colCount = arr[0].length;
    for(let i = 0; i < rowCount; i++){
        for(let j = 0; j < colCount; j++){
            if (!pivotedArr[j]) {
                pivotedArr[j] = [];
            }
            pivotedArr[j][i] = arr[i][j];
        }
    }
    return pivotedArr;
}
function arrayReduce(array, iteratee, accumulator, initFromArray) {
    let index = -1;
    const iterable = Array.isArray(array) ? array : Array.from(array);
    const length = iterable.length;
    if (initFromArray && length) {
        index += 1;
        accumulator = iterable[index];
    }
    let result = accumulator;
    index += 1;
    while(index < length){
        result = iteratee(result, iterable[index], index, iterable);
        index += 1;
    }
    return result;
}
function arrayFilter(array, predicate) {
    let index = 0;
    const iterable = Array.isArray(array) ? array : Array.from(array);
    const length = iterable.length;
    const result = [];
    let resIndex = -1;
    while(index < length){
        const value = iterable[index];
        if (predicate(value, index, iterable)) {
            resIndex += 1;
            result[resIndex] = value;
        }
        index += 1;
    }
    return result;
}
function arrayMap(array, iteratee) {
    let index = 0;
    const iterable = Array.isArray(array) ? array : Array.from(array);
    const length = iterable.length;
    const result = [];
    let resIndex = -1;
    while(index < length){
        const value = iterable[index];
        resIndex += 1;
        result[resIndex] = iteratee(value, index, iterable);
        index += 1;
    }
    return result;
}
function arrayEach(array, iteratee) {
    let index = 0;
    let iterable;
    if (Array.isArray(array)) {
        iterable = array;
    } else {
        iterable = Array.from(array);
    }
    const length = iterable.length;
    while(index < length){
        if (iteratee(iterable[index], index, iterable) === false) {
            break;
        }
        index += 1;
    }
    return iterable;
}
function arraySum(array) {
    return arrayReduce(array, (a, b)=>a + b, 0);
}
function arrayMax(array) {
    return arrayReduce(array, (a, b)=>a !== undefined && a > b ? a : b, array[0]);
}
function arrayMin(array) {
    return arrayReduce(array, (a, b)=>a !== undefined && a < b ? a : b, array[0]);
}
function arrayAvg(array) {
    if (!array.length) {
        return 0;
    }
    return arraySum(array) / array.length;
}
function arrayFlatten(array) {
    return arrayReduce(array, (initial, value)=>initial.concat(Array.isArray(value) ? arrayFlatten(value) : value), []);
}
function removeIndexesInPlace(array, indexes) {
    let writeIndex = 0;
    for(let readIndex = 0; readIndex < array.length; readIndex++){
        if (!indexes.has(readIndex)) {
            array[writeIndex] = array[readIndex];
            writeIndex += 1;
        }
    }
    array.length = writeIndex;
    return array;
}
function insertValuesInPlace(array, index, amount, value) {
    if (amount <= 0) {
        return array;
    }
    const oldLength = array.length;
    const insertAt = Math.min(index, oldLength);
    array.length = oldLength + amount;
    for(let i = oldLength - 1; i >= insertAt; i--){
        array[i + amount] = array[i];
    }
    array.fill(value, insertAt, insertAt + amount);
    return array;
}
function arrayUnique(array) {
    const unique = [];
    const seen = new Set();
    arrayEach(array, (value)=>{
        if (!seen.has(value)) {
            seen.add(value);
            unique.push(value);
        }
    });
    return unique;
}
function getDifferenceOfArrays(...arrays) {
    const [first, ...rest] = [
        ...arrays
    ];
    let filteredFirstArray = first;
    arrayEach(rest, (array)=>{
        const lookup = new Set(array);
        filteredFirstArray = filteredFirstArray.filter((value)=>!lookup.has(value));
    });
    return filteredFirstArray;
}
function getIntersectionOfArrays(...args) {
    const arrays = [];
    let comparator;
    arrayEach(args, (arg, index)=>{
        if (typeof arg === 'function') {
            if (index === args.length - 1) {
                comparator = arg;
            }
        } else {
            arrays.push(arg);
        }
    });
    const [first, ...rest] = arrays;
    let filteredFirstArray = first;
    arrayEach(rest, (array)=>{
        if (comparator) {
            filteredFirstArray = filteredFirstArray.filter((value)=>array.some((item)=>comparator(value, item)));
        } else {
            const lookup = new Set(array);
            filteredFirstArray = filteredFirstArray.filter((value)=>lookup.has(value));
        }
    });
    return filteredFirstArray;
}
function getUnionOfArrays(...arrays) {
    const [first, ...rest] = [
        ...arrays
    ];
    const set = new Set(first);
    arrayEach(rest, (array)=>{
        arrayEach(array, (value)=>{
            if (!set.has(value)) {
                set.add(value);
            }
        });
    });
    return Array.from(set);
}
function stringToArray(value, delimiter = ' ') {
    return value.split(delimiter);
}
function arrayToString(array, separator = ' ') {
    return array.join(separator);
}
