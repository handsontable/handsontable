"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get _resetDeprecationWarnings () {
        return _resetDeprecationWarnings;
    },
    get deprecatedWarnOnce () {
        return deprecatedWarnOnce;
    },
    get error () {
        return error;
    },
    get info () {
        return info;
    },
    get log () {
        return log;
    },
    get logAggregatedItems () {
        return logAggregatedItems;
    },
    get removedWarnOnce () {
        return removedWarnOnce;
    },
    get warn () {
        return warn;
    },
    get warnOnce () {
        return warnOnce;
    }
});
const _templateString = require("./templateString");
const _mixed = require("./mixed");
function log(...args) {
    if ((0, _mixed.isDefined)(console)) {
        console.log(...args);
    }
}
function warn(...args) {
    if ((0, _mixed.isDefined)(console)) {
        console.warn(...args);
    }
}
/**
 * Tracks which `key`s have already been warned about, grouped by a scope object.
 * A `WeakMap` lets the entries be garbage-collected together with their scope
 * (for example, when a Handsontable instance is destroyed), so the "warn once"
 * state resets per instance without any manual cleanup.
 */ const warnedScopes = new WeakMap();
function warnOnce(scope, key, ...args) {
    let warnedKeys = warnedScopes.get(scope);
    if (warnedKeys === undefined) {
        warnedKeys = new Set();
        warnedScopes.set(scope, warnedKeys);
    }
    if (warnedKeys.has(key)) {
        return;
    }
    warnedKeys.add(key);
    warn(...args);
}
/**
 * Keys of deprecation and removal warnings that were already printed. Module-level on purpose:
 * a deprecated or removed API is reported once per page, regardless of how many grid instances
 * touch it, which is what the deprecation policy promises.
 */ const printedDeprecations = new Set();
/**
 * Logs `message` to the console only once per `key` if the `console` object is exposed.
 * Shared by the deprecation and removal warnings, so both draw from one record and one reset.
 *
 * @param {string} key A stable identifier of the reported API.
 * @param {string} message The final message to log.
 */ function warnOncePerKey(key, message) {
    if (printedDeprecations.has(key)) {
        return;
    }
    // Record the key only when the message can actually be printed. Otherwise the first call made
    // while `console` is missing would burn the key for the whole page and silence every later one.
    if (!(0, _mixed.isDefined)(console)) {
        return;
    }
    printedDeprecations.add(key);
    console.warn(message);
}
function deprecatedWarnOnce(key, message) {
    warnOncePerKey(key, `Deprecated: ${message}`);
}
function removedWarnOnce(key, message) {
    warnOncePerKey(key, message);
}
function _resetDeprecationWarnings() {
    printedDeprecations.clear();
}
function info(...args) {
    if ((0, _mixed.isDefined)(console)) {
        console.info(...args);
    }
}
function error(...args) {
    if ((0, _mixed.isDefined)(console)) {
        console.error(...args);
    }
}
function logAggregatedItems({ logFunction = log, message = '', items = [], maxSample = 5, itemFormatter = (item)=>`${item}` } = {}) {
    if (!Array.isArray(items) || items.length === 0) {
        return;
    }
    const count = items.length;
    const formattedItems = items.slice(0, maxSample).map((item)=>`  - ${itemFormatter(item)}`);
    const more = count > maxSample ? `  - ...and ${count - maxSample} more` : '';
    const affectedLines = [
        'Affected cells:',
        ...formattedItems,
        ...more ? [
            more
        ] : []
    ].join('\n');
    logFunction((0, _templateString.substitute)(message, {
        itemsCount: `${count} cell${count > 1 ? 's' : ''}`,
        affectedCells: affectedLines
    }));
}
