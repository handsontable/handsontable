/* eslint-disable no-restricted-globals */ /**
 * Polyfill for requestAnimationFrame.
 *
 * @param {Function} callback The function to call when it's time.
 * @returns {number}
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get cancelAnimationFrame () {
        return cancelAnimationFrame;
    },
    get cancelIdleTask () {
        return cancelIdleTask;
    },
    get getComparisonFunction () {
        return getComparisonFunction;
    },
    get isCSR () {
        return isCSR;
    },
    get isTouchSupported () {
        return isTouchSupported;
    },
    get requestAnimationFrame () {
        return requestAnimationFrame;
    },
    get requestIdleTask () {
        return requestIdleTask;
    }
});
function requestAnimationFrame(callback) {
    return window.requestAnimationFrame(callback);
}
function cancelAnimationFrame(id) {
    window.cancelAnimationFrame(id);
}
function requestIdleTask(callback, timeout = 100) {
    if (typeof window.requestIdleCallback === 'function') {
        return window.requestIdleCallback(()=>callback(), {
            timeout
        });
    }
    return window.requestAnimationFrame(callback);
}
function cancelIdleTask(id) {
    if (typeof window.cancelIdleCallback === 'function') {
        window.cancelIdleCallback(id);
    } else {
        window.cancelAnimationFrame(id);
    }
}
function isTouchSupported() {
    return 'ontouchstart' in window;
}
function isCSR() {
    return typeof window !== 'undefined';
}
let comparisonFunction;
function getComparisonFunction(language, options = {}) {
    if (comparisonFunction) {
        return comparisonFunction;
    }
    if (typeof Intl === 'object') {
        comparisonFunction = new Intl.Collator(language, options).compare;
    } else if (typeof String.prototype.localeCompare === 'function') {
        comparisonFunction = (a, b)=>`${a}`.localeCompare(b);
    } else {
        comparisonFunction = (a, b)=>{
            if (a === b) {
                return 0;
            }
            return a > b ? -1 : 1;
        };
    }
    return comparisonFunction;
}
