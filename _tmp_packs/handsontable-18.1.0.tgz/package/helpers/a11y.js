/** Returns [attr, value] for setting on elements (e.g. tabindex, aria-*) */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get A11Y_ACTIVEDESCENDANT () {
        return A11Y_ACTIVEDESCENDANT;
    },
    get A11Y_ALERTDIALOG () {
        return A11Y_ALERTDIALOG;
    },
    get A11Y_AUTOCOMPLETE () {
        return A11Y_AUTOCOMPLETE;
    },
    get A11Y_BUSY () {
        return A11Y_BUSY;
    },
    get A11Y_CHECKBOX () {
        return A11Y_CHECKBOX;
    },
    get A11Y_CHECKED () {
        return A11Y_CHECKED;
    },
    get A11Y_COLCOUNT () {
        return A11Y_COLCOUNT;
    },
    get A11Y_COLINDEX () {
        return A11Y_COLINDEX;
    },
    get A11Y_COLUMNHEADER () {
        return A11Y_COLUMNHEADER;
    },
    get A11Y_COMBOBOX () {
        return A11Y_COMBOBOX;
    },
    get A11Y_CONTROLS () {
        return A11Y_CONTROLS;
    },
    get A11Y_DESCRIBED_BY () {
        return A11Y_DESCRIBED_BY;
    },
    get A11Y_DIALOG () {
        return A11Y_DIALOG;
    },
    get A11Y_DISABLED () {
        return A11Y_DISABLED;
    },
    get A11Y_EXPANDED () {
        return A11Y_EXPANDED;
    },
    get A11Y_GRIDCELL () {
        return A11Y_GRIDCELL;
    },
    get A11Y_GRIDCELL_BUTTON () {
        return A11Y_GRIDCELL_BUTTON;
    },
    get A11Y_GROUP () {
        return A11Y_GROUP;
    },
    get A11Y_HASPOPUP () {
        return A11Y_HASPOPUP;
    },
    get A11Y_HIDDEN () {
        return A11Y_HIDDEN;
    },
    get A11Y_INVALID () {
        return A11Y_INVALID;
    },
    get A11Y_LABEL () {
        return A11Y_LABEL;
    },
    get A11Y_LABELED_BY () {
        return A11Y_LABELED_BY;
    },
    get A11Y_LISTBOX () {
        return A11Y_LISTBOX;
    },
    get A11Y_LIVE () {
        return A11Y_LIVE;
    },
    get A11Y_MENU () {
        return A11Y_MENU;
    },
    get A11Y_MENU_ITEM () {
        return A11Y_MENU_ITEM;
    },
    get A11Y_MENU_ITEM_CHECKBOX () {
        return A11Y_MENU_ITEM_CHECKBOX;
    },
    get A11Y_MODAL () {
        return A11Y_MODAL;
    },
    get A11Y_MULTISELECTABLE () {
        return A11Y_MULTISELECTABLE;
    },
    get A11Y_OPTION () {
        return A11Y_OPTION;
    },
    get A11Y_POSINSET () {
        return A11Y_POSINSET;
    },
    get A11Y_PRESENTATION () {
        return A11Y_PRESENTATION;
    },
    get A11Y_READONLY () {
        return A11Y_READONLY;
    },
    get A11Y_RELEVANT () {
        return A11Y_RELEVANT;
    },
    get A11Y_ROW () {
        return A11Y_ROW;
    },
    get A11Y_ROWCOUNT () {
        return A11Y_ROWCOUNT;
    },
    get A11Y_ROWGROUP () {
        return A11Y_ROWGROUP;
    },
    get A11Y_ROWHEADER () {
        return A11Y_ROWHEADER;
    },
    get A11Y_ROWINDEX () {
        return A11Y_ROWINDEX;
    },
    get A11Y_SCOPE_COL () {
        return A11Y_SCOPE_COL;
    },
    get A11Y_SCOPE_ROW () {
        return A11Y_SCOPE_ROW;
    },
    get A11Y_SELECTED () {
        return A11Y_SELECTED;
    },
    get A11Y_SETSIZE () {
        return A11Y_SETSIZE;
    },
    get A11Y_SORT () {
        return A11Y_SORT;
    },
    get A11Y_TABINDEX () {
        return A11Y_TABINDEX;
    },
    get A11Y_TEXT () {
        return A11Y_TEXT;
    },
    get A11Y_TREEGRID () {
        return A11Y_TREEGRID;
    }
});
const A11Y_TABINDEX = (val)=>[
        'tabindex',
        val
    ];
const A11Y_TREEGRID = ()=>[
        'role',
        'treegrid'
    ];
const A11Y_PRESENTATION = ()=>[
        'role',
        'presentation'
    ];
const A11Y_GRIDCELL = ()=>[
        'role',
        'gridcell'
    ];
const A11Y_GRIDCELL_BUTTON = ()=>[
        'role',
        'gridcell button'
    ];
const A11Y_ROWHEADER = ()=>[
        'role',
        'rowheader'
    ];
const A11Y_ROWGROUP = ()=>[
        'role',
        'rowgroup'
    ];
const A11Y_COLUMNHEADER = ()=>[
        'role',
        'columnheader'
    ];
const A11Y_ROW = ()=>[
        'role',
        'row'
    ];
const A11Y_MENU = ()=>[
        'role',
        'menu'
    ];
const A11Y_MENU_ITEM = ()=>[
        'role',
        'menuitem'
    ];
const A11Y_MENU_ITEM_CHECKBOX = ()=>[
        'role',
        'menuitemcheckbox'
    ];
const A11Y_COMBOBOX = ()=>[
        'role',
        'combobox'
    ];
const A11Y_LISTBOX = ()=>[
        'role',
        'listbox'
    ];
const A11Y_OPTION = ()=>[
        'role',
        'option'
    ];
const A11Y_CHECKBOX = ()=>[
        'role',
        'checkbox'
    ];
const A11Y_DIALOG = ()=>[
        'role',
        'dialog'
    ];
const A11Y_ALERTDIALOG = ()=>[
        'role',
        'alertdialog'
    ];
const A11Y_GROUP = ()=>[
        'role',
        'group'
    ];
const A11Y_SCOPE_COL = ()=>[
        'scope',
        'col'
    ];
const A11Y_SCOPE_ROW = ()=>[
        'scope',
        'row'
    ];
const A11Y_TEXT = ()=>[
        'type',
        'text'
    ];
const A11Y_LABEL = (val)=>[
        'aria-label',
        val
    ];
const A11Y_LABELED_BY = (val)=>[
        'aria-labelledby',
        val
    ];
const A11Y_DESCRIBED_BY = (val)=>[
        'aria-describedby',
        val
    ];
const A11Y_HIDDEN = ()=>[
        'aria-hidden',
        'true'
    ];
const A11Y_DISABLED = (val = true)=>[
        'aria-disabled',
        val
    ];
const A11Y_MULTISELECTABLE = ()=>[
        'aria-multiselectable',
        'true'
    ];
const A11Y_HASPOPUP = (val)=>[
        'aria-haspopup',
        val
    ];
const A11Y_ROWCOUNT = (val)=>[
        'aria-rowcount',
        val
    ];
const A11Y_COLCOUNT = (val)=>[
        'aria-colcount',
        val
    ];
const A11Y_ROWINDEX = (val)=>[
        'aria-rowindex',
        val
    ];
const A11Y_COLINDEX = (val)=>[
        'aria-colindex',
        val
    ];
const A11Y_EXPANDED = (val)=>[
        'aria-expanded',
        val
    ];
const A11Y_SORT = (val)=>[
        'aria-sort',
        val
    ];
const A11Y_READONLY = ()=>[
        'aria-readonly',
        'true'
    ];
const A11Y_INVALID = ()=>[
        'aria-invalid',
        'true'
    ];
const A11Y_CHECKED = (val)=>[
        'aria-checked',
        val
    ];
const A11Y_SELECTED = ()=>[
        'aria-selected',
        'true'
    ];
const A11Y_AUTOCOMPLETE = ()=>[
        'aria-autocomplete',
        'list'
    ];
const A11Y_CONTROLS = (val)=>[
        'aria-controls',
        val
    ];
const A11Y_ACTIVEDESCENDANT = (val)=>[
        'aria-activedescendant',
        val
    ];
const A11Y_LIVE = (val)=>[
        'aria-live',
        val
    ];
const A11Y_RELEVANT = (val)=>[
        'aria-relevant',
        val
    ];
const A11Y_SETSIZE = (val)=>[
        'aria-setsize',
        val
    ];
const A11Y_POSINSET = (val)=>[
        'aria-posinset',
        val
    ];
const A11Y_MODAL = ()=>[
        'aria-modal',
        'true'
    ];
const A11Y_BUSY = ()=>[
        'aria-busy',
        'true'
    ];
