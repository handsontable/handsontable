"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ISO_DATETIME_REGEX () {
        return ISO_DATETIME_REGEX;
    },
    get ISO_DATE_REGEX () {
        return ISO_DATE_REGEX;
    },
    get TIME_REGEX () {
        return TIME_REGEX;
    },
    get getNormalizedDate () {
        return getNormalizedDate;
    },
    get getRelativeLocalDate () {
        return getRelativeLocalDate;
    },
    get getTodayLocalDate () {
        return getTodayLocalDate;
    },
    get isSameLocalDay () {
        return isSameLocalDay;
    },
    get isValidISODate () {
        return isValidISODate;
    },
    get isValidISODateTime () {
        return isValidISODateTime;
    },
    get isValidTime () {
        return isValidTime;
    },
    get parseToLocalDate () {
        return parseToLocalDate;
    },
    get parseToLocalDateTime () {
        return parseToLocalDateTime;
    },
    get parseToLocalTime () {
        return parseToLocalTime;
    }
});
const _mixed = require("./mixed");
const ISO_DATE_REGEX = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
function getNormalizedDate(dateString) {
    const nativeDate = new Date(dateString);
    if (!Number.isNaN(new Date(`${dateString}T00:00`).getDate())) {
        return new Date(nativeDate.getTime() + nativeDate.getTimezoneOffset() * 60000);
    }
    return nativeDate;
}
function parseToLocalDate(value) {
    if ((0, _mixed.isEmpty)(value)) {
        return null;
    }
    if (typeof value === 'string' && ISO_DATE_REGEX.test(value)) {
        const [y, m, d] = value.split('-').map(Number);
        return new Date(y, m - 1, d);
    }
    return null;
}
/**
 * Number of days in each month for a non-leap year, indexed by zero-based month.
 */ const DAYS_IN_MONTH = [
    31,
    28,
    31,
    30,
    31,
    30,
    31,
    31,
    30,
    31,
    30,
    31
];
/**
 * Checks if a year is a leap year in the proleptic Gregorian calendar.
 */ function isLeapYear(year) {
    return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
}
function isValidISODate(value) {
    if (typeof value !== 'string' || !ISO_DATE_REGEX.test(value)) {
        return false;
    }
    // The regex guarantees the YYYY-MM-DD shape with month 01-12 and day 01-31. The only remaining
    // check is the calendar bound: that the day fits the given month and year (e.g. rejecting 02-30,
    // 04-31, or 02-29 in a non-leap year). Doing this arithmetically avoids constructing a Date and
    // round-tripping through toISOString() for every cell, which dominated load time on large
    // date-typed grids.
    const year = +value.slice(0, 4);
    const month = +value.slice(5, 7);
    const day = +value.slice(8, 10);
    const maxDay = month === 2 && isLeapYear(year) ? 29 : DAYS_IN_MONTH[month - 1];
    return day <= maxDay;
}
const TIME_REGEX = /^([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d)(?:\.(\d{1,3}))?)?$/;
function parseToLocalTime(value) {
    if ((0, _mixed.isEmpty)(value)) {
        return null;
    }
    if (typeof value !== 'string') {
        return null;
    }
    const match = TIME_REGEX.exec(value);
    if (!match) {
        return null;
    }
    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    const seconds = match[3] !== undefined ? Number(match[3]) : 0;
    const msString = match[4];
    const milliseconds = msString !== undefined ? Number(msString.padEnd(3, '0').slice(0, 3)) : 0;
    return new Date(1970, 0, 1, hours, minutes, seconds, milliseconds);
}
function isValidTime(value) {
    return typeof value === 'string' && TIME_REGEX.test(value);
}
const ISO_DATETIME_REGEX = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])(?:[T ]([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d)(?:\.(\d{1,3}))?)?)?$/;
function parseToLocalDateTime(value) {
    if ((0, _mixed.isEmpty)(value)) {
        return null;
    }
    if (typeof value !== 'string') {
        return null;
    }
    const match = ISO_DATETIME_REGEX.exec(value);
    if (!match) {
        return null;
    }
    const [datePart] = value.split(/[T ]/);
    const [year, month, day] = datePart.split('-').map(Number);
    const hours = match[3] !== undefined ? Number(match[3]) : 0;
    const minutes = match[4] !== undefined ? Number(match[4]) : 0;
    const seconds = match[5] !== undefined ? Number(match[5]) : 0;
    const milliseconds = match[6] !== undefined ? Number(match[6].padEnd(3, '0').slice(0, 3)) : 0;
    return new Date(year, month - 1, day, hours, minutes, seconds, milliseconds);
}
function isValidISODateTime(value) {
    if (typeof value !== 'string') {
        return false;
    }
    const match = ISO_DATETIME_REGEX.exec(value);
    if (!match) {
        return false;
    }
    const year = +value.slice(0, 4);
    const month = +match[1];
    const day = +match[2];
    const maxDay = month === 2 && isLeapYear(year) ? 29 : DAYS_IN_MONTH[month - 1];
    return day <= maxDay;
}
function getTodayLocalDate() {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}
function getRelativeLocalDate(days) {
    const result = getTodayLocalDate();
    result.setDate(result.getDate() + days);
    return result;
}
function isSameLocalDay(a, b) {
    return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}
