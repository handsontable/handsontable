"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get HTML_CHARACTERS () {
        return HTML_CHARACTERS;
    },
    get SANITIZER_WARN_KEY () {
        return SANITIZER_WARN_KEY;
    },
    get addClass () {
        return addClass;
    },
    get addEvent () {
        return addEvent;
    },
    get clearTextSelection () {
        return clearTextSelection;
    },
    get closest () {
        return closest;
    },
    get closestDown () {
        return closestDown;
    },
    get empty () {
        return empty;
    },
    get eventTargetEl () {
        return eventTargetEl;
    },
    get fastInnerHTML () {
        return fastInnerHTML;
    },
    get fastInnerText () {
        return fastInnerText;
    },
    get findFirstParentWithClass () {
        return findFirstParentWithClass;
    },
    get getCaretPosition () {
        return getCaretPosition;
    },
    get getChildEl () {
        return getChildEl;
    },
    get getCssTransform () {
        return getCssTransform;
    },
    get getDeepActiveElement () {
        return getDeepActiveElement;
    },
    get getFractionalScalingCompensation () {
        return getFractionalScalingCompensation;
    },
    get getFrameElement () {
        return getFrameElement;
    },
    get getMaximumScrollLeft () {
        return getMaximumScrollLeft;
    },
    get getMaximumScrollTop () {
        return getMaximumScrollTop;
    },
    get getParent () {
        return getParent;
    },
    get getParentWindow () {
        return getParentWindow;
    },
    get getScrollLeft () {
        return getScrollLeft;
    },
    get getScrollTop () {
        return getScrollTop;
    },
    get getScrollableElement () {
        return getScrollableElement;
    },
    get getScrollbarWidth () {
        return getScrollbarWidth;
    },
    get getSelectionEndPosition () {
        return getSelectionEndPosition;
    },
    get getSelectionText () {
        return getSelectionText;
    },
    get getShadowHostChain () {
        return getShadowHostChain;
    },
    get getStyle () {
        return getStyle;
    },
    get getTrimmingContainer () {
        return getTrimmingContainer;
    },
    get getWindowScrollLeft () {
        return getWindowScrollLeft;
    },
    get getWindowScrollTop () {
        return getWindowScrollTop;
    },
    get hasAccessToParentWindow () {
        return hasAccessToParentWindow;
    },
    get hasClass () {
        return hasClass;
    },
    get hasHorizontalScrollbar () {
        return hasHorizontalScrollbar;
    },
    get hasVerticalScrollbar () {
        return hasVerticalScrollbar;
    },
    get hasZeroHeight () {
        return hasZeroHeight;
    },
    get index () {
        return index;
    },
    get innerHeight () {
        return innerHeight;
    },
    get innerWidth () {
        return innerWidth;
    },
    get isBottomMostColumnHeader () {
        return isBottomMostColumnHeader;
    },
    get isChildOf () {
        return isChildOf;
    },
    get isDetached () {
        return isDetached;
    },
    get isHTMLElement () {
        return isHTMLElement;
    },
    get isHTMLInputElement () {
        return isHTMLInputElement;
    },
    get isHTMLTableCellElement () {
        return isHTMLTableCellElement;
    },
    get isInput () {
        return isInput;
    },
    get isInternalElement () {
        return isInternalElement;
    },
    get isOutsideInput () {
        return isOutsideInput;
    },
    get isShadowRoot () {
        return isShadowRoot;
    },
    get isVisible () {
        return isVisible;
    },
    get makeElementContentEditableAndSelectItsContent () {
        return makeElementContentEditableAndSelectItsContent;
    },
    get matchesCSSRules () {
        return matchesCSSRules;
    },
    get missingSanitizerMessage () {
        return missingSanitizerMessage;
    },
    get observeVisibilityChangeOnce () {
        return observeVisibilityChangeOnce;
    },
    get offset () {
        return offset;
    },
    get outerHeight () {
        return outerHeight;
    },
    get outerWidth () {
        return outerWidth;
    },
    get overlayContainsElement () {
        return overlayContainsElement;
    },
    get removeAttribute () {
        return removeAttribute;
    },
    get removeClass () {
        return removeClass;
    },
    get removeContentEditableFromElementAndDeselect () {
        return removeContentEditableFromElementAndDeselect;
    },
    get removeEvent () {
        return removeEvent;
    },
    get removeTextNodes () {
        return removeTextNodes;
    },
    get resetCssTransform () {
        return resetCssTransform;
    },
    get runWithSelectedContendEditableElement () {
        return runWithSelectedContendEditableElement;
    },
    get selectElementIfAllowed () {
        return selectElementIfAllowed;
    },
    get setAttribute () {
        return setAttribute;
    },
    get setCaretPosition () {
        return setCaretPosition;
    },
    get setOverlayPosition () {
        return setOverlayPosition;
    }
});
const _a11y = require("../a11y");
const _browser = require("../browser");
const _console = require("../../helpers/console");
function getParent(element, level = 0) {
    let iteration = -1;
    let parent = null;
    let elementToCheck = element;
    while(elementToCheck !== null){
        if (iteration === level) {
            parent = isHTMLElement(elementToCheck) ? elementToCheck : null;
            break;
        }
        if (isShadowRoot(elementToCheck)) {
            elementToCheck = elementToCheck.host;
        } else {
            iteration += 1;
            elementToCheck = elementToCheck.parentNode;
        }
    }
    return parent;
}
function isInternalElement(element, thisHotContainer) {
    const closestHandsontableContainer = element.closest('.handsontable');
    return !!closestHandsontableContainer && (closestHandsontableContainer.parentNode === thisHotContainer || closestHandsontableContainer === thisHotContainer);
}
function eventTargetEl(event) {
    return event.target;
}
function getFrameElement(frame) {
    const { frameElement } = frame;
    // `frame.parent` can be null when the iframe has been detached from the DOM. Guard before
    // passing to Object.getPrototypeOf(), which throws on null/undefined.
    return frame.parent && Object.getPrototypeOf(frame.parent) && frameElement instanceof HTMLIFrameElement ? frameElement : null;
}
function getParentWindow(frame) {
    return getFrameElement(frame) ? frame.parent : null;
}
function hasAccessToParentWindow(frame) {
    return !!Object.getPrototypeOf(frame.parent);
}
function closest(element, nodes = [], until) {
    const { ELEMENT_NODE, DOCUMENT_FRAGMENT_NODE } = Node;
    let elementToCheck = element;
    while(elementToCheck !== null && elementToCheck !== undefined && elementToCheck !== until){
        const { nodeType, nodeName } = elementToCheck;
        if (nodeType === ELEMENT_NODE && isHTMLElement(elementToCheck) && (nodes.includes(nodeName) || nodes.includes(elementToCheck))) {
            return elementToCheck;
        }
        if (isShadowRoot(elementToCheck)) {
            elementToCheck = elementToCheck.host;
        } else {
            elementToCheck = elementToCheck.parentNode;
        }
    }
    return null;
}
function closestDown(element, nodes, until) {
    const matched = [];
    let elementToCheck = isHTMLElement(element) ? element : null;
    while(elementToCheck){
        elementToCheck = closest(elementToCheck, nodes, until);
        if (!elementToCheck || until && !until.contains(elementToCheck)) {
            break;
        }
        matched.push(elementToCheck);
        if (isShadowRoot(elementToCheck)) {
            const { host } = elementToCheck;
            elementToCheck = isHTMLElement(host) ? host : null;
        } else {
            elementToCheck = elementToCheck.parentElement;
        }
    }
    const length = matched.length;
    return length ? matched[length - 1] : null;
}
function findFirstParentWithClass(element, className) {
    const matched = {
        element: undefined,
        classNames: []
    };
    let elementToCheck = element;
    while(elementToCheck !== null && elementToCheck !== element.ownerDocument.documentElement && !matched.element){
        if (typeof className === 'string' && elementToCheck.classList.contains(className)) {
            matched.element = elementToCheck;
            matched.classNames.push(className);
        } else if (className instanceof RegExp) {
            const matchingClasses = Array.from(elementToCheck.classList).filter((cls)=>className.test(cls));
            if (matchingClasses.length) {
                matched.element = elementToCheck;
                matched.classNames.push(...matchingClasses);
            }
        }
        elementToCheck = elementToCheck.parentElement;
    }
    return matched;
}
function isChildOf(child, parent) {
    let node = child.parentNode;
    let queriedParents = [];
    if (typeof parent === 'string') {
        if (child instanceof Document) {
            queriedParents = Array.from(child.querySelectorAll(parent));
        } else {
            queriedParents = Array.from(child.ownerDocument.querySelectorAll(parent));
        }
    } else {
        queriedParents.push(parent);
    }
    while(node !== null){
        if (queriedParents.indexOf(node) > -1) {
            return true;
        }
        node = node.parentNode;
    }
    return false;
}
function index(element) {
    let i = 0;
    let elementToCheck = element;
    if (elementToCheck.previousSibling) {
        /* eslint-disable no-cond-assign */ while(elementToCheck = elementToCheck.previousSibling){
            i += 1;
        }
    }
    return i;
}
function overlayContainsElement(overlayType, element, root) {
    const overlayElement = root.parentElement?.querySelector(`.ht_clone_${overlayType}`);
    return overlayElement ? overlayElement.contains(element) : false;
}
function isBottomMostColumnHeader(TH) {
    if (!TH || !TH.classList || !TH.parentNode || !TH.parentNode.parentNode) {
        return false;
    }
    if (TH.classList.contains('hiddenHeader') || TH.style.display === 'none') {
        return false;
    }
    const headerRow = TH.parentNode;
    const headerRows = Array.from(headerRow?.parentNode?.childNodes ?? []);
    const headerLevel = headerRow ? headerRows.indexOf(headerRow) : -1;
    const rowspan = Number.parseInt(TH.getAttribute('rowspan') ?? '', 10) || 1;
    return headerLevel + rowspan >= headerRows.length;
}
/**
 * @param {string[]} classNames The element "class" attribute string.
 * @returns {string[]}
 */ function filterEmptyClassNames(classNames) {
    if (!classNames || !classNames.length) {
        return [];
    }
    return classNames.filter((x)=>!!x);
}
/**
 * Filter out the RegExp entries from an array.
 *
 * @param {(string|RegExp)[]} list Array of either strings, Regexes or a mix of both.
 * @param {boolean} [returnBoth] If `true`, both the array without regexes and an array of regexes will be returned.
 * @returns {string[]|{regexFree: string[], regexes: RegExp[]}}
 */ function filterRegexes(list, returnBoth) {
    if (!list || !list.length) {
        return returnBoth ? {
            regexFree: [],
            regexes: []
        } : [];
    }
    const regexes = [];
    const regexFree = [];
    regexFree.push(...list.filter((entry)=>{
        const isRegex = entry instanceof RegExp;
        if (isRegex && returnBoth) {
            regexes.push(entry);
        }
        return !isRegex;
    }));
    return returnBoth ? {
        regexFree,
        regexes
    } : regexFree;
}
function hasClass(element, className) {
    if (element.classList === undefined || typeof className !== 'string' || className === '') {
        return false;
    }
    return element.classList.contains(className);
}
function addClass(element, className) {
    if (typeof className === 'string') {
        className = className.split(' ');
    }
    className = filterEmptyClassNames(className);
    if (className.length > 0) {
        element.classList.add(...className);
    }
}
function removeClass(element, className) {
    if (typeof className === 'string') {
        className = className.split(' ');
    } else if (className instanceof RegExp) {
        className = [
            className
        ];
    }
    let { regexFree: stringClasses, // eslint-disable-next-line prefer-const
    regexes: regexClasses } = filterRegexes(className, true);
    stringClasses = filterEmptyClassNames(stringClasses);
    if (stringClasses.length > 0) {
        element.classList.remove(...stringClasses);
    }
    regexClasses.forEach((regexClassName)=>{
        element.classList.forEach((currentClassName)=>{
            if (regexClassName.test(currentClassName)) {
                element.classList.remove(currentClassName);
            }
        });
    });
}
function setAttribute(domElement, attributes = [], attributeValue) {
    if (!Array.isArray(attributes)) {
        attributes = [
            [
                attributes,
                attributeValue ?? ''
            ]
        ];
    }
    attributes.forEach((attributeInfo)=>{
        if (Array.isArray(attributeInfo) && attributeInfo[0] !== '') {
            domElement.setAttribute(attributeInfo[0], String(attributeInfo[1]));
        }
    });
}
function removeAttribute(domElement, attributesToRemove = []) {
    if (typeof attributesToRemove === 'string') {
        attributesToRemove = attributesToRemove.split(' ');
    } else if (attributesToRemove instanceof RegExp) {
        attributesToRemove = [
            attributesToRemove
        ];
    }
    const { regexFree: stringAttributes, regexes: regexAttributes } = filterRegexes(attributesToRemove, true);
    stringAttributes.forEach((attributeNameToRemove)=>{
        if (attributeNameToRemove !== '') {
            domElement.removeAttribute(attributeNameToRemove);
        }
    });
    if (regexAttributes.length > 0) {
        // Read the attribute names once and test each against all regexes, instead of re-reading the
        // (allocating) attribute-name list per regex. This path runs per cell on every render.
        const attributeNames = domElement.getAttributeNames();
        for(let i = 0; i < attributeNames.length; i++){
            const attributeName = attributeNames[i];
            for(let r = 0; r < regexAttributes.length; r++){
                if (regexAttributes[r].test(attributeName)) {
                    domElement.removeAttribute(attributeName);
                    break;
                }
            }
        }
    }
}
function removeTextNodes(element) {
    if (element.nodeType === 3) {
        element.parentNode?.removeChild(element); // bye text nodes!
    } else if ([
        'TABLE',
        'THEAD',
        'TBODY',
        'TFOOT',
        'TR'
    ].indexOf(element.nodeName) > -1) {
        const childs = element.childNodes;
        for(let i = childs.length - 1; i >= 0; i--){
            removeTextNodes(childs[i]);
        }
    }
}
function empty(element) {
    let child;
    /* eslint-disable no-cond-assign */ while(child = element.lastChild){
        element.removeChild(child);
    }
}
const HTML_CHARACTERS = /(<([^>]*)>|&([^;]*);)/;
const SANITIZER_WARN_KEY = 'sanitizer';
function missingSanitizerMessage(context) {
    return `HTML content is being written to the DOM ("${context}") without a sanitizer. ` + 'Configure the "sanitizer" option to prevent XSS vulnerabilities.';
}
/**
 * Default scope used when a caller writes raw HTML without supplying a per-instance
 * scope. Keeps the warning to once per process for such callers.
 */ const defaultSanitizerWarnScope = {};
function fastInnerHTML(element, content, sanitizer = true, context = 'innerHTML', scope = defaultSanitizerWarnScope) {
    if (HTML_CHARACTERS.test(content)) {
        let sanitized;
        if (typeof sanitizer === 'function') {
            // `?? ''` rather than `?? content`: a sanitizer that returns nothing for input it strips
            // entirely must not have the raw input written back, which would undo the sanitizing. The
            // declared return type is `string`, but JavaScript callers are not held to it, and without
            // this guard the literal word "undefined" reaches the DOM.
            sanitized = sanitizer(content, context) ?? '';
        } else {
            // `false` means the caller renders raw HTML deliberately (for example, the `html` cell type).
            // Any other non-function value (the default `true`) is an implicit raw write, so nudge once
            // toward configuring a sanitizer to prevent XSS.
            if (sanitizer !== false) {
                (0, _console.warnOnce)(scope, SANITIZER_WARN_KEY, missingSanitizerMessage(context));
            }
            sanitized = content;
        }
        element.innerHTML = sanitized;
    } else {
        fastInnerText(element, content);
    }
}
function fastInnerText(element, content) {
    const child = element.firstChild;
    if (child && child.nodeType === 3 && child.nextSibling === null) {
        // fast lane - replace existing text node
        child.textContent = content;
    } else {
        // slow lane - empty element and insert a text node
        empty(element);
        element.appendChild(element.ownerDocument.createTextNode(content));
    }
}
function isVisible(element) {
    // Fast path: use the native checkVisibility() API (Chrome 105+, Firefox 106+, Safari 17.4+).
    // With no options it checks whether the element has an associated box — returning false for
    // display:none and display:contents — and whether any ancestor sets content-visibility:hidden.
    // This is stricter than the legacy walk below (which only catches display:none), but the
    // extra cases are also semantically invisible, so the stricter result is correct.
    // The benefit over the legacy walk: O(1) browser-native time instead of O(DOM depth) with
    // per-node getComputedStyle() calls that force full-document layout recalculation.
    if (typeof element.checkVisibility === 'function') {
        return element.checkVisibility();
    }
    // Legacy fallback: manual ancestor walk for browsers that do not support checkVisibility().
    const documentElement = element.ownerDocument.documentElement;
    const windowElement = element.ownerDocument.defaultView;
    let next = element;
    while(next !== documentElement){
        if (next === null) {
            return false;
        } else if (isShadowRoot(next)) {
            const host = next.host;
            if (host.impl) {
                return isVisible(host.impl);
            } else {
                return isVisible(host);
            }
        } else if (next.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
            return false; // this is a node detached from document in IE8
        } else if (next.nodeType === Node.ELEMENT_NODE && isHTMLElement(next) && windowElement?.getComputedStyle(next).display === 'none') {
            return false;
        }
        next = next.parentNode;
    }
    return true;
}
function hasZeroHeight(element) {
    const rootDocument = element.ownerDocument;
    const rootWindow = rootDocument.defaultView;
    let currentElement = element;
    while(currentElement.parentElement){
        if (currentElement.style.height === '0px' || currentElement.style.height === '0') {
            const computedOverflow = rootWindow?.getComputedStyle(currentElement).getPropertyValue('overflow');
            return computedOverflow === 'hidden' || computedOverflow === 'clip';
        }
        currentElement = currentElement.parentElement;
    }
    return false;
}
function offset(element) {
    const rootDocument = element.ownerDocument;
    const rootWindow = rootDocument.defaultView;
    const documentElement = rootDocument.documentElement;
    let elementToCheck = element;
    let offsetLeft;
    let offsetTop;
    let lastElem;
    offsetLeft = elementToCheck.offsetLeft;
    offsetTop = elementToCheck.offsetTop;
    lastElem = elementToCheck;
    /* eslint-disable no-cond-assign */ while(elementToCheck = isHTMLElement(elementToCheck.offsetParent) ? elementToCheck.offsetParent : null){
        // from my observation, document.body always has scrollLeft/scrollTop == 0
        if (elementToCheck === rootDocument.body) {
            break;
        }
        // If the element is inside an SVG context, the `offsetParent` can be
        // a <foreignObject> that does not have properties `offsetLeft` and `offsetTop` defined.
        if (!('offsetLeft' in elementToCheck)) {
            break;
        }
        offsetLeft += elementToCheck.offsetLeft;
        offsetTop += elementToCheck.offsetTop;
        lastElem = elementToCheck;
    }
    // slow - http://jsperf.com/offset-vs-getboundingclientrect/6
    if (lastElem && lastElem.style.position === 'fixed') {
        // if(lastElem !== document.body) { //faster but does gives false positive in Firefox
        offsetLeft += (rootWindow?.pageXOffset ?? 0) || documentElement.scrollLeft;
        offsetTop += (rootWindow?.pageYOffset ?? 0) || documentElement.scrollTop;
    }
    return {
        left: offsetLeft,
        top: offsetTop
    };
}
function getWindowScrollTop(rootWindow = window) {
    return rootWindow.scrollY;
}
function getWindowScrollLeft(rootWindow = window) {
    return rootWindow.scrollX;
}
function getScrollTop(element, rootWindow = window) {
    if (element instanceof Window) {
        return getWindowScrollTop(rootWindow);
    }
    return element.scrollTop;
}
function getScrollLeft(element, rootWindow = window) {
    if (element instanceof Window) {
        return getWindowScrollLeft(rootWindow);
    }
    return element.scrollLeft;
}
function getScrollableElement(element) {
    const rootDocument = element.ownerDocument;
    const rootWindow = rootDocument.defaultView;
    const props = [
        'auto',
        'scroll'
    ];
    let el = element.parentElement;
    while(el && el.style && rootDocument.body !== el){
        let { overflow, overflowX, overflowY } = el.style;
        if ([
            overflow,
            overflowX,
            overflowY
        ].includes('scroll')) {
            return el;
        } else {
            if (rootWindow) {
                ({ overflow, overflowX, overflowY } = rootWindow.getComputedStyle(el));
            }
            if (props.includes(overflow) || props.includes(overflowX) || props.includes(overflowY)) {
                return el;
            }
        }
        // The '+ 1' after the scrollHeight/scrollWidth is to prevent problems with zoomed out Chrome.
        if (el.clientHeight <= el.scrollHeight + 1 && (props.includes(overflowY) || props.includes(overflow))) {
            return el;
        }
        if (el.clientWidth <= el.scrollWidth + 1 && (props.includes(overflowX) || props.includes(overflow))) {
            return el;
        }
        el = el.parentElement;
    }
    return rootWindow ?? rootDocument.documentElement;
}
function getMaximumScrollTop(element) {
    return element.scrollHeight - element.clientHeight;
}
function getMaximumScrollLeft(element) {
    return element.scrollWidth - element.clientWidth;
}
const OVERFLOW_TRIMMING_VALUES = [
    'scroll',
    'hidden',
    'auto',
    'clip'
];
const OVERFLOW_CONCRETE_VALUES = [
    'visible',
    'clip',
    'hidden',
    'scroll',
    'auto',
    'overlay'
];
/**
 * Checks whether a single overflow axis traps the table on that axis.
 *
 * `overflow: clip` establishes no scroll port. When an axis is `clip` while the perpendicular axis
 * stays `visible`, it does not trap the table's scroll — the table still scrolls with the window on
 * the visible axis. A width-constrained, window-scrolled table sets `overflow-x: clip` on its root
 * (see core.ts, DEV-1025); treating that root as the trimming container drops the overlays out of
 * window-scroll mode (frozen rows stop pinning, vertical virtualization stops). Such a single-axis
 * clip must not qualify the axis as trimming.
 *
 * @param {string} axis The `overflow-x`/`overflow-y` value of the axis being tested.
 * @param {string} perpendicular The `overflow` value of the other axis.
 * @returns {boolean}
 */ function overflowAxisTraps(axis, perpendicular) {
    return OVERFLOW_TRIMMING_VALUES.includes(axis) && !(axis === 'clip' && (perpendicular === 'visible' || perpendicular === ''));
}
/**
 * Resolves the effective `overflow-x`/`overflow-y` of an element, preferring inline styles.
 *
 * The inline `overflow` shorthand can carry two values (`overflow: clip visible` → x, y). Some
 * engines (jsdom) neither split that shorthand into `overflowX`/`overflowY` nor reflect it in the
 * computed style, so the shorthand string is parsed directly. An inline value is only preferred when
 * it is a concrete overflow keyword; a global keyword (`inherit`, `initial`, `revert`, `unset`) or
 * any other non-concrete value falls back to the computed style, which resolves it to the real value
 * (e.g. an inherited `auto`). Otherwise an inline `inherit` would be read literally and miss the
 * scroll value it inherits.
 *
 * @param {HTMLElement} el The element to read overflow from.
 * @param {CSSStyleDeclaration} computedStyle The element's computed style.
 * @returns {{ x: string, y: string }}
 */ function resolveOverflowAxes(el, computedStyle) {
    const shorthand = el.style.overflow.split(/\s+/).filter(Boolean);
    const [shorthandX = '', shorthandY = shorthandX] = shorthand;
    const resolveAxis = (inlineAxis, shorthandAxis, computedProperty)=>{
        const inline = inlineAxis || shorthandAxis;
        return OVERFLOW_CONCRETE_VALUES.includes(inline) ? inline : computedStyle.getPropertyValue(computedProperty);
    };
    return {
        x: resolveAxis(el.style.overflowX, shorthandX, 'overflow-x'),
        y: resolveAxis(el.style.overflowY, shorthandY, 'overflow-y')
    };
}
function getTrimmingContainer(base) {
    const rootDocument = base.ownerDocument;
    const rootWindow = rootDocument.defaultView;
    let el = base.parentElement;
    while(el && el.style && rootDocument.body !== el){
        if (rootWindow) {
            const { x, y } = resolveOverflowAxes(el, rootWindow.getComputedStyle(el));
            if (overflowAxisTraps(x, y) || overflowAxisTraps(y, x)) {
                return el;
            }
        } else if (el.style.overflow !== 'visible' && el.style.overflow !== '') {
            return el;
        }
        el = el.parentElement;
    }
    return rootWindow ?? rootDocument.documentElement;
}
function getStyle(element, prop, rootWindow = window) {
    if (!element) {
        return;
    } else if (element instanceof Window) {
        if (prop === 'width') {
            return `${element.innerWidth}px`;
        } else if (prop === 'height') {
            return `${element.innerHeight}px`;
        }
        return;
    }
    const styleProp = element.style.getPropertyValue(prop) || element.style[prop];
    if (styleProp !== '' && styleProp !== undefined) {
        return styleProp;
    }
    const computedStyle = rootWindow.getComputedStyle(element);
    const computedProp = computedStyle.getPropertyValue(prop) || computedStyle[prop];
    if (computedProp !== '' && computedProp !== undefined) {
        return computedProp;
    }
}
function matchesCSSRules(element, rule) {
    let result = false;
    if (rule instanceof CSSStyleRule && rule.selectorText) {
        const elementWithMs = element;
        if ('msMatchesSelector' in element && typeof elementWithMs.msMatchesSelector === 'function') {
            result = elementWithMs.msMatchesSelector(rule.selectorText);
        } else if (element.matches) {
            result = element.matches(rule.selectorText);
        }
    }
    return result;
}
function outerWidth(element) {
    return element.offsetWidth;
}
function outerHeight(element) {
    return element.offsetHeight;
}
function innerHeight(element) {
    return element instanceof Window ? element.innerHeight : element.clientHeight;
}
function innerWidth(element) {
    return element instanceof Window ? element.innerWidth : element.clientWidth;
}
function addEvent(element, event, callback) {
    element.addEventListener(event, callback, false);
}
function removeEvent(element, event, callback) {
    element.removeEventListener(event, callback, false);
}
function getCaretPosition(el) {
    if (el.selectionStart) {
        return el.selectionStart;
    }
    return 0;
}
function getSelectionEndPosition(el) {
    if (el.selectionEnd) {
        return el.selectionEnd;
    }
    return 0;
}
function getSelectionText(rootWindow = window) {
    const rootDocument = rootWindow.document;
    let text = '';
    if (rootWindow.getSelection) {
        text = rootWindow.getSelection()?.toString() ?? '';
    } else {
        if ('selection' in rootDocument) {
            const docWithSel = rootDocument;
            if (docWithSel.selection && docWithSel.selection.type !== 'Control') {
                text = docWithSel.selection.createRange().text;
            }
        }
    }
    return text;
}
function clearTextSelection(rootWindow = window) {
    // http://stackoverflow.com/questions/3169786/clear-text-selection-with-javascript
    if (rootWindow.getSelection) {
        const sel = rootWindow.getSelection();
        if (sel?.empty) {
            sel.empty();
        } else if (sel?.removeAllRanges) {
            sel.removeAllRanges();
        }
    }
}
function setCaretPosition(element, pos, endPos) {
    if (endPos === undefined) {
        endPos = pos;
    }
    if (element.setSelectionRange) {
        element.focus();
        try {
            element.setSelectionRange(pos, endPos);
        } catch (err) {
            const elementParent = element.parentElement;
            if (elementParent) {
                const parentDisplayValue = elementParent.style.display;
                elementParent.style.display = 'block';
                element.setSelectionRange(pos, endPos);
                elementParent.style.display = parentDisplayValue;
            }
        }
    }
}
let cachedScrollbarWidth;
function getFractionalScalingCompensation(rootDocument = document) {
    if (!(0, _browser.isWindowsOS)()) {
        return 0;
    }
    // On Windows, fractional scaling makes the scrollbar wider to compensate for the anti-aliasing.
    // This is a workaround to calculate the correct scrollbar width.
    return Number.isInteger(rootDocument.defaultView?.devicePixelRatio || 1) ? 0 : 2;
}
/**
 * Helper to calculate scrollbar width.
 * Source: https://stackoverflow.com/questions/986937/how-can-i-get-the-browsers-scrollbar-sizes.
 *
 * @private
 * @param {Document} rootDocument The owner of the document.
 * @returns {number}
 */ // eslint-disable-next-line no-restricted-globals
function walkontableCalculateScrollbarWidth(rootDocument = document) {
    const calculateScrollbarWidth = (shouldForceWebkitScrollbarStyles = false)=>{
        const inner = rootDocument.createElement('div');
        inner.style.height = '200px';
        inner.style.width = '100%';
        const outer = rootDocument.createElement('div');
        outer.classList.add('htScrollbarTest');
        if (shouldForceWebkitScrollbarStyles) {
            outer.classList.add('htScrollbarSafariTest');
        }
        outer.style.boxSizing = 'content-box';
        outer.style.height = '150px';
        outer.style.left = '0px';
        outer.style.overflow = 'hidden';
        outer.style.position = 'absolute';
        outer.style.top = '0px';
        outer.style.width = '200px';
        outer.style.visibility = 'hidden';
        outer.appendChild(inner);
        rootDocument.body.appendChild(outer);
        const w1 = inner.offsetWidth;
        outer.style.overflow = 'scroll';
        let w2 = inner.offsetWidth;
        if (w1 === w2) {
            w2 = outer.clientWidth;
        }
        rootDocument.body.removeChild(outer);
        return w1 - w2;
    };
    const defaultScrollbarWidth = calculateScrollbarWidth();
    // Safari around 26.x (e.g. 26.2/26.3) changed how scrollbars are rendered: overlay scrollbars
    // and the standard scrollbar-color/scrollbar-width properties are preferred. When those are set
    // (e.g. on .wtHolder via theme), they override the non-standard ::-webkit-scrollbar per spec,
    // so the real scrollbar can be 0-width. Older Safari (before 26.1) sometimes reports 0 because
    // it needs explicit ::-webkit-scrollbar size to lay out a classic scrollbar; the fallback below
    // forces that via htScrollbarSafariTest so we get a correct non-zero width. We must only run
    // this fallback when isSafariBefore261(), otherwise Safari 26.1+ with overlay scrollbars would
    // be given 9px from the probe (which has no theme) while .wtHolder actually has 0-width overlay.
    if (defaultScrollbarWidth === 0 && (0, _browser.isSafariBefore261)() && !(0, _browser.isMobileBrowser)() && !(0, _browser.isIpadOS)()) {
        return calculateScrollbarWidth(true);
    }
    return defaultScrollbarWidth;
}
function getScrollbarWidth(rootDocument = document) {
    if (cachedScrollbarWidth === undefined) {
        cachedScrollbarWidth = walkontableCalculateScrollbarWidth(rootDocument);
    }
    return cachedScrollbarWidth;
}
function hasVerticalScrollbar(element) {
    if (element instanceof Window) {
        return element.document.body.scrollHeight > element.innerHeight;
    }
    return element.offsetWidth !== element.clientWidth;
}
function hasHorizontalScrollbar(element) {
    if (element instanceof Window) {
        return element.document.body.scrollWidth > element.innerWidth;
    }
    return element.offsetHeight !== element.clientHeight;
}
function setOverlayPosition(overlayElem, left, top) {
    overlayElem.style.transform = `translate3d(${left},${top},0)`;
}
function getCssTransform(element) {
    let transform;
    if (element.style.transform && (transform = element.style.transform) !== '') {
        return [
            'transform',
            transform
        ];
    }
    return -1;
}
function resetCssTransform(element) {
    if (element.style.transform && element.style.transform !== '') {
        element.style.transform = '';
    }
}
function isInput(element) {
    const inputs = [
        'INPUT',
        'SELECT',
        'TEXTAREA'
    ];
    return element && (inputs.indexOf(element.nodeName) > -1 || element.contentEditable === 'true');
}
function isOutsideInput(element) {
    return isInput(element) && 'hotInput' in element.dataset === false;
}
function selectElementIfAllowed(element) {
    const activeElement = getDeepActiveElement(element.ownerDocument);
    if (isHTMLElement(activeElement) && !isOutsideInput(activeElement) && (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement)) {
        element.select();
    }
}
function isDetached(element) {
    return !element.parentNode;
}
function observeVisibilityChangeOnce(elementToBeObserved, callback) {
    const visibilityObserver = new IntersectionObserver((entries, observer)=>{
        entries.forEach((entry)=>{
            if (entry.isIntersecting) {
                callback();
                observer.disconnect();
            }
        });
    });
    visibilityObserver.observe(elementToBeObserved);
    return visibilityObserver;
}
function makeElementContentEditableAndSelectItsContent(element, invisibleSelection = true, ariaHidden = true) {
    const ownerDocument = element.ownerDocument;
    const range = ownerDocument.createRange();
    const sel = ownerDocument.defaultView?.getSelection();
    setAttribute(element, 'contenteditable', true);
    if (ariaHidden) {
        const hiddenAttr = (0, _a11y.A11Y_HIDDEN)();
        setAttribute(element, hiddenAttr[0], hiddenAttr[1]);
    }
    if (invisibleSelection) {
        addClass(element, 'invisibleSelection');
    }
    range.selectNodeContents(element);
    sel?.removeAllRanges();
    sel?.addRange(range);
}
function removeContentEditableFromElementAndDeselect(selectedElement, removeInvisibleSelectionClass = true) {
    const sel = selectedElement.ownerDocument.defaultView?.getSelection();
    if (selectedElement.hasAttribute('aria-hidden')) {
        selectedElement.removeAttribute('aria-hidden');
    }
    sel?.removeAllRanges();
    if (removeInvisibleSelectionClass) {
        removeClass(selectedElement, 'invisibleSelection');
    }
    selectedElement.removeAttribute('contenteditable');
}
function runWithSelectedContendEditableElement(element, callback, invisibleSelection = true) {
    makeElementContentEditableAndSelectItsContent(element, invisibleSelection);
    callback();
    removeContentEditableFromElementAndDeselect(element, invisibleSelection);
}
function isHTMLElement(element) {
    if (typeof element !== 'object' || element === null) {
        return false;
    }
    const OwnElement = element.ownerDocument?.defaultView?.Element;
    return !!(OwnElement && element instanceof OwnElement);
}
function isHTMLTableCellElement(element) {
    return isHTMLElement(element) && (element.tagName === 'TD' || element.tagName === 'TH');
}
function isHTMLInputElement(element) {
    return element.tagName === 'INPUT';
}
function isShadowRoot(node) {
    if (typeof node !== 'object' || node === null) {
        return false;
    }
    return 'nodeType' in node && node.nodeType === Node.DOCUMENT_FRAGMENT_NODE && 'host' in node;
}
function getShadowHostChain(node) {
    const hosts = [];
    let rootNode = node.getRootNode();
    while(isShadowRoot(rootNode)){
        const { host } = rootNode;
        if (!isHTMLElement(host)) {
            break;
        }
        hosts.push(host);
        rootNode = host.getRootNode();
    }
    return hosts;
}
function getDeepActiveElement(rootDocument) {
    let element = rootDocument.activeElement;
    while(element?.shadowRoot?.activeElement){
        element = element.shadowRoot.activeElement;
    }
    return element;
}
function getChildEl(parent, index) {
    const node = parent.childNodes[index];
    return node ? node : null;
}
