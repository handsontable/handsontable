"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get getFirstChangedTouch () {
        return getFirstChangedTouch;
    },
    get getTouchPointById () {
        return getTouchPointById;
    },
    get hasTouchList () {
        return hasTouchList;
    },
    get isImmediatePropagationStopped () {
        return isImmediatePropagationStopped;
    },
    get isLeftClick () {
        return isLeftClick;
    },
    get isMiddleClick () {
        return isMiddleClick;
    },
    get isRightClick () {
        return isRightClick;
    },
    get isTouchEvent () {
        return isTouchEvent;
    },
    get offsetRelativeTo () {
        return offsetRelativeTo;
    },
    get stopImmediatePropagation () {
        return stopImmediatePropagation;
    }
});
const _element = require("./element");
function stopImmediatePropagation(event) {
    event.isImmediatePropagationEnabled = false;
    event.cancelBubble = true;
}
function isImmediatePropagationStopped(event) {
    return event.isImmediatePropagationEnabled === false;
}
function isRightClick(event) {
    return event.button === 2;
}
function isLeftClick(event) {
    return event.button === 0;
}
function isMiddleClick(event) {
    return event.button === 1;
}
function isTouchEvent(event) {
    return typeof TouchEvent !== 'undefined' && event instanceof TouchEvent;
}
function hasTouchList(event) {
    return 'touches' in event && 'changedTouches' in event;
}
function getFirstChangedTouch(event) {
    if (!hasTouchList(event) || event.changedTouches.length === 0) {
        return null;
    }
    const { identifier, clientX, clientY } = event.changedTouches[0];
    return {
        identifier,
        clientX,
        clientY
    };
}
function getTouchPointById(event, identifier) {
    if (!hasTouchList(event)) {
        return null;
    }
    for(let i = 0; i < event.touches.length; i++){
        const touch = event.touches[i];
        if (touch.identifier === identifier) {
            return {
                identifier: touch.identifier,
                clientX: touch.clientX,
                clientY: touch.clientY
            };
        }
    }
    return null;
}
function offsetRelativeTo(event, untilElement) {
    const offset = {
        x: event.offsetX,
        y: event.offsetY
    };
    let element = (0, _element.eventTargetEl)(event);
    if (!(0, _element.isHTMLElement)(untilElement) || element !== untilElement && element.contains(untilElement)) {
        return offset;
    }
    while(element !== untilElement){
        offset.x += element.offsetLeft;
        offset.y += element.offsetTop;
        element = element.offsetParent;
    }
    return offset;
}
