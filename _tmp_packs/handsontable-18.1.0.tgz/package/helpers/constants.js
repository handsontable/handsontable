"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BAD_VALUE_TEXT () {
        return BAD_VALUE_TEXT;
    },
    get LOADING_CLASS_NAME () {
        return LOADING_CLASS_NAME;
    }
});
const BAD_VALUE_TEXT = '#bad-value#';
const LOADING_CLASS_NAME = 'ht-loading';
