"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get isChrome () {
        return isChrome;
    },
    get isChromeWebKit () {
        return isChromeWebKit;
    },
    get isEdge () {
        return isEdge;
    },
    get isEdgeWebKit () {
        return isEdgeWebKit;
    },
    get isFirefox () {
        return isFirefox;
    },
    get isFirefoxWebKit () {
        return isFirefoxWebKit;
    },
    get isIOS () {
        return isIOS;
    },
    get isIpadOS () {
        return isIpadOS;
    },
    get isLinuxOS () {
        return isLinuxOS;
    },
    get isMacOS () {
        return isMacOS;
    },
    get isMobileBrowser () {
        return isMobileBrowser;
    },
    get isSafari () {
        return isSafari;
    },
    get isSafariBefore261 () {
        return isSafariBefore261;
    },
    get isWindowsOS () {
        return isWindowsOS;
    },
    get setBrowserMeta () {
        return setBrowserMeta;
    },
    get setPlatformMeta () {
        return setPlatformMeta;
    }
});
const _object = require("./object");
const _feature = require("./feature");
const tester = (testerFunc)=>{
    const result = {
        value: false,
        test (_ua, _vendor) {
            result.value = testerFunc(_ua, _vendor);
        }
    };
    return result;
};
const browsers = {
    chrome: tester((ua, vendor)=>/Chrome/.test(ua) && /Google/.test(vendor ?? '')),
    chromeWebKit: tester((ua)=>/CriOS/.test(ua)),
    edge: tester((ua)=>/Edge/.test(ua)),
    edgeWebKit: tester((ua)=>/EdgiOS/.test(ua)),
    firefox: tester((ua)=>/Firefox/.test(ua)),
    firefoxWebKit: tester((ua)=>/FxiOS/.test(ua)),
    mobile: tester((ua)=>/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua)),
    safari: tester((ua, vendor)=>/Safari/.test(ua) && /Apple Computer/.test(vendor ?? '')),
    safariBefore261: tester((ua, vendor)=>{
        if (!/Safari/.test(ua) || !/Apple Computer/.test(vendor ?? '')) {
            return false;
        }
        const match = /Version\/(\d+(?:\.\d+)?)/i.exec(ua);
        const version = match ? Number.parseFloat(match[1]) : 0;
        return version < 26.1;
    })
};
const platforms = {
    mac: tester((platform)=>/^Mac/.test(platform)),
    win: tester((platform)=>/^Win/.test(platform)),
    linux: tester((platform)=>/^Linux/.test(platform)),
    ios: tester((platform)=>/iPhone|iPad|iPod/i.test(platform))
};
function setBrowserMeta({ userAgent = navigator.userAgent, vendor = navigator.vendor } = {}) {
    (0, _object.objectEach)(browsers, ({ test })=>test(userAgent, vendor));
}
function setPlatformMeta({ platform = navigator.platform } = {}) {
    (0, _object.objectEach)(platforms, ({ test })=>test(platform));
}
if ((0, _feature.isCSR)()) {
    setBrowserMeta();
    setPlatformMeta();
}
function isChrome() {
    return browsers.chrome.value;
}
function isChromeWebKit() {
    return browsers.chromeWebKit.value;
}
function isFirefox() {
    return browsers.firefox.value;
}
function isFirefoxWebKit() {
    return browsers.firefoxWebKit.value;
}
function isSafari() {
    return browsers.safari.value;
}
function isSafariBefore261() {
    return browsers.safariBefore261.value;
}
function isEdge() {
    return browsers.edge.value;
}
function isEdgeWebKit() {
    return browsers.edgeWebKit.value;
}
function isMobileBrowser() {
    return browsers.mobile.value;
}
function isIOS() {
    return platforms.ios.value;
}
function isIpadOS({ maxTouchPoints } = navigator) {
    return (maxTouchPoints ?? 0) > 2 && platforms.mac.value;
}
function isWindowsOS() {
    return platforms.win.value;
}
function isMacOS() {
    return platforms.mac.value;
}
function isLinuxOS() {
    return platforms.linux.value;
}
