/*
 * This file is auto-generated. Do not edit directly.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const horizonTokens = {
    fontFamily: 'Inter',
    fontSize: '14px',
    fontSizeSmall: '12px',
    lineHeight: '20px',
    lineHeightSmall: '18px',
    fontWeight: '400',
    letterSpacing: '0px',
    borderColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    accentColor: [
        'colors.primary.500',
        'colors.primary.200'
    ],
    foregroundColor: [
        'colors.palette.700',
        'colors.palette.200'
    ],
    foregroundSecondaryColor: [
        'colors.palette.500',
        'colors.palette.400'
    ],
    backgroundColor: [
        'colors.white',
        'colors.palette.950'
    ],
    backgroundSecondaryColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    placeholderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    readOnlyColor: [
        'colors.palette.700',
        'colors.palette.200'
    ],
    disabledColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    gapSize: 'density.gap',
    iconSize: 'sizing.size_4',
    tableTransition: '0.2s',
    borderRadius: 'sizing.size_3',
    barForegroundColor: 'tokens.foregroundColor',
    barBackgroundColor: 'tokens.backgroundSecondaryColor',
    barHorizontalPadding: 'density.barsHorizontal',
    barVerticalPadding: 'density.barsVertical',
    shadowColor: [
        'colors.palette.700',
        'colors.palette.200'
    ],
    shadowX: 'sizing.size_0',
    shadowY: 'sizing.size_2',
    shadowBlur: 'sizing.size_4',
    shadowOpacity: '6%',
    cellHorizontalPadding: 'density.cellHorizontal',
    cellVerticalPadding: 'density.cellVertical',
    cellHorizontalBorderColor: 'colors.transparent',
    cellVerticalBorderColor: 'tokens.borderColor',
    cellSelectionBorderColor: 'tokens.accentColor',
    cellSelectionBackgroundColor: 'tokens.accentColor',
    cellSuccessBackgroundColor: '#37bc6c4d',
    cellErrorBackgroundColor: '#fa4d324d',
    cellReadOnlyBackgroundColor: 'tokens.backgroundSecondaryColor',
    cellAutofillSize: 'sizing.size_1_5',
    cellAutofillHitAreaSize: 'sizing.size_3',
    cellAutofillBorderWidth: 'sizing.size_0_25',
    cellAutofillBorderRadius: 'sizing.size_1',
    cellAutofillBorderColor: 'tokens.backgroundColor',
    cellAutofillBackgroundColor: 'tokens.accentColor',
    cellAutofillFillBorderColor: 'tokens.foregroundColor',
    cellEditorBorderWidth: '2px',
    cellEditorBorderColor: 'tokens.accentColor',
    cellEditorForegroundColor: [
        'colors.palette.950',
        'colors.white'
    ],
    cellEditorBackgroundColor: 'tokens.backgroundColor',
    cellEditorShadowBlurRadius: '8px',
    cellEditorShadowColor: 'tokens.accentColor',
    cellMobileHandleSize: 'sizing.size_3',
    cellMobileHandleBorderWidth: 'sizing.size_0_25',
    cellMobileHandleBorderRadius: 'sizing.size_3',
    cellMobileHandleBorderColor: 'tokens.accentColor',
    cellMobileHandleBackgroundColor: 'tokens.accentColor',
    cellMobileHandleBackgroundOpacity: '40%',
    cellSelectionHandleSize: 'sizing.size_2',
    cellSelectionHandleLength: 'sizing.size_6',
    cellSelectionHandleBorderWidth: 'sizing.size_0_25',
    cellSelectionHandleBorderRadius: 'sizing.size_3',
    cellSelectionHandleBorderColor: 'tokens.accentColor',
    cellSelectionHandleBackgroundColor: 'tokens.backgroundColor',
    headerFontWeight: 'tokens.fontWeight',
    headerForegroundColor: 'tokens.foregroundColor',
    headerBackgroundColor: 'tokens.backgroundSecondaryColor',
    headerHighlightedShadowSize: '1px',
    headerHighlightedForegroundColor: 'tokens.foregroundColor',
    headerHighlightedBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    headerActiveBorderColor: [
        'colors.palette.800',
        'colors.primary.100'
    ],
    headerActiveForegroundColor: 'tokens.backgroundColor',
    headerActiveBackgroundColor: [
        'colors.palette.950',
        'colors.primary.200'
    ],
    headerFilterBackgroundColor: 'tokens.cellSuccessBackgroundColor',
    headerRowForegroundColor: 'tokens.foregroundColor',
    headerRowBackgroundColor: 'tokens.backgroundColor',
    headerRowHighlightedForegroundColor: 'tokens.foregroundColor',
    headerRowHighlightedBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    headerRowActiveForegroundColor: 'tokens.backgroundColor',
    headerRowActiveBackgroundColor: [
        'colors.palette.950',
        'colors.primary.200'
    ],
    rowHeaderOddBackgroundColor: 'tokens.headerRowBackgroundColor',
    rowHeaderEvenBackgroundColor: 'tokens.backgroundSecondaryColor',
    rowCellOddBackgroundColor: 'tokens.backgroundColor',
    rowCellEvenBackgroundColor: 'tokens.backgroundSecondaryColor',
    buttonBorderRadius: 'sizing.size_4',
    buttonHorizontalPadding: 'density.buttonHorizontal',
    buttonVerticalPadding: 'density.buttonVertical',
    primaryButtonBorderColor: 'colors.transparent',
    primaryButtonForegroundColor: 'tokens.backgroundColor',
    primaryButtonBackgroundColor: 'tokens.accentColor',
    primaryButtonDisabledBorderColor: 'colors.transparent',
    primaryButtonDisabledForegroundColor: 'tokens.disabledColor',
    primaryButtonDisabledBackgroundColor: [
        'colors.palette.200',
        'colors.palette.700'
    ],
    primaryButtonHoverBorderColor: 'colors.transparent',
    primaryButtonHoverForegroundColor: 'tokens.backgroundColor',
    primaryButtonHoverBackgroundColor: [
        'colors.primary.600',
        'colors.primary.100'
    ],
    primaryButtonFocusBorderColor: 'tokens.backgroundColor',
    primaryButtonFocusForegroundColor: 'tokens.backgroundColor',
    primaryButtonFocusBackgroundColor: 'tokens.accentColor',
    secondaryButtonBorderColor: 'tokens.borderColor',
    secondaryButtonForegroundColor: 'tokens.foregroundColor',
    secondaryButtonBackgroundColor: 'tokens.backgroundColor',
    secondaryButtonDisabledBorderColor: 'tokens.borderColor',
    secondaryButtonDisabledForegroundColor: 'tokens.disabledColor',
    secondaryButtonDisabledBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    secondaryButtonHoverBorderColor: 'tokens.borderColor',
    secondaryButtonHoverForegroundColor: 'tokens.foregroundColor',
    secondaryButtonHoverBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    secondaryButtonFocusBorderColor: 'tokens.borderColor',
    secondaryButtonFocusForegroundColor: 'tokens.foregroundColor',
    secondaryButtonFocusBackgroundColor: 'tokens.backgroundColor',
    iconButtonBorderRadius: 'sizing.size_4',
    iconButtonLargeBorderRadius: 'sizing.size_1',
    iconButtonLargePadding: 'sizing.size_1',
    iconButtonBorderColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    iconButtonBackgroundColor: 'tokens.backgroundSecondaryColor',
    iconButtonIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    iconButtonHitAreaSize: 'sizing.size_6',
    iconButtonHoverBorderColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    iconButtonHoverBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    iconButtonHoverIconColor: [
        'colors.palette.700',
        'colors.palette.200'
    ],
    iconButtonActiveBorderColor: 'colors.transparent',
    iconButtonActiveBackgroundColor: 'colors.transparent',
    iconButtonActiveIconColor: 'tokens.backgroundColor',
    iconButtonActiveHoverBorderColor: 'colors.transparent',
    iconButtonActiveHoverBackgroundColor: [
        'colors.palette.950',
        'colors.primary.200'
    ],
    iconButtonActiveHoverIconColor: 'tokens.backgroundColor',
    collapseButtonBorderRadius: 'sizing.size_4',
    collapseButtonOpenBorderColor: 'colors.transparent',
    collapseButtonOpenBackgroundColor: 'colors.transparent',
    collapseButtonOpenIconColor: [
        'colors.palette.500',
        'colors.palette.400'
    ],
    collapseButtonOpenIconActiveColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonOpenHoverBorderColor: 'colors.transparent',
    collapseButtonOpenHoverBackgroundColor: 'colors.transparent',
    collapseButtonOpenHoverIconColor: [
        'colors.palette.800',
        'colors.palette.200'
    ],
    collapseButtonOpenHoverIconActiveColor: [
        'colors.white',
        'colors.palette.950'
    ],
    collapseButtonCloseBorderColor: 'colors.transparent',
    collapseButtonCloseBackgroundColor: 'colors.transparent',
    collapseButtonCloseIconColor: [
        'colors.palette.500',
        'colors.palette.400'
    ],
    collapseButtonCloseIconActiveColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonCloseHoverBorderColor: 'colors.transparent',
    collapseButtonCloseHoverBackgroundColor: 'colors.transparent',
    collapseButtonCloseHoverIconColor: [
        'colors.palette.800',
        'colors.palette.200'
    ],
    collapseButtonCloseHoverIconActiveColor: [
        'colors.white',
        'colors.palette.950'
    ],
    linkColor: 'tokens.accentColor',
    linkHoverColor: [
        'colors.primary.600',
        'colors.primary.100'
    ],
    inputBorderWidth: '1px',
    inputBorderRadius: 'sizing.size_1',
    inputHorizontalPadding: 'density.inputHorizontal',
    inputVerticalPadding: 'density.inputVertical',
    inputBorderColor: 'tokens.borderColor',
    inputForegroundColor: 'tokens.foregroundColor',
    inputBackgroundColor: 'tokens.backgroundColor',
    inputHoverBorderColor: 'tokens.borderColor',
    inputHoverForegroundColor: 'tokens.foregroundColor',
    inputHoverBackgroundColor: 'tokens.backgroundColor',
    inputDisabledBorderColor: 'tokens.borderColor',
    inputDisabledForegroundColor: 'tokens.disabledColor',
    inputDisabledBackgroundColor: 'tokens.backgroundColor',
    inputFocusBorderColor: 'tokens.accentColor',
    inputFocusForegroundColor: 'tokens.foregroundColor',
    inputFocusBackgroundColor: 'tokens.backgroundColor',
    checkboxSize: 'tokens.iconSize',
    checkboxBorderRadius: 'sizing.size_1_5',
    checkboxBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    checkboxBackgroundColor: 'tokens.backgroundColor',
    checkboxIconColor: 'colors.transparent',
    checkboxFocusBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    checkboxFocusBackgroundColor: 'tokens.backgroundColor',
    checkboxFocusIconColor: 'colors.transparent',
    checkboxFocusRingColor: 'tokens.accentColor',
    checkboxDisabledBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    checkboxDisabledBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    checkboxDisabledIconColor: 'colors.transparent',
    checkboxCheckedBorderColor: [
        'colors.primary.400',
        'colors.primary.300'
    ],
    checkboxCheckedBackgroundColor: 'tokens.accentColor',
    checkboxCheckedIconColor: 'tokens.backgroundColor',
    checkboxCheckedFocusBorderColor: 'tokens.backgroundColor',
    checkboxCheckedFocusBackgroundColor: 'tokens.accentColor',
    checkboxCheckedFocusIconColor: 'tokens.backgroundColor',
    checkboxCheckedDisabledBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    checkboxCheckedDisabledBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    checkboxCheckedDisabledIconColor: 'tokens.disabledColor',
    checkboxIndeterminateBorderColor: [
        'colors.primary.400',
        'colors.primary.300'
    ],
    checkboxIndeterminateBackgroundColor: 'tokens.accentColor',
    checkboxIndeterminateIconColor: 'tokens.backgroundColor',
    checkboxIndeterminateFocusBorderColor: 'tokens.backgroundColor',
    checkboxIndeterminateFocusBackgroundColor: 'tokens.accentColor',
    checkboxIndeterminateFocusIconColor: 'tokens.backgroundColor',
    checkboxIndeterminateDisabledBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    checkboxIndeterminateDisabledBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    checkboxIndeterminateDisabledIconColor: 'tokens.disabledColor',
    radioSize: 'tokens.iconSize',
    radioBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    radioBackgroundColor: 'tokens.backgroundColor',
    radioIconColor: 'colors.transparent',
    radioFocusBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    radioFocusBackgroundColor: 'tokens.backgroundColor',
    radioFocusIconColor: 'colors.transparent',
    radioFocusRingColor: 'tokens.accentColor',
    radioDisabledBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    radioDisabledBackgroundColor: 'tokens.backgroundSecondaryColor',
    radioDisabledIconColor: 'colors.transparent',
    radioCheckedBorderColor: 'tokens.accentColor',
    radioCheckedBackgroundColor: 'tokens.backgroundColor',
    radioCheckedIconColor: 'tokens.accentColor',
    radioCheckedFocusBorderColor: [
        'colors.primary.400',
        'colors.primary.300'
    ],
    radioCheckedFocusBackgroundColor: 'tokens.backgroundColor',
    radioCheckedFocusIconColor: 'tokens.accentColor',
    radioCheckedDisabledBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    radioCheckedDisabledBackgroundColor: 'tokens.backgroundSecondaryColor',
    radioCheckedDisabledIconColor: 'tokens.disabledColor',
    moveBacklightColor: [
        'colors.palette.800',
        'colors.palette.200'
    ],
    moveBacklightOpacity: '6%',
    moveIndicatorColor: 'tokens.accentColor',
    resizeIndicatorColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    hiddenIndicatorColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    menuBorderWidth: '0px',
    menuBorderRadius: 'sizing.size_3',
    menuHorizontalPadding: 'density.menuHorizontal',
    menuVerticalPadding: 'density.menuVertical',
    menuItemHorizontalPadding: 'density.menuItemHorizontal',
    menuItemVerticalPadding: 'density.menuItemVertical',
    menuBorderColor: 'tokens.borderColor',
    menuShadowX: 'tokens.shadowX',
    menuShadowY: 'tokens.shadowY',
    menuShadowBlur: 'tokens.shadowBlur',
    menuShadowColor: [
        'colors.palette.950',
        'colors.white'
    ],
    menuShadowOpacity: '6%',
    menuItemHoverColor: [
        'colors.palette.500',
        'colors.palette.400'
    ],
    menuItemHoverColorOpacity: '8%',
    menuItemActiveColor: 'tokens.accentColor',
    menuItemActiveColorOpacity: '12%',
    commentsTextareaHorizontalPadding: 'density.cellHorizontal',
    commentsTextareaVerticalPadding: 'density.cellVertical',
    commentsTextareaBorderWidth: '1px',
    commentsTextareaBorderColor: 'colors.transparent',
    commentsTextareaForegroundColor: 'tokens.foregroundColor',
    commentsTextareaBackgroundColor: 'tokens.backgroundSecondaryColor',
    commentsTextareaFocusBorderWidth: '1px',
    commentsTextareaFocusBorderColor: 'tokens.accentColor',
    commentsTextareaFocusForegroundColor: 'tokens.foregroundColor',
    commentsTextareaFocusBackgroundColor: 'tokens.backgroundColor',
    commentsIndicatorSize: 'sizing.size_1_5',
    commentsIndicatorColor: 'tokens.accentColor',
    licenseHorizontalPadding: 'tokens.barHorizontalPadding',
    licenseVerticalPadding: 'tokens.barVerticalPadding',
    licenseForegroundColor: 'tokens.barForegroundColor',
    licenseBackgroundColor: 'tokens.barBackgroundColor',
    paginationBarForegroundColor: 'tokens.barForegroundColor',
    paginationBarBackgroundColor: 'tokens.barBackgroundColor',
    paginationBarHorizontalPadding: 'tokens.barHorizontalPadding',
    paginationBarVerticalPadding: 'tokens.barVerticalPadding',
    paginationButtonBorderColor: 'tokens.paginationBarBackgroundColor',
    paginationButtonForegroundColor: 'tokens.foregroundSecondaryColor',
    paginationButtonBackgroundColor: 'tokens.paginationBarBackgroundColor',
    paginationButtonHoverBorderColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    paginationButtonHoverForegroundColor: 'tokens.foregroundColor',
    paginationButtonHoverBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    paginationButtonDisabledBorderColor: 'tokens.paginationBarBackgroundColor',
    paginationButtonDisabledForegroundColor: 'tokens.disabledColor',
    paginationButtonDisabledBackgroundColor: 'tokens.paginationBarBackgroundColor',
    paginationButtonFocusBorderColor: 'tokens.accentColor',
    paginationButtonFocusForegroundColor: 'tokens.foregroundColor',
    paginationButtonFocusBackgroundColor: 'tokens.paginationBarBackgroundColor',
    dialogSemiTransparentBackgroundColor: [
        'colors.white',
        'colors.palette.950'
    ],
    dialogSemiTransparentBackgroundOpacity: '80%',
    dialogSolidBackgroundColor: [
        'colors.white',
        'colors.palette.950'
    ],
    dialogContentPaddingHorizontal: 'density.dialogHorizontal',
    dialogContentPaddingVertical: 'density.dialogVertical',
    dialogContentBorderRadius: 'sizing.size_4',
    dialogContentBackgroundColor: 'tokens.backgroundColor',
    notificationForegroundColor: 'tokens.foregroundColor',
    notificationBackgroundColor: 'tokens.backgroundColor',
    notificationBorderColor: 'tokens.backgroundColor',
    notificationSuccessAccent: '#37bc6cff',
    notificationWarningAccent: '#fbe952ff',
    notificationErrorAccent: '#fa4d32ff',
    chipBackground: 'tokens.backgroundSecondaryColor',
    chipBorderRadius: 'sizing.size_2',
    chipVerticalPadding: 'sizing.size_0',
    chipHorizontalPadding: 'sizing.size_0_5',
    chipGap: 'sizing.size_1',
    scrollbarBorderRadius: 'sizing.size_2',
    scrollbarTrackColor: 'tokens.backgroundSecondaryColor',
    scrollbarThumbColor: [
        'colors.palette.400',
        'colors.palette.500'
    ]
};
const _default = horizonTokens;
