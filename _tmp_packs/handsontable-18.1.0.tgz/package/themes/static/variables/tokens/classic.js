/*
 * This file is auto-generated. Do not edit directly.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const classicTokens = {
    fontFamily: 'Inter',
    fontSize: '13px',
    fontSizeSmall: '11px',
    lineHeight: '21px',
    lineHeightSmall: '16px',
    fontWeight: '400',
    letterSpacing: '0px',
    borderColor: [
        'colors.palette.200',
        'colors.palette.700'
    ],
    accentColor: [
        'colors.primary.500',
        'colors.primary.100'
    ],
    foregroundColor: [
        'colors.palette.800',
        'colors.palette.300'
    ],
    foregroundSecondaryColor: [
        'colors.palette.500',
        'colors.palette.400'
    ],
    backgroundColor: [
        'colors.white',
        'colors.palette.950'
    ],
    backgroundSecondaryColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    placeholderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    readOnlyColor: [
        'colors.palette.500',
        'colors.palette.400'
    ],
    disabledColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    gapSize: 'density.gap',
    iconSize: 'sizing.size_3',
    tableTransition: '0s',
    borderRadius: 'sizing.size_0',
    barForegroundColor: 'tokens.foregroundColor',
    barBackgroundColor: 'tokens.backgroundSecondaryColor',
    barHorizontalPadding: 'density.barsHorizontal',
    barVerticalPadding: 'density.barsVertical',
    shadowColor: [
        'colors.palette.800',
        'colors.palette.300'
    ],
    shadowX: 'sizing.size_0_25',
    shadowY: 'sizing.size_0_25',
    shadowBlur: 'sizing.size_0',
    shadowOpacity: '8%',
    cellHorizontalPadding: 'density.cellHorizontal',
    cellVerticalPadding: 'density.cellVertical',
    cellHorizontalBorderColor: 'tokens.borderColor',
    cellVerticalBorderColor: 'tokens.borderColor',
    cellSelectionBorderColor: 'tokens.accentColor',
    cellSelectionBackgroundColor: 'tokens.accentColor',
    cellSuccessBackgroundColor: '#37bc6c33',
    cellErrorBackgroundColor: '#fa4d3233',
    cellReadOnlyBackgroundColor: 'colors.transparent',
    cellAutofillSize: 'sizing.size_1_5',
    cellAutofillHitAreaSize: 'sizing.size_3',
    cellAutofillBorderWidth: 'sizing.size_0_25',
    cellAutofillBorderRadius: 'sizing.size_0',
    cellAutofillBorderColor: 'tokens.backgroundColor',
    cellAutofillBackgroundColor: 'tokens.accentColor',
    cellAutofillFillBorderColor: 'tokens.foregroundColor',
    cellEditorBorderWidth: '2px',
    cellEditorBorderColor: 'tokens.accentColor',
    cellEditorForegroundColor: [
        'colors.palette.950',
        'colors.white'
    ],
    cellEditorBackgroundColor: 'tokens.backgroundColor',
    cellEditorShadowBlurRadius: '0px',
    cellEditorShadowColor: 'tokens.accentColor',
    cellMobileHandleSize: 'sizing.size_3',
    cellMobileHandleBorderWidth: 'sizing.size_0_25',
    cellMobileHandleBorderRadius: 'sizing.size_3',
    cellMobileHandleBorderColor: 'tokens.accentColor',
    cellMobileHandleBackgroundColor: 'tokens.accentColor',
    cellMobileHandleBackgroundOpacity: '40%',
    cellSelectionHandleSize: 'sizing.size_2',
    cellSelectionHandleLength: 'sizing.size_2',
    cellSelectionHandleBorderWidth: 'sizing.size_0_25',
    cellSelectionHandleBorderRadius: 'sizing.size_3',
    cellSelectionHandleBorderColor: 'tokens.accentColor',
    cellSelectionHandleBackgroundColor: 'tokens.backgroundColor',
    headerFontWeight: 'tokens.fontWeight',
    headerForegroundColor: 'tokens.foregroundColor',
    headerBackgroundColor: 'tokens.backgroundSecondaryColor',
    headerHighlightedShadowSize: '0px',
    headerHighlightedForegroundColor: 'tokens.foregroundColor',
    headerHighlightedBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    headerActiveBorderColor: 'tokens.borderColor',
    headerActiveForegroundColor: [
        'colors.palette.950',
        'colors.white'
    ],
    headerActiveBackgroundColor: [
        'colors.primary.400',
        'colors.primary.300'
    ],
    headerFilterBackgroundColor: 'tokens.cellSuccessBackgroundColor',
    headerRowForegroundColor: 'tokens.foregroundColor',
    headerRowBackgroundColor: 'tokens.backgroundSecondaryColor',
    headerRowHighlightedForegroundColor: 'tokens.foregroundColor',
    headerRowHighlightedBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    headerRowActiveForegroundColor: [
        'colors.palette.950',
        'colors.white'
    ],
    headerRowActiveBackgroundColor: [
        'colors.primary.400',
        'colors.primary.300'
    ],
    rowHeaderOddBackgroundColor: 'tokens.headerRowBackgroundColor',
    rowHeaderEvenBackgroundColor: 'tokens.headerRowBackgroundColor',
    rowCellOddBackgroundColor: 'tokens.backgroundColor',
    rowCellEvenBackgroundColor: 'tokens.backgroundColor',
    buttonBorderRadius: 'sizing.size_0_5',
    buttonHorizontalPadding: 'density.buttonHorizontal',
    buttonVerticalPadding: 'density.buttonVertical',
    primaryButtonBorderColor: 'colors.transparent',
    primaryButtonForegroundColor: 'tokens.backgroundColor',
    primaryButtonBackgroundColor: 'tokens.accentColor',
    primaryButtonDisabledBorderColor: 'colors.transparent',
    primaryButtonDisabledForegroundColor: 'tokens.disabledColor',
    primaryButtonDisabledBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    primaryButtonHoverBorderColor: 'colors.transparent',
    primaryButtonHoverForegroundColor: 'tokens.backgroundColor',
    primaryButtonHoverBackgroundColor: [
        'colors.primary.600',
        'colors.primary.200'
    ],
    primaryButtonFocusBorderColor: 'tokens.backgroundColor',
    primaryButtonFocusForegroundColor: 'tokens.backgroundColor',
    primaryButtonFocusBackgroundColor: 'tokens.accentColor',
    secondaryButtonBorderColor: 'tokens.borderColor',
    secondaryButtonForegroundColor: 'tokens.foregroundColor',
    secondaryButtonBackgroundColor: 'tokens.backgroundColor',
    secondaryButtonDisabledBorderColor: 'tokens.borderColor',
    secondaryButtonDisabledForegroundColor: 'tokens.disabledColor',
    secondaryButtonDisabledBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    secondaryButtonHoverBorderColor: 'tokens.borderColor',
    secondaryButtonHoverForegroundColor: 'tokens.foregroundColor',
    secondaryButtonHoverBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    secondaryButtonFocusBorderColor: 'tokens.borderColor',
    secondaryButtonFocusForegroundColor: 'tokens.foregroundColor',
    secondaryButtonFocusBackgroundColor: 'tokens.backgroundSecondaryColor',
    iconButtonBorderRadius: 'sizing.size_0_5',
    iconButtonLargeBorderRadius: 'sizing.size_0_5',
    iconButtonLargePadding: 'sizing.size_1',
    iconButtonBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    iconButtonBackgroundColor: 'tokens.backgroundSecondaryColor',
    iconButtonIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    iconButtonHitAreaSize: 'sizing.size_6',
    iconButtonHoverBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    iconButtonHoverBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    iconButtonHoverIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    iconButtonActiveBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    iconButtonActiveBackgroundColor: 'tokens.backgroundSecondaryColor',
    iconButtonActiveIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    iconButtonActiveHoverBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    iconButtonActiveHoverBackgroundColor: 'tokens.backgroundSecondaryColor',
    iconButtonActiveHoverIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonBorderRadius: 'sizing.size_4',
    collapseButtonOpenBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    collapseButtonOpenBackgroundColor: [
        'colors.white',
        'colors.palette.950'
    ],
    collapseButtonOpenIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonOpenIconActiveColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonOpenHoverBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    collapseButtonOpenHoverBackgroundColor: [
        'colors.white',
        'colors.palette.950'
    ],
    collapseButtonOpenHoverIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonOpenHoverIconActiveColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonCloseBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    collapseButtonCloseBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    collapseButtonCloseIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonCloseIconActiveColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonCloseHoverBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    collapseButtonCloseHoverBackgroundColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    collapseButtonCloseHoverIconColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    collapseButtonCloseHoverIconActiveColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    linkColor: [
        'colors.primary.600',
        'colors.primary.200'
    ],
    linkHoverColor: [
        'colors.primary.600',
        'colors.primary.200'
    ],
    inputBorderWidth: '1px',
    inputBorderRadius: 'sizing.size_1',
    inputHorizontalPadding: 'density.inputHorizontal',
    inputVerticalPadding: 'density.inputVertical',
    inputBorderColor: 'tokens.borderColor',
    inputForegroundColor: 'tokens.foregroundColor',
    inputBackgroundColor: 'tokens.backgroundSecondaryColor',
    inputHoverBorderColor: 'tokens.borderColor',
    inputHoverForegroundColor: 'tokens.foregroundColor',
    inputHoverBackgroundColor: 'tokens.backgroundSecondaryColor',
    inputDisabledBorderColor: 'tokens.borderColor',
    inputDisabledForegroundColor: 'tokens.disabledColor',
    inputDisabledBackgroundColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    inputFocusBorderColor: 'tokens.accentColor',
    inputFocusForegroundColor: 'tokens.foregroundColor',
    inputFocusBackgroundColor: 'tokens.backgroundSecondaryColor',
    checkboxSize: 'tokens.iconSize',
    checkboxBorderRadius: 'sizing.size_0_5',
    checkboxBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    checkboxBackgroundColor: 'tokens.backgroundColor',
    checkboxIconColor: 'colors.transparent',
    checkboxFocusBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    checkboxFocusBackgroundColor: 'tokens.backgroundColor',
    checkboxFocusIconColor: 'colors.transparent',
    checkboxFocusRingColor: 'tokens.accentColor',
    checkboxDisabledBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    checkboxDisabledBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    checkboxDisabledIconColor: 'colors.transparent',
    checkboxCheckedBorderColor: [
        'colors.primary.600',
        'colors.primary.200'
    ],
    checkboxCheckedBackgroundColor: 'tokens.accentColor',
    checkboxCheckedIconColor: 'tokens.backgroundColor',
    checkboxCheckedFocusBorderColor: 'tokens.backgroundColor',
    checkboxCheckedFocusBackgroundColor: 'tokens.accentColor',
    checkboxCheckedFocusIconColor: 'tokens.backgroundColor',
    checkboxCheckedDisabledBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    checkboxCheckedDisabledBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    checkboxCheckedDisabledIconColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    checkboxIndeterminateBorderColor: [
        'colors.primary.600',
        'colors.primary.200'
    ],
    checkboxIndeterminateBackgroundColor: 'tokens.accentColor',
    checkboxIndeterminateIconColor: 'tokens.backgroundColor',
    checkboxIndeterminateFocusBorderColor: 'tokens.backgroundColor',
    checkboxIndeterminateFocusBackgroundColor: 'tokens.accentColor',
    checkboxIndeterminateFocusIconColor: 'tokens.backgroundColor',
    checkboxIndeterminateDisabledBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    checkboxIndeterminateDisabledBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    checkboxIndeterminateDisabledIconColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    radioSize: 'tokens.iconSize',
    radioBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    radioBackgroundColor: 'tokens.backgroundColor',
    radioIconColor: 'colors.transparent',
    radioFocusBorderColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    radioFocusBackgroundColor: 'tokens.backgroundColor',
    radioFocusIconColor: 'colors.transparent',
    radioFocusRingColor: 'tokens.accentColor',
    radioDisabledBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    radioDisabledBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    radioDisabledIconColor: 'colors.transparent',
    radioCheckedBorderColor: 'tokens.accentColor',
    radioCheckedBackgroundColor: 'tokens.backgroundColor',
    radioCheckedIconColor: 'tokens.accentColor',
    radioCheckedFocusBorderColor: [
        'colors.primary.600',
        'colors.primary.200'
    ],
    radioCheckedFocusBackgroundColor: 'tokens.backgroundColor',
    radioCheckedFocusIconColor: 'tokens.accentColor',
    radioCheckedDisabledBorderColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    radioCheckedDisabledBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    radioCheckedDisabledIconColor: [
        'colors.palette.300',
        'colors.palette.600'
    ],
    moveBacklightColor: [
        'colors.palette.800',
        'colors.palette.300'
    ],
    moveBacklightOpacity: '16%',
    moveIndicatorColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    resizeIndicatorColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    hiddenIndicatorColor: [
        'colors.palette.400',
        'colors.palette.500'
    ],
    menuBorderWidth: '1px',
    menuBorderRadius: '0px',
    menuHorizontalPadding: 'density.menuHorizontal',
    menuVerticalPadding: 'density.menuVertical',
    menuItemHorizontalPadding: 'density.menuItemHorizontal',
    menuItemVerticalPadding: 'density.menuItemVertical',
    menuBorderColor: 'tokens.borderColor',
    menuShadowX: 'tokens.shadowX',
    menuShadowY: 'tokens.shadowY',
    menuShadowBlur: 'tokens.shadowBlur',
    menuShadowColor: 'tokens.borderColor',
    menuShadowOpacity: '100%',
    menuItemHoverColor: [
        'colors.palette.800',
        'colors.palette.300'
    ],
    menuItemHoverColorOpacity: '8%',
    menuItemActiveColor: [
        'colors.palette.800',
        'colors.palette.300'
    ],
    menuItemActiveColorOpacity: '12%',
    commentsTextareaHorizontalPadding: 'density.cellHorizontal',
    commentsTextareaVerticalPadding: 'density.cellVertical',
    commentsTextareaBorderWidth: '1px',
    commentsTextareaBorderColor: 'tokens.borderColor',
    commentsTextareaForegroundColor: 'tokens.foregroundColor',
    commentsTextareaBackgroundColor: 'tokens.backgroundSecondaryColor',
    commentsTextareaFocusBorderWidth: '1px',
    commentsTextareaFocusBorderColor: 'tokens.accentColor',
    commentsTextareaFocusForegroundColor: 'tokens.foregroundColor',
    commentsTextareaFocusBackgroundColor: 'tokens.backgroundColor',
    commentsIndicatorSize: 'sizing.size_1_5',
    commentsIndicatorColor: 'tokens.accentColor',
    licenseHorizontalPadding: 'tokens.barHorizontalPadding',
    licenseVerticalPadding: 'tokens.barVerticalPadding',
    licenseForegroundColor: 'tokens.barForegroundColor',
    licenseBackgroundColor: 'tokens.barBackgroundColor',
    paginationBarForegroundColor: 'tokens.barForegroundColor',
    paginationBarBackgroundColor: 'tokens.barBackgroundColor',
    paginationBarHorizontalPadding: 'tokens.barHorizontalPadding',
    paginationBarVerticalPadding: 'tokens.barVerticalPadding',
    paginationButtonBorderColor: 'tokens.paginationBarBackgroundColor',
    paginationButtonForegroundColor: 'tokens.foregroundSecondaryColor',
    paginationButtonBackgroundColor: 'tokens.paginationBarBackgroundColor',
    paginationButtonHoverBorderColor: [
        'colors.palette.50',
        'colors.palette.900'
    ],
    paginationButtonHoverForegroundColor: 'tokens.foregroundColor',
    paginationButtonHoverBackgroundColor: [
        'colors.palette.100',
        'colors.palette.800'
    ],
    paginationButtonDisabledBorderColor: 'tokens.paginationBarBackgroundColor',
    paginationButtonDisabledForegroundColor: 'tokens.disabledColor',
    paginationButtonDisabledBackgroundColor: 'tokens.paginationBarBackgroundColor',
    paginationButtonFocusBorderColor: 'tokens.accentColor',
    paginationButtonFocusForegroundColor: 'tokens.foregroundColor',
    paginationButtonFocusBackgroundColor: 'tokens.paginationBarBackgroundColor',
    dialogSemiTransparentBackgroundColor: [
        'colors.white',
        'colors.palette.950'
    ],
    dialogSemiTransparentBackgroundOpacity: '80%',
    dialogSolidBackgroundColor: [
        'colors.white',
        'colors.palette.950'
    ],
    dialogContentPaddingHorizontal: 'density.dialogHorizontal',
    dialogContentPaddingVertical: 'density.dialogVertical',
    dialogContentBorderRadius: 'sizing.size_2',
    dialogContentBackgroundColor: 'tokens.backgroundSecondaryColor',
    notificationForegroundColor: 'tokens.foregroundColor',
    notificationBackgroundColor: 'tokens.backgroundColor',
    notificationBorderColor: 'tokens.borderColor',
    notificationSuccessAccent: '#37bc6cff',
    notificationWarningAccent: '#fbe952ff',
    notificationErrorAccent: '#fa4d32ff',
    chipBackground: 'tokens.backgroundSecondaryColor',
    chipBorderRadius: 'sizing.size_0_5',
    chipVerticalPadding: 'sizing.size_0',
    chipHorizontalPadding: 'sizing.size_1',
    chipGap: 'sizing.size_1',
    scrollbarBorderRadius: 'sizing.size_2',
    scrollbarTrackColor: 'tokens.backgroundSecondaryColor',
    scrollbarThumbColor: [
        'colors.palette.400',
        'colors.palette.500'
    ]
};
const _default = classicTokens;
