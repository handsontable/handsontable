"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "flattenCssVariables", {
    enumerable: true,
    get: function() {
        return flattenCssVariables;
    }
});
const _object = require("../../../helpers/object");
const _string = require("../../../helpers/string");
/**
 * The theme prefix.
 *
 * @type {string}
 */ const VAR_PREFIX = '--ht-';
/**
 * List of keys that should not be converted to CSS variable references.
 *
 * @type {string[]}
 */ const CSS_KEY_EXCEPTIONS = [
    'font-family'
];
/**
 * List of prefixes that indicate a value should be converted to a CSS variable reference.
 *
 * @type {string[]}
 */ const VAR_REFERENCE_PREFIXES = [
    'tokens.',
    'colors.',
    'sizing.',
    'density.'
];
/**
 * Checks if a value is a reference to another CSS variable (e.g., 'colors.primary').
 *
 * @param {string} value - The value to check.
 * @returns {boolean} - True if the value is a variable reference.
 */ function isVarReference(value) {
    return typeof value === 'string' && VAR_REFERENCE_PREFIXES.some((prefix)=>value.includes(prefix));
}
/**
 * Converts a dot notation path to a CSS variable reference.
 * Handles special case for 'tokens.' prefix which strips the first segment.
 *
 * @param {string} path - The dot notation path (e.g., 'colors.primary').
 * @returns {string} - The CSS variable reference (e.g., 'var(--ht-colors-primary)').
 */ function toVarReference(path) {
    if (path.includes('tokens.')) {
        return `var(${VAR_PREFIX}${(0, _string.toHyphen)(path.split('.').slice(1).join('-'))})`;
    }
    return `var(${VAR_PREFIX}${(0, _string.toHyphen)(path.split('.').join('-'))})`;
}
/**
 * Converts a key to a CSS variable key.
 *
 * @param {string} prefix - The prefix to add to the CSS variable.
 * @param {string} key - The key to convert.
 * @returns {string} - The CSS variable key.
 */ function toCssKey(prefix, key) {
    return `${VAR_PREFIX}${prefix ? `${prefix}-` : ''}${(0, _string.toHyphen)(key)}`;
}
/**
 * Checks whether a value is a `[light, dark]` value list.
 *
 * @param {*} value - The value to check.
 * @returns {boolean} - True when the value carries a separate light and dark value.
 */ function isLightDarkValue(value) {
    return Array.isArray(value) && value.length >= 2 && typeof value[0] === 'string' && typeof value[1] === 'string';
}
/**
 * Converts a value to a CSS variable value.
 * Handles variable references, light/dark values, and single values.
 *
 * @param {string|object} value - The value to convert.
 * @param {string} [key] - The CSS key name (used for exceptions like font-family).
 * @param {object} [options] - The flattening options.
 * @returns {string} - The CSS value.
 */ function toCssValue(value, key, options = {}) {
    if (typeof value === 'string' && isVarReference(value)) {
        return toVarReference(value);
    }
    if (Array.isArray(value)) {
        if (value.length >= 2) {
            const [light, dark] = value;
            if (typeof light === 'string' && typeof dark === 'string') {
                if (options.resolveScheme === 'light') {
                    return toCssValue(light, key, options);
                }
                if (options.resolveScheme === 'dark') {
                    return toCssValue(dark, key, options);
                }
                return `light-dark(${toCssValue(light, key, options)}, ${toCssValue(dark, key, options)})`;
            }
            if (typeof light === 'string') {
                return toCssValue(light, key, options);
            }
            if (typeof dark === 'string') {
                return toCssValue(dark, key, options);
            }
            return '';
        }
        return toCssValue(value[0], key, options);
    }
    if (key && CSS_KEY_EXCEPTIONS.includes(key)) {
        return String(value);
    }
    return (0, _string.toHyphen)(String(value));
}
/**
 * Converts a key and value to a CSS variable line.
 *
 * @param {string} prefix - The prefix to add to the CSS variable.
 * @param {string} key - The key to convert.
 * @param {string} value - The value to convert.
 * @param {object} [options] - The flattening options.
 * @returns {string} - The CSS variable line.
 */ function toCssLine(prefix, key, value, options = {}) {
    return `${toCssKey(prefix, key)}: ${toCssValue(value, key, options)};`;
}
function flattenCssVariables(cssVariables, prefix = '', parentKey = '', options = {}) {
    let cssVars = '';
    Object.entries(cssVariables).forEach(([key, value])=>{
        const normalizedKey = (0, _string.toHyphen)(key);
        const fullKey = parentKey ? `${parentKey}-${normalizedKey}` : normalizedKey;
        if ((0, _object.isObject)(value)) {
            cssVars += flattenCssVariables(value, prefix, fullKey, options);
        } else if (!options.lightDarkOnly || isLightDarkValue(value)) {
            cssVars += `${toCssLine(prefix, fullKey, value, options)}\n`;
        }
    });
    return cssVars;
}
