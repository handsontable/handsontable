"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ThemeBuilder () {
        return _builder.ThemeBuilder;
    },
    get ThemeManager () {
        return _manager.ThemeManager;
    },
    get createTheme () {
        return _builder.createTheme;
    },
    get createThemeManager () {
        return _manager.createThemeManager;
    },
    get isThemeOverrideEmpty () {
        return _manager.isThemeOverrideEmpty;
    }
});
const _builder = require("./builder");
const _manager = require("./manager");
