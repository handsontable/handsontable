"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "horizonTheme", {
    enumerable: true,
    get: function() {
        return horizonTheme;
    }
});
const _horizon = /*#__PURE__*/ _interop_require_default(require("../static/variables/icons/horizon"));
const _horizon1 = /*#__PURE__*/ _interop_require_default(require("../static/variables/colors/horizon"));
const _horizon2 = /*#__PURE__*/ _interop_require_default(require("../static/variables/tokens/horizon"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const horizonTheme = {
    name: 'horizon',
    density: 'comfortable',
    icons: _horizon.default,
    colors: _horizon1.default,
    tokens: _horizon2.default
};
