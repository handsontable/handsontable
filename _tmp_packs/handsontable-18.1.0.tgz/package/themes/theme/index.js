"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get classicTheme () {
        return _classic.classicTheme;
    },
    get horizonTheme () {
        return _horizon.horizonTheme;
    },
    get mainTheme () {
        return _main.mainTheme;
    }
});
const _classic = require("./classic");
const _main = require("./main");
const _horizon = require("./horizon");
