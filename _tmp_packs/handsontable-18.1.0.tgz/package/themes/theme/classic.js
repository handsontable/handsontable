"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "classicTheme", {
    enumerable: true,
    get: function() {
        return classicTheme;
    }
});
const _main = /*#__PURE__*/ _interop_require_default(require("../static/variables/icons/main"));
const _classic = /*#__PURE__*/ _interop_require_default(require("../static/variables/colors/classic"));
const _classic1 = /*#__PURE__*/ _interop_require_default(require("../static/variables/tokens/classic"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const classicTheme = {
    name: 'classic',
    density: 'compact',
    icons: _main.default,
    colors: _classic.default,
    tokens: _classic1.default
};
