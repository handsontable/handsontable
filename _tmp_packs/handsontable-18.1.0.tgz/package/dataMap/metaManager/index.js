"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return MetaManager;
    }
});
const _globalMeta = /*#__PURE__*/ _interop_require_default(require("./metaLayers/globalMeta"));
const _tableMeta = /*#__PURE__*/ _interop_require_default(require("./metaLayers/tableMeta"));
const _columnMeta = /*#__PURE__*/ _interop_require_default(require("./metaLayers/columnMeta"));
const _cellMeta = /*#__PURE__*/ _interop_require_default(require("./metaLayers/cellMeta"));
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../mixins/localHooks"));
const _object = require("../../helpers/object");
const _errors = require("../../helpers/errors");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
class MetaManager {
    /**
   * Gets the global meta object that is a root of all default settings, which are recognizable by Handsontable.
   * Other layers inherites all properties from this. Adding, removing, or changing property in that
   * object has a direct reflection to all layers.
   *
   * @returns {object}
   */ getGlobalMeta() {
        return this.globalMeta.getMeta();
    }
    /**
   * Updates global settings object by merging settings with the current state.
   *
   * @param {object} settings An object to merge with.
   */ updateGlobalMeta(settings) {
        this.globalMeta.updateMeta(settings);
    }
    /**
   * Gets settings object that was passed in the Handsontable constructor. That layer contains all
   * default settings inherited from the GlobalMeta layer merged with settings passed by the developer.
   * Adding, removing, or changing property in that object has no direct reflection on any other layers.
   *
   * @returns {TableMeta}
   */ getTableMeta() {
        return this.tableMeta.getMeta();
    }
    /**
   * Updates table settings object by merging settings with the current state.
   *
   * @param {object} settings An object to merge with.
   */ updateTableMeta(settings) {
        this.tableMeta.updateMeta(settings);
    }
    /**
   * Gets column meta object that is a root of all settings defined in the column property of the Handsontable
   * settings. Each column in the Handsontable is associated with a unique meta object which identified by
   * the physical column index. Adding, removing, or changing property in that object has a direct reflection
   * only for the CellMeta layer. The reflection will be visible only if the property doesn't exist in the lower
   * layers (prototype lookup).
   *
   * @param {number} physicalColumn The physical column index.
   * @returns {object}
   */ getColumnMeta(physicalColumn) {
        return this.columnMeta.getMeta(physicalColumn);
    }
    /**
   * Updates column meta object by merging settings with the current state.
   *
   * @param {number} physicalColumn The physical column index which points what column meta object is updated.
   * @param {object} settings An object to merge with.
   */ updateColumnMeta(physicalColumn, settings) {
        this.columnMeta.updateMeta(physicalColumn, settings);
    }
    /**
   * Gets the cell meta object that is a root of all settings defined for the specific cell rendered by
   * the Handsontable. Each cell meta inherits settings from higher layers. When a property doesn't
   * exist in that layer, it is looked up through a prototype to the highest layer. Starting
   * from CellMeta -> ColumnMeta and ending to GlobalMeta, which stores default settings. Adding,
   * removing, or changing property in that object has no direct reflection on any other layers.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @param {object} options Options for the `getCellMeta` method.
   * @param {number} options.visualRow The visual row index of the currently requested cell meta object.
   * @param {number} options.visualColumn The visual column index of the currently requested cell meta object.
   * @param {boolean} [options.skipMetaExtension=false] If `true`, omits the `afterGetCellMeta` hook which calls the `extendCellMeta` method.
   * @returns {object}
   */ getCellMeta(physicalRow, physicalColumn, options) {
        const cellMeta = this.cellMeta.getMeta(physicalRow, physicalColumn);
        cellMeta.visualRow = options.visualRow;
        cellMeta.visualCol = options.visualColumn;
        cellMeta.row = physicalRow;
        cellMeta.col = physicalColumn;
        if (!options.skipMetaExtension) {
            this.runLocalHooks('afterGetCellMeta', cellMeta);
        }
        return cellMeta;
    }
    /**
   * Gets a cell meta object for read-only access without retaining it. When the cell already has a
   * stored meta object (because it carries user-defined or declarative `cell` overrides) that object
   * is returned; otherwise a transient object inheriting from the column layer is created and NOT
   * stored. This avoids permanently materializing one cell meta object per scanned cell when iterating
   * the whole dataset (for example, filtering), where the eager `getCellMeta` would otherwise grow the
   * meta cache to O(rows × columns). The `afterGetCellMeta` extension is intentionally not run.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @param {object} options Options for the method.
   * @param {number} options.visualRow The visual row index of the currently requested cell meta object.
   * @param {number} options.visualColumn The visual column index of the currently requested cell meta object.
   * @returns {object}
   */ getCellMetaUncached(physicalRow, physicalColumn, options) {
        // Two map lookups on the warm path (vs five for `hasMeta` + `getMeta`), and the miss
        // fallback stays inline - extracting this expression into a helper regresses the read
        // through V8 inline-cache pollution.
        const cellMeta = this.cellMeta.getMetaIfExists(physicalRow, physicalColumn) ?? this.cellMeta.createTransientMeta(physicalColumn);
        cellMeta.visualRow = options.visualRow;
        cellMeta.visualCol = options.visualColumn;
        cellMeta.row = physicalRow;
        cellMeta.col = physicalColumn;
        return cellMeta;
    }
    /**
   * Gets a fully-extended cell meta object without retaining it. Unlike `getCellMetaUncached`, the
   * dynamic extension DOES run - the `beforeGetCellMeta`/`afterGetCellMeta` hooks and the `cells`
   * function are applied (through the `extendTransientCellMeta` local hook), so hook-driven
   * properties such as `readOnly`, `hidden`, or `spanned` resolve correctly. Unlike `getCellMeta`,
   * nothing is stored: when the cell has no persisted meta, the extension runs on a transient object
   * that is thrown away, so a bulk scan (for example, column-width sampling over the whole row
   * range) does not permanently materialize one meta object per visited cell. Cells that already
   * carry stored meta go through the regular memoized `getCellMeta` path. Hook mutations made on a
   * transient object do not persist - callers that need to write meta must use `setCellMeta`.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @param {object} options Options for the method.
   * @param {number} options.visualRow The visual row index of the currently requested cell meta object.
   * @param {number} options.visualColumn The visual column index of the currently requested cell meta object.
   * @returns {object}
   */ getCellMetaTransient(physicalRow, physicalColumn, options) {
        const storedMeta = this.cellMeta.getMetaIfExists(physicalRow, physicalColumn);
        // The stored path mirrors `getCellMeta` on the already-resolved object instead of delegating
        // to it - delegation would re-resolve the same cell (two more map lookups per stored cell on
        // every bulk validate/copy/export scan), and widening `getCellMeta` itself with a pre-resolved
        // parameter would add a branch to the hottest read path in the grid.
        if (storedMeta !== undefined) {
            storedMeta.visualRow = options.visualRow;
            storedMeta.visualCol = options.visualColumn;
            storedMeta.row = physicalRow;
            storedMeta.col = physicalColumn;
            this.runLocalHooks('afterGetCellMeta', storedMeta);
            return storedMeta;
        }
        const cellMeta = this.cellMeta.createTransientMeta(physicalColumn);
        cellMeta.visualRow = options.visualRow;
        cellMeta.visualCol = options.visualColumn;
        cellMeta.row = physicalRow;
        cellMeta.col = physicalColumn;
        this.runLocalHooks('extendTransientCellMeta', cellMeta);
        return cellMeta;
    }
    /**
   * Gets a value (defined by the `key` property) from the cell meta object.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @param {string} key Defines the value that will be returned from the cell meta object.
   * @returns {*}
   */ getCellMetaKeyValue(physicalRow, physicalColumn, key) {
        if (typeof key !== 'string') {
            (0, _errors.throwWithCause)('The passed cell meta object key is not a string');
        }
        return this.cellMeta.getMeta(physicalRow, physicalColumn, key);
    }
    /**
   * Sets settings object for cell meta object defined by "key" property.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @param {string} key The property name to set.
   * @param {*} value Value to save.
   */ setCellMeta(physicalRow, physicalColumn, key, value) {
        this.cellMeta.setMeta(physicalRow, physicalColumn, key, value);
    }
    /**
   * Updates cell meta object by merging settings with the current state.
   *
   * @param {number} physicalRow The physical row index which points what cell meta object is updated.
   * @param {number} physicalColumn The physical column index which points what cell meta object is updated.
   * @param {object} settings An object to merge with.
   */ updateCellMeta(physicalRow, physicalColumn, settings) {
        this.cellMeta.updateMeta(physicalRow, physicalColumn, settings);
    }
    /**
   * Removes a property defined by the "key" argument from the cell meta object.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @param {string} key The property name to remove.
   */ removeCellMeta(physicalRow, physicalColumn, key) {
        this.cellMeta.removeMeta(physicalRow, physicalColumn, key);
    }
    /**
   * Returns all cell meta objects that were created during the Handsontable operation. As cell meta
   * objects are created lazy, the length of the returned collection depends on how and when the
   * table has asked for access to that meta objects.
   *
   * @returns {object[]}
   */ getCellsMeta() {
        return this.cellMeta.getMetas();
    }
    /**
   * Returns all cell meta objects that were created during the Handsontable operation but for
   * specific row index.
   *
   * @param {number} physicalRow The physical row index.
   * @returns {object[]}
   */ getCellsMetaAtRow(physicalRow) {
        return this.cellMeta.getMetasAtRow(physicalRow);
    }
    /**
   * Returns a flat snapshot of all cell meta properties that were set imperatively through
   * `setCellMeta` (for example, by the user or by the context menu), keyed by physical coordinates.
   * Used to preserve user-defined meta across a `clearCache` call during `updateSettings`.
   *
   * @returns {{physicalRow: number, physicalColumn: number, key: string, value: *}[]}
   */ getUserDefinedCellMetas() {
        return this.cellMeta.getUserDefinedMetas();
    }
    /**
   * Enables tracking of user-defined cell meta properties set through `setCellMeta`.
   */ enableUserDefinedMetaRecording() {
        this.cellMeta.enableUserDefinedMetaRecording();
    }
    /**
   * Disables tracking of user-defined cell meta properties. Writes made while disabled are treated
   * as declarative (for example, the `cell` option applied during `updateSettings`).
   */ disableUserDefinedMetaRecording() {
        this.cellMeta.disableUserDefinedMetaRecording();
    }
    /**
   * Creates one or more rows at specific position.
   *
   * @param {number} physicalRow The physical row index which points from what position the row is added.
   *   Pass `null` to append at the end.
   * @param {number} [amount=1] An amount of rows to add.
   */ createRow(physicalRow, amount = 1) {
        this.cellMeta.createRow(physicalRow, amount);
    }
    /**
   * Removes one or more rows from the collection.
   *
   * @param {number} physicalRow The physical row index which points from what position the row is removed.
   * @param {number} [amount=1] An amount rows to remove.
   */ removeRow(physicalRow, amount = 1) {
        this.cellMeta.removeRow(physicalRow, amount);
    }
    /**
   * Creates one or more columns at specific position.
   *
   * @param {number} physicalColumn The physical column index which points from what position the column is added.
   *   Pass `null` to append at the end.
   * @param {number} [amount=1] An amount of columns to add.
   */ createColumn(physicalColumn, amount = 1) {
        this.cellMeta.createColumn(physicalColumn, amount);
        this.columnMeta.createColumn(physicalColumn, amount);
    }
    /**
   * Removes one or more columns from the collection.
   *
   * @param {number} physicalColumn The physical column index which points from what position the column is removed.
   * @param {number} [amount=1] An amount of columns to remove.
   */ removeColumn(physicalColumn, amount = 1) {
        this.cellMeta.removeColumn(physicalColumn, amount);
        this.columnMeta.removeColumn(physicalColumn, amount);
    }
    /**
   * Clears all saved cell meta objects. It keeps column meta, table meta, and global meta intact.
   */ clearCellsCache() {
        this.cellMeta.clearCache();
    }
    /**
   * Clears all saved cell and columns meta objects.
   */ clearCache() {
        this.cellMeta.clearCache();
        this.columnMeta.clearCache();
    }
    /**
   * Initializes all meta layers, applies custom settings to global meta, and instantiates any meta modifier classes.
   */ constructor(hot, customSettings = {}, metaMods = []){
        this.hot = hot;
        this.globalMeta = new _globalMeta.default(hot);
        this.tableMeta = new _tableMeta.default(this.globalMeta);
        this.columnMeta = new _columnMeta.default(this.globalMeta);
        this.cellMeta = new _cellMeta.default(this.columnMeta);
        metaMods.forEach((ModifierClass)=>new ModifierClass(this));
        this.globalMeta.updateMeta(customSettings);
    }
}
(0, _object.mixin)(MetaManager, _localHooks.default);
