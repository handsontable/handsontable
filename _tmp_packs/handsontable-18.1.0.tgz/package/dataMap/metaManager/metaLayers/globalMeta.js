"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return GlobalMeta;
    }
});
const _object = require("../../../helpers/object");
const _utils = require("../utils");
const _metaSchema = /*#__PURE__*/ _interop_require_default(require("../metaSchema"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * @typedef {Options} TableMeta
 */ /**
 * @returns {TableMeta} Returns an empty object. The holder for global meta object.
 */ function createTableMetaEmptyClass() {
    return class TableMeta {
    };
}
class GlobalMeta {
    /**
   * Gets constructor of the global meta object. Necessary for inheritance for creating the next meta layers.
   *
   * @returns {Function}
   */ getMetaConstructor() {
        return this.metaCtor;
    }
    /**
   * Gets settings object for this layer.
   *
   * @returns {object}
   */ getMeta() {
        return this.meta;
    }
    /**
   * Updates global settings object by merging settings with the current state.
   *
   * @param {object} settings An object to merge with.
   */ updateMeta(settings) {
        (0, _object.extend)(this.meta, settings);
        (0, _utils.extendByMetaType)(this.meta, {
            ...settings,
            type: settings.type ?? this.meta.type
        }, settings);
    }
    /**
   * Initializes the global meta layer, populates the meta prototype with schema defaults, and attaches the Handsontable instance reference.
   */ constructor(hot){
        /**
   * An alias for the constructor. Necessary for inheritance for creating new layers.
   *
   * @type {TableMeta}
   */ this.metaCtor = createTableMetaEmptyClass();
        this.meta = this.metaCtor.prototype;
        (0, _object.extend)(this.meta, (0, _metaSchema.default)());
        this.meta.instance = hot;
    }
}
