"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return CellMeta;
    }
});
const _utils = require("../utils");
const _lazyFactoryMap = /*#__PURE__*/ _interop_require_default(require("../lazyFactoryMap"));
const _object = require("../../../helpers/object");
const _mixed = require("../../../helpers/mixed");
const _number = require("../../../helpers/number");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * Counts how many times user-defined meta recording has been suspended without a matching
   * resume. Recording is active only when the count is `0`. A counter (rather than a boolean) keeps
   * nested suspend/resume scopes correct - for example, when a re-entrant `updateSettings` runs from
   * a `setCellMeta` hook while the outer `cell` option loop is still applying declarative writes.
   *
   * @type {number}
   */ _userDefinedMetaRecordingSuspendCount = /*#__PURE__*/ new WeakMap();
class CellMeta {
    /**
   * Resumes tracking of user-defined cell meta properties by closing one suspension scope opened by
   * `disableUserDefinedMetaRecording`. Recording becomes active again only once every suspension has
   * been closed. Subsequent `setMeta` calls then mark their keys as user-defined, so they are
   * preserved across `updateSettings`.
   */ enableUserDefinedMetaRecording() {
        if (_class_private_field_get(this, _userDefinedMetaRecordingSuspendCount) > 0) {
            _class_private_field_set(this, _userDefinedMetaRecordingSuspendCount, _class_private_field_get(this, _userDefinedMetaRecordingSuspendCount) - 1);
        }
    }
    /**
   * Suspends tracking of user-defined cell meta properties. While suspended, `setMeta` calls are
   * treated as declarative writes and de-mark their keys, so they are not preserved across
   * `updateSettings`. Suspensions nest - each call must be matched by an `enableUserDefinedMetaRecording`
   * call before recording resumes.
   */ disableUserDefinedMetaRecording() {
        _class_private_field_set(this, _userDefinedMetaRecordingSuspendCount, _class_private_field_get(this, _userDefinedMetaRecordingSuspendCount) + 1);
    }
    /**
   * Updates cell meta object by merging settings with the current state.
   *
   * @param {number} physicalRow The physical row index which points what cell meta object is updated.
   * @param {number} physicalColumn The physical column index which points what cell meta object is updated.
   * @param {object} settings An object to merge with.
   */ updateMeta(physicalRow, physicalColumn, settings) {
        const meta = this.getMeta(physicalRow, physicalColumn);
        (0, _object.extend)(meta, settings);
        (0, _utils.extendByMetaType)(meta, settings);
    }
    /**
   * Creates one or more rows at specific position.
   *
   * @param {number} physicalRow The physical row index which points from what position the row is added.
   *   Pass `null` to append at the end.
   * @param {number} amount An amount of rows to add.
   */ createRow(physicalRow, amount) {
        this.metas.insert(physicalRow, amount);
    }
    /**
   * Creates one or more columns at specific position.
   *
   * @param {number} physicalColumn The physical column index which points from what position the column is added.
   *   Pass `null` to append at the end.
   * @param {number} amount An amount of columns to add.
   */ createColumn(physicalColumn, amount) {
        // Iterate only materialized rows. Evicted/unmaterialized rows hold no cell meta to shift, so
        // re-creating them here (the previous `obtain(i)` over `size()`) would needlessly re-inflate
        // memory and add O(total rows) work after a viewport eviction.
        for (const [, rowMeta] of this.metas){
            rowMeta.insert(physicalColumn, amount);
        }
    }
    /**
   * Removes one or more rows from the collection.
   *
   * @param {number} physicalRow The physical row index which points from what position the row is removed.
   * @param {number} amount An amount of rows to remove.
   */ removeRow(physicalRow, amount) {
        this.metas.remove(physicalRow, amount);
    }
    /**
   * Removes one or more columns from the collection.
   *
   * @param {number} physicalColumn The physical column index which points from what position the column is removed.
   * @param {number} amount An amount of columns to remove.
   */ removeColumn(physicalColumn, amount) {
        // Iterate only materialized rows (see `createColumn`); evicted/unmaterialized rows have no cell
        // meta to shift, so skipping them avoids re-creating them after a viewport eviction.
        for (const [, rowMeta] of this.metas){
            rowMeta.remove(physicalColumn, amount);
        }
    }
    /**
   * Returns the cell meta object or a specific property value from it, depending on whether a key is provided.
   */ getMeta(physicalRow, physicalColumn, key) {
        const cellMeta = this.metas.obtain(physicalRow).obtain(physicalColumn);
        if (key === undefined) {
            return cellMeta;
        }
        return cellMeta[key];
    }
    /**
   * Checks whether a cell meta object has already been created for the given coordinates, without
   * creating one. Used to decide whether a cell carries its own (user/declarative) meta that must be
   * reused, as opposed to deriving a fresh object from the column layer.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @returns {boolean}
   */ hasMeta(physicalRow, physicalColumn) {
        return this.metas.has(physicalRow) && this.metas.obtain(physicalRow).has(physicalColumn);
    }
    /**
   * Returns the stored cell meta object for the given coordinates, or `undefined` when the cell
   * has no materialized meta. Unlike `getMeta`, it never creates row or cell objects, so it is
   * safe for bulk scans; unlike `hasMeta` followed by `getMeta`, it resolves in two map lookups
   * instead of five, which matters on the per-cell read path.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @returns {object|undefined}
   */ getMetaIfExists(physicalRow, physicalColumn) {
        return this.metas.getIfExists(physicalRow)?.getIfExists(physicalColumn);
    }
    /**
   * Creates a cell meta object inheriting from the column layer without storing it in the map. The
   * returned object is transient (eligible for garbage collection) and carries no per-cell overrides,
   * so it must only be used for reads that do not need persisted per-cell meta.
   *
   * @param {number} physicalColumn The physical column index.
   * @returns {object}
   */ createTransientMeta(physicalColumn) {
        return this._createMeta(physicalColumn);
    }
    /**
   * Sets settings object for this layer defined by "key" property.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @param {string} key The property name to set.
   * @param {*} value Value to save.
   */ setMeta(physicalRow, physicalColumn, key, value) {
        const cellMeta = this.metas.obtain(physicalRow).obtain(physicalColumn);
        cellMeta._automaticallyAssignedMetaProps?.delete(key);
        cellMeta[key] = value;
        // Every `setMeta` write - imperative or declarative (`cell` option) - is non-reconstructable by
        // `getCellMeta`, so record it; the viewport-eviction pass keeps cells whose set is non-empty.
        if (cellMeta._persistedMetaProps === undefined) {
            cellMeta._persistedMetaProps = new Set();
        }
        cellMeta._persistedMetaProps.add(key);
        if (_class_private_field_get(this, _userDefinedMetaRecordingSuspendCount) === 0) {
            if (cellMeta._userDefinedMetaProps === undefined) {
                cellMeta._userDefinedMetaProps = new Set();
            }
            cellMeta._userDefinedMetaProps.add(key);
        } else {
            cellMeta._userDefinedMetaProps?.delete(key);
        }
    }
    /**
   * Removes a property defined by the "key" argument from the cell meta object.
   *
   * @param {number} physicalRow The physical row index.
   * @param {number} physicalColumn The physical column index.
   * @param {string} key The property name to remove.
   */ removeMeta(physicalRow, physicalColumn, key) {
        // Peek instead of `obtain`: removing a key from a cell with no materialized meta is a no-op,
        // and materializing one object per visited cell here would retain memory the viewport
        // eviction cannot sweep (bulk callers remove keys across whole regions).
        const cellMeta = this.metas.getIfExists(physicalRow)?.getIfExists(physicalColumn);
        if (cellMeta === undefined) {
            return;
        }
        delete cellMeta[key];
        cellMeta._userDefinedMetaProps?.delete(key);
        cellMeta._persistedMetaProps?.delete(key);
    }
    /**
   * Returns all cell meta objects that were created during the Handsontable operation. As cell meta
   * objects are created lazy, the length of the returned collection depends on how and when the
   * table has asked for access to that meta objects.
   *
   * @returns {object[]}
   */ getMetas() {
        const metas = [];
        const rows = Array.from(this.metas.values());
        for(let row = 0; row < rows.length; row++){
            // Getting a meta for already added row (new row already exist - it has been added using `createRow` method).
            // However, is not ready until the first `getMeta` call (lazy loading).
            if ((0, _mixed.isDefined)(rows[row])) {
                metas.push(...Array.from(rows[row].values()));
            }
        }
        return metas;
    }
    /**
   * Returns all cell meta objects that were created during the Handsontable operation but for
   * specific row index.
   *
   * @param {number} physicalRow The physical row index.
   * @returns {object[]}
   */ getMetasAtRow(physicalRow) {
        (0, _utils.assert)(()=>(0, _number.isUnsignedNumber)(physicalRow), 'Expecting an unsigned number.');
        const rowMeta = this.metas.getIfExists(physicalRow);
        if (rowMeta === undefined) {
            return [];
        }
        return Array.from(rowMeta).sort(([a], [b])=>a - b).map(([, meta])=>meta);
    }
    /**
   * Returns a flat snapshot of all cell meta properties that were set imperatively through
   * `setMeta` (tracked in each cell's `_userDefinedMetaProps`). The coordinates are read from the
   * map keys (physical indexes), not from the meta object's `row`/`col` properties, which are only
   * populated on `getCellMeta` and become stale after row or column shifts. Used to preserve
   * user-defined meta across a cache clear during `updateSettings`.
   *
   * @returns {{physicalRow: number, physicalColumn: number, key: string, value: *}[]}
   */ getUserDefinedMetas() {
        const result = [];
        for (const [physicalRow, rowMap] of this.metas){
            for (const [physicalColumn, meta] of rowMap){
                const userDefinedProps = meta._userDefinedMetaProps;
                if (userDefinedProps === undefined) {
                    continue; // eslint-disable-line no-continue
                }
                userDefinedProps.forEach((key)=>{
                    if ((0, _object.hasOwnProperty)(meta, key)) {
                        result.push({
                            physicalRow,
                            physicalColumn,
                            key,
                            value: meta[key]
                        });
                    }
                });
            }
        }
        return result;
    }
    /**
   * Releases render-derived cell meta objects for a single physical row, freeing memory for rows
   * scrolled out of the viewport. A cell is evicted only when it is purely render-derived: it carries
   * no persisted meta props (nothing set through `setMeta`/`setCellMeta`, whether imperatively or via
   * the declarative `cell` option) and is not flagged invalid (`valid === false`, written directly by
   * the validation flow and not rebuilt on render). Such cells are pure cascade/`cells`/`type`
   * derivations and are re-created lazily on the next `getMeta` call. Cells with persisted props or a
   * failed validation result are kept so those values survive scrolling. When the whole row is purely
   * render-derived, its inner map is dropped as well.
   *
   * @param {number} physicalRow The physical row index to evict.
   * @returns {number[]} The physical column indexes whose meta was evicted (empty when nothing was).
   */ evictRow(physicalRow) {
        const rowMap = this.metas.getIfExists(physicalRow);
        if (rowMap === undefined) {
            return [];
        }
        let hasKeptCell = false;
        const evictedColumns = [];
        for (const [physicalColumn, meta] of rowMap){
            const persistedProps = meta._persistedMetaProps;
            const hasPersistedProps = persistedProps !== undefined && persistedProps.size > 0;
            // A failed validation result (`valid === false`) is written directly onto the meta object by
            // the core validation flow (not through `setMeta`) and is not rebuilt on render, so the cell
            // must survive eviction or the invalid-cell highlight would disappear after scrolling away.
            // Only `false` is preserved, not `valid === true`: a passing result has no rendered state and
            // preserving every validated-valid cell would defeat the memory bound on a fully validated grid.
            // The trade-off is that `getCellMeta().valid` reads back as `undefined` (not `true`) for an
            // evicted-and-re-minted valid cell until it is validated again; no core reader distinguishes the
            // two (all branch on `!== false`).
            const isInvalid = meta.valid === false;
            if (hasPersistedProps || isInvalid) {
                hasKeptCell = true;
            } else {
                rowMap.evict(physicalColumn);
                evictedColumns.push(physicalColumn);
            }
        }
        if (!hasKeptCell) {
            this.metas.evict(physicalRow);
        }
        return evictedColumns;
    }
    /**
   * Clears all saved cell meta objects.
   */ clearCache() {
        this.metas.clear();
    }
    /**
   * Creates and returns new structure for cell meta objects stored in columnar axis.
   *
   * @private
   * @returns {object}
   */ _createRow() {
        return new _lazyFactoryMap.default((physicalColumn)=>this._createMeta(physicalColumn));
    }
    /**
   * Creates and returns new cell meta object with properties inherited from the column meta layer.
   *
   * @private
   * @param {number} physicalColumn The physical column index.
   * @returns {object}
   */ _createMeta(physicalColumn) {
        // The constructor is produced by `columnFactory` through runtime prototype inheritance, which
        // TypeScript cannot follow - this single cast is where the meta object type enters the layer.
        // The prototype chain supplies every grid setting; the coordinate properties are stamped by
        // `MetaManager` on each read, completing the `CellProperties` shape.
        const ColumnMeta = this.columnMeta.getMetaConstructor(physicalColumn);
        return new ColumnMeta();
    }
    /**
   * Initializes the cell meta layer with a reference to the ColumnMeta layer used as the prototype source for new cell meta objects.
   */ constructor(columnMeta){
        _class_private_field_init(this, _userDefinedMetaRecordingSuspendCount, {
            writable: true,
            value: void 0
        });
        /**
   * Holder for cell meta objects, organized as a grid of LazyFactoryMap of LazyFactoryMaps.
   * The access to the cell meta object is done through access to the row defined by the physical
   * row index and then by accessing the second LazyFactory Map under the physical column index.
   *
   * @type {LazyFactoryMap<number, LazyFactoryMap<number, object>>}
   */ this.metas = new _lazyFactoryMap.default(()=>this._createRow());
        _class_private_field_set(this, _userDefinedMetaRecordingSuspendCount, 0);
        this.columnMeta = columnMeta;
    }
}
