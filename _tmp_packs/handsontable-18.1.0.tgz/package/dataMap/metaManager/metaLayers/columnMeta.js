"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return ColumnMeta;
    }
});
const _object = require("../../../helpers/object");
const _utils = require("../utils");
const _lazyFactoryMap = /*#__PURE__*/ _interop_require_default(require("../lazyFactoryMap"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * List of props which have to be cleared in the column meta-layer. That props have a
 * different meaning when using in column meta.
 *
 * @type {string[]}
 */ const COLUMNS_PROPS_CONFLICTS = [
    'data',
    'width'
];
class ColumnMeta {
    /**
   * Updates column meta object by merging settings with the current state.
   *
   * @param {number} physicalColumn The physical column index which points what column meta object is updated.
   * @param {object} settings An object to merge with.
   */ updateMeta(physicalColumn, settings) {
        const meta = this.getMeta(physicalColumn);
        (0, _object.extend)(meta, settings);
        (0, _utils.extendByMetaType)(meta, settings);
    }
    /**
   * Creates one or more columns at specific position.
   *
   * @param {number} physicalColumn The physical column index which points from what position the column is added.
   *   Pass `null` to append at the end.
   * @param {number} amount An amount of columns to add.
   */ createColumn(physicalColumn, amount) {
        this.metas.insert(physicalColumn, amount);
    }
    /**
   * Removes one or more columns from the collection.
   *
   * @param {number} physicalColumn The physical column index which points from what position the column is removed.
   * @param {number} amount An amount columns to remove.
   */ removeColumn(physicalColumn, amount) {
        this.metas.remove(physicalColumn, amount);
    }
    /**
   * Gets settings object for this layer.
   *
   * @param {number} physicalColumn The physical column index.
   * @returns {object}
   */ getMeta(physicalColumn) {
        return this.metas.obtain(physicalColumn);
    }
    /**
   * Gets constructor of the column meta object. Necessary for inheritance - creating the next meta layers.
   *
   * @param {number} physicalColumn The physical column index.
   * @returns {Function}
   */ getMetaConstructor(physicalColumn) {
        return this.metas.obtain(physicalColumn).constructor;
    }
    /**
   * Clears all saved column meta objects.
   */ clearCache() {
        this.metas.clear();
    }
    /**
   * Creates and returns new column meta object with properties inherited from the global meta layer.
   *
   * @private
   * @returns {object}
   */ _createMeta() {
        const factory = (0, _utils.columnFactory)(this.globalMeta.getMetaConstructor(), COLUMNS_PROPS_CONFLICTS);
        return factory.prototype;
    }
    /**
   * Initializes the column meta layer with a reference to the GlobalMeta layer and sets up the lazy map for per-column meta objects.
   */ constructor(globalMeta){
        /**
   * The LazyFactoryMap structure, holder for column meta objects where each column meta is
   * stored under the physical column index.
   *
   * @type {LazyFactoryMap}
   */ this.metas = new _lazyFactoryMap.default(()=>this._createMeta());
        this.globalMeta = globalMeta;
        this.metas = new _lazyFactoryMap.default(()=>this._createMeta());
    }
}
