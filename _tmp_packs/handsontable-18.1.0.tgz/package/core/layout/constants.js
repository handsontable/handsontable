/**
 * Names of the user-orderable wrapper layout slots. Every slot listed here is orderable through the
 * `layout` setting; add new edge slots (for example `start`/`end`) here to introduce them.
 *
 * The overlays layer (`ht-overlay`) is intentionally not a slot — it renders like the grid: a fixed
 * internal element, always present and not orderable.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get LAYOUT_SLOTS () {
        return LAYOUT_SLOTS;
    },
    get SLOT_ITEM_CLASS () {
        return SLOT_ITEM_CLASS;
    },
    get getSlotFilledClassName () {
        return getSlotFilledClassName;
    }
});
const LAYOUT_SLOTS = {
    TOP: 'top',
    BOTTOM: 'bottom'
};
const SLOT_ITEM_CLASS = 'ht-slot-element';
function getSlotFilledClassName(name) {
    return `ht-slot-${name}-filled`;
}
