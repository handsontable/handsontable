"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DomSlot", {
    enumerable: true,
    get: function() {
        return DomSlot;
    }
});
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var _parent = /*#__PURE__*/ new WeakMap(), /**
   * The registered children keyed by their identifier.
   *
   * @type {Map<string, SlotEntry>}
   */ _entries = /*#__PURE__*/ new WeakMap(), /**
   * Monotonic counter used as a stable tie-breaker for equal weights.
   *
   * @type {number}
   */ _seq = /*#__PURE__*/ new WeakMap(), /**
   * The user-configured key order applied before weight ordering.
   *
   * @type {string[]}
   */ _order = /*#__PURE__*/ new WeakMap(), _itemClass = /*#__PURE__*/ new WeakMap(), _onContentChange = /*#__PURE__*/ new WeakMap(), /**
   * Returns the registered keys sorted by configured order, then weight, then registration order.
   *
   * @returns {string[]} The sorted keys.
   */ _sortedKeys = /*#__PURE__*/ new WeakSet(), /**
   * Reconciles the registered elements into the container in resolved order. Only elements that are
   * not already at their target position are moved. Reordering an already-ordered slot performs no
   * DOM moves, which avoids needless reflow and -- because moving a node that holds
   * `document.activeElement` fires a blur -- avoids silently dropping keyboard focus on re-renders.
   *
   * @returns {void}
   */ _reorder = /*#__PURE__*/ new WeakSet();
class DomSlot {
    /**
   * Returns the slot container element.
   *
   * @returns {HTMLElement} The container element.
   */ getElement() {
        return _class_private_field_get(this, _parent);
    }
    /**
   * Checks whether a key is registered.
   *
   * @param {string} key The registration key.
   * @returns {boolean} `true` when the key is registered.
   */ has(key) {
        return _class_private_field_get(this, _entries).has(key);
    }
    /**
   * Registers (or replaces) an element under a key and re-applies the slot order.
   *
   * @param {string} key The registration key.
   * @param {HTMLElement} element The element to insert.
   * @param {number} [weight=0] The ordering weight (lower comes first).
   * @returns {void}
   */ add(key, element, weight = 0) {
        const existing = _class_private_field_get(this, _entries).get(key);
        const seq = existing ? existing.seq : _class_private_field_get(this, _seq);
        if (existing) {
            existing.element.remove();
        }
        if (_class_private_field_get(this, _itemClass)) {
            element.classList.add(_class_private_field_get(this, _itemClass));
        }
        _class_private_field_get(this, _entries).set(key, {
            element,
            weight,
            seq
        });
        if (!existing) {
            _class_private_field_set(this, _seq, _class_private_field_get(this, _seq) + 1);
        }
        _class_private_method_get(this, _reorder, reorder).call(this);
        _class_private_field_get(this, _onContentChange).call(this);
    }
    /**
   * Unregisters a key and detaches its element from the DOM.
   *
   * @param {string} key The registration key.
   * @returns {void}
   */ remove(key) {
        const entry = _class_private_field_get(this, _entries).get(key);
        if (!entry) {
            return;
        }
        if (_class_private_field_get(this, _itemClass)) {
            entry.element.classList.remove(_class_private_field_get(this, _itemClass));
        }
        entry.element.remove();
        _class_private_field_get(this, _entries).delete(key);
        _class_private_field_get(this, _onContentChange).call(this);
    }
    /**
   * Sets the user-configured key order and re-applies it.
   *
   * @param {string[]} order The ordered list of keys.
   * @returns {void}
   */ setOrder(order) {
        // The `layout` setting is user-provided JS, so tolerate a malformed (non-array) value.
        _class_private_field_set(this, _order, Array.isArray(order) ? order.slice() : []);
        _class_private_method_get(this, _reorder, reorder).call(this);
    }
    /**
   * Returns the current resolved key order.
   *
   * @returns {string[]} The ordered keys.
   */ getOrder() {
        return _class_private_method_get(this, _sortedKeys, sortedKeys).call(this);
    }
    /**
   * Removes all registered elements and clears the registry.
   *
   * @returns {void}
   */ clear() {
        _class_private_field_get(this, _entries).forEach((entry)=>entry.element.remove());
        _class_private_field_get(this, _entries).clear();
        _class_private_field_get(this, _onContentChange).call(this);
    }
    /**
   * @param {HTMLElement} parent The slot container element.
   * @param {object} [options] Slot options.
   * @param {string} [options.itemClass=''] Class added to every registered element.
   * @param {Function} [options.onContentChange] Called after any registered-content mutation.
   */ constructor(parent, { itemClass = '', onContentChange = ()=>{} } = {}){
        _class_private_method_init(this, _sortedKeys);
        _class_private_method_init(this, _reorder);
        /**
   * The slot container element that registered children are appended to.
   *
   * @type {HTMLElement}
   */ _class_private_field_init(this, _parent, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _entries, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _seq, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _order, {
            writable: true,
            value: void 0
        });
        /**
   * Optional class added to every registered element (used to mark slot items for styling).
   *
   * @type {string}
   */ _class_private_field_init(this, _itemClass, {
            writable: true,
            value: void 0
        });
        /**
   * Optional callback fired after any registered-content mutation (add, remove, clear), so the
   * owner can derive slot-dependent state from the resulting DOM.
   *
   * @type {Function}
   */ _class_private_field_init(this, _onContentChange, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _entries, new Map());
        _class_private_field_set(this, _seq, 0);
        _class_private_field_set(this, _order, []);
        _class_private_field_set(this, _parent, parent);
        _class_private_field_set(this, _itemClass, itemClass);
        _class_private_field_set(this, _onContentChange, onContentChange);
    }
}
function sortedKeys() {
    const order = _class_private_field_get(this, _order);
    return Array.from(_class_private_field_get(this, _entries).keys()).sort((a, b)=>{
        const ai = order.indexOf(a);
        const bi = order.indexOf(b);
        if (ai !== -1 || bi !== -1) {
            return (ai === -1 ? Infinity : ai) - (bi === -1 ? Infinity : bi);
        }
        const ea = _class_private_field_get(this, _entries).get(a);
        const eb = _class_private_field_get(this, _entries).get(b);
        return ea.weight !== eb.weight ? ea.weight - eb.weight : ea.seq - eb.seq;
    });
}
function reorder() {
    let ref = _class_private_field_get(this, _parent).firstChild;
    _class_private_method_get(this, _sortedKeys, sortedKeys).call(this).forEach((key)=>{
        const element = _class_private_field_get(this, _entries).get(key).element;
        if (element === ref) {
            // Already in place; advance past it without touching the DOM.
            ref = ref.nextSibling;
        } else {
            // Out of place; move it before the current reference node (or to the end when `ref` is null).
            _class_private_field_get(this, _parent).insertBefore(element, ref);
        }
    });
}
