"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HooksBucket", {
    enumerable: true,
    get: function() {
        return HooksBucket;
    }
});
const _constants = require("./constants");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var /**
   * A map that stores the per-hook linked lists.
   */ _hooks = /*#__PURE__*/ new WeakMap(), /**
   * Inserts an entry keeping the list sorted by ascending `orderIndex`. Entries with an equal `orderIndex`
   * keep insertion order (stable). The common case (`orderIndex` 0, appended after equal entries) is an
   * O(1) tail append.
   *
   * @param {HookList} list The list to insert into.
   * @param {HookEntry} entry The entry to insert.
   */ _insertByOrder = /*#__PURE__*/ new WeakSet(), /**
   * Creates an initial (empty) collection for the provided hook name.
   *
   * @param {string} hookName The name of the hook.
   * @returns {HookList}
   */ _createHooksCollection = /*#__PURE__*/ new WeakSet();
class HooksBucket {
    /**
   * Gets the internal linked list for the provided hook name. Used by the dispatcher (`Hooks#runHandlers`)
   * to walk entries without materializing an array on the hot path.
   *
   * @param {string} hookName The name of the hook.
   * @returns {HookList|null}
   */ getList(hookName) {
        return _class_private_field_get(this, _hooks).get(hookName) ?? null;
    }
    /**
   * Gets all live hooks for the provided hook name as an array, in execution order. The returned entries are
   * the live list nodes (not copies), so an in-place `addAsFixed` callback swap is reflected in a
   * previously returned array — relied on by the framework wrappers.
   *
   * @param {string} hookName The name of the hook.
   * @returns {HookEntry[]}
   */ getHooks(hookName) {
        const list = _class_private_field_get(this, _hooks).get(hookName);
        const result = [];
        if (list) {
            let node = list.head;
            while(node){
                result.push(node);
                node = node.next;
            }
        }
        return result;
    }
    /**
   * Adds a new hook to the collection.
   *
   * @param {string} hookName The name of the hook.
   * @param {Function} callback The callback function to add.
   * @param {{ orderIndex?: number, runOnce?: boolean, initialHook?: boolean }} options The options object.
   */ add(hookName, callback, options = {}) {
        let list = _class_private_field_get(this, _hooks).get(hookName);
        if (!list) {
            list = _class_private_method_get(this, _createHooksCollection, createHooksCollection).call(this, hookName);
            _constants.REGISTERED_HOOKS.push(hookName);
        }
        // Adding the same callback twice is silently ignored. With true-delete a match is always a live entry.
        for(let node = list.head; node !== null; node = node.next){
            if (node.callback === callback) {
                return;
            }
        }
        const orderIndex = Number.isInteger(options.orderIndex) ? options.orderIndex ?? 0 : 0;
        const runOnce = !!options.runOnce;
        const initialHook = !!options.initialHook;
        if (initialHook) {
            // Replace the callback of the existing initial hook IN PLACE — keeps the entry object and its
            // position, so an array previously returned by getHooks() reflects the swap (wrapper contract).
            for(let node = list.head; node !== null; node = node.next){
                if (node.initialHook) {
                    node.callback = callback;
                    return;
                }
            }
        }
        _class_private_method_get(this, _insertByOrder, insertByOrder).call(this, list, {
            callback,
            orderIndex,
            runOnce,
            initialHook,
            next: null
        });
    }
    /**
   * Checks if there are any live hooks for the provided hook name.
   *
   * @param {string} hookName The name of the hook.
   * @returns {boolean}
   */ has(hookName) {
        const list = _class_private_field_get(this, _hooks).get(hookName);
        return !!list && list.head !== null;
    }
    /**
   * Removes a hook from the collection (true delete). Returns `true` if the callback was found and removed,
   * `false` otherwise.
   *
   * @param {string} hookName The name of the hook.
   * @param {*} callback The callback function to remove.
   * @returns {boolean}
   */ remove(hookName, callback) {
        const list = _class_private_field_get(this, _hooks).get(hookName);
        if (!list) {
            return false;
        }
        let prev = null;
        let node = list.head;
        while(node !== null){
            if (node.callback === callback) {
                if (prev) {
                    prev.next = node.next;
                } else {
                    list.head = node.next;
                }
                if (node === list.tail) {
                    list.tail = prev;
                }
                // Intentionally do NOT null `node.next`: an in-flight run() may hold this node and needs to advance.
                return true;
            }
            prev = node;
            node = node.next;
        }
        return false;
    }
    /**
   * Destroys the bucket.
   */ destroy() {
        _class_private_field_get(this, _hooks).clear();
    }
    /**
   * Initializes the bucket and pre-creates empty hook collections for all currently registered hook names.
   */ constructor(){
        _class_private_method_init(this, _insertByOrder);
        _class_private_method_init(this, _createHooksCollection);
        _class_private_field_init(this, _hooks, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _hooks, new Map());
        _constants.REGISTERED_HOOKS.forEach((hookName)=>_class_private_method_get(this, _createHooksCollection, createHooksCollection).call(this, hookName));
    }
}
function insertByOrder(list, entry) {
    if (list.head === null) {
        list.head = entry;
        list.tail = entry;
        return;
    }
    if (entry.orderIndex >= list.tail.orderIndex) {
        list.tail.next = entry;
        list.tail = entry;
        return;
    }
    let prev = null;
    let node = list.head;
    while(node !== null && node.orderIndex <= entry.orderIndex){
        prev = node;
        node = node.next;
    }
    if (prev === null) {
        entry.next = list.head;
        list.head = entry;
    } else {
        entry.next = node;
        prev.next = entry;
    }
}
function createHooksCollection(hookName) {
    const list = {
        head: null,
        tail: null
    };
    _class_private_field_get(this, _hooks).set(hookName, list);
    return list;
}
