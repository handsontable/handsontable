"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createViewportScroller", {
    enumerable: true,
    get: function() {
        return createViewportScroller;
    }
});
const _columnHeaderScroll = require("./scrollStrategies/columnHeaderScroll");
const _cornerHeaderScroll = require("./scrollStrategies/cornerHeaderScroll");
const _focusScroll = require("./scrollStrategies/focusScroll");
const _multipleScroll = require("./scrollStrategies/multipleScroll");
const _noncontiguousScroll = require("./scrollStrategies/noncontiguousScroll");
const _rowHeaderScroll = require("./scrollStrategies/rowHeaderScroll");
const _singleScroll = require("./scrollStrategies/singleScroll");
function createViewportScroller(hot) {
    const { selection } = hot;
    let skipNextCall = false;
    let isSuspended = false;
    return {
        resume () {
            isSuspended = false;
        },
        suspend () {
            isSuspended = true;
        },
        skipNextScrollCycle () {
            skipNextCall = true;
        },
        scrollTo (cellCoords) {
            if (skipNextCall || isSuspended) {
                skipNextCall = false;
                return;
            }
            let scrollStrategy;
            if (selection.isFocusSelectionChanged()) {
                scrollStrategy = (0, _focusScroll.focusScrollStrategy)(hot);
            } else if (selection.isSelectedByCorner()) {
                scrollStrategy = (0, _cornerHeaderScroll.cornerHeaderScrollStrategy)(hot);
            } else if (selection.isSelectedByRowHeader()) {
                scrollStrategy = (0, _rowHeaderScroll.rowHeaderScrollStrategy)(hot);
            } else if (selection.isSelectedByColumnHeader()) {
                scrollStrategy = (0, _columnHeaderScroll.columnHeaderScrollStrategy)(hot);
            } else if (selection.getSelectedRange().size() === 1 && selection.isMultiple()) {
                scrollStrategy = (0, _multipleScroll.multipleScrollStrategy)(hot);
            } else if (selection.getSelectedRange().size() === 1 && !selection.isMultiple()) {
                scrollStrategy = (0, _singleScroll.singleScrollStrategy)(hot);
            } else if (selection.getSelectedRange().size() > 1) {
                scrollStrategy = (0, _noncontiguousScroll.noncontiguousScrollStrategy)(hot);
            }
            scrollStrategy?.(cellCoords);
        }
    };
}
