"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "focusScrollStrategy", {
    enumerable: true,
    get: function() {
        return focusScrollStrategy;
    }
});
const _utils = require("../utils");
function focusScrollStrategy(hot) {
    return (cellCoords)=>{
        hot.scrollViewportTo(cellCoords.toObject(), ()=>{
            const activeRange = hot.getSelectedRangeActive();
            if (!activeRange) {
                return;
            }
            const { row, col } = activeRange.highlight;
            if (row !== null && col !== null) {
                (0, _utils.scrollWindowToCell)(hot.getCell(row, col, true));
            }
        });
    };
}
