"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "columnHeaderScrollStrategy", {
    enumerable: true,
    get: function() {
        return columnHeaderScrollStrategy;
    }
});
const _utils = require("../utils");
function columnHeaderScrollStrategy(hot) {
    return (cellCoords)=>{
        const scrollColumnTarget = (0, _utils.createScrollTargetCalculator)(hot).getComputedColumnTarget(cellCoords);
        hot.scrollViewportTo({
            col: scrollColumnTarget
        }, ()=>{
            const hasColumnHeaders = !!hot.getSettings().colHeaders;
            (0, _utils.scrollWindowToCell)(hot.getCell(hasColumnHeaders ? -1 : 0, scrollColumnTarget, true));
        });
    };
}
