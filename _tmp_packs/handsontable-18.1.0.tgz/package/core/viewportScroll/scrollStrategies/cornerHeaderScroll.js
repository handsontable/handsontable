/**
 * Scroll strategy for corner header selection.
 *
 * @returns {function(): function(CellCoords): void}
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "cornerHeaderScrollStrategy", {
    enumerable: true,
    get: function() {
        return cornerHeaderScrollStrategy;
    }
});
function cornerHeaderScrollStrategy(_hot) {
    return ()=>{
    // do not scroll the viewport when the corner is clicked
    };
}
