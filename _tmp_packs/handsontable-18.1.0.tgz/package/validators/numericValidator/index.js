"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get VALIDATOR_TYPE () {
        return _numericValidator.VALIDATOR_TYPE;
    },
    get numericValidator () {
        return _numericValidator.numericValidator;
    }
});
const _numericValidator = require("./numericValidator");
