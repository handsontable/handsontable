"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AUTOCOMPLETE_VALIDATOR () {
        return _autocompleteValidator.VALIDATOR_TYPE;
    },
    get DATE_VALIDATOR () {
        return _dateValidator.VALIDATOR_TYPE;
    },
    get DROPDOWN_VALIDATOR () {
        return _dropdownValidator.VALIDATOR_TYPE;
    },
    get INTL_DATETIME_VALIDATOR () {
        return _intlDatetimeValidator.VALIDATOR_TYPE;
    },
    get INTL_DATE_VALIDATOR () {
        return _intlDateValidator.VALIDATOR_TYPE;
    },
    get INTL_TIME_VALIDATOR () {
        return _intlTimeValidator.VALIDATOR_TYPE;
    },
    get MULTISELECT_VALIDATOR () {
        return _multiSelectValidator.VALIDATOR_TYPE;
    },
    get NUMERIC_VALIDATOR () {
        return _numericValidator.VALIDATOR_TYPE;
    },
    get TIME_VALIDATOR () {
        return _timeValidator.VALIDATOR_TYPE;
    },
    get autocompleteValidator () {
        return _autocompleteValidator.autocompleteValidator;
    },
    get dateValidator () {
        return _dateValidator.dateValidator;
    },
    get dropdownValidator () {
        return _dropdownValidator.dropdownValidator;
    },
    get getRegisteredValidatorNames () {
        return _registry.getRegisteredValidatorNames;
    },
    get getRegisteredValidators () {
        return _registry.getRegisteredValidators;
    },
    get getValidator () {
        return _registry.getValidator;
    },
    get hasValidator () {
        return _registry.hasValidator;
    },
    get intlDateValidator () {
        return _intlDateValidator.intlDateValidator;
    },
    get intlDatetimeValidator () {
        return _intlDatetimeValidator.intlDatetimeValidator;
    },
    get intlTimeValidator () {
        return _intlTimeValidator.intlTimeValidator;
    },
    get multiSelectValidator () {
        return _multiSelectValidator.multiSelectValidator;
    },
    get numericValidator () {
        return _numericValidator.numericValidator;
    },
    get registerAllValidators () {
        return registerAllValidators;
    },
    get registerValidator () {
        return _registry.registerValidator;
    },
    get timeValidator () {
        return _timeValidator.timeValidator;
    }
});
const _autocompleteValidator = require("./autocompleteValidator");
const _dateValidator = require("./dateValidator");
const _dropdownValidator = require("./dropdownValidator");
const _intlDateValidator = require("./intlDateValidator");
const _intlDatetimeValidator = require("./intlDatetimeValidator");
const _intlTimeValidator = require("./intlTimeValidator");
const _multiSelectValidator = require("./multiSelectValidator");
const _numericValidator = require("./numericValidator");
const _timeValidator = require("./timeValidator");
const _registry = require("./registry");
function registerAllValidators() {
    (0, _registry.registerValidator)(_autocompleteValidator.autocompleteValidator);
    (0, _registry.registerValidator)(_dropdownValidator.dropdownValidator);
    (0, _registry.registerValidator)(_dateValidator.dateValidator);
    (0, _registry.registerValidator)(_intlDateValidator.intlDateValidator);
    (0, _registry.registerValidator)(_intlDatetimeValidator.intlDatetimeValidator);
    (0, _registry.registerValidator)(_intlTimeValidator.intlTimeValidator);
    (0, _registry.registerValidator)(_multiSelectValidator.multiSelectValidator);
    (0, _registry.registerValidator)(_numericValidator.numericValidator);
    (0, _registry.registerValidator)(_timeValidator.timeValidator);
}
