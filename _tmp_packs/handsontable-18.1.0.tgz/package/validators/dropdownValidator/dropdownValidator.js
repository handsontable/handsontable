"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get VALIDATOR_TYPE () {
        return VALIDATOR_TYPE;
    },
    get dropdownValidator () {
        return dropdownValidator;
    }
});
const _autocompleteValidator = require("../autocompleteValidator/autocompleteValidator");
const VALIDATOR_TYPE = 'dropdown';
function dropdownValidator(value, callback) {
    _autocompleteValidator.autocompleteValidator.apply(this, [
        value,
        callback
    ]);
}
dropdownValidator.VALIDATOR_TYPE = VALIDATOR_TYPE;
