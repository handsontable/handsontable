"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get VALIDATOR_TYPE () {
        return VALIDATOR_TYPE;
    },
    get autocompleteValidator () {
        return autocompleteValidator;
    }
});
const _object = require("../../helpers/object");
const _mixed = require("../../helpers/mixed");
const VALIDATOR_TYPE = 'autocomplete';
function autocompleteValidator(value, callback) {
    const isKeyValueObject = (obj)=>{
        const rec = obj;
        return (0, _object.isObject)(obj) && (0, _mixed.isDefined)(rec.key) && (0, _mixed.isDefined)(rec.value);
    };
    const isNullOrUndefined = (val)=>{
        if (isKeyValueObject(val)) {
            const rec = val;
            return isNullOrUndefined(rec.key) && isNullOrUndefined(rec.value);
        }
        return val === null || val === undefined;
    };
    let valueToValidate = value;
    if (isNullOrUndefined(valueToValidate)) {
        valueToValidate = '';
    }
    if (valueToValidate === '') {
        callback(!!this.allowEmpty);
        return;
    }
    if (this.strict && this.source) {
        if (typeof this.source === 'function') {
            // The `source` option declares its query parameter as `string`; the validator forwards the
            // raw cell value unchanged (a number stays a number), matching the long-standing runtime
            // behavior, so the value is cast rather than coerced.
            this.source(valueToValidate, process(valueToValidate, callback));
        } else {
            process(valueToValidate, callback)(this.source);
        }
    } else {
        callback(true);
    }
}
autocompleteValidator.VALIDATOR_TYPE = VALIDATOR_TYPE;
/**
 * Function responsible for validation of autocomplete value.
 *
 * @param {*} value Value of edited cell.
 * @param {Function} callback Callback called with validation result.
 * @returns {Function}
 */ function process(value, callback) {
    const originalVal = value;
    return function(source) {
        let found = false;
        for(let s = 0, slen = source.length; s < slen; s++){
            if ((0, _object.isObjectEqual)(originalVal, source[s])) {
                found = true; // perfect match
                break;
            }
        }
        callback(found);
    };
}
