"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get SOURCE_DATA_WARNING_MESSAGE () {
        return SOURCE_DATA_WARNING_MESSAGE;
    },
    get VALIDATOR_TYPE () {
        return VALIDATOR_TYPE;
    },
    get dateValidator () {
        return dateValidator;
    },
    get sourceDataValidator () {
        return sourceDataValidator;
    }
});
const _dateTime = require("../../helpers/dateTime");
const _mixed = require("../../helpers/mixed");
const VALIDATOR_TYPE = 'date';
const SOURCE_DATA_WARNING_MESSAGE = 'Source data warning ([itemsCount]). ' + 'Invalid value for "date" cell type.\n\n' + '[affectedCells]\n\n' + 'Expected a value compatible with the ISO 8601 date format ("YYYY-MM-DD").';
function sourceDataValidator(value, cellMeta) {
    if (cellMeta.allowEmpty && (0, _mixed.isEmpty)(value)) {
        return true;
    }
    // Formula expressions are handled by the Formulas plugin — skip source-data validation for them.
    if (typeof value === 'string' && value.startsWith('=')) {
        return true;
    }
    return (0, _dateTime.isValidISODate)(value);
}
// Marks the validator as row-independent: its result depends only on the value and column/global-level
// meta (`allowEmpty`), never on per-row meta. This lets the source-data validation runner reuse one
// column-level meta object across all rows instead of materializing a meta object per cell.
sourceDataValidator.rowIndependent = true;
function dateValidator(value, callback) {
    if (this.allowEmpty && (0, _mixed.isEmpty)(value)) {
        callback(true);
        return;
    }
    callback((0, _dateTime.isValidISODate)(value));
}
dateValidator.VALIDATOR_TYPE = VALIDATOR_TYPE;
