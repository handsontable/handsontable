"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get SOURCE_DATA_WARNING_MESSAGE () {
        return _timeValidator.SOURCE_DATA_WARNING_MESSAGE;
    },
    get VALIDATOR_TYPE () {
        return _timeValidator.VALIDATOR_TYPE;
    },
    get sourceDataValidator () {
        return _timeValidator.sourceDataValidator;
    },
    get timeValidator () {
        return _timeValidator.timeValidator;
    }
});
const _timeValidator = require("./timeValidator");
