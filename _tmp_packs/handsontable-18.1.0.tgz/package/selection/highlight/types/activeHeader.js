"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createHighlight", {
    enumerable: true,
    get: function() {
        return createHighlight;
    }
});
const _src = require("../../../3rdparty/walkontable/src");
const _visualSelection = /*#__PURE__*/ _interop_require_default(require("../visualSelection"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function createHighlight({ activeHeaderClassName, ...restOptions }) {
    return new _visualSelection.default({
        className: activeHeaderClassName,
        ...restOptions,
        selectionType: _src.HIGHLIGHT_ACTIVE_HEADER_TYPE
    });
}
