"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Selection () {
        return _selection.default;
    },
    get detectSelectionType () {
        return _utils.detectSelectionType;
    },
    get handleMouseEvent () {
        return _mouseEventHandler.handleMouseEvent;
    },
    get normalizeSelectionFactory () {
        return _utils.normalizeSelectionFactory;
    }
});
const _selection = /*#__PURE__*/ _interop_require_default(require("./selection"));
const _mouseEventHandler = require("./mouseEventHandler");
const _utils = require("./utils");
_export_star(require("./highlight/highlight"), exports);
function _export_star(from, to) {
    Object.keys(from).forEach(function(k) {
        if (k !== "default" && !Object.prototype.hasOwnProperty.call(to, k)) {
            Object.defineProperty(to, k, {
                enumerable: true,
                get: function() {
                    return from[k];
                }
            });
        }
    });
    return from;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
