"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "FocusTransformation", {
    enumerable: true,
    get: function() {
        return FocusTransformation;
    }
});
const _base = require("./_base");
const _errors = require("../../helpers/errors");
class FocusTransformation extends _base.BaseTransformation {
    /**
   * Calculates offset coordinates for focus selection based on the current selection state.
   * For header focus selection, calculates offset including headers.
   * For cell focus selection, calculates offset only for selected cells.
   *
   * @returns {{x: number, y: number}}
   */ calculateOffset() {
        const range = this.getCurrentSelection();
        const { row, col } = range.getOuterTopStartCorner();
        const rowNum = row ?? 0;
        const colNum = col ?? 0;
        const columnsInRange = this.tableApi.countRenderableColumnsInRange(0, colNum - 1);
        const rowsInRange = this.tableApi.countRenderableRowsInRange(0, rowNum - 1);
        const isHeaderSelection = range.highlight.isHeader();
        const headerX = isHeaderSelection ? Math.abs(colNum) : 0;
        const headerY = isHeaderSelection ? Math.abs(rowNum) : 0;
        return {
            x: colNum < 0 ? headerX : -columnsInRange,
            y: rowNum < 0 ? headerY : -rowsInRange
        };
    }
    /**
   * Gets the count of renderable rows for focus transformation.
   * Focus transformation operates on the current selection range.
   *
   * @returns {number}
   */ countRenderableRows() {
        const range = this.getCurrentSelection();
        return this.tableApi.countRenderableRowsInRange(0, range.getOuterBottomEndCorner().row ?? 0);
    }
    /**
   * Gets the count of renderable columns for focus transformation.
   * Focus transformation operates on the current selection range.
   *
   * @returns {number}
   */ countRenderableColumns() {
        const range = this.getCurrentSelection();
        return this.tableApi.countRenderableColumnsInRange(0, range.getOuterBottomEndCorner().col ?? 0);
    }
    /**
   * Throws an error because focus transformation doesn't support `transformEnd`.
   */ transformEnd(_rowDelta, _colDelta) {
        (0, _errors.throwWithCause)('`transformEnd` is not valid for focus selection use `transformStart` instead');
    }
    /**
   * Changes the behavior of the transformation logic by switching the selection layer
   * when the selection is out of range.
   *
   * @returns {boolean}
   */ shouldSwitchSelectionLayer() {
        return true;
    }
}
