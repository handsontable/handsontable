"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ExtenderTransformation", {
    enumerable: true,
    get: function() {
        return ExtenderTransformation;
    }
});
const _base = require("./_base");
class ExtenderTransformation extends _base.BaseTransformation {
    /**
   * Calculates offset coordinates for extender selection.
   *
   * @returns {{x: number, y: number}}
   */ calculateOffset() {
        return {
            x: this.tableApi.navigableHeaders() ? this.tableApi.countRowHeaders() : 0,
            y: this.tableApi.navigableHeaders() ? this.tableApi.countColHeaders() : 0
        };
    }
    /**
   * Gets the count of renderable rows for extender transformation.
   * Extender transformation operates on the full table size.
   *
   * @returns {number}
   */ countRenderableRows() {
        return this.tableApi.countRenderableRows();
    }
    /**
   * Gets the count of renderable columns for extender transformation.
   * Extender transformation operates on the full table size.
   *
   * @returns {number}
   */ countRenderableColumns() {
        return this.tableApi.countRenderableColumns();
    }
    /**
   * Changes the behavior of the transformation logic by not switching the selection layer
   * when the selection is out of range.
   *
   * @returns {boolean}
   */ shouldSwitchSelectionLayer() {
        return false;
    }
}
