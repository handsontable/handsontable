"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ExtenderTransformation () {
        return _extender.ExtenderTransformation;
    },
    get FocusTransformation () {
        return _focus.FocusTransformation;
    }
});
const _extender = require("./extender");
const _focus = require("./focus");
