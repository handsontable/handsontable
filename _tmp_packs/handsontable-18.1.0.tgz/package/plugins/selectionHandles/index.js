"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get PLUGIN_KEY () {
        return _selectionHandles.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _selectionHandles.PLUGIN_PRIORITY;
    },
    get SelectionHandles () {
        return _selectionHandles.SelectionHandles;
    }
});
const _selectionHandles = require("./selectionHandles");
