/**
 * Represents the selection edge that the user drags.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "clampEdge", {
    enumerable: true,
    get: function() {
        return clampEdge;
    }
});
function clampEdge({ edge, target, oppositeIndex }) {
    const bounded = Math.max(0, target);
    return edge === 'top' || edge === 'start' ? Math.min(bounded, oppositeIndex) : Math.max(bounded, oppositeIndex);
}
