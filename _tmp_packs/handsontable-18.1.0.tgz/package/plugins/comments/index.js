"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Comments () {
        return _comments.Comments;
    },
    get PLUGIN_KEY () {
        return _comments.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _comments.PLUGIN_PRIORITY;
    }
});
const _comments = require("./comments");
