"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _function = require("../../helpers/function");
const _object = require("../../helpers/object");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../mixins/localHooks"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const DEFAULT_DISPLAY_DELAY = 250;
const DEFAULT_HIDE_DELAY = 250;
/**
 * Display switch for the Comments plugin. Manages the time of delayed displaying / hiding comments.
 *
 * @private
 * @class DisplaySwitch
 */ class DisplaySwitch {
    /**
   * Responsible for hiding comment after proper delay.
   */ hide() {
        this.wasLastActionShow = false;
        this.hidingTimer = setTimeout(()=>{
            if (this.wasLastActionShow === false) {
                this.runLocalHooks('hide');
            }
        }, DEFAULT_HIDE_DELAY);
    }
    /**
   * Responsible for showing comment after proper delay.
   *
   * @param {object} range Coordinates of selected cell.
   */ show(range) {
        this.wasLastActionShow = true;
        this.showDebounced?.(range);
    }
    /**
   * Cancel hiding comment.
   */ cancelHiding() {
        this.wasLastActionShow = true;
        clearTimeout(this.hidingTimer ?? undefined);
        this.hidingTimer = null;
    }
    /**
   * Update the switch settings.
   *
   * @param {number} displayDelay Delay of showing the comments (in milliseconds).
   */ updateDelay(displayDelay = DEFAULT_DISPLAY_DELAY) {
        this.showDebounced = (0, _function.debounce)((range)=>{
            if (this.wasLastActionShow) {
                const r = range;
                this.runLocalHooks('show', r.from.row, r.from.col);
            }
        }, displayDelay);
    }
    /**
   * Destroy the switcher.
   */ destroy() {
        this.clearLocalHooks();
    }
    /**
   * Initializes the display switch and configures the debounced show delay.
   */ constructor(displayDelay){
        /**
   * Flag to determine if comment can be showed or hidden. State `true` mean that last performed action
   * was an attempt to show comment element. State `false` mean that it was attempt to hide comment element.
   *
   * @type {boolean}
   */ this.wasLastActionShow = true;
        /**
   * Show comment after predefined delay. It keeps reference to immutable `debounce` function.
   *
   * @type {Function}
   */ this.showDebounced = null;
        /**
   * Reference to timer, run by `setTimeout`, which is hiding comment.
   *
   * @type {number}
   */ this.hidingTimer = null;
        this.updateDelay(displayDelay);
    }
}
(0, _object.mixin)(DisplaySwitch, _localHooks.default);
const _default = DisplaySwitch;
