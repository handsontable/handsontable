"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, /**
 * @param {Comments} plugin The Comments plugin instance.
 * @returns {object}
 */ "default", {
    enumerable: true,
    get: function() {
        return addEditCommentItem;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
function addEditCommentItem(plugin) {
    return {
        key: 'commentsAddEdit',
        name () {
            const highlight = this.getSelectedRangeActive()?.highlight;
            if (highlight?.isCell() && highlight.row !== null && highlight.col !== null && plugin.getCommentAtCell(highlight.row, highlight.col)) {
                return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_EDIT_COMMENT);
            }
            return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ADD_COMMENT);
        },
        callback () {
            const range = this.getSelectedRangeActive();
            if (range) {
                plugin.setRange({
                    from: range.from,
                    to: range.to
                });
            }
            plugin.show();
            plugin.focusEditor();
        },
        disabled () {
            const range = this.getSelectedRangeActive();
            if (!range || range.highlight.isHeader() || this.selection.isEntireRowSelected() && this.selection.isEntireColumnSelected() || this.countRenderedRows() === 0 || this.countRenderedCols() === 0) {
                return true;
            }
            return false;
        }
    };
}
