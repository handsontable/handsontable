"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "EditorResizeObserver", {
    enumerable: true,
    get: function() {
        return EditorResizeObserver;
    }
});
const _object = require("../../helpers/object");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../mixins/localHooks"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * The flag that indicates if the initial call should be ignored. It is used to prevent the initial call
   * that happens after the observer is attached to the element.
   *
   * @type {boolean}
   */ _ignoreInitialCall = /*#__PURE__*/ new WeakMap(), /**
   * The element that is observed by the observer.
   *
   * @type {HTMLElement}
   */ _observedElement = /*#__PURE__*/ new WeakMap(), /**
   * The ResizeObserver instance.
   *
   * @type {ResizeObserver}
   */ _observer = /*#__PURE__*/ new WeakMap(), /**
   * Listens for event from the ResizeObserver and forwards the through the local hooks.
   *
   * @param {*} entries The entries from the ResizeObserver.
   */ _onResize = /*#__PURE__*/ new WeakSet();
class EditorResizeObserver {
    /**
   * Sets the observed element.
   *
   * @param {HTMLElement} element The element to observe.
   */ setObservedElement(element) {
        _class_private_field_set(this, _observedElement, element);
    }
    /**
   * Stops observing the element.
   */ unobserve() {
        if (_class_private_field_get(this, _observedElement)) {
            _class_private_field_get(this, _observer).unobserve(_class_private_field_get(this, _observedElement));
        }
    }
    /**
   * Starts observing the element.
   */ observe() {
        _class_private_field_set(this, _ignoreInitialCall, true);
        if (_class_private_field_get(this, _observedElement)) {
            _class_private_field_get(this, _observer).observe(_class_private_field_get(this, _observedElement));
        }
    }
    /**
   * Destroys the observer.
   */ destroy() {
        _class_private_field_get(this, _observer).disconnect();
    }
    constructor(){
        _class_private_method_init(this, _onResize);
        _class_private_field_init(this, _ignoreInitialCall, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _observedElement, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _observer, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _ignoreInitialCall, true);
        _class_private_field_set(this, _observedElement, null);
        _class_private_field_set(this, _observer, new ResizeObserver((entries)=>_class_private_method_get(this, _onResize, onResize).call(this, entries)));
    }
}
function onResize(entries) {
    if (_class_private_field_get(this, _ignoreInitialCall) || !Array.isArray(entries) || !entries.length) {
        _class_private_field_set(this, _ignoreInitialCall, false);
        return;
    }
    entries.forEach(({ borderBoxSize })=>{
        const { inlineSize, blockSize } = borderBoxSize[0];
        this.runLocalHooks('resize', inlineSize, blockSize);
    });
}
(0, _object.mixin)(EditorResizeObserver, _localHooks.default);
