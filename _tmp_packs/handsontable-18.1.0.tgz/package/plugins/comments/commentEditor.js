"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _element = require("../../helpers/dom/element");
const _object = require("../../helpers/object");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../mixins/localHooks"));
const _editorResizeObserver = require("./editorResizeObserver");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * @type {Document}
   */ _rootDocument = /*#__PURE__*/ new WeakMap(), /**
   * @type {HTMLElement}
   */ _rootPortalElement = /*#__PURE__*/ new WeakMap(), /**
   * @type {boolean}
   */ _isRtl = /*#__PURE__*/ new WeakMap(), /**
   * @type {HTMLElement}
   */ _container = /*#__PURE__*/ new WeakMap(), /**
   * @type {HTMLElement | null}
   */ _editor = /*#__PURE__*/ new WeakMap(), /**
   * @type {CSSStyleDeclaration | null}
   */ _editorStyle = /*#__PURE__*/ new WeakMap(), /**
   * @type {boolean}
   */ _hidden = /*#__PURE__*/ new WeakMap(), /**
   * @type {EditorResizeObserver}
   */ _resizeObserver = /*#__PURE__*/ new WeakMap();
/**
 * Comment editor for the Comments plugin.
 *
 * @private
 * @class CommentEditor
 */ class CommentEditor {
    /**
   * Returns the CSS class name applied to the outer comments container element.
   */ static get CLASS_EDITOR_CONTAINER() {
        return 'htCommentsContainer';
    }
    /**
   * Returns the CSS class name applied to the comment editor element.
   */ static get CLASS_EDITOR() {
        return 'htComments';
    }
    /**
   * Returns the CSS class name applied to the comment textarea input element.
   */ static get CLASS_INPUT() {
        return 'htCommentTextArea';
    }
    /**
   * Returns the CSS class name applied to cells that have comments attached.
   */ static get CLASS_CELL() {
        return 'htCommentCell';
    }
    /**
   * Set position of the comments editor according to the  provided x and y coordinates.
   *
   * @param {number} x X position (in pixels).
   * @param {number} y Y position (in pixels).
   */ setPosition(x, y) {
        if (_class_private_field_get(this, _editorStyle)) {
            _class_private_field_get(this, _editorStyle).left = `${x}px`;
            _class_private_field_get(this, _editorStyle).top = `${y}px`;
        }
    }
    /**
   * Set the editor size according to the provided arguments.
   *
   * @param {number} width Width in pixels.
   * @param {number} height Height in pixels.
   */ setSize(width, height) {
        if (width && height) {
            const input = this.getInputElement();
            input.style.width = `${width}px`;
            input.style.height = `${height}px`;
        }
    }
    /**
   * Returns the size of the comments editor.
   *
   * @returns {{ width: number, height: number }}
   */ getSize() {
        return {
            width: (0, _element.outerWidth)(this.getInputElement()),
            height: (0, _element.outerHeight)(this.getInputElement())
        };
    }
    /**
   * Starts observing the editor size.
   */ observeSize() {
        _class_private_field_get(this, _resizeObserver).observe();
    }
    /**
   * Reset the editor size to its initial state.
   */ resetSize() {
        const input = this.getInputElement();
        input.style.width = '';
        input.style.height = '';
    }
    /**
   * Set the read-only state for the comments editor.
   *
   * @param {boolean} state The new read only state.
   */ setReadOnlyState(state) {
        const input = this.getInputElement();
        input.readOnly = state;
    }
    /**
   * Show the comments editor.
   */ show() {
        if (_class_private_field_get(this, _editorStyle)) {
            _class_private_field_get(this, _editorStyle).display = 'block';
        }
        _class_private_field_set(this, _hidden, false);
    }
    /**
   * Hide the comments editor.
   */ hide() {
        _class_private_field_get(this, _resizeObserver).unobserve();
        if (!_class_private_field_get(this, _hidden)) {
            if (_class_private_field_get(this, _editorStyle)) {
                _class_private_field_get(this, _editorStyle).display = 'none';
            }
        }
        _class_private_field_set(this, _hidden, true);
    }
    /**
   * Checks if the editor is visible.
   *
   * @returns {boolean}
   */ isVisible() {
        return _class_private_field_get(this, _editorStyle)?.display === 'block';
    }
    /**
   * Set the comment value.
   *
   * @param {string} [value] The value to use.
   */ setValue(value = '') {
        const comment = value || '';
        this.getInputElement().value = comment;
    }
    /**
   * Get the comment value.
   *
   * @returns {string}
   */ getValue() {
        return this.getInputElement().value;
    }
    /**
   * Checks if the comment input element is focused.
   *
   * @returns {boolean}
   */ isFocused() {
        return (0, _element.getDeepActiveElement)(_class_private_field_get(this, _rootDocument)) === this.getInputElement();
    }
    /**
   * Focus the comments input element.
   */ focus() {
        this.getInputElement().focus();
    }
    /**
   * Create the `textarea` to be used as a comments editor.
   *
   * @returns {HTMLElement}
   */ createEditor() {
        const editor = _class_private_field_get(this, _rootDocument).createElement('div');
        const textarea = _class_private_field_get(this, _rootDocument).createElement('textarea');
        editor.style.display = 'none';
        _class_private_field_set(this, _container, _class_private_field_get(this, _rootDocument).createElement('div'));
        _class_private_field_get(this, _container).setAttribute('dir', _class_private_field_get(this, _isRtl) ? 'rtl' : 'ltr');
        (0, _element.addClass)(_class_private_field_get(this, _container), CommentEditor.CLASS_EDITOR_CONTAINER);
        _class_private_field_get(this, _rootPortalElement).appendChild(_class_private_field_get(this, _container));
        (0, _element.addClass)(editor, CommentEditor.CLASS_EDITOR);
        (0, _element.addClass)(textarea, CommentEditor.CLASS_INPUT);
        textarea.dataset.hotInput = 'true';
        editor.appendChild(textarea);
        _class_private_field_get(this, _container).appendChild(editor);
        return editor;
    }
    /**
   * Get the input element.
   *
   * @returns {HTMLTextAreaElement | null}
   */ getInputElement() {
        return _class_private_field_get(this, _editor)?.querySelector(`.${CommentEditor.CLASS_INPUT}`) ?? null;
    }
    /**
   * Get the editor element.
   *
   * @returns {HTMLElement} The editor element.
   */ getEditorElement() {
        return _class_private_field_get(this, _editor);
    }
    /**
   * Destroy the comments editor.
   */ destroy() {
        const containerParentElement = _class_private_field_get(this, _container) ? _class_private_field_get(this, _container).parentNode : null;
        _class_private_field_get(this, _editor)?.parentNode?.removeChild(_class_private_field_get(this, _editor));
        _class_private_field_set(this, _editor, null);
        _class_private_field_set(this, _editorStyle, null);
        _class_private_field_get(this, _resizeObserver).destroy();
        if (containerParentElement && _class_private_field_get(this, _container)) {
            containerParentElement.removeChild(_class_private_field_get(this, _container));
        }
    }
    /**
   * Initializes the comment editor, builds its DOM structure, and attaches the resize observer.
   */ constructor(rootDocument, isRtl, rootPortalElement){
        _class_private_field_init(this, _rootDocument, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _rootPortalElement, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _isRtl, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _container, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _editor, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _editorStyle, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _hidden, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _resizeObserver, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _isRtl, false);
        _class_private_field_set(this, _container, null);
        _class_private_field_set(this, _editor, null);
        _class_private_field_set(this, _editorStyle, null);
        _class_private_field_set(this, _hidden, true);
        _class_private_field_set(this, _resizeObserver, new _editorResizeObserver.EditorResizeObserver());
        _class_private_field_set(this, _rootDocument, rootDocument);
        _class_private_field_set(this, _rootPortalElement, rootPortalElement);
        _class_private_field_set(this, _isRtl, isRtl);
        _class_private_field_set(this, _editor, this.createEditor());
        _class_private_field_set(this, _editorStyle, _class_private_field_get(this, _editor).style);
        _class_private_field_get(this, _resizeObserver).setObservedElement(this.getInputElement());
        _class_private_field_get(this, _resizeObserver).addLocalHook('resize', (...args)=>{
            this.runLocalHooks('resize', ...args);
        });
        this.hide();
    }
}
(0, _object.mixin)(CommentEditor, _localHooks.default);
const _default = CommentEditor;
