"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "expandNode", {
    enumerable: true,
    get: function() {
        return expandNode;
    }
});
const _array = require("../../../../helpers/array");
const _collapse = require("./collapse");
const _tree = require("./utils/tree");
function expandNode(nodeToProcess) {
    const { data: nodeData, childs: nodeChilds } = nodeToProcess;
    if (!nodeData.isCollapsed || nodeData.isHidden || nodeData.origColspan <= 1) {
        return {
            rollbackModification: ()=>{},
            affectedColumns: [],
            colspanCompensation: 0
        };
    }
    // Declarative groups (issue #10243) only flip `isCollapsed` back; the columns to show/hide are
    // re-derived from the `visibleWhen` markers and applied through the CollapsibleColumns hiding map.
    // Mirrors the declarative branch in collapseNode.
    if ((0, _tree.isDeclarativeGroup)(nodeToProcess)) {
        nodeData.isCollapsed = false;
        return {
            rollbackModification: ()=>(0, _collapse.collapseNode)(nodeToProcess),
            affectedColumns: [],
            colspanCompensation: 0
        };
    }
    const isNodeReflected = (0, _tree.isNodeReflectsFirstChildColspan)(nodeToProcess);
    if (isNodeReflected) {
        return expandNode(nodeChilds[0]);
    }
    nodeData.isCollapsed = false;
    // Restore exactly the children that this node's collapse hid - they are the ones carrying a
    // cloned tree. Mirrors the "first visible child" selection done in collapseNode, so children
    // hidden by an external source (or by their own collapse) are left untouched.
    const childsToRestore = nodeChilds.filter(({ data })=>data.clonedTree);
    const affectedColumns = new Set();
    let colspanCompensation = 0;
    if (childsToRestore.length > 0) {
        (0, _array.arrayEach)(childsToRestore, (treeNode)=>{
            // Restore original state of the collapsed headers. `replaceTreeWith` swaps in a fresh
            // `data` object, so read the restored colspan from `treeNode.data` *after* the replace -
            // the pre-replace reference still points at the (possibly hidden, colspan 0) old data.
            // `childsToRestore` is filtered to nodes that carry a cloned tree, so it is never null here.
            const clonedTree = treeNode.data.clonedTree;
            treeNode.replaceTreeWith(clonedTree);
            const leafData = treeNode.data;
            leafData.clonedTree = null;
            // Calculate by how many colspan it needs to increase the headings.
            colspanCompensation += leafData.colspan;
            // Release exactly the columns this child exposes, mirroring the claim in collapseNode. The
            // restored subtree carries its inner `isCollapsed` flags, so columns owned by a nested
            // collapse are left hidden while the ones this collapse owned (visible or externally hidden)
            // are handed back.
            (0, _tree.traverseExposedColumnIndexes)(treeNode, (gridColumnIndex)=>{
                affectedColumns.add(gridColumnIndex);
            });
        });
    } else if (nodeChilds.length === 0) {
        const { colspan, origColspan, columnIndex } = nodeData;
        // In a case when the node doesn't have any children restore the colspan width.
        colspanCompensation = origColspan - colspan;
        // Add column to "affected" started from 1.
        for(let i = 1; i < origColspan; i++){
            affectedColumns.add(columnIndex + i);
        }
    }
    nodeToProcess.walkUp((node)=>{
        const { data } = node;
        data.colspan += colspanCompensation;
        if (data.colspan >= data.origColspan) {
            data.colspan = data.origColspan;
            data.isCollapsed = false;
        } else if ((0, _tree.isNodeReflectsFirstChildColspan)(node)) {
            data.isCollapsed = (0, _tree.getFirstChildProperty)(node, 'isCollapsed');
        }
    });
    return {
        rollbackModification: ()=>(0, _collapse.collapseNode)(nodeToProcess),
        affectedColumns: Array.from(affectedColumns),
        colspanCompensation
    };
}
