"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "triggerNodeModification", {
    enumerable: true,
    get: function() {
        return triggerNodeModification;
    }
});
const _errors = require("../../../../helpers/errors");
const _collapse = require("./collapse");
const _expand = require("./expand");
const availableModifiers = new Map([
    [
        'collapse',
        _collapse.collapseNode
    ],
    [
        'expand',
        _expand.expandNode
    ]
]);
function triggerNodeModification(actionName, nodeToProcess, gridColumnIndex) {
    const modifier = availableModifiers.get(actionName);
    if (!modifier) {
        (0, _errors.throwWithCause)(`The node modifier action ("${actionName}") does not exist.`);
    }
    return modifier(nodeToProcess, gridColumnIndex);
}
