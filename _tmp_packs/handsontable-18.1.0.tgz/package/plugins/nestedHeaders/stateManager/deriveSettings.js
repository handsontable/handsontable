"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get computeOwnerIndex () {
        return computeOwnerIndex;
    },
    get deriveVisualSettings () {
        return deriveVisualSettings;
    },
    get resolveOwnerKey () {
        return resolveOwnerKey;
    }
});
const _utils = require("./utils");
function computeOwnerIndex(layer) {
    const owners = [];
    let index = 0;
    while(index < layer.length){
        const cell = layer[index];
        const span = cell.isPlaceholder ? 1 : Math.max(1, cell.origColspan ?? 1);
        for(let offset = 0; offset < span; offset++){
            owners[index + offset] = index;
        }
        index += span;
    }
    return owners;
}
function resolveOwnerKey(physical, ownerIndex, override) {
    if (override !== undefined) {
        return override >= 0 ? override : -1 - physical;
    }
    const owner = ownerIndex[physical];
    return owner === undefined ? -1 - physical : owner;
}
/**
 * Clones an authored owner cell into a visual-order header cell of the given run width.
 *
 * Array-valued fields are copied so that two banners derived from one authored group (after a split)
 * never share a mutable array with each other or with the authored source.
 *
 * @param {SourceHeaderCell} ownerCell - The authored cell that owns the run.
 * @param {number} runLength - The number of visually adjacent columns the run covers.
 * @param {number} authoredColumnIndex - The authored owner column index (stable group identity).
 * @returns {SourceHeaderCell} The cloned visual-order header cell.
 */ function cloneOwnerCell(ownerCell, runLength, authoredColumnIndex) {
    const cell = {
        ...ownerCell,
        colspan: runLength,
        origColspan: runLength,
        isPlaceholder: false,
        // Stable identity of the authored group this run came from. Survives column moves (the authored
        // settings do not change on a move), so collapse state can be re-attached by it after a re-derive.
        authoredColumnIndex
    };
    // Copy the array-valued fields so two banners derived from one authored group (after a split) never
    // share a mutable array with each other or with the source. SourceHeaderCell types these fields, so
    // `Array.isArray` narrows them precisely and the copy needs no cast.
    if (Array.isArray(cell.headerClassNames)) {
        cell.headerClassNames = cell.headerClassNames.slice();
    }
    if (Array.isArray(cell.crossHiddenColumns)) {
        cell.crossHiddenColumns = cell.crossHiddenColumns.slice();
    }
    return cell;
}
/**
 * Derives one visual-order header layer from an authored (physical-order) layer and an arrangement.
 *
 * Columns are visited in their current visual order; each maps through the arrangement to a physical
 * column whose authored owner identifies its group. Maximal runs of visually adjacent columns that
 * share the same owner are coalesced into a single header cell (with placeholders for the rest of the
 * span). A group split apart by a move therefore renders as several cells sharing the same label.
 *
 * @param {SourceHeaderCell[]} authoredLayer - One normalized header layer in authored order.
 * @param {ColumnArrangement} arrangement - The current visual-to-physical column arrangement.
 * @param {number} columnsCount - The number of visual columns the structure spans (authored width).
 * @param {number} headerLevel - The level (row) of this layer, used to look up membership overrides.
 * @param {MembershipOverrides} [membershipOverrides] - Per-column re-parenting from column moves.
 * @returns {SourceHeaderCell[]} The header layer in visual order.
 */ function deriveVisualLayer(authoredLayer, arrangement, columnsCount, headerLevel, membershipOverrides) {
    const ownerIndex = computeOwnerIndex(authoredLayer);
    // Resolves the group key for a visual column. See resolveOwnerKey for the override/standalone rules.
    const ownerKeyAt = (visualColumn)=>{
        const physical = arrangement.getPhysicalFromVisual(visualColumn);
        return resolveOwnerKey(physical, ownerIndex, membershipOverrides?.get(physical)?.get(headerLevel));
    };
    const visualLayer = [];
    let visualColumn = 0;
    while(visualColumn < columnsCount){
        const ownerKey = ownerKeyAt(visualColumn);
        let runLength = 1;
        while(visualColumn + runLength < columnsCount && ownerKeyAt(visualColumn + runLength) === ownerKey){
            runLength += 1;
        }
        const ownerCell = ownerKey >= 0 ? authoredLayer[ownerKey] : (0, _utils.createDefaultHeaderSettings)();
        visualLayer.push(cloneOwnerCell(ownerCell, runLength, ownerKey));
        for(let offset = 1; offset < runLength; offset++){
            visualLayer.push((0, _utils.createPlaceholderHeaderSettings)());
        }
        visualColumn += runLength;
    }
    return visualLayer;
}
function deriveVisualSettings(authoredSettings, arrangement, membershipOverrides) {
    const columnsCount = authoredSettings.length > 0 ? authoredSettings[0].length : 0;
    return authoredSettings.map((authoredLayer, headerLevel)=>deriveVisualLayer(authoredLayer, arrangement, columnsCount, headerLevel, membershipOverrides));
}
