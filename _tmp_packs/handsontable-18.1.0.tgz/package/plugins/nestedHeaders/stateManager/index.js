"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return StateManager;
    }
});
const _array = require("../../../helpers/array");
const _sourceSettings = /*#__PURE__*/ _interop_require_default(require("./sourceSettings"));
const _headersTree = /*#__PURE__*/ _interop_require_default(require("./headersTree"));
const _nodeModifiers = require("./nodeModifiers");
const _tree = require("./nodeModifiers/utils/tree");
const _matrixGenerator = require("./matrixGenerator");
const _syncVisibility = require("./syncVisibility");
const _deriveSettings = require("./deriveSettings");
const _columnArrangement = require("./columnArrangement");
const _tree1 = require("../../../utils/dataStructures/tree");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var _sourceSettings1 = /*#__PURE__*/ new WeakMap(), _derivedSettings = /*#__PURE__*/ new WeakMap(), _headersTree1 = /*#__PURE__*/ new WeakMap(), /**
   * Cached matrix which is generated from the tree structure.
   *
   * @private
   * @type {Array[]}
   */ _stateMatrix = /*#__PURE__*/ new WeakMap(), /**
   * The last column-visibility adapter passed to syncVisibility(). Stored so that
   * mapState()/mergeStateWith() can re-apply it after rebuilding the tree.
   */ _lastColumnVisibility = /*#__PURE__*/ new WeakMap(), /**
   * The column arrangement the headers tree is derived against. When null, an identity arrangement
   * (visual equals physical) is used, which reproduces the authored structure. The plugin sets a
   * live adapter so the structure follows column moves.
   */ _columnArrangement1 = /*#__PURE__*/ new WeakMap(), /**
   * Per-column membership overrides set by column moves (`physical -> level -> owner identity`). They
   * re-parent a moved column into the cohesive (`columnDropMode: 'adopt'`) group it was dropped inside, or
   * mark it standalone when it left its group - the piece a pure derive cannot infer from the final
   * arrangement alone. Consumed by `#deriveTree`. Empty means "use the authored structure".
   */ _membershipOverrides = /*#__PURE__*/ new WeakMap(), /**
   * Captures the header level and authored group identity of every currently collapsed group, so the
   * collapsed state can be re-attached after a move re-derives the tree.
   *
   * @returns {Array<{headerLevel: number, authoredColumnIndex: number}>}
   */ _snapshotCollapsedGroups = /*#__PURE__*/ new WeakSet(), /**
   * Re-collapses the groups captured by #snapshotCollapsedGroups() on the freshly re-derived tree,
   * matching by authored identity. A group that maps to exactly one node stayed contiguous and is
   * re-collapsed; a group that maps to more than one node was split by the move and is left expanded.
   *
   * @param {Array<{headerLevel: number, authoredColumnIndex: number}>} collapsedGroups The captured groups.
   */ _reapplyCollapsedGroupsByIdentity = /*#__PURE__*/ new WeakSet(), /**
   * Finds every tree node at the given header level that was derived from the given authored owner
   * column. More than one match means the authored group is split across non-adjacent visual columns.
   *
   * @param {number} headerLevel Header level index.
   * @param {number} authoredColumnIndex The authored owner column index identifying the group.
   * @returns {TreeNode[]} The matching nodes.
   */ _findNodesByAuthoredIdentity = /*#__PURE__*/ new WeakSet(), /**
   * Rebuilds the header tree after a structural mutation while preserving the collapsed state.
   *
   * Visibility is derived BEFORE re-collapsing, so collapseNode picks the correct first *visible*
   * representative (and clones the right children) even when columns are hidden by an external
   * source; then it is derived again to reflect the re-applied collapse. Re-running the collapse -
   * rather than only restoring the `isCollapsed` flag - rebuilds the `clonedTree` needed to expand
   * the group again.
   *
   * @param {Function} mutate Applies the structural change to the source settings.
   * @param {Function} shiftColumnIndex Maps a pre-rebuild collapsed column index to its new position.
   */ _rebuildPreservingCollapse = /*#__PURE__*/ new WeakSet(), /**
   * Captures the header level and visual column index of every currently collapsed node, so the
   * collapsed state can be re-applied after a tree rebuild (e.g. after inserting/removing columns).
   *
   * @returns {Array<{headerLevel: number, columnIndex: number}>}
   */ _snapshotCollapsedNodes = /*#__PURE__*/ new WeakSet(), /**
   * Re-collapses the nodes captured by #snapshotCollapsedNodes() on the freshly rebuilt tree. The
   * `shiftColumnIndex` callback maps a pre-rebuild visual column index to its post-rebuild position.
   * Re-running the collapse reconstructs both the `isCollapsed` flag (header indicator) and the
   * `clonedTree` needed to expand the group later.
   *
   * @param {Array<{headerLevel: number, columnIndex: number}>} collapsedNodes The captured nodes.
   * @param {Function} shiftColumnIndex Maps an old visual column index to the new one.
   */ _reapplyCollapsedNodes = /*#__PURE__*/ new WeakSet(), /**
   * Applies a NodeModifiers action to the tree WITHOUT regenerating the state matrix, and reports
   * whether a node was actually modified. Callers that batch several modifications (re-applying
   * collapse after a re-derive) use this and regenerate the matrix once at the end, instead of paying
   * a full whole-matrix regeneration per modified node.
   *
   * @param {string} action An action name to trigger.
   * @param {number} headerLevel Header level index.
   * @param {number} columnIndex A visual column index.
   * @returns {{ actionResult: NodeModificationResult|undefined, modified: boolean }}
   */ _applyNodeModification = /*#__PURE__*/ new WeakSet(), /**
   * Re-applies the last column visibility adapter after a tree rebuild, so that mapState() and
   * mergeStateWith() calls from CollapsibleColumns do not discard visibility state set earlier.
   * The collapsed state is restored separately by #rebuildPreservingCollapse re-running the collapse.
   */ _applySyncVisibility = /*#__PURE__*/ new WeakSet(), /**
   * Re-derives tree-node visibility (colspan, isHidden, crossHiddenColumns) from the last column
   * visibility adapter WITHOUT regenerating the state matrix. Used as the first pass of
   * #rebuildPreservingCollapse, where the matrix would be immediately discarded by re-collapsing.
   */ _deriveVisibility = /*#__PURE__*/ new WeakSet(), /**
   * Derives the visual-order settings from the authored source settings, then builds the headers
   * tree from them. The headers tree is therefore always a function of the authored configuration
   * and the current column arrangement. With the identity arrangement the derived settings equal the
   * authored ones, so the built tree is identical to building directly from the authored settings; a
   * non-identity arrangement (a column move) makes the structure follow the data.
   */ _deriveTree = /*#__PURE__*/ new WeakSet(), /**
   * Resolves the owner a moved column takes at an enclosing level (at or outside its cohesive adoption
   * level), so the adopted column is contained by the same group its visual neighbors belong to. Uses
   * the neighbors' shared effective owner when they agree (which keeps the run contiguous, never
   * straddling), and otherwise falls back to the authored ancestor of the adopted group's anchor.
   *
   * @param {number} visualColumn - The column's post-move visual index.
   * @param {number} level - The enclosing header level.
   * @param {Function} enclosingOwnerAt - Resolves the owner shared by both neighbors, or -1.
   * @param {Function} authoredOwnerAt - Resolves the authored owner of a (visual, level).
   * @param {number[][]} ownerIndexByLevel - The authored owner column index per (level, column).
   * @returns {number} The owner identity the column takes at this level.
   */ _adoptedAncestorOwner = /*#__PURE__*/ new WeakSet(), /**
   * Clears all move-driven membership overrides. Call when the authored structure changes - a fresh
   * config (setState) or an index-shifting insert/remove - because the overrides are keyed by physical
   * column and their owner identities index the authored structure, both invalidated by such a change.
   */ _resetMembershipOverrides = /*#__PURE__*/ new WeakSet(), /**
   * Records or clears one membership override.
   *
   * @param {number} physical - The physical column index.
   * @param {number} level - The header level.
   * @param {number|null} identity - The owner identity to record (`>= 0` group, `< 0` standalone), or
   *   `null` to clear it (fall back to the authored structure).
   */ _setMembershipOverride = /*#__PURE__*/ new WeakSet();
class StateManager {
    /**
   * Sets a new state for the nested headers plugin based on settings passed
   * directly to the plugin.
   *
   * @param {Array[]} nestedHeadersSettings The user-defined settings.
   * @returns {boolean} Returns `true` if the settings are processed correctly, `false` otherwise.
   */ setState(nestedHeadersSettings) {
        _class_private_field_get(this, _sourceSettings1).setData(nestedHeadersSettings);
        // A fresh authored configuration invalidates move-driven membership overrides (their owner
        // identities index the previous structure), so reset them.
        _class_private_method_get(this, _resetMembershipOverrides, resetMembershipOverrides).call(this);
        let hasError = false;
        try {
            _class_private_method_get(this, _deriveTree, deriveTree).call(this);
        } catch (ex) {
            _class_private_field_get(this, _headersTree1).clear();
            _class_private_field_get(this, _derivedSettings).clear();
            _class_private_field_get(this, _sourceSettings1).clear();
            hasError = true;
        }
        _class_private_method_get(this, _applySyncVisibility, applySyncVisibility).call(this);
        return hasError;
    }
    /**
   * Sets columns limit to the state will be trimmed.
   *
   * @param {number} columnsCount The number of columns to limit to.
   */ setColumnsLimit(columnsCount) {
        _class_private_field_get(this, _sourceSettings1).setColumnsLimit(columnsCount);
    }
    /**
   * Sets the column arrangement the headers tree is derived against. Pass a live adapter (backed by
   * the column index mapper) so the rendered structure follows column moves, or `null` to fall back
   * to the identity arrangement (authored structure). Does not rebuild on its own - call
   * `rebuildState()` (or any structural mutation) to re-derive the tree.
   *
   * @param {ColumnArrangement|null} columnArrangement The arrangement to derive against, or null.
   */ setColumnArrangement(columnArrangement) {
        _class_private_field_set(this, _columnArrangement1, columnArrangement);
    }
    /**
   * Re-derives the headers tree from the current authored settings and column arrangement, preserving
   * the collapsed state and re-applying visibility. Call this when only the arrangement changed (a
   * column move) and no structural mutation of the authored settings is needed.
   *
   * Collapse is re-attached by authored group identity (not visual column index, which the move just
   * changed): a group that stayed contiguous is re-collapsed at its new position; a group split apart
   * by the move auto-expands (its collapse is dropped), since a non-contiguous group cannot stay
   * collapsed coherently.
   */ rebuildState() {
        const collapsedGroups = _class_private_method_get(this, _snapshotCollapsedGroups, snapshotCollapsedGroups).call(this);
        _class_private_method_get(this, _deriveTree, deriveTree).call(this);
        _class_private_method_get(this, _deriveVisibility, deriveVisibility).call(this);
        _class_private_method_get(this, _reapplyCollapsedGroupsByIdentity, reapplyCollapsedGroupsByIdentity).call(this, collapsedGroups);
        _class_private_method_get(this, _applySyncVisibility, applySyncVisibility).call(this);
    }
    /**
   * Merges settings with current plugin state.
   *
   * @param {object[]} settings An array of objects to merge with the current source settings.
   */ mergeStateWith(settings) {
        const transformedSettings = (0, _array.arrayMap)(settings, ({ row, ...rest })=>{
            // Negative rows are header-coordinate; map them to a header level. An out-of-range row keeps
            // its (negative) value, which getHeaderSettings() resolves to no match - same as before.
            return {
                row: row < 0 ? this.rowCoordsToLevel(row) ?? row : row,
                ...rest
            };
        });
        _class_private_method_get(this, _rebuildPreservingCollapse, rebuildPreservingCollapse).call(this, ()=>_class_private_field_get(this, _sourceSettings1).mergeWith(transformedSettings), (columnIndex)=>columnIndex);
    }
    /**
   * Maps the current state with a callback.
   *
   * @param {Function} callback A function that is called for every header source settings.
   */ mapState(callback) {
        _class_private_method_get(this, _rebuildPreservingCollapse, rebuildPreservingCollapse).call(this, ()=>_class_private_field_get(this, _sourceSettings1).map(callback), (columnIndex)=>columnIndex);
    }
    /**
   * Inserts `amount` columns into the source settings, then rebuilds the tree and re-derives
   * visibility. Headers spanning the insertion point are extended; columns inserted at a header
   * boundary become standalone headers.
   *
   * The authored source settings are keyed by physical column, while the collapsed state is keyed by
   * visual column - so the insertion takes both indexes. They are equal when no column move is active;
   * after a move they differ, and using each in its own space keeps headers and collapse aligned.
   *
   * @param {number} visualColumnIndex The visual index the columns were inserted at (collapse space).
   * @param {number} physicalColumnIndex The physical index the columns were inserted at (source space).
   * @param {number} amount The number of columns to insert.
   */ insertColumns(visualColumnIndex, physicalColumnIndex, amount) {
        // An index-shifting structural change invalidates move-driven membership overrides (keyed by
        // physical column, with owner identities indexing the authored structure - both shifted here).
        _class_private_method_get(this, _resetMembershipOverrides, resetMembershipOverrides).call(this);
        _class_private_method_get(this, _rebuildPreservingCollapse, rebuildPreservingCollapse).call(this, ()=>_class_private_field_get(this, _sourceSettings1).insertColumns(physicalColumnIndex, amount), (c)=>c >= visualColumnIndex ? c + amount : c);
    }
    /**
   * Removes the given columns from the source settings, then rebuilds the tree and re-derives
   * visibility. Headers overlapping the removed columns are shrunk, re-anchored, or dropped when they
   * lose all their columns.
   *
   * The removed columns are identified by physical index (authored source settings are physical-keyed)
   * and may be non-contiguous after a column move; they are removed highest-index-first so the lower
   * indexes stay valid. The collapsed state is shifted in visual space, which an insert/remove always
   * changes the same way regardless of any active move.
   *
   * @param {number} visualColumnIndex The visual index the columns were removed from (collapse space).
   * @param {number} amount The number of columns removed (length of `physicalColumns`).
   * @param {number[]} physicalColumns The physical indexes of the removed columns (source space).
   */ removeColumns(visualColumnIndex, amount, physicalColumns) {
        const endIndex = visualColumnIndex + amount;
        // An index-shifting structural change invalidates move-driven membership overrides (keyed by
        // physical column, with owner identities indexing the authored structure - both shifted here).
        _class_private_method_get(this, _resetMembershipOverrides, resetMembershipOverrides).call(this);
        _class_private_method_get(this, _rebuildPreservingCollapse, rebuildPreservingCollapse).call(this, ()=>{
            [
                ...physicalColumns
            ].sort((a, b)=>b - a).forEach((physicalColumn)=>_class_private_field_get(this, _sourceSettings1).removeColumns(physicalColumn, 1));
        }, (c)=>{
            if (c < visualColumnIndex) {
                return c;
            }
            // The anchor column was removed but the group may survive - re-anchor to the range start.
            return c >= endIndex ? c - amount : visualColumnIndex;
        });
    }
    /**
   * Maps the current tree nodes with a callback.
   *
   * @param {Function} callback A function that is called for every tree node.
   * @returns {Array}
   */ mapNodes(callback) {
        const results = [];
        // getRoots() returns TreeNode<HeaderNodeData>, so node.data is already HeaderNodeData here - the
        // previous `as TreeNode`/`as unknown[]` casts only threw that type away. Walk and collect directly.
        _class_private_field_get(this, _headersTree1).getRoots().forEach((rootNode)=>{
            rootNode.walkDown((node)=>{
                const result = callback(node.data);
                if (result !== undefined) {
                    results.push(result);
                }
            });
        });
        return results;
    }
    /**
   * Triggers an action from the NodeModifiers module.
   *
   * @param {string} action An action name to trigger.
   * @param {number} headerLevel Header level index.
   * @param {number} columnIndex A visual column index.
   * @returns {object|undefined}
   */ triggerNodeModification(action, headerLevel, columnIndex) {
        const { actionResult, modified } = _class_private_method_get(this, _applyNodeModification, applyNodeModification).call(this, action, headerLevel, columnIndex);
        if (modified) {
            _class_private_field_set(this, _stateMatrix, (0, _matrixGenerator.generateMatrix)(_class_private_field_get(this, _headersTree1).getRoots()));
        }
        return actionResult;
    }
    /**
   * Triggers an action from the NodeModifiers module starting from the lowest header.
   *
   * @param {string} action An action name to trigger.
   * @param {number} columnIndex A visual column index.
   * @returns {object|undefined}
   */ triggerColumnModification(action, columnIndex) {
        return this.triggerNodeModification(action, -1, columnIndex);
    }
    /**
   * Derives tree-node visibility state (colspan, crossHiddenColumns, isHidden) from an external
   * ColumnVisibility port, then regenerates the state matrix. Call this whenever the hiding map
   * changes (HiddenColumns, CollapsibleColumns) or after column sequence changes.
   *
   * @param {ColumnVisibility} columnVisibility The visibility port.
   */ syncVisibility(columnVisibility) {
        _class_private_field_set(this, _lastColumnVisibility, columnVisibility);
        (0, _syncVisibility.syncVisibilityOnTree)(_class_private_field_get(this, _headersTree1).getRoots(), columnVisibility);
        _class_private_field_set(this, _stateMatrix, (0, _matrixGenerator.generateMatrix)(_class_private_field_get(this, _headersTree1).getRoots()));
    }
    /**
   * Re-parents the moved columns after a column move, recording membership overrides the derive uses
   * to keep `columnDropMode: 'adopt'` groups cohesive. Call before `rebuildState()`.
   *
   * For each moved column the deepest group level at which it was dropped strictly inside a cohesive
   * group is found first. From that level outward the column joins that group's ancestor chain (the
   * group the column visually sits inside at each enclosing level), so a splitting ancestor grows
   * to contain the adopted column instead of the inner run straddling its boundary. At every other
   * level (deeper than the adoption, or none found) the column keeps its group when still beside a
   * sibling, else goes standalone. The decisions are taken from the pre-update layout, then applied,
   * so a whole group moved together (each member adjacent to a sibling) stays intact.
   *
   * @param {number[]} movedVisualColumns - The post-move visual indexes of the columns that moved.
   */ reparentColumns(movedVisualColumns) {
        const arrangement = _class_private_field_get(this, _columnArrangement1) ?? (0, _columnArrangement.createIdentityColumnArrangement)();
        const authoredLayers = _class_private_field_get(this, _sourceSettings1).getData();
        const layersCount = authoredLayers.length;
        const columnsCount = layersCount > 0 ? authoredLayers[0].length : 0;
        if (layersCount <= 1 || columnsCount === 0) {
            return; // a single header level is all leaves - nothing to re-parent
        }
        const ownerIndexByLevel = authoredLayers.map((layer)=>(0, _deriveSettings.computeOwnerIndex)(layer));
        // Effective owner = the move override if any, else the authored owner (see resolveOwnerKey).
        const effectiveOwnerAt = (visualColumn, level)=>{
            const physical = arrangement.getPhysicalFromVisual(visualColumn);
            return (0, _deriveSettings.resolveOwnerKey)(physical, ownerIndexByLevel[level], _class_private_field_get(this, _membershipOverrides).get(physical)?.get(level));
        };
        // Authored owner ignores any override - the group the column belongs to in the authored config.
        const authoredOwnerAt = (visualColumn, level)=>{
            const physical = arrangement.getPhysicalFromVisual(visualColumn);
            return (0, _deriveSettings.resolveOwnerKey)(physical, ownerIndexByLevel[level]);
        };
        // The columns moved together in this operation. Their mutual adjacency must be skipped when
        // looking for the group a moved column sits inside, so a whole group dropped into another cohesive
        // group is adopted as a block (each member's neighbor toward the block is a fellow moved column,
        // not the surrounding group).
        const movedSet = new Set(movedVisualColumns);
        // The effective owner shared by the columns flanking the moved block at a level (the group the
        // block sits strictly inside), or -1 when they differ or the block sits at an edge. Fellow moved
        // columns are stepped over so the whole block is judged against the columns surrounding it.
        const enclosingOwnerAt = (visualColumn, level)=>{
            let left = visualColumn - 1;
            let right = visualColumn + 1;
            while(left >= 0 && movedSet.has(left)){
                left -= 1;
            }
            while(right < columnsCount && movedSet.has(right)){
                right += 1;
            }
            if (left < 0 || right >= columnsCount) {
                return -1;
            }
            const leftOwner = effectiveOwnerAt(left, level);
            return leftOwner === effectiveOwnerAt(right, level) && leftOwner >= 0 ? leftOwner : -1;
        };
        // Decide from the current layout first, then apply, so moved siblings see each other's old owner.
        const decisions = [];
        movedVisualColumns.forEach((visualColumn)=>{
            const physical = arrangement.getPhysicalFromVisual(visualColumn);
            // Deepest level at which the column was dropped strictly inside a cohesive group. The adoption
            // there propagates outward through the group's ancestors (see #adoptedAncestorOwner).
            let adoptionLevel = -1;
            for(let level = 0; level < layersCount - 1; level++){
                const enclosing = enclosingOwnerAt(visualColumn, level);
                if (enclosing >= 0 && authoredLayers[level][enclosing]?.columnDropMode !== 'split') {
                    adoptionLevel = level;
                }
            }
            for(let level = 0; level < layersCount - 1; level++){
                const authoredOwner = authoredOwnerAt(visualColumn, level);
                // At or inside the adoption level the column joins the cohesive group's ancestor chain;
                // anywhere else it reverts to its authored owner, so a column moved out of a group keeps its
                // own ancestor labels and the group renders a same-label banner over each contiguous run.
                const target = level <= adoptionLevel ? _class_private_method_get(this, _adoptedAncestorOwner, adoptedAncestorOwner).call(this, visualColumn, level, enclosingOwnerAt, authoredOwnerAt, ownerIndexByLevel) : authoredOwner;
                decisions.push({
                    physical,
                    level,
                    identity: target === authoredOwner ? null : target
                });
            }
        });
        decisions.forEach(({ physical, level, identity })=>{
            _class_private_method_get(this, _setMembershipOverride, setMembershipOverride).call(this, physical, level, identity);
        });
    }
    /**
   * @memberof StateManager#
   * @function rowCoordsToLevel
   *
   * Translates row coordinates into header level.
   *
   * @param {number} rowIndex A visual row index.
   * @returns {number|null} Returns unsigned number.
   */ rowCoordsToLevel(rowIndex) {
        if (rowIndex >= 0) {
            return null;
        }
        const headerLevel = rowIndex + Math.max(this.getLayersCount(), 1);
        if (headerLevel < 0) {
            return null;
        }
        return headerLevel;
    }
    /**
   * @memberof StateManager#
   * @function levelToRowCoords
   *
   * Translates header level into row coordinates.
   *
   * @param {number} headerLevel Header level index.
   * @returns {number} Returns negative number.
   */ levelToRowCoords(headerLevel) {
        if (headerLevel < 0) {
            return null;
        }
        const rowIndex = headerLevel - Math.max(this.getLayersCount(), 1);
        if (rowIndex >= 0) {
            return null;
        }
        return rowIndex;
    }
    /**
   * Gets column header settings for a specified column and header index.
   *
   * @param {number} headerLevel Header level.
   * @param {number} columnIndex A visual column index.
   * @returns {object|null}
   */ getHeaderSettings(headerLevel, columnIndex) {
        if (headerLevel < 0) {
            headerLevel = this.rowCoordsToLevel(headerLevel) ?? 0;
        }
        if (headerLevel === null || headerLevel >= this.getLayersCount()) {
            return null;
        }
        return _class_private_field_get(this, _stateMatrix)[headerLevel]?.[columnIndex] ?? null;
    }
    /**
   * Gets tree data that is connected to the column header.
   *
   * @param {number} headerLevel Header level.
   * @param {number} columnIndex A visual column index.
   * @returns {object|null}
   */ getHeaderTreeNodeData(headerLevel, columnIndex) {
        const node = this.getHeaderTreeNode(headerLevel, columnIndex);
        if (!node) {
            return null;
        }
        return {
            ...node.data
        };
    }
    /**
   * Gets tree node that is connected to the column header.
   *
   * @param {number} headerLevel Header level.
   * @param {number} columnIndex A visual column index.
   * @returns {TreeNode|null}
   */ getHeaderTreeNode(headerLevel, columnIndex) {
        let resolvedLevel = headerLevel;
        if (headerLevel < 0) {
            resolvedLevel = this.rowCoordsToLevel(headerLevel);
        }
        if (resolvedLevel === null || resolvedLevel >= this.getLayersCount()) {
            return null;
        }
        const node = _class_private_field_get(this, _headersTree1).getNode(resolvedLevel, columnIndex);
        if (!node) {
            return null;
        }
        return node;
    }
    /**
   * Finds the most top header level of the column header.
   *
   * @param {number} columnIndexFrom A visual column index.
   * @param {number} [columnIndexTo] A visual column index.
   * @returns {number} Returns a header level in format -1 to -N.
   */ findTopMostEntireHeaderLevel(columnIndexFrom, columnIndexTo = columnIndexFrom) {
        const columnsWidth = columnIndexTo - columnIndexFrom + 1;
        let atLeastOneRootFound = false;
        let headerLevel = null;
        for(let columnIndex = columnIndexFrom; columnIndex <= columnIndexTo; columnIndex++){
            const rootNode = _class_private_field_get(this, _headersTree1).getRootByColumn(columnIndex);
            if (!rootNode) {
                break;
            }
            atLeastOneRootFound = true;
            // eslint-disable-next-line no-loop-func
            rootNode.walkDown((node)=>{
                const { columnIndex: nodeColumnIndex, headerLevel: nodeHeaderLevel, origColspan, isHidden } = node.data;
                if (isHidden) {
                    return;
                }
                if (origColspan <= columnsWidth && nodeColumnIndex >= columnIndexFrom && nodeColumnIndex + origColspan - 1 <= columnIndexTo && (headerLevel === null || nodeHeaderLevel < headerLevel)) {
                    headerLevel = nodeHeaderLevel;
                }
            }, _tree1.TRAVERSAL_DF_PRE);
        }
        if (atLeastOneRootFound && headerLevel === null) {
            return -1;
        }
        return this.levelToRowCoords(headerLevel ?? 0);
    }
    /**
   * Finds the left-most column index where the nested header begins.
   *
   * @param {number} headerLevel Header level.
   * @param {number} columnIndex A visual column index.
   * @returns {number}
   */ findLeftMostColumnIndex(headerLevel, columnIndex) {
        const { isRoot } = this.getHeaderSettings(headerLevel, columnIndex) ?? {
            isRoot: true
        };
        if (isRoot) {
            return columnIndex;
        }
        let stepBackColumn = columnIndex - 1;
        while(stepBackColumn >= 0){
            const { isRoot: isRootNode } = this.getHeaderSettings(headerLevel, stepBackColumn) ?? {
                isRoot: true
            };
            if (isRootNode) {
                break;
            }
            stepBackColumn -= 1;
        }
        return stepBackColumn;
    }
    /**
   * Finds the right-most column index where the nested header ends.
   *
   * @param {number} headerLevel Header level.
   * @param {number} columnIndex A visual column index.
   * @returns {number}
   */ findRightMostColumnIndex(headerLevel, columnIndex) {
        const { isRoot, origColspan } = this.getHeaderSettings(headerLevel, columnIndex) ?? {
            isRoot: true,
            origColspan: 1
        };
        if (isRoot) {
            return columnIndex + origColspan - 1;
        }
        let stepForthColumn = columnIndex + 1;
        while(stepForthColumn < this.getColumnsCount()){
            const { isRoot: isRootNode } = this.getHeaderSettings(headerLevel, stepForthColumn) ?? {
                isRoot: true
            };
            if (isRootNode) {
                break;
            }
            stepForthColumn += 1;
        }
        return stepForthColumn - 1;
    }
    /**
   * Gets a total number of headers levels.
   *
   * @returns {number}
   */ getLayersCount() {
        return _class_private_field_get(this, _sourceSettings1).getLayersCount();
    }
    /**
   * Gets the number of columns the rendered header structure spans (the visual width). This reads
   * the derived settings, so it matches the generated matrix and the current column arrangement.
   * With an identity arrangement it equals the authored column count.
   *
   * @returns {number}
   */ getColumnsCount() {
        return _class_private_field_get(this, _derivedSettings).getColumnsCount();
    }
    /**
   * Computes the visual column indexes that should be hidden purely by the `visibleWhen` rules of
   * declarative collapsible groups (issue #10243), given each group's current `isCollapsed` state.
   *
   * A group is "declarative" when at least one of its direct children declares an explicit
   * `visibleWhen` ('collapsed', 'expanded', or 'always'); legacy groups (no markers) are left to the
   * regular first-visible-child collapse path and are skipped here. Within a declarative group a child
   * with no marker defaults to `'expanded'` - it is hidden when the group collapses, matching the
   * default collapse behavior; `'always'` is the explicit opt-in for staying visible in both states.
   * Only `collapsible` groups are considered. At least one column per group always stays visible so the
   * group's collapse indicator survives. The result is a pure function of the tree shape, the markers,
   * and the `isCollapsed` flags, so it stays correct across tree rebuilds.
   *
   * @returns {number[]} Visual column indexes to hide.
   */ getVisibleWhenHiddenColumns() {
        const columnsToHide = [];
        _class_private_field_get(this, _headersTree1).getRoots().forEach((rootNode)=>{
            rootNode.walkDown((node)=>{
                const childNodes = node.childs;
                if (node.data.collapsible !== true || childNodes.length === 0) {
                    return;
                }
                // Only declarative groups (at least one explicit `visibleWhen` marker) are handled here;
                // legacy groups keep the first-visible-child collapse path. The predicate lives in one place
                // so this computation and the collapse/expand modifiers agree on what "declarative" means.
                if (!(0, _tree.isDeclarativeGroup)(node)) {
                    return;
                }
                const isGroupCollapsed = node.data.isCollapsed === true;
                const childrenToHide = childNodes.filter((childNode)=>{
                    // An unset child defaults to 'expanded' (hidden on collapse).
                    const visibility = childNode.data.visibleWhen ?? 'expanded';
                    return visibility === 'expanded' && isGroupCollapsed || visibility === 'collapsed' && !isGroupCollapsed;
                });
                // Never hide every column of the group through `visibleWhen` - the collapse indicator renders
                // on the group's first visible column, so keep the first child visible when a (mis)configuration
                // would otherwise blank the whole group and leave no way to expand it back. Known limitation:
                // if that kept column is independently hidden by another source (HiddenColumns or trimming) the
                // indicator can still be lost. Reading the external hidden state here is avoided on purpose -
                // this set feeds the hiding map that syncVisibility consumes, so a node's `isHidden` flag
                // already carries this set's own previous effect and cannot be trusted as an external-only signal.
                if (childrenToHide.length === childNodes.length) {
                    childrenToHide.shift();
                }
                childrenToHide.forEach(({ data: { columnIndex, origColspan } })=>{
                    for(let i = 0; i < origColspan; i++){
                        columnsToHide.push(columnIndex + i);
                    }
                });
            });
        });
        return columnsToHide;
    }
    /**
   * Gets every currently collapsed group as its header level and the visual column span it covers
   * (its left-edge visual column index and original colspan). Used to detect, before a column move,
   * whether the move would split a collapsed group.
   *
   * @returns {Array<{headerLevel: number, columnIndex: number, origColspan: number}>}
   */ getCollapsedGroups() {
        const groups = [];
        _class_private_field_get(this, _headersTree1).getRoots().forEach((rootNode)=>{
            rootNode.walkDown((node)=>{
                const { isCollapsed, headerLevel, columnIndex, origColspan } = node.data;
                if (isCollapsed) {
                    groups.push({
                        headerLevel,
                        columnIndex,
                        origColspan
                    });
                }
            });
        });
        return groups;
    }
    /**
   * Clears the column state manager to the initial state.
   */ clear() {
        _class_private_field_set(this, _stateMatrix, []);
        _class_private_field_get(this, _sourceSettings1).clear();
        _class_private_field_get(this, _derivedSettings).clear();
        _class_private_field_get(this, _headersTree1).clear();
        _class_private_field_set(this, _lastColumnVisibility, null);
        _class_private_field_set(this, _membershipOverrides, new Map());
    }
    constructor(){
        _class_private_method_init(this, _snapshotCollapsedGroups);
        _class_private_method_init(this, _reapplyCollapsedGroupsByIdentity);
        _class_private_method_init(this, _findNodesByAuthoredIdentity);
        _class_private_method_init(this, _rebuildPreservingCollapse);
        _class_private_method_init(this, _snapshotCollapsedNodes);
        _class_private_method_init(this, _reapplyCollapsedNodes);
        _class_private_method_init(this, _applyNodeModification);
        _class_private_method_init(this, _applySyncVisibility);
        _class_private_method_init(this, _deriveVisibility);
        _class_private_method_init(this, _deriveTree);
        _class_private_method_init(this, _adoptedAncestorOwner);
        _class_private_method_init(this, _resetMembershipOverrides);
        _class_private_method_init(this, _setMembershipOverride);
        /**
   * The authored (physical-order) source settings - the normalized user configuration. All
   * structural mutations (setData, mergeWith, map, insertColumns, removeColumns) operate on this.
   *
   * @private
   * @type {SourceSettings}
   */ _class_private_field_init(this, _sourceSettings1, {
            writable: true,
            value: void 0
        });
        /**
   * Visual-order settings derived from #sourceSettings through deriveVisualSettings(). The headers
   * tree is built from these, so the rendered structure follows the current column arrangement. With
   * an identity arrangement they equal the authored settings, so the built tree is unchanged.
   *
   * @private
   * @type {SourceSettings}
   */ _class_private_field_init(this, _derivedSettings, {
            writable: true,
            value: void 0
        });
        /**
   * The instance of the headers tree.
   *
   * @private
   * @type {HeadersTree}
   */ _class_private_field_init(this, _headersTree1, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _stateMatrix, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _lastColumnVisibility, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _columnArrangement1, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _membershipOverrides, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _sourceSettings1, new _sourceSettings.default());
        _class_private_field_set(this, _derivedSettings, new _sourceSettings.default());
        _class_private_field_set(this, _headersTree1, new _headersTree.default(_class_private_field_get(this, _derivedSettings)));
        _class_private_field_set(this, _stateMatrix, [
            []
        ]);
        _class_private_field_set(this, _lastColumnVisibility, null);
        _class_private_field_set(this, _columnArrangement1, null);
        _class_private_field_set(this, _membershipOverrides, new Map());
    }
}
function snapshotCollapsedGroups() {
    const groups = [];
    _class_private_field_get(this, _headersTree1).getRoots().forEach((rootNode)=>{
        rootNode.walkDown((node)=>{
            const { isCollapsed, headerLevel, authoredColumnIndex } = node.data;
            if (isCollapsed && typeof authoredColumnIndex === 'number' && authoredColumnIndex >= 0) {
                groups.push({
                    headerLevel,
                    authoredColumnIndex
                });
            }
        });
    });
    return groups;
}
function reapplyCollapsedGroupsByIdentity(collapsedGroups) {
    collapsedGroups.forEach(({ headerLevel, authoredColumnIndex })=>{
        const matches = _class_private_method_get(this, _findNodesByAuthoredIdentity, findNodesByAuthoredIdentity).call(this, headerLevel, authoredColumnIndex);
        if (matches.length === 1) {
            // Matrix-free: the trailing #applySyncVisibility regenerates the matrix once for all groups.
            _class_private_method_get(this, _applyNodeModification, applyNodeModification).call(this, 'collapse', headerLevel, matches[0].data.columnIndex);
        }
    });
}
function findNodesByAuthoredIdentity(headerLevel, authoredColumnIndex) {
    const matches = [];
    _class_private_field_get(this, _headersTree1).getRoots().forEach((rootNode)=>{
        rootNode.walkDown((node)=>{
            if (node.data.headerLevel === headerLevel && node.data.authoredColumnIndex === authoredColumnIndex) {
                matches.push(node);
            }
        });
    });
    return matches;
}
function rebuildPreservingCollapse(mutate, shiftColumnIndex) {
    const collapsedNodes = _class_private_method_get(this, _snapshotCollapsedNodes, snapshotCollapsedNodes).call(this);
    mutate();
    _class_private_method_get(this, _deriveTree, deriveTree).call(this);
    // Derive visibility before re-collapsing, but skip the matrix here - #reapplyCollapsedNodes
    // reads the tree (not the matrix) and the trailing #applySyncVisibility regenerates it once,
    // so building the matrix at this point would only be discarded work.
    _class_private_method_get(this, _deriveVisibility, deriveVisibility).call(this);
    _class_private_method_get(this, _reapplyCollapsedNodes, reapplyCollapsedNodes).call(this, collapsedNodes, shiftColumnIndex);
    _class_private_method_get(this, _applySyncVisibility, applySyncVisibility).call(this);
}
function snapshotCollapsedNodes() {
    const collapsedNodes = [];
    _class_private_field_get(this, _headersTree1).getRoots().forEach((rootNode)=>{
        rootNode.walkDown((node)=>{
            const data = node.data;
            if (data.isCollapsed) {
                collapsedNodes.push({
                    headerLevel: data.headerLevel,
                    columnIndex: data.columnIndex
                });
            }
        });
    });
    return collapsedNodes;
}
function reapplyCollapsedNodes(collapsedNodes, shiftColumnIndex) {
    collapsedNodes.forEach(({ headerLevel, columnIndex })=>{
        // Matrix-free: the trailing #applySyncVisibility regenerates the matrix once for all nodes.
        _class_private_method_get(this, _applyNodeModification, applyNodeModification).call(this, 'collapse', headerLevel, shiftColumnIndex(columnIndex));
    });
}
function applyNodeModification(action, headerLevel, columnIndex) {
    if (headerLevel < 0) {
        headerLevel = this.rowCoordsToLevel(headerLevel) ?? 0;
    }
    const nodeToProcess = _class_private_field_get(this, _headersTree1).getNode(headerLevel, columnIndex);
    if (!nodeToProcess) {
        return {
            actionResult: undefined,
            modified: false
        };
    }
    return {
        actionResult: (0, _nodeModifiers.triggerNodeModification)(action, nodeToProcess, columnIndex) ?? undefined,
        modified: true
    };
}
function applySyncVisibility() {
    _class_private_method_get(this, _deriveVisibility, deriveVisibility).call(this);
    _class_private_field_set(this, _stateMatrix, (0, _matrixGenerator.generateMatrix)(_class_private_field_get(this, _headersTree1).getRoots()));
}
function deriveVisibility() {
    if (_class_private_field_get(this, _lastColumnVisibility)) {
        (0, _syncVisibility.syncVisibilityOnTree)(_class_private_field_get(this, _headersTree1).getRoots(), _class_private_field_get(this, _lastColumnVisibility));
    }
}
function deriveTree() {
    const arrangement = _class_private_field_get(this, _columnArrangement1) ?? (0, _columnArrangement.createIdentityColumnArrangement)();
    _class_private_field_get(this, _derivedSettings).setNormalizedData((0, _deriveSettings.deriveVisualSettings)(_class_private_field_get(this, _sourceSettings1).getData(), arrangement, _class_private_field_get(this, _membershipOverrides)));
    _class_private_field_get(this, _headersTree1).buildTree();
}
function adoptedAncestorOwner(visualColumn, level, enclosingOwnerAt, authoredOwnerAt, ownerIndexByLevel) {
    const enclosing = enclosingOwnerAt(visualColumn, level);
    if (enclosing >= 0) {
        return enclosing;
    }
    // The neighbors disagree at this enclosing level; fall back to the authored ancestor of the group
    // the column sits inside one level deeper, which is a valid (properly nested) parent.
    const innerOwner = enclosingOwnerAt(visualColumn, level + 1);
    return innerOwner >= 0 ? ownerIndexByLevel[level][innerOwner] : authoredOwnerAt(visualColumn, level);
}
function resetMembershipOverrides() {
    _class_private_field_set(this, _membershipOverrides, new Map());
}
function setMembershipOverride(physical, level, identity) {
    if (identity === null) {
        const levels = _class_private_field_get(this, _membershipOverrides).get(physical);
        levels?.delete(level);
        if (levels?.size === 0) {
            _class_private_field_get(this, _membershipOverrides).delete(physical);
        }
        return;
    }
    if (!_class_private_field_get(this, _membershipOverrides).has(physical)) {
        _class_private_field_get(this, _membershipOverrides).set(physical, new Map());
    }
    _class_private_field_get(this, _membershipOverrides).get(physical).set(level, identity);
}
