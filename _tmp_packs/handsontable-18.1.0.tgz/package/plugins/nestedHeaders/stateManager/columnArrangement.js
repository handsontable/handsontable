"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get createColumnArrangementAdapter () {
        return createColumnArrangementAdapter;
    },
    get createIdentityColumnArrangement () {
        return createIdentityColumnArrangement;
    }
});
function createColumnArrangementAdapter(hot) {
    return {
        getPhysicalFromVisual (visualColumnIndex) {
            const physicalIndex = hot.columnIndexMapper.getPhysicalFromVisualIndex(visualColumnIndex);
            // A null result means the visual index is out of range; fall back to the identity mapping so
            // the caller (which only iterates indexes within the authored width) stays well defined.
            return physicalIndex === null ? visualColumnIndex : physicalIndex;
        }
    };
}
function createIdentityColumnArrangement() {
    return {
        getPhysicalFromVisual (visualColumnIndex) {
            return visualColumnIndex;
        }
    };
}
