"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createColumnVisibilityAdapter", {
    enumerable: true,
    get: function() {
        return createColumnVisibilityAdapter;
    }
});
function createColumnVisibilityAdapter(hot) {
    return {
        isVisible (visualColumnIndex) {
            const physicalIndex = hot.columnIndexMapper.getPhysicalFromVisualIndex(visualColumnIndex);
            if (physicalIndex === null) {
                return false;
            }
            return !hot.columnIndexMapper.isHidden(physicalIndex);
        }
    };
}
