"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get NestedHeaders () {
        return _nestedHeaders.NestedHeaders;
    },
    get PLUGIN_KEY () {
        return _nestedHeaders.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _nestedHeaders.PLUGIN_PRIORITY;
    }
});
const _nestedHeaders = require("./nestedHeaders");
