"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DropdownMenu () {
        return _dropdownMenu.DropdownMenu;
    },
    get PLUGIN_KEY () {
        return _dropdownMenu.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _dropdownMenu.PLUGIN_PRIORITY;
    }
});
const _dropdownMenu = require("./dropdownMenu");
