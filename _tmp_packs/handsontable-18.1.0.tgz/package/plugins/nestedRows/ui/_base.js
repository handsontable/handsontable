"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
/**
 * Base class for the Nested Rows' UI sub-classes.
 *
 * @private
 * @class
 */ class BaseUI {
    /**
   * Initializes the base UI component with references to the NestedRows plugin instance and the Handsontable instance.
   */ constructor(pluginInstance, hotInstance){
        this.hot = hotInstance;
        this.plugin = pluginInstance;
    }
}
const _default = BaseUI;
