"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _event = require("../../../helpers/dom/event");
const _errors = require("../../../helpers/errors");
const _array = require("../../../helpers/array");
const _number = require("../../../helpers/number");
const _element = require("../../../helpers/dom/element");
const _base = /*#__PURE__*/ _interop_require_default(require("./_base"));
const _headers = /*#__PURE__*/ _interop_require_default(require("./headers"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const actionDictionary = new Map([
    [
        'collapse',
        {
            beforeHook: 'beforeRowCollapse',
            afterHook: 'afterRowCollapse'
        }
    ],
    [
        'expand',
        {
            beforeHook: 'beforeRowExpand',
            afterHook: 'afterRowExpand'
        }
    ]
]);
var /**
   * Builds the collapsed-parents list the grid will hold once the action finishes.
   *
   * @param {number[]} currentCollapsedRows Physical indexes of the currently collapsed parents.
   * @param {number[]} parents Physical indexes of the parents being collapsed or expanded.
   * @param {boolean} isCollapse `true` for a collapse, `false` for an expand.
   * @returns {number[]} Physical row indexes, sorted ascending.
   */ _getDestinationCollapsedRows = /*#__PURE__*/ new WeakSet(), /**
   * Checks whether the physical row index points at a row that can be collapsed, meaning it exists
   * and has children.
   *
   * @param {number} parent Physical row index.
   * @returns {boolean}
   */ _isCollapsibleParent = /*#__PURE__*/ new WeakSet(), /**
   * Compares the collapsed-parents list against a snapshot taken before an action ran.
   *
   * @param {number[]} snapshot Physical row indexes captured before the action.
   * @returns {boolean} `true` when nothing changed.
   */ _isSameCollapsedState = /*#__PURE__*/ new WeakSet(), /**
   * Physical row indexes of every top-level row that has children.
   *
   * @returns {number[]}
   */ _getTopLevelParents = /*#__PURE__*/ new WeakSet();
/**
 * Class responsible for the UI for collapsing and expanding groups.
 *
 * @private
 * @class
 * @augments BaseUI
 */ class CollapsingUI extends _base.default {
    /**
   * Collapse the children of the row passed as an argument.
   *
   * @param {number|object} row The parent row.
   * @param {boolean} [forceRender=true] Whether to render the table after the function ends.
   * @param {boolean} [doTrimming=true] I determine whether collapsing should envolve trimming rows.
   * @returns {Array}
   */ collapseChildren(row, forceRender = true, doTrimming = true) {
        const rowsToCollapse = [];
        let rowObject = null;
        let rowIndex = null;
        let rowsToTrim = null;
        if (isNaN(row)) {
            rowObject = row;
            rowIndex = this.dataManager.getRowIndex(rowObject);
        } else {
            rowObject = this.dataManager.getDataObject(row);
            rowIndex = row;
        }
        const hasChildren = !!rowObject && this.dataManager.hasChildren(rowObject);
        if (hasChildren) {
            (0, _array.arrayEach)(rowObject.__children, (elem)=>{
                const childIndex = this.dataManager.getRowIndex(elem);
                // Skip children the cache does not know about - `getRowIndex` returns `null` for a row
                // object that is no longer part of the current nested structure.
                if (childIndex !== null) {
                    rowsToCollapse.push(childIndex);
                }
            });
        }
        rowsToTrim = this.collapseRows(rowsToCollapse, true, false);
        if (doTrimming) {
            this.trimRows(rowsToTrim);
        }
        if (forceRender) {
            this.renderAndAdjust();
        }
        // Only a row that actually has children can be collapsed. Without this check pressing Enter on a
        // leaf row header would record that leaf as a collapsed parent.
        if (hasChildren && rowIndex !== null && this.collapsedRows.indexOf(rowIndex) === -1) {
            this.collapsedRows.push(rowIndex);
        }
        return rowsToTrim;
    }
    /**
   * Collapse multiple children.
   *
   * @param {Array} rows Rows to collapse (including their children).
   * @param {boolean} [forceRender=true] `true` if the table should be rendered after finishing the function.
   * @param {boolean} [doTrimming=true] I determine whether collapsing should envolve trimming rows.
   */ collapseMultipleChildren(rows, forceRender = true, doTrimming = true) {
        const rowsToTrim = [];
        (0, _array.arrayEach)(rows, (elem)=>{
            rowsToTrim.push(...this.collapseChildren(elem, false, false));
        });
        if (doTrimming) {
            this.trimRows(rowsToTrim);
        }
        if (forceRender) {
            this.renderAndAdjust();
        }
    }
    /**
   * Collapse a single row.
   *
   * @param {number} rowIndex Index of the row to collapse.
   * @param {boolean} [recursive=true] `true` if it should collapse the row's children.
   */ collapseRow(rowIndex, recursive = true) {
        this.collapseRows([
            rowIndex
        ], recursive);
    }
    /**
   * Collapse multiple rows.
   *
   * @param {Array} rowIndexes Array of row indexes to collapse.
   * @param {boolean} [recursive=true] `true` if it should collapse the rows' children.
   * @param {boolean} [doTrimming=true] I determine whether collapsing should envolve trimming rows.
   * @returns {Array} Rows prepared for trimming (or trimmed, if doTrimming == true).
   */ collapseRows(rowIndexes, recursive = true, doTrimming = false) {
        const rowsToTrim = [];
        (0, _array.arrayEach)(rowIndexes, (elem)=>{
            rowsToTrim.push(elem);
            if (recursive) {
                this.collapseChildRows(elem, rowsToTrim);
            }
        });
        if (doTrimming) {
            this.trimRows(rowsToTrim);
        }
        return rowsToTrim;
    }
    /**
   * Collapse child rows of the row at the provided index.
   *
   * @param {number} parentIndex Index of the parent node.
   * @param {Array} [rowsToTrim=[]] Array of rows to trim. Defaults to an empty array.
   * @param {boolean} [recursive] `true` if the collapsing process should be recursive.
   * @param {boolean} [doTrimming=true] I determine whether collapsing should envolve trimming rows.
   */ collapseChildRows(parentIndex, rowsToTrim = [], recursive, doTrimming = false) {
        if (this.dataManager.hasChildren(parentIndex)) {
            const parentObject = this.dataManager.getDataObject(parentIndex);
            (0, _array.arrayEach)(parentObject.__children ?? [], (elem)=>{
                const elemIndex = this.dataManager.getRowIndex(elem);
                if (elemIndex !== null) {
                    rowsToTrim.push(elemIndex);
                    this.collapseChildRows(elemIndex, rowsToTrim);
                }
            });
        }
        if (doTrimming) {
            this.trimRows(rowsToTrim);
        }
    }
    /**
   * Expand a single row.
   *
   * @param {number} rowIndex Index of the row to expand.
   * @param {boolean} [recursive=true] `true` if it should expand the row's children recursively.
   */ expandRow(rowIndex, recursive = true) {
        this.expandRows([
            rowIndex
        ], recursive);
    }
    /**
   * Expand multiple rows.
   *
   * @param {Array} rowIndexes Array of indexes of the rows to expand.
   * @param {boolean} [recursive=true] `true` if it should expand the rows' children recursively.
   * @param {boolean} [doTrimming=true] I determine whether collapsing should envolve trimming rows.
   * @returns {Array} Array of row indexes to be untrimmed.
   */ expandRows(rowIndexes, recursive = true, doTrimming = false) {
        const rowsToUntrim = [];
        (0, _array.arrayEach)(rowIndexes, (elem)=>{
            rowsToUntrim.push(elem);
            if (recursive) {
                this.expandChildRows(elem, rowsToUntrim);
            }
        });
        if (doTrimming) {
            this.untrimRows(rowsToUntrim);
        }
        return rowsToUntrim;
    }
    /**
   * Expand child rows of the provided index.
   *
   * @param {number} parentIndex Index of the parent row.
   * @param {Array} [rowsToUntrim=[]] Array of the rows to be untrimmed.
   * @param {boolean} [recursive] `true` if it should expand the rows' children recursively.
   * @param {boolean} [doTrimming=false] I determine whether collapsing should envolve trimming rows.
   */ expandChildRows(parentIndex, rowsToUntrim = [], recursive, doTrimming = false) {
        if (this.dataManager.hasChildren(parentIndex)) {
            const parentObject = this.dataManager.getDataObject(parentIndex);
            (0, _array.arrayEach)(parentObject.__children ?? [], (elem)=>{
                if (!this.isAnyParentCollapsed(elem)) {
                    const elemIndex = this.dataManager.getRowIndex(elem);
                    if (elemIndex !== null) {
                        rowsToUntrim.push(elemIndex);
                        this.expandChildRows(elemIndex, rowsToUntrim);
                    }
                }
            });
        }
        if (doTrimming) {
            this.untrimRows(rowsToUntrim);
        }
    }
    /**
   * Expand the children of the row passed as an argument.
   *
   * @param {number|object} row Parent row.
   * @param {boolean} [forceRender=true] Whether to render the table after the function ends.
   * @param {boolean} [doTrimming=true] If set to `true`, the trimming will be applied when the function finishes.
   * @returns {number[]}
   */ expandChildren(row, forceRender = true, doTrimming = true) {
        const rowsToExpand = [];
        let rowObject = null;
        let rowIndex = null;
        let rowsToUntrim = null;
        if (isNaN(row)) {
            rowObject = row;
            rowIndex = this.dataManager.getRowIndex(row);
        } else {
            rowObject = this.dataManager.getDataObject(row);
            rowIndex = row;
        }
        const collapsedIndex = rowIndex === null ? -1 : this.collapsedRows.indexOf(rowIndex);
        // `indexOf` returns -1 for a row that is not collapsed, and `splice(-1, 1)` would drop the last
        // tracked parent instead of doing nothing.
        if (collapsedIndex > -1) {
            this.collapsedRows.splice(collapsedIndex, 1);
        }
        if (rowObject && this.dataManager.hasChildren(rowObject)) {
            (0, _array.arrayEach)(rowObject.__children, (elem)=>{
                const childIndex = this.dataManager.getRowIndex(elem);
                if (childIndex !== null) {
                    rowsToExpand.push(childIndex);
                }
            });
        }
        rowsToUntrim = this.expandRows(rowsToExpand, true, false);
        if (doTrimming) {
            this.untrimRows(rowsToUntrim);
        }
        if (forceRender) {
            this.renderAndAdjust();
        }
        return rowsToUntrim;
    }
    /**
   * Expand multiple rows' children.
   *
   * @param {Array} rows Array of rows which children are about to be expanded.
   * @param {boolean} [forceRender=true] `true` if the table should render after finishing the function.
   * @param {boolean} [doTrimming=true] `true` if the rows should be untrimmed after finishing the function.
   */ expandMultipleChildren(rows, forceRender = true, doTrimming = true) {
        const rowsToUntrim = [];
        (0, _array.arrayEach)(rows, (elem)=>{
            rowsToUntrim.push(...this.expandChildren(elem, false, false));
        });
        if (doTrimming) {
            this.untrimRows(rowsToUntrim);
        }
        if (forceRender) {
            this.renderAndAdjust();
        }
    }
    /**
   * Returns the physical indexes of the parent rows that are collapsed right now.
   *
   * The list is sorted ascending so hook payloads are stable and comparable between calls.
   *
   * @returns {number[]} Physical row indexes of collapsed parents.
   */ getCollapsedParents() {
        return this.collapsedRows.slice().sort((a, b)=>a - b);
    }
    /**
   * Collapses or expands the given parent rows and fires the matching pair of hooks.
   *
   * This is the single choke point for every collapse and expand in the plugin - the row header
   * button, the Enter shortcut, and the public plugin methods all run through it, so all of them
   * produce the same state change and the same hooks.
   *
   * @param {number[]} parents Physical row indexes of the parents to act on.
   * @param {string} action Either `'collapse'` or `'expand'`.
   * @param {boolean} [shouldRunHooks=true] `false` skips both hooks - used when replaying state that the
   * user already chose, such as restoring after an `updateSettings` call.
   * @returns {boolean} `true` if the collapsed state actually changed.
   * @fires Hooks#beforeRowCollapse
   * @fires Hooks#afterRowCollapse
   * @fires Hooks#beforeRowExpand
   * @fires Hooks#afterRowExpand
   */ toggleCollapsedRows(parents, action, shouldRunHooks = true) {
        return this.applyCollapsedRowsChange(parents, action, shouldRunHooks).performed;
    }
    /**
   * Same as `toggleCollapsedRows`, but it also reports whether a `before*` hook blocked the action.
   *
   * A caller that performs two passes needs that apart from `performed`: `performed` is `false` both
   * when a hook blocked the change and when there was simply nothing to do, and those two cases call
   * for opposite decisions.
   *
   * @param {number[]} parents Physical row indexes of the parents to act on.
   * @param {string} action Either `'collapse'` or `'expand'`.
   * @param {boolean} [shouldRunHooks=true] `false` skips both hooks.
   * @returns {{performed: boolean, vetoed: boolean}} `performed` says the collapsed state changed,
   * `vetoed` says a `before*` hook returned `false`.
   * @fires Hooks#beforeRowCollapse
   * @fires Hooks#afterRowCollapse
   * @fires Hooks#beforeRowExpand
   * @fires Hooks#afterRowExpand
   */ applyCollapsedRowsChange(parents, action, shouldRunHooks = true) {
        const actionTranslator = actionDictionary.get(action);
        if (!actionTranslator) {
            (0, _errors.throwWithCause)(`Unsupported action is passed (${action}).`);
        }
        if (!Array.isArray(parents)) {
            return {
                performed: false,
                vetoed: false
            };
        }
        const isCollapse = action === 'collapse';
        const currentCollapsedRows = this.getCollapsedParents();
        // The action is possible only when every index points at a row that really has children. An
        // impossible action still reports through the hooks, matching the CollapsibleColumns plugin.
        const actionPossible = parents.length > 0 && parents.every((parent)=>_class_private_method_get(this, _isCollapsibleParent, isCollapsibleParent).call(this, parent));
        const destinationCollapsedRows = _class_private_method_get(this, _getDestinationCollapsedRows, getDestinationCollapsedRows).call(this, currentCollapsedRows, parents, isCollapse);
        if (shouldRunHooks) {
            const isActionAllowed = this.hot.runHooks(actionTranslator.beforeHook, currentCollapsedRows, destinationCollapsedRows, actionPossible);
            if (isActionAllowed === false) {
                return {
                    performed: false,
                    vetoed: true
                };
            }
        }
        if (actionPossible) {
            if (isCollapse) {
                this.collapseMultipleChildren(parents, false, true);
            } else {
                this.expandMultipleChildren(parents, false, true);
            }
        }
        const isActionPerformed = !_class_private_method_get(this, _isSameCollapsedState, isSameCollapsedState).call(this, currentCollapsedRows);
        if (isActionPerformed) {
            this.renderAndAdjust();
        }
        if (shouldRunHooks) {
            this.hot.runHooks(actionTranslator.afterHook, currentCollapsedRows, destinationCollapsedRows, actionPossible, isActionPerformed);
        }
        return {
            performed: isActionPerformed,
            vetoed: false
        };
    }
    /**
   * Collapse all collapsable rows.
   */ collapseAll() {
        this.toggleCollapsedRows(_class_private_method_get(this, _getTopLevelParents, getTopLevelParents).call(this), 'collapse');
    }
    /**
   * Expand all collapsable rows.
   *
   * Acts on the top-level parents, which leaves a parent that was collapsed inside another one
   * collapsed. Use `NestedRows#expandAll` to expand every level.
   */ expandAll() {
        this.toggleCollapsedRows(_class_private_method_get(this, _getTopLevelParents, getTopLevelParents).call(this), 'expand');
    }
    /**
   * Collapsed parents ordered from the shallowest to the deepest, so an ancestor is always handled
   * before its own descendants.
   *
   * @returns {number[]} Physical row indexes.
   */ getCollapsedParentsShallowestFirst() {
        return this.getCollapsedParents().map((row)=>({
                row,
                level: this.dataManager.getRowLevel(row) ?? 0
            })).sort((a, b)=>a.level - b.level).map(({ row })=>row);
    }
    /**
   * Trim rows.
   *
   * @param {Array} rows Physical row indexes.
   */ trimRows(rows) {
        this.hot.batchExecution(()=>{
            (0, _array.arrayEach)(rows, (physicalRow)=>{
                this.plugin.collapsedRowsMap.setValueAtIndex(physicalRow, true);
            });
        }, true);
    }
    /**
   * Untrim rows.
   *
   * @param {Array} rows Physical row indexes.
   */ untrimRows(rows) {
        this.hot.batchExecution(()=>{
            (0, _array.arrayEach)(rows, (physicalRow)=>{
                this.plugin.collapsedRowsMap.setValueAtIndex(physicalRow, false);
            });
        }, true);
    }
    /**
   * Check if all child rows are collapsed.
   *
   * @private
   * @param {number|object|null} row The parent row. `null` for the top level.
   * @returns {boolean}
   */ areChildrenCollapsed(row) {
        let rowObj = isNaN(row) ? row : this.dataManager.getDataObject(row);
        let allCollapsed = true;
        // Checking the children of the top-level "parent"
        if (rowObj === null || rowObj === undefined) {
            rowObj = {
                __children: this.dataManager.data
            };
        }
        if (rowObj && this.dataManager.hasChildren(rowObj)) {
            (0, _array.arrayEach)(rowObj.__children, (elem)=>{
                const rowIndex = this.dataManager.getRowIndex(elem);
                if (rowIndex === null || !this.plugin.collapsedRowsMap.getValueAtIndex(rowIndex)) {
                    allCollapsed = false;
                    return false;
                }
            });
        }
        return allCollapsed;
    }
    /**
   * Check if any of the row object parents are collapsed.
   *
   * @private
   * @param {object} rowObj Row object.
   * @returns {boolean}
   */ isAnyParentCollapsed(rowObj) {
        let parent = rowObj;
        while(parent !== null){
            parent = this.dataManager.getRowParent(parent);
            const parentIndex = this.dataManager.getRowIndex(parent);
            if (parentIndex !== null && this.collapsedRows.indexOf(parentIndex) > -1) {
                return true;
            }
        }
        return false;
    }
    /**
   * Toggle collapsed state. Callback for the `beforeOnCellMousedown` hook.
   *
   * @private
   * @param {MouseEvent} event `mousedown` event.
   * @param {object} coords Coordinates of the clicked cell/header.
   */ toggleState(event, coords, _TD) {
        if (coords.col >= 0) {
            return;
        }
        const row = this.translateTrimmedRow(coords.row);
        if ((0, _element.hasClass)((0, _element.eventTargetEl)(event), _headers.default.CSS_CLASSES.button)) {
            this.toggleCollapsedRows([
                row
            ], this.areChildrenCollapsed(row) ? 'expand' : 'collapse');
            (0, _event.stopImmediatePropagation)(event);
        }
    }
    /**
   * Translate visual row after trimming to physical base row index.
   *
   * @private
   * @param {number} row Row index.
   * @returns {number} Base row index.
   */ translateTrimmedRow(row) {
        return this.hot.toPhysicalRow(row);
    }
    /**
   * Translate physical row after trimming to visual base row index.
   *
   * @private
   * @param {number} row Row index.
   * @returns {number} Base row index.
   */ untranslateTrimmedRow(row) {
        return this.hot.toVisualRow(row);
    }
    /**
   * Helper function to render the table and call the `adjustElementsSize` method.
   *
   * @private
   */ renderAndAdjust() {
        // Dirty workaround to prevent scroll height not adjusting to the table height. Needs refactoring in the future.
        this.hot.view.adjustElementsSize();
        this.hot.render();
    }
    /**
   * Initializes the collapsing UI component and sets up the stash mechanism for preserving collapsed row state across operations.
   */ constructor(nestedRowsPlugin, hotInstance){
        super(nestedRowsPlugin, hotInstance), _class_private_method_init(this, _getDestinationCollapsedRows), _class_private_method_init(this, _isCollapsibleParent), _class_private_method_init(this, _isSameCollapsedState), _class_private_method_init(this, _getTopLevelParents);
        /**
     * Reference to the TrimRows plugin.
     */ this.dataManager = this.plugin.dataManager;
        this.collapsedRows = [];
        this.collapsedRowsStash = {
            stash: (forceRender = false)=>{
                this.lastCollapsedRows = this.collapsedRows.slice(0);
                // Workaround for wrong indexes being set in the trimRows plugin
                this.expandMultipleChildren(this.lastCollapsedRows ?? [], forceRender);
            },
            shiftStash: (baseIndex, targetIndex = undefined, delta = 1)=>{
                const targetIdx = targetIndex === null || targetIndex === undefined ? Infinity : targetIndex;
                (0, _array.arrayEach)(this.lastCollapsedRows ?? [], (elem, i)=>{
                    if (elem >= baseIndex && elem < targetIdx) {
                        this.lastCollapsedRows[i] = elem + delta;
                    }
                });
            },
            applyStash: (forceRender = true)=>{
                this.collapseMultipleChildren(this.lastCollapsedRows ?? [], forceRender);
                this.lastCollapsedRows = undefined;
            },
            trimStash: (realElementIndex, amount)=>{
                (0, _number.rangeEach)(realElementIndex, realElementIndex + amount - 1, (i)=>{
                    const indexOfElement = this.lastCollapsedRows.indexOf(i);
                    if (indexOfElement > -1) {
                        this.lastCollapsedRows.splice(indexOfElement, 1);
                    }
                });
            }
        };
    }
}
function getDestinationCollapsedRows(currentCollapsedRows, parents, isCollapse) {
    const collapsible = parents.filter((parent)=>_class_private_method_get(this, _isCollapsibleParent, isCollapsibleParent).call(this, parent));
    if (isCollapse) {
        const destination = currentCollapsedRows.slice();
        collapsible.forEach((parent)=>{
            if (destination.indexOf(parent) === -1) {
                destination.push(parent);
            }
        });
        return destination.sort((a, b)=>a - b);
    }
    return currentCollapsedRows.filter((parent)=>collapsible.indexOf(parent) === -1);
}
function isCollapsibleParent(parent) {
    if (!Number.isInteger(parent) || parent < 0) {
        return false;
    }
    const rowObject = this.dataManager.getDataObject(parent);
    return !!rowObject && this.dataManager.hasChildren(rowObject);
}
function isSameCollapsedState(snapshot) {
    const current = this.getCollapsedParents();
    return current.length === snapshot.length && current.every((row, index)=>row === snapshot[index]);
}
function getTopLevelParents() {
    const data = this.dataManager.getData() ?? [];
    const parents = [];
    (0, _array.arrayEach)(data, (elem)=>{
        if (this.dataManager.hasChildren(elem)) {
            const rowIndex = this.dataManager.getRowIndex(elem);
            if (rowIndex !== null) {
                parents.push(rowIndex);
            }
        }
    });
    return parents;
}
const _default = CollapsingUI;
