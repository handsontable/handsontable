"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _number = require("../../../helpers/number");
const _array = require("../../../helpers/array");
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
const _base = /*#__PURE__*/ _interop_require_default(require("./_base"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
var /**
   * Map of context menu entry keys to their handler functions that modify the nested row structure.
   */ _menuEntries = /*#__PURE__*/ new WeakMap();
/**
 * Class responsible for the Context Menu entries for the Nested Rows plugin.
 *
 * @private
 * @class ContextMenuUI
 * @augments BaseUI
 */ class ContextMenuUI extends _base.default {
    /**
   * Append options to the context menu. (Propagated from the `afterContextMenuDefaultOptions` hook callback)
   * f.
   *
   * @private
   * @param {object} defaultOptions Default context menu options.
   * @returns {*}
   */ appendOptions(defaultOptions) {
        const newEntries = [
            {
                key: 'add_child',
                name () {
                    return String(this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD));
                },
                callback: ()=>{
                    const selectedActive = this.hot.getSelectedActive();
                    const translatedRowIndex = this.dataManager.translateTrimmedRow(selectedActive?.[0] ?? 0);
                    const parent = this.dataManager.getDataObject(translatedRowIndex);
                    this.dataManager.addChild(parent);
                },
                disabled: ()=>{
                    const selected = this.hot.getSelectedActive();
                    return !selected || (selected[0] ?? 0) < 0 || this.hot.selection.isSelectedByColumnHeader() || this.hot.countRows() >= (this.hot.getSettings().maxRows ?? Infinity);
                }
            },
            {
                key: 'detach_from_parent',
                name () {
                    return String(this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD));
                },
                callback: ()=>{
                    this.dataManager.detachFromParent(this.hot.getSelectedActive() ?? []);
                },
                disabled: ()=>{
                    const selected = this.hot.getSelectedActive();
                    const translatedRowIndex = this.dataManager.translateTrimmedRow(selected?.[0] ?? 0);
                    const parent = this.dataManager.getRowParent(translatedRowIndex);
                    return !parent || !selected || (selected[0] ?? 0) < 0 || this.hot.selection.isSelectedByColumnHeader() || this.hot.countRows() >= (this.hot.getSettings().maxRows ?? Infinity);
                }
            },
            {
                name: '---------'
            }
        ];
        (0, _number.rangeEach)(0, defaultOptions.items.length - 1, (i)=>{
            if (i === 0) {
                (0, _array.arrayEach)(newEntries, (val, j)=>{
                    defaultOptions.items.splice(i + j, 0, val);
                });
                return false;
            }
        });
        return this.modifyRowInsertingOptions(defaultOptions);
    }
    /**
   * Modify how the row inserting options work.
   *
   * @private
   * @param {object} defaultOptions Default context menu items.
   * @returns {*}
   */ modifyRowInsertingOptions(defaultOptions) {
        (0, _number.rangeEach)(0, defaultOptions.items.length - 1, (i)=>{
            const option = _class_private_field_get(this, _menuEntries)[defaultOptions.items[i].key];
            if (option !== null && option !== undefined) {
                defaultOptions.items[i].callback = option;
            }
        });
        return defaultOptions;
    }
    constructor(...args){
        super(...args), _class_private_field_init(this, _menuEntries, {
            writable: true,
            value: void 0
        }), /**
   * Reference to the DataManager instance connected with the Nested Rows plugin.
   *
   * @type {DataManager}
   */ this.dataManager = this.plugin.dataManager, _class_private_field_set(this, _menuEntries, {
            row_above: (key, selection)=>{
                const lastSelection = selection[selection.length - 1];
                this.dataManager.addSibling(lastSelection.start.row, 'above');
            },
            row_below: (key, selection)=>{
                const lastSelection = selection[selection.length - 1];
                this.dataManager.addSibling(lastSelection.start.row, 'below');
            }
        });
    }
}
const _default = ContextMenuUI;
