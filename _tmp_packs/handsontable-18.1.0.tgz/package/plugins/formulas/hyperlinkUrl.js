"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "resolveHyperlinkUrl", {
    enumerable: true,
    get: function() {
        return resolveHyperlinkUrl;
    }
});
/**
 * URL schemes a `HYPERLINK` cell may link to. Everything outside this list is refused, which is what
 * keeps `javascript:`, `data:` and `vbscript:` payloads out of the anchor's `href`. Default
 * sanitization is a pass-through in this codebase, so the guard cannot be delegated to a sanitizer.
 */ const ALLOWED_PROTOCOLS = new Set([
    'http:',
    'https:',
    'mailto:',
    'tel:'
]);
function resolveHyperlinkUrl(rawUrl, baseUrl) {
    if (typeof rawUrl !== 'string' || rawUrl.trim() === '') {
        return null;
    }
    let url;
    try {
        url = new URL(rawUrl, baseUrl);
    } catch (error) {
        return null;
    }
    return ALLOWED_PROTOCOLS.has(url.protocol) ? url.href : null;
}
