"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Formulas () {
        return Formulas;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    },
    get SETTING_KEYS () {
        return SETTING_KEYS;
    }
});
const _base = require("../base");
const _staticRegister = require("../../utils/staticRegister");
const _console = require("../../helpers/console");
const _number = require("../../helpers/number");
const _object = require("../../helpers/object");
const _mixed = require("../../helpers/mixed");
const _register = require("./engine/register");
const _utils = require("./utils");
const _hyperlinkUrl = require("./hyperlinkUrl");
const _settings = require("./engine/settings");
const _data = require("../../helpers/data");
const _string = require("../../helpers/string");
const _valueAccessors = require("../../utils/valueAccessors");
const _hooks = require("../../core/hooks");
const _indexSyncer = /*#__PURE__*/ _interop_require_default(require("./indexSyncer"));
const _range = require("../../3rdparty/walkontable/src/cell/range");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * Narrow an arbitrary value to a HyperFormula cell change shape.
 *
 * @param {unknown} value Value to check.
 * @returns {boolean} `true` if the value matches the cell change shape.
 */ function isHFCellChange(value) {
    return typeof value === 'object' && value !== null;
}
/**
 * Narrow the raw `formulas` setting value to the object form.
 *
 * @param {unknown} value Raw setting value.
 * @returns {boolean} `true` when the value is a settings object.
 */ function isFormulasSettingsObject(value) {
    return typeof value === 'object' && value !== null;
}
/**
 * Narrow a value to an object with a `value` property.
 *
 * @param {unknown} candidate Value to check.
 * @returns {boolean} `true` when the value is an object exposing a `value` property.
 */ function hasValueProperty(candidate) {
    return typeof candidate === 'object' && candidate !== null && 'value' in candidate;
}
const PLUGIN_KEY = 'formulas';
const SETTING_KEYS = [
    'maxRows',
    'maxColumns',
    'language'
];
const PLUGIN_PRIORITY = 260;
_hooks.Hooks.getSingleton().register('afterNamedExpressionAdded');
_hooks.Hooks.getSingleton().register('afterNamedExpressionRemoved');
_hooks.Hooks.getSingleton().register('afterSheetAdded');
_hooks.Hooks.getSingleton().register('afterSheetRemoved');
_hooks.Hooks.getSingleton().register('afterSheetRenamed');
_hooks.Hooks.getSingleton().register('afterFormulasValuesUpdate');
// This function will be used for detecting changes coming from the `UndoRedo` plugin. This kind of change won't be
// handled by whole body of listeners and therefore won't change undo/redo stack inside engine provided by HyperFormula.
// HyperFormula's `undo` and `redo` methods will do it instead. Please keep in mind that undo/redo stacks inside
// instances of Handsontable and HyperFormula should be synced (number of actions should be the same).
const isBlockedSource = (source)=>source === 'UndoRedo.undo' || source === 'UndoRedo.redo' || source === 'auto';
// Maximum number of `[startIndex, amount]` spans passed to a single variadic engine
// `removeRows`/`removeColumns` call. An unbounded argument spread could overflow the call stack.
const REMOVAL_SPANS_CHUNK_SIZE = 1000;
// Group under which the plugin's grid shortcuts are registered, so `disablePlugin` can drop them all.
const SHORTCUTS_GROUP = PLUGIN_KEY;
// Class name of the anchor that wraps the content of a `HYPERLINK` cell. It is also the marker that
// keeps the wrapping idempotent when a renderer leaves the previous DOM in place.
const HYPERLINK_CLASS_NAME = 'ht-hyperlink';
// `warnOnce` key for a `HYPERLINK` URL refused by the protocol allowlist. Warning per cell would
// flood the console on every render pass.
const HYPERLINK_WARN_KEY = 'formulas-hyperlink-refused';
var /**
   * Flag used to bypass hooks in internal operations.
   *
   * @private
   * @type {boolean}
   */ _internalOperationPending = /*#__PURE__*/ new WeakMap(), /**
   * Whether `HYPERLINK` cells are rendered as links. Mirrors the `hyperlinks` plugin setting, cached
   * because it is read once per rendered cell.
   */ _hyperlinksEnabled = /*#__PURE__*/ new WeakMap(), /**
   * Flag needed to mark if Handsontable was initialized with no data.
   * (Required to work around the fact, that Handsontable auto-generates sample data, when no data is provided).
   *
   * @type {boolean}
   */ _hotWasInitializedWithEmptyData = /*#__PURE__*/ new WeakMap(), /**
   * Stores the HyperFormula source range and destination address prepared in `beforeMoveCells` so that
   * `commitPendingMoveCells` can execute the corresponding HF operation without recomputing
   * visual-to-HF coordinates. `rect` carries the same operation in visual coordinates for the
   * post-commit data sync.
   *
   * Set to `null` when no move is in flight.
   *
   * @private
   * @type {{ source: object, dest: object, isCopy: boolean, rect: object }|null}
   */ _pendingMoveCells = /*#__PURE__*/ new WeakMap(), /**
   * The visual rectangle of the operation `commitPendingMoveCells` committed to the engine (or
   * intentionally skipped during undo/redo replay). Consumed by the `afterMoveCells` listener,
   * which runs the HOT-data sync only for committed operations and only off this value — never
   * off its own hook arguments, which a preceding listener's return value can replace.
   *
   * Set to `null` when no committed move is awaiting its sync.
   *
   * @private
   * @type {object|null}
   */ _committedMoveCells = /*#__PURE__*/ new WeakMap(), /**
   * `true` while a move-cells redo is replaying through the MoveCells plugin.
   *
   * Unlike other redo actions, it must validate the Handsontable move before advancing
   * HyperFormula, so `commitPendingMoveCells` performs the engine operation itself.
   */ _isRedoingMoveCells = /*#__PURE__*/ new WeakMap(), /**
   * The dependent-cell changes returned by the engine operation in `commitPendingMoveCells`,
   * consumed by the `afterMoveCells` listener to re-render dependent sheets. `null` when the
   * engine step was skipped (undo/redo replay re-renders everything anyway).
   *
   * @private
   * @type {unknown[]|null}
   */ _moveCellsChanges = /*#__PURE__*/ new WeakMap(), /**
   * Guard flag set while writing synced values back to HOT after a `moveCells` operation.
   * Prevents the `afterSetDataAtCell` / `afterSetSourceDataAtCell` hooks from re-writing
   * the same values into HyperFormula a second time.
   *
   * @private
   * @type {boolean}
   */ _moveCellsSyncPending = /*#__PURE__*/ new WeakMap(), /**
   * Guard flag set while `#getProcessedSourceDataArray` reads the source data on the engine's
   * behalf. Read by `#onModifySourceData` alone, so the read reports what Handsontable stores
   * without also suspending the value projection every other hook depends on.
   *
   * @private
   * @type {boolean}
   */ _sourceDataProjectionSuspended = /*#__PURE__*/ new WeakMap(), /**
   * The changes that the engine reported while undoing or redoing an action. They are collected in
   * `beforeUndo`/`beforeRedo` and consumed in `afterUndo`/`afterRedo`, where the dependent cells get
   * validated.
   *
   * @type {Array}
   */ _undoRedoDependentCells = /*#__PURE__*/ new WeakMap(), /**
   * The addresses of the cells that the `UndoRedo` plugin writes through `setDataAtCell`. The Core
   * validates those on its own, so they are excluded from the dependent-cell validation.
   *
   * Cells restored through `setSourceDataAtCell` are deliberately absent: that path runs
   * `sourceDataValidator`, which never touches the `valid` flag, so excluding them would leave them
   * unvalidated by anyone.
   *
   * @type {Array}
   */ _undoRedoChangedCells = /*#__PURE__*/ new WeakMap(), /**
   * Whether the action being undone or redone wrote any cell data. Only then are the dependent cells
   * worth validating.
   *
   * @type {boolean}
   */ _undoRedoWroteData = /*#__PURE__*/ new WeakMap(), /**
   * Maps a HyperFormula `ExportedCellChange` to the same change with `newValue` translated to a
   * Handsontable-formatted string when the target cell is of type `date` or `time`. For other cells
   * (or non-numeric values, or named expressions, or trimmed cells, or cells on other sheets), the
   * original change is returned unchanged.
   *
   * @param {object} change The HyperFormula exported change.
   * @returns {object}
   */ _exportChangeValue = /*#__PURE__*/ new WeakSet(), /**
   * Called when a value is updated in the engine.
   *
   * @fires Hooks#afterFormulasValuesUpdate
   * @param {Array} changes The values and location of applied changes.
   */ _onEngineValuesUpdated = /*#__PURE__*/ new WeakMap(), /**
   * Called when a named expression is added to the engine instance.
   *
   * @fires Hooks#afterNamedExpressionAdded
   * @param {string} namedExpressionName The name of the added expression.
   * @param {Array} changes The values and location of applied changes.
   */ _onEngineNamedExpressionsAdded = /*#__PURE__*/ new WeakMap(), /**
   * Called when a named expression is removed from the engine instance.
   *
   * @fires Hooks#afterNamedExpressionRemoved
   * @param {string} namedExpressionName The name of the removed expression.
   * @param {Array} changes The values and location of applied changes.
   */ _onEngineNamedExpressionsRemoved = /*#__PURE__*/ new WeakMap(), /**
   * Called when a new sheet is added to the engine instance.
   *
   * @fires Hooks#afterSheetAdded
   * @param {string} addedSheetDisplayName The name of the added sheet.
   */ _onEngineSheetAdded = /*#__PURE__*/ new WeakMap(), /**
   * Called when a sheet in the engine instance is renamed.
   *
   * @fires Hooks#afterSheetRenamed
   * @param {string} oldDisplayName The old name of the sheet.
   * @param {string} newDisplayName The new name of the sheet.
   */ _onEngineSheetRenamed = /*#__PURE__*/ new WeakMap(), /**
   * Called when a sheet is removed from the engine instance.
   *
   * @fires Hooks#afterSheetRemoved
   * @param {string} removedSheetDisplayName The removed sheet name.
   * @param {Array} changes The values and location of applied changes.
   */ _onEngineSheetRemoved = /*#__PURE__*/ new WeakMap(), /**
   * The list of the HyperFormula listeners.
   *
   * @type {Array}
   */ _engineListeners = /*#__PURE__*/ new WeakMap(), /**
   * Update sheetName and sheetId properties.
   *
   * @param {string} [sheetName] The new sheet name.
   */ _updateSheetNameAndSheetId = /*#__PURE__*/ new WeakSet(), /**
   * Reads the `hyperlinks` plugin setting into the cached flag.
   */ _refreshHyperlinksSetting = /*#__PURE__*/ new WeakSet(), /**
   * Unwraps every `HYPERLINK` anchor currently in the grid, including the overlay clones.
   *
   * Disabling the plugin removes the `afterRenderer` hook, so a renderer that leaves its previous
   * DOM in place would keep its cells clickable with nothing left to clean them up. The anchors are
   * matched by the plugin's own class, so no knowledge of the rendering internals is needed.
   */ _unwrapRenderedHyperlinks = /*#__PURE__*/ new WeakSet(), /**
   * Moves an anchor's content up into the anchor's own parent and drops the anchor.
   *
   * The insertion goes through `link.parentNode` rather than the cell: a renderer that leaves the
   * previous DOM in place can wrap an existing anchor, leaving it as `TD > div > a` instead of a
   * direct child. Inserting relative to the cell would then throw `NotFoundError` and, because this
   * runs inside `afterRenderer`, take the whole draw down with it.
   *
   * @param {Element} link The anchor to unwrap.
   */ _unwrapLink = /*#__PURE__*/ new WeakSet(), /**
   * Moves the content of a cell's `HYPERLINK` anchor back into the cell and drops the anchor. Loops
   * so that anchors nested by an older render pass are unwrapped as well.
   *
   * @param {HTMLTableCellElement} TD The rendered cell element.
   */ _unwrapHyperlink = /*#__PURE__*/ new WeakSet(), /**
   * Returns the URL that a cell should link to, or `null` when the cell must not become a link.
   *
   * The engine reports a hyperlink only for a cell whose root expression is `HYPERLINK()`, so a
   * nested call such as `=CONCATENATE("see ", HYPERLINK(...))` resolves to `null` here.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @returns {string|null} The resolved absolute URL, or `null`.
   */ _getHyperlinkHref = /*#__PURE__*/ new WeakSet(), /**
   * Records that the action being undone or redone wrote cell data, and - when the Core validates
   * that write itself - which cells it wrote, so that `#validateUndoRedoDependentCells` can skip
   * them.
   *
   * `coreValidatesWrite` separates the two write paths. `setDataAtCell` ends in the Core's own
   * `validateCell`, so those cells must be excluded to avoid validating them twice.
   * `setSourceDataAtCell` does not - it runs `sourceDataValidator`, which never touches the `valid`
   * flag - so its cells must stay in the validation pass. Skipping them is also why their row index
   * is never translated here: that hook reports physical rows, unlike `afterSetDataAtCell`.
   *
   * @param {Array[]} changes An array of changes in format [[row, prop, oldValue, value], ...].
   * @param {string} source String that identifies the source of the hook call.
   * @param {boolean} coreValidatesWrite `true` when the Core validates the written cells itself.
   */ _registerUndoRedoWrite = /*#__PURE__*/ new WeakSet(), /**
   * Validates the cells that the engine recalculated while an action was undone or redone.
   *
   * The `afterSetDataAtCell` and `afterSetSourceDataAtCell` listeners ignore changes coming from the
   * `UndoRedo` plugin, because the engine reverts them through its own undo stack. Without this step
   * the dependent formula cells would keep the `valid` flag they were given before the action was
   * reverted - a formula cell that turned into an error, and is a correct value again after the undo,
   * would stay marked as invalid.
   *
   * Runs only when the action wrote cell data. That covers undoing an edit (`setDataAtCell`) and
   * undoing a row or column removal, which restores the data with `setSourceDataAtCell`. Actions
   * that only reorder or hide - moving, sorting, filtering, merging - write no data, do not validate
   * dependent cells outside of undo either, and are skipped.
   */ _validateUndoRedoDependentCells = /*#__PURE__*/ new WeakSet(), /**
   * Get the value to be passed to the formula engine.
   * If the value is an object, utilize the valueGetter for that cell, otherwise return the value as is.
   *
   * @param {number} row The physical row index.
   * @param {number} column The physical column index.
   * @param {*} value The value to be passed to the formula engine.
   * @returns {*} The value to be displayed in the cell.
   */ _getValueGetterValue = /*#__PURE__*/ new WeakSet(), /**
   * Get the source data array to be passed to the formula engine.
   * If the value is an object, utilize the valueGetter for that cell, otherwise return the value as is.
   *
   * @param {number} [row] The starting visual row index.
   * @param {number} [column] The starting visual column index.
   * @param {number} [row2] The ending visual row index.
   * @param {number} [column2] The ending visual column index.
   * @returns {Array} The source data array to be passed to the formula engine.
   */ _getProcessedSourceDataArray = /*#__PURE__*/ new WeakSet(), /**
   * The hook allows to translate the formula value to calculated value before it goes to the
   * validator function.
   *
   * @param {*} value The cell value to validate.
   * @param {number} visualRow The visual row index.
   * @param {number|string} prop The visual column index or property name of the column.
   * @returns {*} Returns value to validate.
   */ _onBeforeValidate = /*#__PURE__*/ new WeakMap(), /**
   * `onBeforeAutofill` hook callback.
   *
   * @param {Array[]} fillData The data that was used to fill the `targetRange`. If `beforeAutofill` was used
   * and returned `[[]]`, this will be the same object that was returned from `beforeAutofill`.
   * @param {CellRange} sourceRange The range values will be filled from.
   * @param {CellRange} targetRange The range new values will be filled into.
   * @returns {boolean|*}
   */ _onBeforeAutofill = /*#__PURE__*/ new WeakMap(), /**
   * `beforeLoadData` hook callback.
   *
   * @param {Array} sourceData Array of arrays or array of objects containing data.
   * @param {boolean} initialLoad Flag that determines whether the data has been loaded during the initialization.
   * @param {string} [source] Source of the call.
   */ _onBeforeLoadData = /*#__PURE__*/ new WeakMap(), /**
   * Callback to `afterCellMetaReset` hook which is triggered after setting cell meta.
   */ _onAfterCellMetaReset = /*#__PURE__*/ new WeakMap(), /**
   * `afterLoadData` hook callback.
   *
   * @param {Array} sourceData Array of arrays or array of objects containing data.
   * @param {boolean} initialLoad Flag that determines whether the data has been loaded during the initialization.
   * @param {string} [source] Source of the call.
   */ _onAfterLoadData = /*#__PURE__*/ new WeakMap(), /**
   * `modifyData` hook callback.
   *
   * @param {number} visualRow Visual row index.
   * @param {number} visualColumn Visual column index.
   * @param {object} valueHolder Object which contains original value which can be modified by overwriting `.value`
   *   property.
   * @param {string} ioMode String which indicates for what operation hook is fired (`get` or `set`).
   */ _onModifyData = /*#__PURE__*/ new WeakMap(), /**
   * `afterRenderer` hook callback. Wraps the already rendered content of a `HYPERLINK` cell in an
   * anchor. The cell keeps its own renderer and its cell meta is left untouched, so disabling the
   * plugin or clearing the formula needs no cleanup.
   *
   * @param {HTMLTableCellElement} TD The rendered cell element.
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   */ _onAfterRenderer = /*#__PURE__*/ new WeakMap(), /**
   * `modifySourceData` hook callback.
   *
   * @param {number} row Physical row index.
   * @param {number|string} columnOrProp Physical column index or prop.
   * @param {object} valueHolder Object which contains original value which can be modified by overwriting `.value`
   *   property.
   * @param {string} ioMode String which indicates for what operation hook is fired (`get` or `set`).
   */ _onModifySourceData = /*#__PURE__*/ new WeakMap(), /**
   * `onAfterSetDataAtCell` hook callback.
   *
   * @param {Array[]} changes An array of changes in format [[row, prop, oldValue, value], ...].
   * @param {string} [source] String that identifies source of hook call
   *                          ([list of all available sources](@/guides/getting-started/events-and-hooks/events-and-hooks.md#definition-for-source-argument)).
   */ _onAfterSetDataAtCell = /*#__PURE__*/ new WeakMap(), /**
   * `onAfterSetSourceDataAtCell` hook callback.
   *
   * @param {Array[]} changes An array of changes in format [[row, column, oldValue, value], ...].
   * @param {string} [source] String that identifies source of hook call
   *                          ([list of all available sources](@/guides/getting-started/events-and-hooks/events-and-hooks.md#definition-for-source-argument)).
   */ _onAfterSetSourceDataAtCell = /*#__PURE__*/ new WeakMap(), /**
   * `beforeCreateRow` hook callback.
   *
   * @param {number} visualRow Represents the visual index of first newly created row in the data source array.
   * @param {number} amount Number of newly created rows in the data source array.
   * @returns {*|boolean} If false is returned the action is canceled.
   */ _onBeforeCreateRow = /*#__PURE__*/ new WeakMap(), /**
   * `beforeCreateCol` hook callback.
   *
   * @param {number} visualColumn Represents the visual index of first newly created column in the data source.
   * @param {number} amount Number of newly created columns in the data source.
   * @returns {*|boolean} If false is returned the action is canceled.
   */ _onBeforeCreateCol = /*#__PURE__*/ new WeakMap(), /**
   * `beforeRemoveRow` hook callback.
   *
   * @param {number} row Visual index of starter row.
   * @param {number} amount Amount of rows to be removed.
   * @param {number[]} physicalRows An array of physical rows removed from the data source.
   * @returns {*|boolean} If false is returned the action is canceled.
   */ _onBeforeRemoveRow = /*#__PURE__*/ new WeakMap(), /**
   * `beforeRemoveCol` hook callback.
   *
   * @param {number} col Visual index of starter column.
   * @param {number} amount Amount of columns to be removed.
   * @param {number[]} physicalColumns An array of physical columns removed from the data source.
   * @returns {*|boolean} If false is returned the action is canceled.
   */ _onBeforeRemoveCol = /*#__PURE__*/ new WeakMap(), /**
   * `afterCreateRow` hook callback.
   *
   * @param {number} visualRow Represents the visual index of first newly created row in the data source array.
   * @param {number} amount Number of newly created rows in the data source array.
   * @param {string} [source] String that identifies source of hook call
   *                          ([list of all available sources](@/guides/getting-started/events-and-hooks/events-and-hooks.md#definition-for-source-argument)).
   */ _onAfterCreateRow = /*#__PURE__*/ new WeakMap(), /**
   * `afterCreateCol` hook callback.
   *
   * @param {number} visualColumn Represents the visual index of first newly created column in the data source.
   * @param {number} amount Number of newly created columns in the data source.
   * @param {string} [source] String that identifies source of hook call
   *                          ([list of all available sources](@/guides/getting-started/events-and-hooks/events-and-hooks.md#definition-for-source-argument)).
   */ _onAfterCreateCol = /*#__PURE__*/ new WeakMap(), /**
   * `afterRemoveRow` hook callback.
   *
   * @param {number} row Visual index of starter row.
   * @param {number} amount An amount of removed rows.
   * @param {number[]} physicalRows An array of physical rows removed from the data source.
   * @param {string} [source] String that identifies source of hook call
   *                          ([list of all available sources](@/guides/getting-started/events-and-hooks/events-and-hooks.md#definition-for-source-argument)).
   */ _onAfterRemoveRow = /*#__PURE__*/ new WeakMap(), /**
   * `afterRemoveCol` hook callback.
   *
   * @param {number} col Visual index of starter column.
   * @param {number} amount An amount of removed columns.
   * @param {number[]} physicalColumns An array of physical columns removed from the data source.
   * @param {string} [source] String that identifies source of hook call
   *                          ([list of all available sources](@/guides/getting-started/events-and-hooks/events-and-hooks.md#definition-for-source-argument)).
   */ _onAfterRemoveCol = /*#__PURE__*/ new WeakMap(), /**
   * Checks whether every visual index in the `[visualFrom, visualTo]` span maps to consecutive
   * HyperFormula indexes on the given axis. Only then is a visual rectangle equivalent to the
   * single HF rectangle the `moveCells` engine operation works on.
   *
   * @param {AxisSyncer} syncer The row or column axis syncer.
   * @param {number} visualFrom The first visual index of the span.
   * @param {number} visualTo The last visual index of the span.
   * @returns {boolean}
   */ _mapsToContiguousHfBlock = /*#__PURE__*/ new WeakSet(), /**
   * `beforeMoveCells` hook callback.
   *
   * Converts the visual source range and target top-left corner to HyperFormula
   * (physical) coordinates, validates feasibility for a MOVE operation, and stores
   * the converted addresses for use in the `afterMoveCells` handler.
   *
   * Returns `false` to veto the whole operation when the source range is not a valid range
   * (the documented `false` veto value, or garbage folded into the argument by a preceding
   * listener's truthy return value), when HyperFormula reports the move is not possible
   * (e.g. the source or target contains an array formula), or when the visual ranges do not map
   * to contiguous HF blocks (trimmed/filtered/reordered indexes), because the engine rectangle
   * would then cover cells outside the visual operation.
   *
   * @param {CellRange|boolean} sourceRange The visual source range, or `false` after an earlier veto.
   * @param {CellCoords} targetTopLeft The visual top-left of the destination.
   * @param {boolean} isCopy `true` when copying (not moving) cells.
   * @returns {boolean|undefined} `false` to cancel the operation; `undefined` otherwise.
   */ _onBeforeMoveCells = /*#__PURE__*/ new WeakMap(), /**
   * `afterMoveCells` hook callback.
   *
   * Runs after the engine operation already executed in `commitPendingMoveCells` (the core
   * calls it before mutating the grid, so a failed engine operation never reaches this hook).
   * Synchronises HOT's source data array with HF's state so that `getDataAtCell` returns
   * correct values for plain VALUE / EMPTY cells (formula cells are already served from HF
   * via the `modifyData` hook), then re-renders the dependent sheets. The sync is guarded by
   * `#moveCellsSyncPending` so that `afterSetDataAtCell` does not re-write the same values
   * back into HyperFormula.
   *
   * Takes no arguments on purpose. The engine has already moved the cells by the time this runs, so
   * there is nothing left to veto and bailing out would strand the data source out of sync with the
   * engine — which is what reading the replaceable `sourceRange` argument used to cause. The
   * operation is read from `#committedMoveCells` instead, captured before any listener could run.
   */ _onAfterMoveCells = /*#__PURE__*/ new WeakMap(), /**
   * Synchronises HOT's raw data source array with HyperFormula's state after a
   * `moveCells` or copy operation.
   *
   * Formula cells are already served correctly through `modifyData` via `getCellValue`.
   * Plain VALUE / EMPTY cells, however, fall back to the raw HOT data, so after HF
   * moves the data the old raw values must be cleared from the source cells and the
   * serialised HF content must be written to the target cells.
   *
   * The write is fenced with `#moveCellsSyncPending` to prevent the `afterSetDataAtCell`
   * hook from re-syncing the same data back into HyperFormula.
   *
   * @private
   * @param {object} rect The committed operation in visual coordinates.
   */ _syncHotDataAfterMoveCells = /*#__PURE__*/ new WeakSet(), /**
   * Removes the provided `[startIndex, amount]` spans from the engine in as few calls as possible.
   * One call handles many spans, so the engine pays its dependency-graph remap once per call instead
   * of once per removed row or column. The engine methods are variadic, so the spans are chunked to
   * keep the argument spread within call-stack limits; chunks run from the highest spans down, which
   * keeps the original coordinates of the not-yet-removed lower spans valid.
   *
   * @param {Array<Array<number>>} spans Ascending list of `[startIndex, amount]` spans to remove.
   * @param {'removeRows'|'removeColumns'} engineMethodName The engine removal method to call.
   */ _removeSpansFromEngine = /*#__PURE__*/ new WeakSet(), /**
   * `afterDetachChild` hook callback.
   * Used to sync the data of the rows detached in the Nested Rows plugin with the engine's dataset.
   *
   * @param {object} parent An object representing the parent from which the element was detached.
   * @param {object} element The detached element.
   * @param {number} finalElementRowIndex The final row index of the detached element.
   */ _onAfterDetachChild = /*#__PURE__*/ new WeakMap();
class Formulas extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns the list of settings keys observed by the plugin for configuration changes.
   */ static get SETTING_KEYS() {
        return [
            PLUGIN_KEY,
            ...SETTING_KEYS
        ];
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link Formulas#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        /* eslint-disable no-unneeded-ternary */ return this.hot.getSettings()[PLUGIN_KEY] ? true : false;
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        this.engine = (0, _register.setupEngine)(this.hot) ?? this.engine;
        if (!this.engine) {
            (0, _console.warn)('Missing the required `engine` key in the Formulas settings. Please fill it with either an' + ' engine class or an engine instance.');
            return;
        }
        // Useful for disabling -> enabling the plugin using `updateSettings` or the API.
        if (this.sheetName !== null && !this.engine.doesSheetExist(this.sheetName)) {
            const newSheetName = this.addSheet(this.sheetName, _class_private_method_get(this, _getProcessedSourceDataArray, getProcessedSourceDataArray).call(this));
            if (typeof newSheetName === 'string') {
                _class_private_method_get(this, _updateSheetNameAndSheetId, updateSheetNameAndSheetId).call(this, newSheetName);
            }
        }
        this.addHook('beforeLoadData', _class_private_field_get(this, _onBeforeLoadData));
        this.addHook('afterLoadData', _class_private_field_get(this, _onAfterLoadData));
        // The `updateData` hooks utilize the same logic as the `loadData` hooks.
        this.addHook('beforeUpdateData', _class_private_field_get(this, _onBeforeLoadData));
        this.addHook('afterUpdateData', _class_private_field_get(this, _onAfterLoadData));
        this.addHook('modifyData', _class_private_field_get(this, _onModifyData));
        this.addHook('modifySourceData', _class_private_field_get(this, _onModifySourceData));
        this.addHook('beforeValidate', _class_private_field_get(this, _onBeforeValidate));
        this.addHook('afterSetSourceDataAtCell', _class_private_field_get(this, _onAfterSetSourceDataAtCell));
        this.addHook('afterSetDataAtCell', _class_private_field_get(this, _onAfterSetDataAtCell));
        this.addHook('afterSetDataAtRowProp', _class_private_field_get(this, _onAfterSetDataAtCell));
        this.addHook('beforeCreateRow', _class_private_field_get(this, _onBeforeCreateRow));
        this.addHook('beforeCreateCol', _class_private_field_get(this, _onBeforeCreateCol));
        this.addHook('afterCreateRow', _class_private_field_get(this, _onAfterCreateRow));
        this.addHook('afterCreateCol', _class_private_field_get(this, _onAfterCreateCol));
        this.addHook('beforeRemoveRow', _class_private_field_get(this, _onBeforeRemoveRow));
        this.addHook('beforeRemoveCol', _class_private_field_get(this, _onBeforeRemoveCol));
        this.addHook('afterRemoveRow', _class_private_field_get(this, _onAfterRemoveRow));
        this.addHook('afterRemoveCol', _class_private_field_get(this, _onAfterRemoveCol));
        this.indexSyncer = new _indexSyncer.default(this.hot.rowIndexMapper, this.hot.columnIndexMapper, (postponedAction)=>{
            this.hot.addHookOnce('init', ()=>{
                // Engine is initialized after executing callback to `afterLoadData` hook. Thus, some actions on indexes should
                // be postponed.
                postponedAction();
            });
        });
        this.rowAxisSyncer = this.indexSyncer.getForAxis('row');
        this.columnAxisSyncer = this.indexSyncer.getForAxis('column');
        this.hot.addHook('afterRowSequenceChange', this.rowAxisSyncer.getIndexesChangeSyncMethod());
        this.hot.addHook('afterColumnSequenceChange', this.columnAxisSyncer.getIndexesChangeSyncMethod());
        this.hot.addHook('beforeRowMove', (movedRows, finalIndex, _dropIndex, movePossible)=>{
            this.rowAxisSyncer.storeMovesInformation(movedRows, finalIndex, movePossible);
        });
        this.hot.addHook('beforeColumnMove', (movedColumns, finalIndex, _dropIndex, movePossible)=>{
            this.columnAxisSyncer.storeMovesInformation(movedColumns, finalIndex, movePossible);
        });
        this.hot.addHook('afterRowMove', (_movedRows, _finalIndex, _dropIndex, movePossible, orderChanged)=>{
            this.rowAxisSyncer.calculateAndSyncMoves(movePossible, orderChanged);
        });
        this.hot.addHook('afterColumnMove', (_movedColumns, _finalIndex, _dropIndex, movePossible, orderChanged)=>{
            this.columnAxisSyncer.calculateAndSyncMoves(movePossible, orderChanged);
        });
        this.hot.addHook('beforeColumnFreeze', (column, freezePerformed)=>{
            const fixedColumnsStart = this.hot.getSettings().fixedColumnsStart;
            this.columnAxisSyncer.storeMovesInformation([
                column
            ], fixedColumnsStart, freezePerformed);
        });
        this.hot.addHook('afterColumnFreeze', (_column, freezePerformed)=>{
            this.columnAxisSyncer.calculateAndSyncMoves(freezePerformed, freezePerformed);
        });
        this.hot.addHook('beforeColumnUnfreeze', (column, unfreezePerformed)=>{
            const fixedColumnsStart = this.hot.getSettings().fixedColumnsStart;
            this.columnAxisSyncer.storeMovesInformation([
                column
            ], fixedColumnsStart - 1, unfreezePerformed);
        });
        this.hot.addHook('afterColumnUnfreeze', (_column, unfreezePerformed)=>{
            this.columnAxisSyncer.calculateAndSyncMoves(unfreezePerformed, unfreezePerformed);
        });
        // TODO: Actions related to overwriting dates from HOT format to HF default format are done as callback to this
        // hook, because some hooks, such as `afterLoadData` doesn't have information about composed cell properties.
        // Another hooks are triggered to late for setting HF's engine data needed for some actions.
        this.addHook('afterCellMetaReset', _class_private_field_get(this, _onAfterCellMetaReset));
        // Handling undo actions on data just using HyperFormula's UndoRedo mechanism
        this.addHook('beforeUndo', ()=>{
            this.indexSyncer.setPerformUndo(true);
            _class_private_field_set(this, _undoRedoChangedCells, []);
            _class_private_field_set(this, _undoRedoWroteData, false);
            _class_private_field_set(this, _undoRedoDependentCells, this.engine.undo() ?? []);
        });
        // Handling redo actions on data just using HyperFormula's UndoRedo mechanism.
        this.addHook('beforeRedo', (action)=>{
            // Defensive: `Hooks.run` threads a preceding listener's non-`undefined` return value into
            // this argument, and the global bucket runs before this one. Without a trustworthy
            // `actionType` the engine step cannot be dispatched safely (`engine.redo()` vs the
            // `move_cells` replay path — the wrong branch runs the engine operation twice), so cancel
            // the redo instead of desyncing HyperFormula. The guard runs BEFORE `setPerformRedo(true)`
            // — a cancelled redo never fires `afterRedo`, so a flag set here would leak.
            if (typeof action !== 'object' || action === null || !('actionType' in action)) {
                return false;
            }
            this.indexSyncer.setPerformRedo(true);
            _class_private_field_set(this, _isRedoingMoveCells, action.actionType === 'move_cells');
            _class_private_field_set(this, _undoRedoChangedCells, []);
            _class_private_field_set(this, _undoRedoWroteData, false);
            // For a `move_cells` redo the engine operation runs in `commitPendingMoveCells` (the
            // Handsontable move must be validated first), so `engine.redo()` is not called here and
            // there are no engine-reported dependent cells to collect.
            _class_private_field_set(this, _undoRedoDependentCells, _class_private_field_get(this, _isRedoingMoveCells) ? [] : this.engine.redo() ?? []);
        });
        this.addHook('afterUndo', ()=>{
            this.indexSyncer.setPerformUndo(false);
            // Also clears the redo flags: a redo cancelled by a `beforeRedo` listener never fires
            // `afterRedo`, so without these resets the flags set in `beforeRedo` would leak until the
            // next successful redo.
            this.indexSyncer.setPerformRedo(false);
            _class_private_field_set(this, _isRedoingMoveCells, false);
            _class_private_method_get(this, _validateUndoRedoDependentCells, validateUndoRedoDependentCells).call(this);
        });
        this.addHook('afterRedo', ()=>{
            this.indexSyncer.setPerformRedo(false);
            _class_private_method_get(this, _validateUndoRedoDependentCells, validateUndoRedoDependentCells).call(this);
        });
        this.addHook('afterRedo', ()=>{
            _class_private_field_set(this, _isRedoingMoveCells, false);
        });
        this.addHook('afterDetachChild', _class_private_field_get(this, _onAfterDetachChild));
        this.addHook('beforeAutofill', _class_private_field_get(this, _onBeforeAutofill));
        this.addHook('beforeMoveCells', _class_private_field_get(this, _onBeforeMoveCells));
        this.addHook('afterMoveCells', _class_private_field_get(this, _onAfterMoveCells));
        this.addHook('afterRenderer', _class_private_field_get(this, _onAfterRenderer));
        _class_private_field_get(this, _engineListeners)?.forEach(([eventName, listener])=>this.engine.on(eventName, listener));
        _class_private_method_get(this, _refreshHyperlinksSetting, refreshHyperlinksSetting).call(this);
        this.registerShortcuts();
        super.enablePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        _class_private_method_get(this, _unwrapRenderedHyperlinks, unwrapRenderedHyperlinks).call(this);
        this.unregisterShortcuts();
        _class_private_field_get(this, _engineListeners)?.forEach(([eventName, listener])=>this.engine?.off(eventName, listener));
        if (this.engine) {
            (0, _register.unregisterEngine)(this.engine, this.hot);
        }
        this.engine = null;
        super.disablePlugin();
    }
    /**
   * Triggered on `updateSettings`.
   *
   * @private
   * @param {object} newSettings New set of settings passed to the `updateSettings` method.
   */ updatePlugin(newSettings) {
        const newEngineSettings = (0, _settings.getEngineSettingsWithOverrides)(this.hot.getSettings());
        if (this.engine && (0, _settings.haveEngineSettingsChanged)(this.engine.getConfig(), newEngineSettings)) {
            this.engine.updateConfig(newEngineSettings);
        }
        const pluginSettings = this.hot.getSettings()[PLUGIN_KEY];
        if (pluginSettings !== undefined && typeof pluginSettings !== 'boolean' && pluginSettings.sheetName !== undefined && // Sheet ids are compared rather than names, because `sheetName` holds the engine's casing
        // while the setting keeps the one it was written with. An unknown name has no id, which
        // still differs from the current one and lets `switchSheet` report it.
        this.engine?.getSheetId(pluginSettings.sheetName) !== this.sheetId) {
            this.switchSheet(pluginSettings.sheetName);
        }
        // If no data was passed to the `updateSettings` method and no sheet is connected to the instance -> create a
        // new sheet using the currently used data. Otherwise, it will be handled by the `afterLoadData` call.
        if (!newSettings.data && this.sheetName === null) {
            const formulasSettings = this.hot.getSettings()[PLUGIN_KEY];
            const sheetName = isFormulasSettingsObject(formulasSettings) ? formulasSettings.sheetName : undefined;
            if (sheetName && this.engine?.doesSheetExist(sheetName)) {
                this.switchSheet(sheetName);
            } else {
                const newSheetName = this.addSheet(sheetName ?? undefined, _class_private_method_get(this, _getProcessedSourceDataArray, getProcessedSourceDataArray).call(this));
                if (typeof newSheetName === 'string') {
                    _class_private_method_get(this, _updateSheetNameAndSheetId, updateSheetNameAndSheetId).call(this, newSheetName);
                }
            }
        }
        _class_private_method_get(this, _refreshHyperlinksSetting, refreshHyperlinksSetting).call(this);
        super.updatePlugin(newSettings);
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        _class_private_field_get(this, _engineListeners)?.forEach(([eventName, listener])=>this.engine?.off(eventName, listener));
        _class_private_field_set(this, _engineListeners, null);
        if (this.engine) {
            (0, _register.unregisterEngine)(this.engine, this.hot);
        }
        this.engine = null;
        super.destroy();
    }
    /**
   * Add a sheet to the shared HyperFormula instance.
   *
   * @param {string|null} [sheetName] The new sheet name. If not provided (or a null is passed), will be
   * auto-generated by HyperFormula.
   * @param {Array} [sheetData] Data passed to the shared HyperFormula instance. Has to be declared as an array of
   * arrays - array of objects is not supported in this scenario.
   * @returns {boolean|string} `false` if the data format is unusable or it is impossible to add a new sheet to the
   * engine, the created sheet name otherwise.
   */ addSheet(sheetName, sheetData) {
        if ((0, _mixed.isDefined)(sheetData) && !(0, _data.isArrayOfArrays)(sheetData)) {
            (0, _console.warn)('The provided data should be an array of arrays.');
            return false;
        }
        if (sheetName !== undefined && sheetName !== null && this.engine?.doesSheetExist(sheetName)) {
            (0, _console.warn)('Sheet with the provided name already exists.');
            return false;
        }
        try {
            const actualSheetName = this.engine.addSheet(sheetName ?? undefined);
            if (sheetData) {
                this.engine.setSheetContent(this.engine.getSheetId(actualSheetName), sheetData);
            }
            return actualSheetName;
        } catch (e) {
            (0, _console.warn)(e instanceof Error ? e.message : String(e));
            return false;
        }
    }
    /**
   * Switch the sheet used as data in the Handsontable instance (it loads the data from the shared HyperFormula
   * instance).
   *
   * @param {string} sheetName Sheet name used in the shared HyperFormula instance.
   */ switchSheet(sheetName) {
        if (!this.engine?.doesSheetExist(sheetName)) {
            (0, _console.error)(`The sheet named \`${sheetName}\` does not exist, switch aborted.`);
            return;
        }
        _class_private_method_get(this, _updateSheetNameAndSheetId, updateSheetNameAndSheetId).call(this, sheetName);
        const serialized = this.engine.getSheetSerialized(this.sheetId);
        if (serialized.length > 0) {
            this.hot.loadData(serialized, `${(0, _string.toUpperCaseFirst)(PLUGIN_KEY)}.switchSheet`);
        }
    }
    /**
   * Get the cell type under specified visual coordinates.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {number} [sheet] The target sheet id, defaults to the current sheet.
   * @returns {string} Possible values: 'FORMULA' | 'VALUE' | 'ARRAYFORMULA' | 'EMPTY'.
   */ getCellType(row, column, sheet = this.sheetId) {
        const physicalRow = this.hot.toPhysicalRow(row);
        const physicalColumn = this.hot.toPhysicalColumn(column);
        if (physicalRow !== null && physicalColumn !== null) {
            return this.engine.getCellType({
                sheet,
                row: this.rowAxisSyncer.getHfIndexFromVisualIndex(row),
                col: this.columnAxisSyncer.getHfIndexFromVisualIndex(column)
            });
        } else {
            // Should return `EMPTY` when out of bounds (according to the test cases).
            return 'EMPTY';
        }
    }
    /**
   * Returns `true` if under specified visual coordinates is formula.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {number} [sheet] The target sheet id, defaults to the current sheet.
   * @returns {boolean}
   */ isFormulaCellType(row, column, sheet = this.sheetId) {
        return this.engine.doesCellHaveFormula({
            sheet,
            row: this.rowAxisSyncer.getHfIndexFromVisualIndex(row),
            col: this.columnAxisSyncer.getHfIndexFromVisualIndex(column)
        });
    }
    /**
   * Registers the shortcut that opens the link of the selected `HYPERLINK` cell. The anchor is kept
   * out of the tab order, so this is the only keyboard path to the link.
   *
   * @private
   */ registerShortcuts() {
        this.hot.getShortcutManager().getContext('grid')?.addShortcut({
            keys: [
                [
                    'Alt',
                    'Enter'
                ]
            ],
            callback: ()=>{
                const highlight = this.hot.getSelectedRangeActive()?.highlight;
                if (!highlight || highlight.row === null || highlight.col === null) {
                    return;
                }
                const href = _class_private_method_get(this, _getHyperlinkHref, getHyperlinkHref).call(this, highlight.row, highlight.col);
                if (href !== null) {
                    this.hot.rootWindow.open(href, '_blank', 'noopener,noreferrer');
                }
            },
            stopPropagation: true,
            // The shortcut prevents the default action and stops propagation whenever `runOnlyIf`
            // passes, so it must claim the chord only for a cell that actually resolves to a link.
            // Testing just `isCell()` would swallow `Alt`+`Enter` grid-wide and break a host
            // application's own handler for it.
            runOnlyIf: ()=>{
                const highlight = this.hot.getSelectedRangeActive()?.highlight;
                return _class_private_field_get(this, _hyperlinksEnabled) && !!highlight?.isCell() && highlight.row !== null && highlight.col !== null && _class_private_method_get(this, _getHyperlinkHref, getHyperlinkHref).call(this, highlight.row, highlight.col) !== null;
            },
            group: SHORTCUTS_GROUP
        });
    }
    /**
   * Removes the shortcuts registered by the plugin.
   *
   * @private
   */ unregisterShortcuts() {
        this.hot.getShortcutManager().getContext('grid')?.removeShortcutsByGroup(SHORTCUTS_GROUP);
    }
    /**
   * Renders dependent sheets (handsontable instances) based on the changes - list of the
   * recalculated dependent cells.
   *
   * @private
   * @param {object[]} dependentCells The values and location of applied changes within HF engine.
   * @param {boolean} [renderSelf] `true` if it's supposed to render itself, `false` otherwise.
   */ renderDependentSheets(dependentCells, renderSelf = false) {
        const affectedSheetIds = new Set();
        dependentCells.forEach((change)=>{
            // For the Named expression the address is empty, hence the `sheetId` is undefined.
            const sheetId = isHFCellChange(change) ? change.address?.sheet : undefined;
            if (sheetId !== undefined && !affectedSheetIds.has(sheetId)) {
                affectedSheetIds.add(sheetId);
            }
        });
        if (!this.engine) {
            return;
        }
        (0, _register.getRegisteredHotInstances)(this.engine).forEach((relatedHot, sheetId)=>{
            if ((renderSelf || sheetId !== this.sheetId) && affectedSheetIds.has(sheetId)) {
                relatedHot.render();
                relatedHot.view?.adjustElementsSize();
            }
        });
    }
    /**
   * Validates dependent cells based on the cells that are modified by the change.
   *
   * @private
   * @param {object[]} dependentCells The values and location of applied changes within HF engine.
   * @param {object[]} [changedCells] The values and location of applied changes by developer (through API or UI).
   */ validateDependentCells(dependentCells, changedCells = []) {
        const stringifyAddress = (change)=>{
            const address = isHFCellChange(change) ? change.address : undefined;
            const { row, col, sheet } = address ?? {};
            return (0, _mixed.isDefined)(sheet) ? `${sheet}:${row}x${col}` : '';
        };
        const changedCellsSet = new Set(changedCells.map((change)=>stringifyAddress(change)));
        dependentCells.forEach((change)=>{
            const address = isHFCellChange(change) ? change.address : undefined;
            const { row, col, sheet: sheetId } = address ?? {};
            // Don't try to validate cells outside of the visual part of the table.
            if (row === undefined || col === undefined || row >= this.hot.countRows() || col >= this.hot.countCols()) {
                return;
            }
            const addressId = stringifyAddress(change);
            // Validate the cells that depend on the calculated formulas. Skip that cells
            // where the user directly changes the values - the Core triggers those validators.
            if (sheetId !== undefined && !changedCellsSet.has(addressId) && this.engine) {
                const boundHot = (0, _register.getRegisteredHotInstances)(this.engine).get(sheetId);
                // if `sheetId` is not bound to any Handsontable instance, skip the validation process
                if (!boundHot) {
                    return;
                }
                // It will just re-render certain cell when necessary.
                boundHot.validateCell(boundHot.getDataAtCell(row, col), boundHot.getCellMeta(row, col), ()=>{});
            }
        });
    }
    /**
   * Sync a change from the change-related hooks with the engine.
   *
   * @private
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {Handsontable.CellValue} newValue New value.
   * @returns {Array} Array of changes exported from the engine.
   */ syncChangeWithEngine(row, column, newValue) {
        const address = {
            row: this.rowAxisSyncer.getHfIndexFromVisualIndex(row),
            col: this.columnAxisSyncer.getHfIndexFromVisualIndex(column),
            sheet: this.sheetId
        };
        if (!this.engine?.isItPossibleToSetCellContents(address)) {
            (0, _console.warn)(`Not possible to set cell data at ${JSON.stringify(address)}`);
            return;
        }
        const cellMeta = this.hot.getCellMetaTransient(row, column);
        if ((0, _utils.isDate)(newValue, cellMeta.type)) {
            if ((0, _utils.isDateValid)(newValue)) {
                // Rewriting date in HOT format to HF format.
                newValue = (0, _utils.getDateInHfFormat)(newValue);
            } else if ((0, _utils.isFormula)(newValue) === false) {
                // Escaping value from date parsing using "'" sign (HF feature).
                newValue = `'${newValue}`;
            }
        }
        return this.engine?.setCellContents(address, newValue);
    }
    /**
   * Executes the HyperFormula move or copy operation prepared in `beforeMoveCells`. Called by
   * the MoveCells plugin BEFORE any grid mutation (cell meta, selection, undo history),
   * so a failed engine operation aborts the whole `moveCells` operation atomically instead of
   * leaving the grid state recording a move whose data write never happened.
   *
   * For a MOVE, calls `engine.moveCells`, which physically relocates cell content and adjusts
   * all dependent formula references (Excel-style). For a COPY, calls `engine.copy` followed
   * by `engine.paste`, which duplicates the content with adjusted relative references. Note:
   * `engine.copy` reads cell values and must NOT be wrapped in `engine.batch` because batch
   * suspends evaluation, causing `copy` to throw `EvaluationSuspendedError`.
   *
   * During undo and non-move redo operations, the engine has already been advanced in the
   * `beforeUndo`/`beforeRedo` hook, so this method only enables the HOT-data sync in the
   * `afterMoveCells` listener. A move redo is validated first, then executed here to keep a
   * rejected move from advancing HyperFormula.
   *
   * This is the second half of a two-phase protocol with the MoveCells plugin: `beforeMoveCells`
   * prepares `#pendingMoveCells`, and this method commits it. It is internal despite being reachable
   * through `getPlugin('formulas')` — not part of the public API.
   *
   * @private
   * @returns {boolean} `true` when the engine operation succeeded (or was intentionally
   *   skipped); `false` when there is no prepared operation or the engine rejected it.
   */ commitPendingMoveCells() {
        if (!this.engine || !_class_private_field_get(this, _pendingMoveCells)) {
            return false;
        }
        const { source, dest, isCopy, rect } = _class_private_field_get(this, _pendingMoveCells);
        _class_private_field_set(this, _pendingMoveCells, null);
        _class_private_field_set(this, _moveCellsChanges, null);
        if (this.indexSyncer?.isPerformingUndoRedo() && !_class_private_field_get(this, _isRedoingMoveCells)) {
            _class_private_field_set(this, _committedMoveCells, rect);
            return true;
        }
        // HyperFormula can still throw for cases the isItPossibleTo* pre-checks in
        // `beforeMoveCells` do not cover. Failing here is safe: the core has not mutated
        // anything yet and aborts the whole operation when `false` is returned.
        try {
            if (isCopy) {
                // copy() reads cell values and cannot run inside batch() (evaluation must not be suspended).
                this.engine.copy(source);
                _class_private_field_set(this, _moveCellsChanges, this.engine.paste(dest));
            } else {
                _class_private_field_set(this, _moveCellsChanges, this.engine.batch(()=>{
                    this.engine.moveCells(source, dest);
                }));
            }
        } catch (e) {
            const operation = isCopy ? 'copy/paste' : 'moveCells';
            const reason = e instanceof Error ? e.message : String(e);
            (0, _console.warn)(`Formulas: HyperFormula operation failed during ${operation}: ${reason}`);
            return false;
        }
        _class_private_field_set(this, _committedMoveCells, rect);
        return true;
    }
    constructor(...args){
        super(...args), _class_private_method_init(this, _exportChangeValue), _class_private_method_init(this, _updateSheetNameAndSheetId), _class_private_method_init(this, _refreshHyperlinksSetting), _class_private_method_init(this, _unwrapRenderedHyperlinks), _class_private_method_init(this, _unwrapLink), _class_private_method_init(this, _unwrapHyperlink), _class_private_method_init(this, _getHyperlinkHref), _class_private_method_init(this, _registerUndoRedoWrite), _class_private_method_init(this, _validateUndoRedoDependentCells), _class_private_method_init(this, _getValueGetterValue), _class_private_method_init(this, _getProcessedSourceDataArray), _class_private_method_init(this, _mapsToContiguousHfBlock), _class_private_method_init(this, _syncHotDataAfterMoveCells), _class_private_method_init(this, _removeSpansFromEngine), _class_private_field_init(this, _internalOperationPending, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _hyperlinksEnabled, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _hotWasInitializedWithEmptyData, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _pendingMoveCells, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _committedMoveCells, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _isRedoingMoveCells, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _moveCellsChanges, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _moveCellsSyncPending, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _sourceDataProjectionSuspended, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _undoRedoDependentCells, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _undoRedoChangedCells, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _undoRedoWroteData, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onEngineValuesUpdated, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onEngineNamedExpressionsAdded, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onEngineNamedExpressionsRemoved, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onEngineSheetAdded, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onEngineSheetRenamed, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onEngineSheetRemoved, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _engineListeners, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeValidate, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeAutofill, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeLoadData, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterCellMetaReset, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterLoadData, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onModifyData, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterRenderer, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onModifySourceData, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterSetDataAtCell, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterSetSourceDataAtCell, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeCreateRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeCreateCol, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeRemoveRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeRemoveCol, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterCreateRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterCreateCol, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterRemoveRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterRemoveCol, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeMoveCells, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterMoveCells, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterDetachChild, {
            writable: true,
            value: void 0
        }), _class_private_field_set(this, _internalOperationPending, false), _class_private_field_set(this, _hyperlinksEnabled, false), _class_private_field_set(this, _hotWasInitializedWithEmptyData, false), _class_private_field_set(this, _pendingMoveCells, null), _class_private_field_set(this, _committedMoveCells, null), _class_private_field_set(this, _isRedoingMoveCells, false), _class_private_field_set(this, _moveCellsChanges, null), _class_private_field_set(this, _moveCellsSyncPending, false), _class_private_field_set(this, _sourceDataProjectionSuspended, false), _class_private_field_set(this, _undoRedoDependentCells, []), _class_private_field_set(this, _undoRedoChangedCells, []), _class_private_field_set(this, _undoRedoWroteData, false), _class_private_field_set(this, _onEngineValuesUpdated, (changes)=>{
            const exportedChanges = changes.map((change)=>_class_private_method_get(this, _exportChangeValue, exportChangeValue).call(this, change));
            this.hot.runHooks('afterFormulasValuesUpdate', exportedChanges);
        }), _class_private_field_set(this, _onEngineNamedExpressionsAdded, (namedExpressionName, changes)=>{
            this.hot.runHooks('afterNamedExpressionAdded', namedExpressionName, changes);
        }), _class_private_field_set(this, _onEngineNamedExpressionsRemoved, (namedExpressionName, changes)=>{
            this.hot.runHooks('afterNamedExpressionRemoved', namedExpressionName, changes);
        }), _class_private_field_set(this, _onEngineSheetAdded, (addedSheetDisplayName)=>{
            this.hot.runHooks('afterSheetAdded', addedSheetDisplayName);
        }), _class_private_field_set(this, _onEngineSheetRenamed, (oldDisplayName, newDisplayName)=>{
            // The event is engine-wide, so it also reaches instances that do not own the renamed sheet.
            // Repointing those would make them operate on a sheet belonging to another instance.
            // Sheet ids are compared rather than names: the engine matches names without looking at the
            // case but keeps the casing it was given, so `sheetName` may differ in case from the event's
            // display names. The rename is already applied here, so the new name resolves to the same id.
            if (this.engine?.getSheetId(newDisplayName) === this.sheetId) {
                _class_private_method_get(this, _updateSheetNameAndSheetId, updateSheetNameAndSheetId).call(this, newDisplayName);
            }
            this.hot.runHooks('afterSheetRenamed', oldDisplayName, newDisplayName);
        }), _class_private_field_set(this, _onEngineSheetRemoved, (removedSheetDisplayName, changes)=>{
            this.hot.runHooks('afterSheetRemoved', removedSheetDisplayName, changes);
        }), _class_private_field_set(this, _engineListeners, [
            [
                'valuesUpdated',
                _class_private_field_get(this, _onEngineValuesUpdated)
            ],
            [
                'namedExpressionAdded',
                _class_private_field_get(this, _onEngineNamedExpressionsAdded)
            ],
            [
                'namedExpressionRemoved',
                _class_private_field_get(this, _onEngineNamedExpressionsRemoved)
            ],
            [
                'sheetAdded',
                _class_private_field_get(this, _onEngineSheetAdded)
            ],
            [
                'sheetRenamed',
                _class_private_field_get(this, _onEngineSheetRenamed)
            ],
            [
                'sheetRemoved',
                _class_private_field_get(this, _onEngineSheetRemoved)
            ]
        ]), /**
   * Static register used to set up one global HyperFormula instance.
   * TODO: currently used in tests, might be removed later.
   *
   * @private
   * @type {object}
   */ this.staticRegister = (0, _staticRegister.staticRegister)('formulas'), /**
   * The engine instance that will be used for this instance of Handsontable.
   *
   * @type {HyperFormula|null}
   */ this.engine = null, /**
   * HyperFormula's sheet id.
   *
   * @type {number|null}
   */ this.sheetId = null, /**
   * HyperFormula's sheet name.
   *
   * @type {string|null}
   */ this.sheetName = null, /**
   * Index synchronizer responsible for manipulating with some general options related to indexes synchronization.
   *
   * @type {IndexSyncer|null}
   */ this.indexSyncer = null, /**
   * Index synchronizer responsible for syncing the order of HOT and HF's data for the axis of the rows.
   *
   * @type {AxisSyncer|null}
   */ this.rowAxisSyncer = null, /**
   * Index synchronizer responsible for syncing the order of HOT and HF's data for the axis of the columns.
   *
   * @type {AxisSyncer|null}
   */ this.columnAxisSyncer = null, _class_private_field_set(this, _onBeforeValidate, (value, visualRow, prop)=>{
            const visualColumn = this.hot.propToCol(prop);
            if (this.isFormulaCellType(visualRow, visualColumn)) {
                const address = {
                    row: this.rowAxisSyncer.getHfIndexFromVisualIndex(visualRow),
                    col: this.columnAxisSyncer.getHfIndexFromVisualIndex(visualColumn),
                    sheet: this.sheetId
                };
                const cellMeta = this.hot.getCellMetaTransient(visualRow, visualColumn);
                let cellValue = this.engine.getCellValue(address); // Date as an integer (Excel-like date).
                if (cellMeta.type === 'date' && (0, _number.isNumeric)(cellValue)) {
                    cellValue = (0, _utils.getDateFromExcelDate)(cellValue);
                } else if (cellMeta.type === 'time' && (0, _number.isNumeric)(cellValue)) {
                    cellValue = (0, _utils.getTimeFromHfTimeFraction)(cellValue);
                }
                // If `cellValue` is an object it is expected to be an error
                return hasValueProperty(cellValue) ? cellValue.value : cellValue;
            }
            return value;
        }), _class_private_field_set(this, _onBeforeAutofill, (fillData, sourceRange, targetRange)=>{
            const { row: sourceTopStartRow, col: sourceTopStartColumn } = sourceRange.getTopStartCorner();
            const { row: sourceBottomEndRow, col: sourceBottomEndColumn } = sourceRange.getBottomEndCorner();
            const { row: targetTopStartRow, col: targetTopStartColumn } = targetRange.getTopStartCorner();
            const { row: targetBottomEndRow, col: targetBottomEndColumn } = targetRange.getBottomEndCorner();
            if (sourceTopStartRow === null || sourceTopStartColumn === null || sourceBottomEndRow === null || sourceBottomEndColumn === null || targetTopStartRow === null || targetTopStartColumn === null || targetBottomEndRow === null || targetBottomEndColumn === null) {
                return;
            }
            const hfSourceStartRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(sourceTopStartRow);
            const hfSourceStartCol = this.columnAxisSyncer.getHfIndexFromVisualIndex(sourceTopStartColumn);
            const hfSourceEndRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(sourceBottomEndRow);
            const hfSourceEndCol = this.columnAxisSyncer.getHfIndexFromVisualIndex(sourceBottomEndColumn);
            const hfTargetStartRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(targetTopStartRow);
            const hfTargetStartCol = this.columnAxisSyncer.getHfIndexFromVisualIndex(targetTopStartColumn);
            const hfTargetEndRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(targetBottomEndRow);
            const hfTargetEndCol = this.columnAxisSyncer.getHfIndexFromVisualIndex(targetBottomEndColumn);
            if (hfSourceStartRow === null || hfSourceStartCol === null || hfSourceEndRow === null || hfSourceEndCol === null || hfTargetStartRow === null || hfTargetStartCol === null || hfTargetEndRow === null || hfTargetEndCol === null) {
                return;
            }
            const engineSourceRange = {
                start: {
                    row: hfSourceStartRow,
                    col: hfSourceStartCol,
                    sheet: this.sheetId
                },
                end: {
                    row: hfSourceEndRow,
                    col: hfSourceEndCol,
                    sheet: this.sheetId
                }
            };
            const engineTargetRange = {
                start: {
                    row: hfTargetStartRow,
                    col: hfTargetStartCol,
                    sheet: this.sheetId
                },
                end: {
                    row: hfTargetEndRow,
                    col: hfTargetEndCol,
                    sheet: this.sheetId
                }
            };
            // Blocks the autofill operation if HyperFormula says that at least one of
            // the underlying cell's contents cannot be set.
            if (this.engine.isItPossibleToSetCellContents(engineTargetRange) === false) {
                return false;
            }
            const fillRangeData = this.engine.getFillRangeData(engineSourceRange, engineTargetRange);
            const { row: sourceStartRow, col: sourceStartColumn } = engineSourceRange.start;
            const { row: sourceEndRow, col: sourceEndColumn } = engineSourceRange.end;
            const populationRowLength = sourceEndRow - sourceStartRow + 1;
            const populationColumnLength = sourceEndColumn - sourceStartColumn + 1;
            for(let populatedRowIndex = 0; populatedRowIndex < fillRangeData.length; populatedRowIndex += 1){
                for(let populatedColumnIndex = 0; populatedColumnIndex < fillRangeData[populatedRowIndex].length; populatedColumnIndex += 1){
                    const populatedValue = fillRangeData[populatedRowIndex][populatedColumnIndex];
                    const sourceRow = sourceStartRow + populatedRowIndex % populationRowLength;
                    const sourceColumn = sourceStartColumn + populatedColumnIndex % populationColumnLength;
                    const sourceCellMeta = this.hot.getCellMeta(sourceRow, sourceColumn);
                    if ((0, _utils.isDate)(populatedValue, sourceCellMeta.type)) {
                        if (populatedValue.startsWith('\'')) {
                            // Populating values on HOT side without apostrophe.
                            fillRangeData[populatedRowIndex][populatedColumnIndex] = populatedValue.slice(1);
                        } else if (this.isFormulaCellType(sourceRow, sourceColumn, this.sheetId) === false) {
                            // Populating date in proper format, coming from the source cell.
                            fillRangeData[populatedRowIndex][populatedColumnIndex] = (0, _utils.getDateInHotFormat)(populatedValue);
                        }
                    }
                }
            }
            return fillRangeData;
        }), _class_private_field_set(this, _onBeforeLoadData, (sourceData, initialLoad, source = '')=>{
            if (source.includes((0, _string.toUpperCaseFirst)(PLUGIN_KEY))) {
                return;
            }
            // This flag needs to be defined, because not passing data to HOT results in HOT auto-generating a `null`-filled
            // initial dataset.
            _class_private_field_set(this, _hotWasInitializedWithEmptyData, (0, _mixed.isUndefined)(this.hot.getSettings().data));
        }), _class_private_field_set(this, _onAfterCellMetaReset, ()=>{
            if (_class_private_field_get(this, _hotWasInitializedWithEmptyData)) {
                if (this.sheetName !== null) {
                    this.switchSheet(this.sheetName);
                }
                return;
            }
            const sourceDataArray = _class_private_method_get(this, _getProcessedSourceDataArray, getProcessedSourceDataArray).call(this);
            sourceDataArray.forEach((rowData, rowIndex)=>{
                rowData.forEach((cellValue, columnIndex)=>{
                    // The uncached read keeps this full source-data scan from permanently materializing
                    // one meta object per cell (same no-extension semantics as `skipMetaExtension`).
                    const cellMeta = this.hot._getMetaManager().getCellMetaUncached(this.hot.toPhysicalRow(rowIndex) ?? rowIndex, this.hot.toPhysicalColumn(columnIndex) ?? columnIndex, {
                        visualRow: rowIndex,
                        visualColumn: columnIndex
                    });
                    if ((0, _utils.isDate)(cellValue, cellMeta.type)) {
                        if ((0, _utils.isDateValid)(cellValue)) {
                            // Rewriting date in HOT format to HF format.
                            sourceDataArray[rowIndex][columnIndex] = (0, _utils.getDateInHfFormat)(cellValue);
                        } else if (!cellValue.startsWith('=')) {
                            // Escaping value from date parsing using "'" sign (HF feature).
                            sourceDataArray[rowIndex][columnIndex] = `'${cellValue}`;
                        }
                    }
                });
            });
            _class_private_field_set(this, _internalOperationPending, true);
            const dependentCells = this.engine.setSheetContent(this.sheetId, sourceDataArray);
            this.indexSyncer.setupSyncEndpoint(this.engine, this.sheetId);
            this.renderDependentSheets(dependentCells);
            _class_private_field_set(this, _internalOperationPending, false);
        }), _class_private_field_set(this, _onAfterLoadData, (sourceData, initialLoad, source = '')=>{
            if (source.includes((0, _string.toUpperCaseFirst)(PLUGIN_KEY))) {
                return;
            }
            if (!this.engine) {
                return;
            }
            const formulasSettings = this.hot.getSettings()[PLUGIN_KEY];
            const settingsSheetName = isFormulasSettingsObject(formulasSettings) ? formulasSettings.sheetName : undefined;
            // Fall back to the sheet this instance already owns. Without it every `loadData`/`updateData`
            // call adds a sheet and abandons the previous one - with its whole dependency graph - inside
            // the engine, which the engine then recalculates on every subsequent call.
            const sheetName = (0, _register.setupSheet)(this.engine, settingsSheetName ?? this.sheetName);
            _class_private_method_get(this, _updateSheetNameAndSheetId, updateSheetNameAndSheetId).call(this, sheetName);
            if (source === 'updateSettings') {
                // For performance reasons, the initialization will be done in afterCellMetaReset hook
                return;
            }
            if (!_class_private_field_get(this, _hotWasInitializedWithEmptyData)) {
                const sourceDataArray = _class_private_method_get(this, _getProcessedSourceDataArray, getProcessedSourceDataArray).call(this);
                if (this.engine.isItPossibleToReplaceSheetContent(this.sheetId, sourceDataArray)) {
                    _class_private_field_set(this, _internalOperationPending, true);
                    const dependentCells = this.engine.setSheetContent(this.sheetId, sourceDataArray);
                    this.indexSyncer.setupSyncEndpoint(this.engine, this.sheetId);
                    this.renderDependentSheets(dependentCells);
                    _class_private_field_set(this, _internalOperationPending, false);
                } else {
                    // The sheet is reused, so leaving it untouched would keep the previous data in the engine
                    // while the grid already shows the new one. Empty it instead of serving stale values.
                    _class_private_field_set(this, _internalOperationPending, true);
                    const dependentCells = this.engine.setSheetContent(this.sheetId, [
                        []
                    ]);
                    // Emptying the sheet changes what the grids reading it compute, so they need a redraw.
                    this.renderDependentSheets(dependentCells);
                    _class_private_field_set(this, _internalOperationPending, false);
                    (0, _console.warn)('The loaded data could not be passed to the formula engine, so the formulas were ' + 'cleared. It most likely exceeds the engine\'s `maxRows` or `maxColumns` limit.');
                }
            } else if (this.sheetName !== null) {
                this.switchSheet(this.sheetName);
            }
        }), _class_private_field_set(this, _onModifyData, (visualRow, visualColumn, valueHolder, ioMode)=>{
            if (ioMode !== 'get' || _class_private_field_get(this, _internalOperationPending) || this.sheetName === null || !this.engine?.doesSheetExist(this.sheetName)) {
                return;
            }
            if (visualRow === null || visualColumn === null) {
                return;
            }
            const cellType = this.getCellType(visualRow, visualColumn);
            if (cellType === 'VALUE' || cellType === 'EMPTY') {
                valueHolder.value = (0, _utils.unescapeFormulaExpression)(valueHolder.value);
                return;
            }
            const address = {
                row: this.rowAxisSyncer.getHfIndexFromVisualIndex(visualRow),
                col: this.columnAxisSyncer.getHfIndexFromVisualIndex(visualColumn),
                sheet: this.sheetId
            };
            let cellValue = this.engine.getCellValue(address); // Date as an integer (Excel like date).
            // The uncached read matters here: this hook fires inside bulk data reads (for example, the
            // filters column scan), so an eager read would materialize one meta per scanned cell.
            const cellMeta = this.hot._getMetaManager().getCellMetaUncached(this.hot.toPhysicalRow(visualRow) ?? visualRow, this.hot.toPhysicalColumn(visualColumn) ?? visualColumn, {
                visualRow,
                visualColumn
            });
            if (cellMeta.type === 'date' && (0, _number.isNumeric)(cellValue)) {
                cellValue = (0, _utils.getDateFromExcelDate)(cellValue);
            } else if (cellMeta.type === 'time' && (0, _number.isNumeric)(cellValue)) {
                cellValue = (0, _utils.getTimeFromHfTimeFraction)(cellValue);
            }
            // If `cellValue` is an object it is expected to be an error
            valueHolder.value = hasValueProperty(cellValue) ? cellValue.value : cellValue;
        }), _class_private_field_set(this, _onAfterRenderer, (TD, row, column)=>{
            if (!_class_private_field_get(this, _hyperlinksEnabled) || _class_private_field_get(this, _internalOperationPending)) {
                return;
            }
            // Walkontable recycles TD elements, and a renderer is free to leave its previous DOM in place.
            // Unwrapping first keeps this idempotent by construction: no anchor nests inside another one
            // across render passes, and the `href` is always rebuilt from the current formula instead of
            // inherited from whatever the previous pass resolved. Cleanup for the option being turned off
            // happens once, in `#refreshHyperlinksSetting`, so this path never runs for a disabled grid.
            _class_private_method_get(this, _unwrapHyperlink, unwrapHyperlink).call(this, TD);
            const href = _class_private_method_get(this, _getHyperlinkHref, getHyperlinkHref).call(this, row, column);
            if (href === null) {
                return;
            }
            const link = this.hot.rootDocument.createElement('a');
            link.className = HYPERLINK_CLASS_NAME;
            link.href = href;
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            // Cell content stays out of the grid's tab order; `Alt`+`Enter` is the keyboard path instead.
            link.tabIndex = -1;
            // The nodes are moved, never re-serialized, so a label containing markup stays text.
            while(TD.firstChild){
                link.appendChild(TD.firstChild);
            }
            TD.appendChild(link);
        }), _class_private_field_set(this, _onModifySourceData, (row, columnOrProp, valueHolder, ioMode)=>{
            if (ioMode !== 'get' || _class_private_field_get(this, _internalOperationPending) || _class_private_field_get(// The read that feeds the engine must report what is really stored: see
            // `#getProcessedSourceDataArray`.
            this, _sourceDataProjectionSuspended) || this.sheetName === null || !this.engine?.doesSheetExist(this.sheetName)) {
                return;
            }
            const visualRow = this.hot.toVisualRow(row);
            const visualColumn = this.hot.propToCol(columnOrProp);
            if (visualRow === null || visualColumn === null) {
                return;
            }
            const cellType = this.getCellType(visualRow, visualColumn);
            if (cellType === 'VALUE' || cellType === 'EMPTY') {
                return;
            }
            const dimensions = this.engine.getSheetDimensions(this.engine.getSheetId(this.sheetName));
            // Don't actually change the source data if HyperFormula is not
            // initialized yet. This is done to allow the `afterLoadData` hook to
            // load the existing source data with `Handsontable#getSourceDataArray`
            // properly.
            if (dimensions.width === 0 && dimensions.height === 0) {
                return;
            }
            const address = {
                row: this.rowAxisSyncer.getHfIndexFromVisualIndex(visualRow),
                col: this.columnAxisSyncer.getHfIndexFromVisualIndex(visualColumn),
                sheet: this.sheetId
            };
            valueHolder.value = this.engine.getCellSerialized(address);
        }), _class_private_field_set(this, _onAfterSetDataAtCell, (changes, source)=>{
            if (isBlockedSource(source)) {
                _class_private_method_get(this, _registerUndoRedoWrite, registerUndoRedoWrite).call(this, changes, source, true);
                return;
            }
            // Skip HF re-sync when we are writing back to HOT after a moveCells HF operation.
            if (_class_private_field_get(this, _moveCellsSyncPending)) {
                return;
            }
            // Skip engine sync when there are no changes (e.g. populateFromArray on readOnly cells).
            // Otherwise engine.batch() would push an empty undo step and undo would revert the wrong action (#dev-2136).
            if (!changes?.length) {
                return;
            }
            const outOfBoundsChanges = [];
            const changedCells = [];
            const dependentCells = this.engine.batch(()=>{
                changes.forEach(([visualRow, prop, , newValue])=>{
                    if (typeof prop !== 'string' && typeof prop !== 'number') {
                        return;
                    }
                    const visualColumn = this.hot.propToCol(prop);
                    const physicalRow = this.hot.toPhysicalRow(visualRow);
                    const physicalColumn = this.hot.toPhysicalColumn(visualColumn);
                    const address = {
                        row: this.rowAxisSyncer.getHfIndexFromVisualIndex(visualRow),
                        col: this.columnAxisSyncer.getHfIndexFromVisualIndex(visualColumn),
                        sheet: this.sheetId
                    };
                    newValue = _class_private_method_get(this, _getValueGetterValue, getValueGetterValue).call(this, physicalRow, physicalColumn, newValue);
                    if (physicalRow !== null && physicalColumn !== null) {
                        this.syncChangeWithEngine(visualRow, visualColumn, newValue);
                    } else {
                        outOfBoundsChanges.push([
                            visualRow,
                            visualColumn,
                            newValue
                        ]);
                    }
                    changedCells.push({
                        address
                    });
                });
            });
            if (outOfBoundsChanges.length) {
                // Workaround for rows/columns being created two times (by HOT and the engine).
                // (unfortunately, this requires an extra re-render)
                this.hot.addHookOnce('afterChange', ()=>{
                    const outOfBoundsDependentCells = this.engine.batch(()=>{
                        outOfBoundsChanges.forEach(([row, column, newValue])=>{
                            this.syncChangeWithEngine(row, column, newValue);
                        });
                    });
                    this.renderDependentSheets(outOfBoundsDependentCells, true);
                });
            }
            this.renderDependentSheets(dependentCells);
            this.validateDependentCells(dependentCells, changedCells);
        }), _class_private_field_set(this, _onAfterSetSourceDataAtCell, (changes, source)=>{
            if (isBlockedSource(source)) {
                _class_private_method_get(this, _registerUndoRedoWrite, registerUndoRedoWrite).call(this, changes, source, false);
                return;
            }
            // Skip HF re-sync when we are writing back to HOT after a moveCells HF operation.
            if (_class_private_field_get(this, _moveCellsSyncPending)) {
                return;
            }
            const dependentCells = [];
            const changedCells = [];
            changes.forEach(([visualRow, prop, , newValue])=>{
                if (typeof prop !== 'string' && typeof prop !== 'number') {
                    return;
                }
                const visualColumn = this.hot.propToCol(prop);
                if (!(0, _number.isNumeric)(visualColumn)) {
                    return;
                }
                const address = {
                    row: this.rowAxisSyncer.getHfIndexFromVisualIndex(visualRow),
                    col: this.columnAxisSyncer.getHfIndexFromVisualIndex(visualColumn),
                    sheet: this.sheetId
                };
                if (!this.engine?.isItPossibleToSetCellContents(address)) {
                    (0, _console.warn)(`Not possible to set source cell data at ${JSON.stringify(address)}`);
                    return;
                }
                newValue = (0, _utils.normalizeValueForFormulaEngine)(newValue);
                changedCells.push({
                    address
                });
                dependentCells.push(...this.engine.setCellContents(address, newValue));
            });
            this.renderDependentSheets(dependentCells);
            this.validateDependentCells(dependentCells, changedCells);
        }), _class_private_field_set(this, _onBeforeCreateRow, (visualRow, amount)=>{
            let hfRowIndex = this.rowAxisSyncer.getHfIndexFromVisualIndex(visualRow);
            if (visualRow >= this.hot.countRows()) {
                hfRowIndex = visualRow; // Row beyond the table boundaries.
            }
            if (this.sheetId === null || !this.engine?.doesSheetExist(this.sheetName) || !this.engine?.isItPossibleToAddRows(this.sheetId, [
                hfRowIndex,
                amount
            ])) {
                return false;
            }
        }), _class_private_field_set(this, _onBeforeCreateCol, (visualColumn, amount)=>{
            let hfColumnIndex = this.columnAxisSyncer.getHfIndexFromVisualIndex(visualColumn);
            if (visualColumn >= this.hot.countCols()) {
                hfColumnIndex = visualColumn; // Column beyond the table boundaries.
            }
            if (this.sheetId === null || !this.engine?.doesSheetExist(this.sheetName) || !this.engine?.isItPossibleToAddColumns(this.sheetId, [
                hfColumnIndex,
                amount
            ])) {
                return false;
            }
        }), _class_private_field_set(this, _onBeforeRemoveRow, (row, amount, physicalRows)=>{
            const hfRows = this.rowAxisSyncer.setRemovedHfIndexes(physicalRows);
            const possible = hfRows.every((hfRow)=>{
                return this.engine?.isItPossibleToRemoveRows(this.sheetId, [
                    hfRow,
                    1
                ]);
            });
            return possible === false ? false : undefined;
        }), _class_private_field_set(this, _onBeforeRemoveCol, (col, amount, physicalColumns)=>{
            const hfColumns = this.columnAxisSyncer.setRemovedHfIndexes(physicalColumns);
            const possible = hfColumns.every((hfColumn)=>{
                return this.engine?.isItPossibleToRemoveColumns(this.sheetId, [
                    hfColumn,
                    1
                ]);
            });
            return possible === false ? false : undefined;
        }), _class_private_field_set(this, _onAfterCreateRow, (visualRow, amount, source)=>{
            if (isBlockedSource(source)) {
                return;
            }
            const changes = this.engine.addRows(this.sheetId, [
                this.rowAxisSyncer.getHfIndexFromVisualIndex(visualRow),
                amount
            ]);
            this.renderDependentSheets(changes);
        }), _class_private_field_set(this, _onAfterCreateCol, (visualColumn, amount, source)=>{
            if (isBlockedSource(source)) {
                return;
            }
            const changes = this.engine.addColumns(this.sheetId, [
                this.columnAxisSyncer.getHfIndexFromVisualIndex(visualColumn),
                amount
            ]);
            this.renderDependentSheets(changes);
        }), _class_private_field_set(this, _onAfterRemoveRow, (row, amount, physicalRows, source)=>{
            if (isBlockedSource(source)) {
                return;
            }
            const removedSpans = (0, _utils.coalesceIndexesToSpans)(this.rowAxisSyncer.getRemovedHfIndexes());
            const changes = this.engine.batch(()=>{
                _class_private_method_get(this, _removeSpansFromEngine, removeSpansFromEngine).call(this, removedSpans, 'removeRows');
            });
            this.renderDependentSheets(changes);
        }), _class_private_field_set(this, _onAfterRemoveCol, (col, amount, physicalColumns, source)=>{
            if (isBlockedSource(source)) {
                return;
            }
            const removedSpans = (0, _utils.coalesceIndexesToSpans)(this.columnAxisSyncer.getRemovedHfIndexes());
            const changes = this.engine.batch(()=>{
                _class_private_method_get(this, _removeSpansFromEngine, removeSpansFromEngine).call(this, removedSpans, 'removeColumns');
            });
            this.renderDependentSheets(changes);
        }), _class_private_field_set(this, _onBeforeMoveCells, (sourceRange, targetTopLeft, isCopy)=>{
            if (!(0, _range.isCellRangeLike)(sourceRange)) {
                _class_private_field_set(this, _pendingMoveCells, null);
                return false;
            }
            if (!this.engine || this.sheetId === null) {
                return;
            }
            const topStart = sourceRange.getTopStartCorner();
            const bottomEnd = sourceRange.getBottomEndCorner();
            const fromRow = topStart.row;
            const fromCol = topStart.col;
            const toRow = bottomEnd.row;
            const toCol = bottomEnd.col;
            const targetRow = targetTopLeft.row;
            const targetCol = targetTopLeft.col;
            // The engine operates on a single HF rectangle built from the mapped corners below. That is
            // only equivalent to the visual operation when every visual index in all four spans maps to
            // consecutive HF indexes. With Filters/TrimRows the HF sheet still contains the trimmed rows,
            // and sorting or manual move permutes the order — a rectangle would then move cells the grid
            // never touches, desyncing the engine from the data source. Veto instead.
            if (!_class_private_method_get(this, _mapsToContiguousHfBlock, mapsToContiguousHfBlock).call(this, this.rowAxisSyncer, fromRow, toRow) || !_class_private_method_get(this, _mapsToContiguousHfBlock, mapsToContiguousHfBlock).call(this, this.columnAxisSyncer, fromCol, toCol) || !_class_private_method_get(this, _mapsToContiguousHfBlock, mapsToContiguousHfBlock).call(this, this.rowAxisSyncer, targetRow, targetRow + (toRow - fromRow)) || !_class_private_method_get(this, _mapsToContiguousHfBlock, mapsToContiguousHfBlock).call(this, this.columnAxisSyncer, targetCol, targetCol + (toCol - fromCol))) {
                _class_private_field_set(this, _pendingMoveCells, null);
                return false;
            }
            const hfFromRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(fromRow);
            const hfFromCol = this.columnAxisSyncer.getHfIndexFromVisualIndex(fromCol);
            const hfToRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(toRow);
            const hfToCol = this.columnAxisSyncer.getHfIndexFromVisualIndex(toCol);
            const hfTargetRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(targetRow);
            const hfTargetCol = this.columnAxisSyncer.getHfIndexFromVisualIndex(targetCol);
            const source = {
                start: {
                    sheet: this.sheetId,
                    row: hfFromRow,
                    col: hfFromCol
                },
                end: {
                    sheet: this.sheetId,
                    row: hfToRow,
                    col: hfToCol
                }
            };
            const dest = {
                sheet: this.sheetId,
                row: hfTargetRow,
                col: hfTargetCol
            };
            if (!isCopy && !this.engine.isItPossibleToMoveCells(source, dest)) {
                _class_private_field_set(this, _pendingMoveCells, null);
                return false;
            }
            if (isCopy) {
                // Pre-check the paste target for a COPY the same way isItPossibleToMoveCells guards a
                // MOVE (e.g. pasting over part of an array formula throws in `engine.paste`), so the
                // operation vetoes cleanly before the grid mutates instead of failing halfway through.
                const targetRegion = {
                    start: dest,
                    end: {
                        sheet: this.sheetId,
                        row: hfTargetRow + (hfToRow - hfFromRow),
                        col: hfTargetCol + (hfToCol - hfFromCol)
                    }
                };
                if (!this.engine.isItPossibleToSetCellContents(targetRegion)) {
                    _class_private_field_set(this, _pendingMoveCells, null);
                    return false;
                }
            }
            _class_private_field_set(this, _pendingMoveCells, {
                source,
                dest,
                isCopy,
                rect: {
                    fromRow,
                    fromCol,
                    toRow,
                    toCol,
                    targetRow,
                    targetCol,
                    isCopy
                }
            });
        }), _class_private_field_set(this, _onAfterMoveCells, ()=>{
            const committed = _class_private_field_get(this, _committedMoveCells);
            const dependentCells = _class_private_field_get(this, _moveCellsChanges);
            // Consume the state on every run, including the ones that return early below, so a run without
            // a committed move behind it cannot pick up the previous operation's leftovers.
            _class_private_field_set(this, _committedMoveCells, null);
            _class_private_field_set(this, _moveCellsChanges, null);
            if (!this.engine || committed === null) {
                return;
            }
            // Sync HOT's source data with HF's updated state so that getDataAtCell returns
            // correct values for VALUE/EMPTY cells (formula cells are already served via modifyData).
            _class_private_method_get(this, _syncHotDataAfterMoveCells, syncHotDataAfterMoveCells).call(this, committed);
            // During undo/redo replay the engine step was skipped (dependentCells is null) and the
            // HOT re-render after undo/redo refreshes all dependent cells anyway.
            if (dependentCells !== null) {
                this.renderDependentSheets(dependentCells, true);
            }
        }), _class_private_field_set(this, _onAfterDetachChild, (parent, element, finalElementRowIndex)=>{
            _class_private_field_set(this, _internalOperationPending, true);
            const children = element.__children;
            const childrenCount = Array.isArray(children) ? children.length : 0;
            const rowsData = _class_private_method_get(this, _getProcessedSourceDataArray, getProcessedSourceDataArray).call(this, finalElementRowIndex, 0, finalElementRowIndex + childrenCount, this.hot.countSourceCols());
            _class_private_field_set(this, _internalOperationPending, false);
            rowsData.forEach((row, relativeRowIndex)=>{
                row.forEach((value, colIndex)=>{
                    this.engine?.setCellContents({
                        col: colIndex,
                        row: finalElementRowIndex + relativeRowIndex,
                        sheet: this.sheetId
                    }, [
                        [
                            value
                        ]
                    ]);
                });
            });
        });
    }
}
function exportChangeValue(change) {
    if (!change.address || change.address.sheet !== this.sheetId || typeof change.newValue !== 'number') {
        return change;
    }
    const visualRow = this.rowAxisSyncer.getVisualIndexFromHfIndex(change.address.row);
    const visualColumn = this.columnAxisSyncer.getVisualIndexFromHfIndex(change.address.col);
    if (visualRow < 0 || visualColumn < 0) {
        return change;
    }
    // The uncached read keeps the same no-extension semantics as the previous
    // `skipMetaExtension` read, without permanently materializing the cell meta.
    const cellMeta = this.hot._getMetaManager().getCellMetaUncached(this.hot.toPhysicalRow(visualRow) ?? visualRow, this.hot.toPhysicalColumn(visualColumn) ?? visualColumn, {
        visualRow,
        visualColumn
    });
    let newValue;
    if (cellMeta.type === 'date') {
        newValue = (0, _utils.getDateFromExcelDate)(change.newValue);
    } else if (cellMeta.type === 'time') {
        newValue = (0, _utils.getTimeFromHfTimeFraction)(change.newValue);
    } else {
        return change;
    }
    const clone = Object.assign(Object.create(Object.getPrototypeOf(change)), change);
    clone.newValue = newValue;
    return clone;
}
function updateSheetNameAndSheetId(sheetName) {
    const sheetId = this.engine?.getSheetId(sheetName) ?? null;
    // Store the name the engine itself reports. The engine matches names without regard to case
    // but keeps the casing it was given, so the name passed here may differ from the engine's own.
    // Keeping them in step makes every exact-string reader of `sheetName` safe by construction.
    this.sheetName = (sheetId === null ? null : this.engine?.getSheetName(sheetId)) ?? sheetName;
    this.sheetId = sheetId;
}
function refreshHyperlinksSetting() {
    const pluginSettings = this.hot.getSettings()[PLUGIN_KEY];
    const wasEnabled = _class_private_field_get(this, _hyperlinksEnabled);
    _class_private_field_set(this, _hyperlinksEnabled, isFormulasSettingsObject(pluginSettings) && pluginSettings.hyperlinks === true);
    // Turning the option off is the moment to clean up, not every subsequent draw: a renderer that
    // leaves its previous DOM in place would keep an anchor that no later render pass rewrites.
    // Doing it here keeps the per-cell path free for the default, disabled case.
    if (wasEnabled && !_class_private_field_get(this, _hyperlinksEnabled)) {
        _class_private_method_get(this, _unwrapRenderedHyperlinks, unwrapRenderedHyperlinks).call(this);
    }
}
function unwrapRenderedHyperlinks() {
    this.hot.rootElement?.querySelectorAll(`a.${HYPERLINK_CLASS_NAME}`).forEach((link)=>_class_private_method_get(this, _unwrapLink, unwrapLink).call(this, link));
}
function unwrapLink(link) {
    const { parentNode } = link;
    while(link.firstChild){
        parentNode?.insertBefore(link.firstChild, link);
    }
    link.remove();
}
function unwrapHyperlink(TD) {
    // A cell rendered as plain text has no element children at all, which is the overwhelmingly
    // common case and the one that must not pay for a selector query on every render pass.
    if (TD.firstElementChild === null) {
        return;
    }
    let link = TD.querySelector(`a.${HYPERLINK_CLASS_NAME}`);
    while(link !== null){
        _class_private_method_get(this, _unwrapLink, unwrapLink).call(this, link);
        link = TD.querySelector(`a.${HYPERLINK_CLASS_NAME}`);
    }
}
function getHyperlinkHref(row, column) {
    if (this.sheetName === null || !this.engine?.doesSheetExist(this.sheetName) || !this.rowAxisSyncer || !this.columnAxisSyncer || !this.isFormulaCellType(row, column)) {
        return null;
    }
    const url = this.engine.getCellHyperlink({
        sheet: this.sheetId,
        row: this.rowAxisSyncer.getHfIndexFromVisualIndex(row),
        col: this.columnAxisSyncer.getHfIndexFromVisualIndex(column)
    });
    if (url === undefined) {
        return null;
    }
    const href = (0, _hyperlinkUrl.resolveHyperlinkUrl)(url, this.hot.rootDocument.baseURI);
    if (href === null) {
        (0, _console.warnOnce)(this, HYPERLINK_WARN_KEY, `A "HYPERLINK" formula points at a URL that Handsontable refuses to link to ("${url}"). ` + 'Only the "http", "https", "mailto" and "tel" schemes can be linked.');
    }
    return href;
}
function registerUndoRedoWrite(changes, source, coreValidatesWrite) {
    if (source !== 'UndoRedo.undo' && source !== 'UndoRedo.redo') {
        return;
    }
    if (!changes?.length) {
        return;
    }
    _class_private_field_set(this, _undoRedoWroteData, true);
    if (!coreValidatesWrite) {
        return;
    }
    changes.forEach(([visualRow, prop])=>{
        if (typeof prop !== 'string' && typeof prop !== 'number') {
            return;
        }
        const visualColumn = this.hot.propToCol(prop);
        if (!(0, _number.isNumeric)(visualRow) || !(0, _number.isNumeric)(visualColumn)) {
            return;
        }
        const hfRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(visualRow);
        const hfColumn = this.columnAxisSyncer.getHfIndexFromVisualIndex(visualColumn);
        // `-1` marks an index that is out of range or trimmed. Such an address matches no real engine
        // address, so keeping it would only risk colliding with a genuine dependent cell.
        if (hfRow === -1 || hfColumn === -1) {
            return;
        }
        _class_private_field_get(this, _undoRedoChangedCells).push({
            address: {
                row: hfRow,
                col: hfColumn,
                sheet: this.sheetId
            }
        });
    });
}
function validateUndoRedoDependentCells() {
    const dependentCells = _class_private_field_get(this, _undoRedoDependentCells);
    const changedCells = _class_private_field_get(this, _undoRedoChangedCells);
    const wroteData = _class_private_field_get(this, _undoRedoWroteData);
    _class_private_field_set(this, _undoRedoDependentCells, []);
    _class_private_field_set(this, _undoRedoChangedCells, []);
    _class_private_field_set(this, _undoRedoWroteData, false);
    if (wroteData && dependentCells.length) {
        this.validateDependentCells(dependentCells, changedCells);
    }
}
function getValueGetterValue(row, column, value) {
    if ((0, _object.isObject)(value) && value !== null) {
        const visualRow = this.hot.toVisualRow(row);
        const visualColumn = this.hot.toVisualColumn(column);
        const cellMeta = this.hot.getCellMetaTransient(visualRow, visualColumn);
        value = (0, _valueAccessors.getValueGetterValue)(value, cellMeta);
        if (value !== null && value !== undefined) {
            value = Object(value).toString();
        }
    }
    return (0, _utils.normalizeValueForFormulaEngine)(value);
}
function getProcessedSourceDataArray(row, column, row2, column2) {
    // Every caller feeds the result to the engine, so this read has to report what Handsontable
    // actually stores – not what it reports. Left unguarded, `#onModifySourceData` answers every
    // formula cell with the formula the engine already holds, so a `loadData()`/`updateData()` call
    // that changes a formula's text reads the engine's PREVIOUS formula back and writes it straight
    // into the engine again, silently discarding the newly loaded one.
    //
    // The projection is suspended through a dedicated flag rather than `#internalOperationPending`,
    // which also gates `#onModifyData` and `#onAfterRenderer`. This read runs the `modifyRowData`
    // and `modifySourceData` hooks for every row and cell, so third-party handlers execute inside
    // the guarded window - and one that calls `getDataAtCell()` on a formula cell has to keep
    // receiving the calculated value, not the raw formula.
    //
    // No other site sets the flag, so the previous value is saved and restored rather than cleared
    // for one reason only: those same third-party handlers run inside the window, and one that
    // reaches this method again - synchronously, through `updateSettings()` or `loadData()` - would
    // otherwise leave the rest of the outer read unguarded, which is the very defect above.
    const wasProjectionSuspended = _class_private_field_get(this, _sourceDataProjectionSuspended);
    _class_private_field_set(this, _sourceDataProjectionSuspended, true);
    let dataArray;
    try {
        dataArray = this.hot.getSourceDataArray(row, column, row2, column2);
    } finally{
        _class_private_field_set(this, _sourceDataProjectionSuspended, wasProjectionSuspended);
    }
    const visibleColumnCount = this.hot.countCols();
    const physicalColumnCount = this.hot.countSourceCols();
    // Only the shape of the data matters, and it is the same for every row, so one row answers it.
    // `getSourceData()` would rebuild the whole dataset - through the per-cell `modifySourceData`
    // hook, and outside the guard above - just to run `isArrayOfArrays` over it.
    const isAoAWithSkippedColumns = visibleColumnCount < physicalColumnCount && Array.isArray(this.hot.getSourceDataAtRow(0));
    if (!isAoAWithSkippedColumns) {
        return dataArray.map((rowObject, rowIndex)=>{
            const rowArray = Array.isArray(rowObject) ? rowObject : [];
            return rowArray.map((value, columnIndex)=>{
                return _class_private_method_get(this, _getValueGetterValue, getValueGetterValue).call(this, rowIndex, columnIndex, value);
            });
        });
    }
    // Array-of-objects data is already projected to visible columns by
    // `dataSource.getAtRow`. Array-of-arrays data returns the full source row,
    // so when `columns` skips physical indexes the data fed to HF misaligns
    // with the axis-syncer's visual->HF mapping (issue #10021). Build a row
    // containing only visible columns so HF cell coordinates stay in sync.
    const columnOffset = column ?? 0;
    return dataArray.map((row, rowIndex)=>{
        // `getSourceDataArray` hands back a falsy row as-is for a hole or a `null` entry, and the
        // shape check above only reads row 0, so such a row can reach this branch. Treated as empty,
        // exactly as the pass-through branch above treats it.
        const rowArray = Array.isArray(row) ? row : [];
        const projected = [];
        for(let visualCol = 0; visualCol < visibleColumnCount; visualCol++){
            const physicalCol = this.hot.colToProp(visualCol);
            if (typeof physicalCol !== 'number') {
                continue;
            }
            const arrayIndex = physicalCol - columnOffset;
            if (arrayIndex < 0 || arrayIndex >= rowArray.length) {
                continue;
            }
            projected.push(_class_private_method_get(this, _getValueGetterValue, getValueGetterValue).call(this, rowIndex, visualCol, rowArray[arrayIndex]));
        }
        return projected;
    });
}
function mapsToContiguousHfBlock(syncer, visualFrom, visualTo) {
    const hfBase = syncer.getHfIndexFromVisualIndex(visualFrom);
    if (hfBase < 0) {
        return false;
    }
    for(let offset = 1; offset <= visualTo - visualFrom; offset++){
        if (syncer.getHfIndexFromVisualIndex(visualFrom + offset) !== hfBase + offset) {
            return false;
        }
    }
    return true;
}
function syncHotDataAfterMoveCells(rect) {
    const { fromRow: srcFromRow, fromCol: srcFromCol, toRow: srcToRow, toCol: srcToCol, targetRow: tgtFromRow, targetCol: tgtFromCol, isCopy } = rect;
    const height = srcToRow - srcFromRow + 1;
    const width = srcToCol - srcFromCol + 1;
    // Build target values from HF serialized content (formula strings or raw values).
    const targetData = [];
    for(let r = 0; r < height; r++){
        const row = [];
        for(let c = 0; c < width; c++){
            const hfRow = this.rowAxisSyncer.getHfIndexFromVisualIndex(tgtFromRow + r);
            const hfCol = this.columnAxisSyncer.getHfIndexFromVisualIndex(tgtFromCol + c);
            const serialized = this.engine.getCellSerialized({
                sheet: this.sheetId,
                row: hfRow,
                col: hfCol
            });
            row.push(serialized ?? null);
        }
        targetData.push(row);
    }
    _class_private_field_set(this, _moveCellsSyncPending, true);
    try {
        if (!isCopy) {
            // Clear source cells in HOT's data first (HF already moved them out), so that an
            // overlapping source/target range does not null out cells the target write is about
            // to fill — the target data was already snapshotted from HF above.
            const nullRow = Array.from({
                length: width
            }).fill(null);
            const nullGrid = Array.from({
                length: height
            }, ()=>nullRow.slice());
            this.hot.populateFromArray(srcFromRow, srcFromCol, nullGrid, srcToRow, srcToCol, 'auto');
        }
        // Write target cells with HF-serialised content (formula strings preserved).
        // Use 'auto' source so UndoRedo does not record these writes as separate DataChangeActions
        // — they are part of the move and are covered by the MoveCellsAction in the undo stack.
        this.hot.populateFromArray(tgtFromRow, tgtFromCol, targetData, tgtFromRow + height - 1, tgtFromCol + width - 1, 'auto');
    } finally{
        _class_private_field_set(this, _moveCellsSyncPending, false);
    }
}
function removeSpansFromEngine(spans, engineMethodName) {
    for(let end = spans.length; end > 0; end -= REMOVAL_SPANS_CHUNK_SIZE){
        const chunk = spans.slice(Math.max(0, end - REMOVAL_SPANS_CHUNK_SIZE), end);
        if (engineMethodName === 'removeRows') {
            this.engine.removeRows(this.sheetId, ...chunk);
        } else {
            this.engine.removeColumns(this.sheetId, ...chunk);
        }
    }
}
