"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Formulas () {
        return _formulas.Formulas;
    },
    get PLUGIN_KEY () {
        return _formulas.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _formulas.PLUGIN_PRIORITY;
    }
});
const _formulas = require("./formulas");
