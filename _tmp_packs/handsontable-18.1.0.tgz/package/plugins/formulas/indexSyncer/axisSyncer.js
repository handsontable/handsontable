"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _string = require("../../../helpers/string");
const _moves = require("../../../helpers/moves");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var _axis = /*#__PURE__*/ new WeakMap(), _indexMapper = /*#__PURE__*/ new WeakMap(), _indexSyncer = /*#__PURE__*/ new WeakMap(), /**
   * Sequence of physical indexes stored for watching changes and calculating some transformations.
   *
   * @private
   * @type {Array<number>}
   */ _indexesSequence = /*#__PURE__*/ new WeakMap(), /**
   * List of moved HF indexes, stored before performing move on HOT to calculate transformation needed on HF's engine.
   *
   * @private
   * @type {Array<number>}
   */ _movedIndexes = /*#__PURE__*/ new WeakMap(), /**
   * Final HF's place where to move indexes, stored before performing move on HOT to calculate transformation needed on HF's engine.
   *
   * @private
   * @type {number|undefined}
   */ _finalIndex = /*#__PURE__*/ new WeakMap(), /**
   * List of removed HF indexes, stored before performing removal on HOT to calculate transformation needed on HF's engine.
   *
   * @private
   * @type {Array<number>}
   */ _removedIndexes = /*#__PURE__*/ new WeakMap(), /**
   * Cached translation tables between physical, visual, and HF indexes. Built lazily on the first
   * translation call and invalidated whenever the indexes sequence or the trimmed indexes change.
   * Keeping the tables makes both translation methods O(1) per call — they are called for every
   * rendered cell, so a per-call sequence scan would scale with the dataset size.
   *
   * @private
   * @type {HfTranslationCache|null}
   */ _translationCache = /*#__PURE__*/ new WeakMap(), /**
   * Gets the cached translation tables between physical, visual, and HF indexes, building them when needed.
   *
   * @returns {HfTranslationCache}
   */ _getTranslationCache = /*#__PURE__*/ new WeakSet(), /**
   * Synchronizes the initial axis order with HF engine. When the IndexMapper's sequence is non-identity at
   * setup time (for example, an initial `manualColumnMove` or `manualRowMove` configuration), HF needs to
   * reorder its data so that HF visual order matches HOT visual order. Without this sync, downstream code
   * that translates visual indexes through `getHfIndexFromVisualIndex` reads the wrong cells.
   *
   * @private
   */ _syncInitialOrder = /*#__PURE__*/ new WeakSet();
/**
 * @private
 * @class IndexSyncer
 * @description
 *
 * Indexes synchronizer responsible for providing logic for particular axis. It respects an idea to represent trimmed
 * elements in HF's engine to perform formulas calculations on them. It also provides method for translation from visual
 * row/column indexes to HF's row/column indexes.
 */ class AxisSyncer {
    /**
   * Sets removed HF indexes (it should be done right before performing move on HOT).
   *
   * @param {Array<number>} removedIndexes List of removed physical indexes.
   * @returns {Array<number>} List of removed visual indexes.
   */ setRemovedHfIndexes(removedIndexes) {
        _class_private_field_set(this, _removedIndexes, removedIndexes.map((physicalIndex)=>{
            const visualIndex = _class_private_field_get(this, _indexMapper).getVisualFromPhysicalIndex(physicalIndex);
            return this.getHfIndexFromVisualIndex(visualIndex ?? -1);
        }));
        return _class_private_field_get(this, _removedIndexes);
    }
    /**
   * Gets removed HF indexes (right before performing removal on HOT).
   *
   * @returns {Array<number>} List of removed HF indexes.
   */ getRemovedHfIndexes() {
        return _class_private_field_get(this, _removedIndexes);
    }
    /**
   * Gets corresponding HyperFormula index for particular visual index. It's respecting the idea that HF's engine
   * is fed also with trimmed indexes (business requirements for formula result calculation also for trimmed elements).
   *
   * @param {number} visualIndex Visual index.
   * @returns {number}
   */ getHfIndexFromVisualIndex(visualIndex) {
        const physicalIndex = _class_private_field_get(this, _indexMapper).getNotTrimmedIndexes()[visualIndex];
        if (physicalIndex === undefined) {
            return -1;
        }
        // The `?? -1` covers a mid-batch state in which the mapper's not-trimmed cache still holds a
        // physical index that is no longer part of the sequence.
        return _class_private_method_get(this, _getTranslationCache, getTranslationCache).call(this).hfIndexOfPhysical[physicalIndex] ?? -1;
    }
    /**
   * Gets corresponding visual index for a HyperFormula index. Inverse of {@link getHfIndexFromVisualIndex}.
   * Returns -1 when the HF index points to a trimmed element (not visible to the user).
   *
   * @param {number} hfIndex HyperFormula index.
   * @returns {number}
   */ getVisualIndexFromHfIndex(hfIndex) {
        const { physicalIndexOfHf, visualIndexOfPhysical } = _class_private_method_get(this, _getTranslationCache, getTranslationCache).call(this);
        const physicalIndex = physicalIndexOfHf[hfIndex];
        if (physicalIndex === undefined) {
            return -1;
        }
        return visualIndexOfPhysical[physicalIndex];
    }
    /**
   * Synchronizes moves done on HOT to HF engine (based on previously calculated positions).
   *
   * @private
   * @param {Array<{from: number, to: number}>} moves Calculated HF's move positions.
   */ syncMoves(moves) {
        const NUMBER_OF_MOVED_INDEXES = 1;
        const SYNC_MOVE_METHOD_NAME = `move${(0, _string.toUpperCaseFirst)(_class_private_field_get(this, _axis))}s`;
        const engine = _class_private_field_get(this, _indexSyncer).getEngine();
        if (!engine) {
            return;
        }
        engine.batch(()=>{
            moves.forEach((move)=>{
                const moveToTheSamePosition = move.from !== move.to;
                // Moving from left to right (or top to bottom) to a line (drop index) right after already moved element.
                const anotherMoveWithoutEffect = move.from + 1 !== move.to;
                if (moveToTheSamePosition && anotherMoveWithoutEffect) {
                    engine[SYNC_MOVE_METHOD_NAME](_class_private_field_get(this, _indexSyncer).getSheetId(), move.from, NUMBER_OF_MOVED_INDEXES, move.to);
                }
            });
        });
    }
    /**
   * Stores information about performed HOT moves for purpose of calculating where to move HF elements.
   *
   * @param {Array<number>} movedVisualIndexes Sequence of moved visual indexes for certain axis.
   * @param {number} visualFinalIndex Final visual place where to move HOT indexes.
   * @param {boolean} movePossible Indicates if it's possible to move HOT indexes to the desired position.
   */ storeMovesInformation(movedVisualIndexes, visualFinalIndex, movePossible) {
        if (movePossible === false) {
            return;
        }
        _class_private_field_set(this, _movedIndexes, movedVisualIndexes.map((index)=>this.getHfIndexFromVisualIndex(index)));
        _class_private_field_set(this, _finalIndex, this.getHfIndexFromVisualIndex(visualFinalIndex));
    }
    /**
   * Calculating where to move HF elements and performing already calculated moves.
   *
   * @param {boolean} movePossible Indicates if it was possible to move HOT indexes to the desired position.
   * @param {boolean} orderChanged Indicates if order of HOT indexes was changed by move.
   */ calculateAndSyncMoves(movePossible, orderChanged) {
        if (_class_private_field_get(this, _indexSyncer).isPerformingUndoRedo()) {
            return;
        }
        if (movePossible === false || orderChanged === false) {
            return;
        }
        const calculatedMoves = (0, _moves.getMoves)(_class_private_field_get(this, _movedIndexes), _class_private_field_get(this, _finalIndex) ?? 0, _class_private_field_get(this, _indexMapper).getNumberOfIndexes());
        if (_class_private_field_get(this, _indexSyncer).getSheetId() === null) {
            _class_private_field_get(this, _indexSyncer).getPostponeAction(()=>this.syncMoves(calculatedMoves));
        } else {
            this.syncMoves(calculatedMoves);
        }
    }
    /**
   * Gets callback for hook triggered after performing change of indexes order.
   *
   * @returns {Function}
   */ getIndexesChangeSyncMethod() {
        const SYNC_ORDER_CHANGE_METHOD_NAME = `set${(0, _string.toUpperCaseFirst)(_class_private_field_get(this, _axis))}Order`;
        return (source)=>{
            if (_class_private_field_get(this, _indexSyncer).isPerformingUndoRedo()) {
                return;
            }
            const newSequence = _class_private_field_get(this, _indexMapper).getIndexesSequence();
            if (source === 'update' && newSequence.length > 0) {
                // One-pass inverse lookup instead of `newSequence.indexOf` per element, which would make
                // every sort/unsort quadratic in the number of rows or columns.
                const positionOfPhysical = new Array(newSequence.length);
                for(let position = 0; position < newSequence.length; position += 1){
                    positionOfPhysical[newSequence[position]] = position;
                }
                const relativeTransformation = _class_private_field_get(this, _indexesSequence).map((index)=>positionOfPhysical[index] ?? -1);
                const sheetDimensions = _class_private_field_get(this, _indexSyncer).getEngine().getSheetDimensions(_class_private_field_get(this, _indexSyncer).getSheetId());
                let sizeForAxis;
                if (_class_private_field_get(this, _axis) === 'row') {
                    sizeForAxis = sheetDimensions.height;
                } else {
                    sizeForAxis = sheetDimensions.width;
                }
                const numberOfReorganisedIndexes = relativeTransformation.length;
                // Sheet dimension can be changed by HF's engine for purpose of calculating values. It extends dependency
                // graph to calculate values outside of a defined dataset. This part of code could be removed after resolving
                // feature request from HF issue board (handsontable/hyperformula#1179).
                for(let i = numberOfReorganisedIndexes; i < sizeForAxis; i += 1){
                    relativeTransformation.push(i);
                }
                _class_private_field_get(this, _indexSyncer).getEngine()[SYNC_ORDER_CHANGE_METHOD_NAME](_class_private_field_get(this, _indexSyncer).getSheetId(), relativeTransformation);
            }
            _class_private_field_set(this, _indexesSequence, newSequence);
        };
    }
    /**
   * Initialize the AxisSyncer.
   */ init() {
        _class_private_method_get(this, _syncInitialOrder, syncInitialOrder).call(this);
        _class_private_field_set(this, _indexesSequence, _class_private_field_get(this, _indexMapper).getIndexesSequence());
    }
    /**
   * Initializes the axis syncer for the given axis with the corresponding index mapper and parent index syncer references.
   */ constructor(axis, indexMapper, indexSyncer){
        _class_private_method_init(this, _getTranslationCache);
        _class_private_method_init(this, _syncInitialOrder);
        /**
   * The axis for which the actions are performed.
   *
   * @private
   * @type {'row'|'column'}
   */ _class_private_field_init(this, _axis, {
            writable: true,
            value: void 0
        });
        /**
   * Reference to index mapper.
   *
   * @private
   * @type {IndexMapper}
   */ _class_private_field_init(this, _indexMapper, {
            writable: true,
            value: void 0
        });
        /**
   * The index synchronizer for both axis (is storing some more general information).
   *
   * @private
   * @type {IndexSyncer}
   */ _class_private_field_init(this, _indexSyncer, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _indexesSequence, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _movedIndexes, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _finalIndex, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _removedIndexes, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _translationCache, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _indexesSequence, []);
        _class_private_field_set(this, _movedIndexes, []);
        _class_private_field_set(this, _removedIndexes, []);
        _class_private_field_set(this, _translationCache, null);
        _class_private_field_set(this, _axis, axis);
        _class_private_field_set(this, _indexMapper, indexMapper);
        _class_private_field_set(this, _indexSyncer, indexSyncer);
        // The sequence hook fires synchronously on every sequence mutation (also mid-batch), the
        // `cacheUpdated` hook fires when the mapper rebuilds its own `notTrimmedIndexes` cache — the
        // same moment from which the translation methods would read the new trimming state.
        _class_private_field_get(this, _indexMapper).addLocalHook('indexesSequenceChange', ()=>{
            _class_private_field_set(this, _translationCache, null);
        });
        _class_private_field_get(this, _indexMapper).addLocalHook('cacheUpdated', (changes)=>{
            if (changes.trimmedIndexesChanged) {
                _class_private_field_set(this, _translationCache, null);
            }
        });
    }
}
function getTranslationCache() {
    if (_class_private_field_get(this, _translationCache) === null) {
        const physicalIndexOfHf = _class_private_field_get(this, _indexMapper).getIndexesSequence();
        const notTrimmedIndexes = _class_private_field_get(this, _indexMapper).getNotTrimmedIndexes();
        const hfIndexOfPhysical = new Array(physicalIndexOfHf.length);
        const visualIndexOfPhysical = new Array(physicalIndexOfHf.length).fill(-1);
        for(let hfIndex = 0; hfIndex < physicalIndexOfHf.length; hfIndex += 1){
            hfIndexOfPhysical[physicalIndexOfHf[hfIndex]] = hfIndex;
        }
        for(let visualIndex = 0; visualIndex < notTrimmedIndexes.length; visualIndex += 1){
            visualIndexOfPhysical[notTrimmedIndexes[visualIndex]] = visualIndex;
        }
        _class_private_field_set(this, _translationCache, {
            physicalIndexOfHf,
            hfIndexOfPhysical,
            visualIndexOfPhysical
        });
    }
    return _class_private_field_get(this, _translationCache);
}
function syncInitialOrder() {
    const sequence = _class_private_field_get(this, _indexMapper).getIndexesSequence();
    const isIdentity = sequence.every((value, index)=>value === index);
    if (isIdentity || sequence.length === 0) {
        return;
    }
    const engine = _class_private_field_get(this, _indexSyncer).getEngine();
    const sheetId = _class_private_field_get(this, _indexSyncer).getSheetId();
    if (engine === null || sheetId === null) {
        _class_private_field_get(this, _indexSyncer).getPostponeAction()(()=>_class_private_method_get(this, _syncInitialOrder, syncInitialOrder).call(this));
        return;
    }
    const SYNC_ORDER_CHANGE_METHOD_NAME = `set${(0, _string.toUpperCaseFirst)(_class_private_field_get(this, _axis))}Order`;
    const sheetDimensions = engine.getSheetDimensions(sheetId);
    const sizeForAxis = _class_private_field_get(this, _axis) === 'row' ? sheetDimensions.height : sheetDimensions.width;
    // HF currently holds data in physical order ([0..n-1] identity). The transformation tells HF where each
    // currently-held element should move to, so that HF's visual order matches HOT's visual order. For each
    // current position `i`, the target position is the visual index of physical `i` — that is, the inverse
    // permutation of the sequence, built in one pass.
    const transformation = new Array(sequence.length);
    for(let position = 0; position < sequence.length; position += 1){
        transformation[sequence[position]] = position;
    }
    for(let i = transformation.length; i < sizeForAxis; i += 1){
        transformation.push(i);
    }
    engine[SYNC_ORDER_CHANGE_METHOD_NAME](sheetId, transformation);
}
const _default = AxisSyncer;
