"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _axisSyncer = /*#__PURE__*/ _interop_require_default(require("./axisSyncer"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var _rowIndexSyncer = /*#__PURE__*/ new WeakMap(), _columnIndexSyncer = /*#__PURE__*/ new WeakMap(), _postponeAction = /*#__PURE__*/ new WeakMap(), /**
   * Flag informing whether undo is already performed (we don't perform synchronization in such case).
   *
   * @private
   * @type {boolean}
   */ _isPerformingUndo = /*#__PURE__*/ new WeakMap(), /**
   * Flag informing whether redo is already performed (we don't perform synchronization in such case).
   *
   * @private
   * @type {boolean}
   */ _isPerformingRedo = /*#__PURE__*/ new WeakMap(), /**
   * The HF's engine instance which will be synced.
   *
   * @private
   * @type {HyperFormula|null}
   */ _engine = /*#__PURE__*/ new WeakMap(), /**
   * HyperFormula's sheet id.
   *
   * @private
   * @type {number|null}
   */ _sheetId = /*#__PURE__*/ new WeakMap();
/**
 * @private
 * @class IndexSyncer
 * @description
 *
 * Indexes synchronizer responsible for providing logic for syncing actions done on indexes for HOT to actions performed
 * on HF's.
 *
 */ class IndexSyncer {
    /**
   * Gets index synchronizer for a particular axis.
   *
   * @param {'row'|'column'} indexType Type of indexes.
   * @returns {AxisSyncer}
   */ getForAxis(indexType) {
        if (indexType === 'row') {
            return _class_private_field_get(this, _rowIndexSyncer);
        }
        return _class_private_field_get(this, _columnIndexSyncer);
    }
    /**
   * Sets flag informing whether an undo action is already performed (we don't execute synchronization in such case).
   *
   * @param {boolean} flagValue Boolean value for the flag.
   */ setPerformUndo(flagValue) {
        _class_private_field_set(this, _isPerformingUndo, flagValue);
    }
    /**
   * Sets flag informing whether a redo action is already performed (we don't execute synchronization in such case).
   *
   * @param {boolean} flagValue Boolean value for the flag.
   */ setPerformRedo(flagValue) {
        _class_private_field_set(this, _isPerformingRedo, flagValue);
    }
    /**
   * Gets information whether redo or undo action is already performed (we don't execute synchronization in such case).
   *
   * @private
   * @returns {boolean}
   */ isPerformingUndoRedo() {
        return _class_private_field_get(this, _isPerformingUndo) || _class_private_field_get(this, _isPerformingRedo);
    }
    /**
   * Gets HyperFormula's sheet id.
   *
   * @returns {number|null}
   */ getSheetId() {
        return _class_private_field_get(this, _sheetId);
    }
    /**
   * Gets engine instance that will be used for handled instance of Handsontable.
   *
   * @type {HyperFormula|null}
   */ getEngine() {
        return _class_private_field_get(this, _engine);
    }
    /**
   * Gets method which will postpone execution of some action (needed when synchronization endpoint isn't setup yet).
   *
   * @returns {Function}
   */ getPostponeAction() {
        return _class_private_field_get(this, _postponeAction);
    }
    /**
   * Setups a synchronization endpoint.
   *
   * @param {HyperFormula|null} engine The HF's engine instance which will be synced.
   * @param {string|null} sheetId HyperFormula's sheet name.
   */ setupSyncEndpoint(engine, sheetId) {
        _class_private_field_set(this, _engine, engine);
        _class_private_field_set(this, _sheetId, sheetId);
        _class_private_field_get(this, _rowIndexSyncer).init();
        _class_private_field_get(this, _columnIndexSyncer).init();
    }
    /**
   * Initializes the index syncer by creating row and column axis syncers and storing the deferred action callback.
   */ constructor(rowIndexMapper, columnIndexMapper, postponeAction){
        /**
   * Indexes synchronizer for the axis of the rows.
   *
   * @private
   * @type {AxisSyncer}
   */ _class_private_field_init(this, _rowIndexSyncer, {
            writable: true,
            value: void 0
        });
        /**
   * Indexes synchronizer for the axis of the columns.
   *
   * @private
   * @type {AxisSyncer}
   */ _class_private_field_init(this, _columnIndexSyncer, {
            writable: true,
            value: void 0
        });
        /**
   * Method which will postpone execution of some action (needed when synchronization endpoint isn't setup yet).
   *
   * @private
   * @type {Function}
   */ _class_private_field_init(this, _postponeAction, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _isPerformingUndo, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _isPerformingRedo, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _engine, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _sheetId, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _isPerformingUndo, false);
        _class_private_field_set(this, _isPerformingRedo, false);
        _class_private_field_set(this, _engine, null);
        _class_private_field_set(this, _sheetId, null);
        _class_private_field_set(this, _rowIndexSyncer, new _axisSyncer.default('row', rowIndexMapper, this));
        _class_private_field_set(this, _columnIndexSyncer, new _axisSyncer.default('column', columnIndexMapper, this));
        _class_private_field_set(this, _postponeAction, postponeAction);
    }
}
const _default = IndexSyncer;
