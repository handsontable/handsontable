"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "Cursor", {
    enumerable: true,
    get: function() {
        return Cursor;
    }
});
const _element = require("../../../helpers/dom/element");
class Cursor {
    /**
   * Get source type name.
   *
   * @param {*} object Event or Object with coordinates.
   * @returns {string} Returns one of this values: `'literal'`, `'event'`.
   */ getSourceType(object) {
        let type = 'literal';
        if (object instanceof Event) {
            type = 'event';
        }
        return type;
    }
    /**
   * Checks if element can be placed above the cursor.
   *
   * @param {HTMLElement} element Element to check if it's size will fit above the cursor.
   * @returns {boolean}
   */ fitsAbove(element) {
        return this.topRelative >= element.offsetHeight;
    }
    /**
   * Checks if element can be placed below the cursor.
   *
   * @param {HTMLElement} element Element to check if it's size will fit below the cursor.
   * @param {number} [viewportHeight] The viewport height.
   * @returns {boolean}
   */ fitsBelow(element, viewportHeight = this.rootWindow.innerHeight) {
        return this.topRelative + element.offsetHeight <= viewportHeight;
    }
    /**
   * Checks if element can be placed on the right of the cursor.
   *
   * @param {HTMLElement} element Element to check if it's size will fit on the right of the cursor.
   * @param {number} [viewportWidth] The viewport width.
   * @returns {boolean}
   */ fitsOnRight(element, viewportWidth = this.rootWindow.document.documentElement.clientWidth) {
        return this.leftRelative + this.cellWidth + element.offsetWidth <= viewportWidth;
    }
    /**
   * Checks if element can be placed on the left on the cursor.
   *
   * @param {HTMLElement} element Element to check if it's size will fit on the left of the cursor.
   * @returns {boolean}
   */ fitsOnLeft(element) {
        return this.leftRelative >= element.offsetWidth;
    }
    /**
   * Initializes the cursor position by computing coordinates from either a literal object or a DOM event.
   */ constructor(object, rootWindow){
        const windowScrollTop = rootWindow.scrollY;
        const windowScrollLeft = rootWindow.scrollX;
        let top = 0;
        let topRelative = 0;
        let left = 0;
        let leftRelative = 0;
        let cellHeight = 0;
        let cellWidth = 0;
        this.rootWindow = rootWindow;
        this.type = this.getSourceType(object);
        if (this.type === 'literal') {
            const literal = object;
            top = parseInt(String(literal.top), 10);
            left = parseInt(String(literal.left), 10);
            cellHeight = literal.height || 0;
            cellWidth = literal.width || 0;
            topRelative = top;
            leftRelative = left;
            top += windowScrollTop;
            left += windowScrollLeft;
        } else if (this.type === 'event') {
            const evt = object;
            top = parseInt(String(evt.pageY), 10);
            left = parseInt(String(evt.pageX), 10);
            cellHeight = (0, _element.eventTargetEl)(evt).clientHeight;
            cellWidth = (0, _element.eventTargetEl)(evt).clientWidth;
            topRelative = top - windowScrollTop;
            leftRelative = left - windowScrollLeft;
        }
        this.top = top;
        this.topRelative = topRelative;
        this.left = left;
        this.leftRelative = leftRelative;
        this.scrollTop = windowScrollTop;
        this.scrollLeft = windowScrollLeft;
        this.cellHeight = cellHeight;
        this.cellWidth = cellWidth;
    }
}
