"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ALIGNMENT () {
        return _alignment.KEY;
    },
    get CLEAR_COLUMN () {
        return _clearColumn.KEY;
    },
    get COLUMN_LEFT () {
        return _columnLeft.KEY;
    },
    get COLUMN_RIGHT () {
        return _columnRight.KEY;
    },
    get ITEMS () {
        return ITEMS;
    },
    get NO_ITEMS () {
        return _noItems.KEY;
    },
    get READ_ONLY () {
        return _readOnly.KEY;
    },
    get REDO () {
        return _redo.KEY;
    },
    get REMOVE_COLUMN () {
        return _removeColumn.KEY;
    },
    get REMOVE_ROW () {
        return _removeRow.KEY;
    },
    get ROW_ABOVE () {
        return _rowAbove.KEY;
    },
    get ROW_BELOW () {
        return _rowBelow.KEY;
    },
    get SEPARATOR () {
        return _separator.KEY;
    },
    get UNDO () {
        return _undo.KEY;
    },
    get addItem () {
        return addItem;
    },
    get predefinedItems () {
        return predefinedItems;
    }
});
const _object = require("../../../helpers/object");
const _alignment = /*#__PURE__*/ _interop_require_wildcard(require("./alignment"));
const _clearColumn = /*#__PURE__*/ _interop_require_wildcard(require("./clearColumn"));
const _columnLeft = /*#__PURE__*/ _interop_require_wildcard(require("./columnLeft"));
const _columnRight = /*#__PURE__*/ _interop_require_wildcard(require("./columnRight"));
const _readOnly = /*#__PURE__*/ _interop_require_wildcard(require("./readOnly"));
const _redo = /*#__PURE__*/ _interop_require_wildcard(require("./redo"));
const _removeColumn = /*#__PURE__*/ _interop_require_wildcard(require("./removeColumn"));
const _removeRow = /*#__PURE__*/ _interop_require_wildcard(require("./removeRow"));
const _rowAbove = /*#__PURE__*/ _interop_require_wildcard(require("./rowAbove"));
const _rowBelow = /*#__PURE__*/ _interop_require_wildcard(require("./rowBelow"));
const _separator = /*#__PURE__*/ _interop_require_wildcard(require("./separator"));
const _noItems = /*#__PURE__*/ _interop_require_wildcard(require("./noItems"));
const _undo = /*#__PURE__*/ _interop_require_wildcard(require("./undo"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const ITEMS = [
    _rowAbove.KEY,
    _rowBelow.KEY,
    _columnLeft.KEY,
    _columnRight.KEY,
    _clearColumn.KEY,
    _removeRow.KEY,
    _removeColumn.KEY,
    _undo.KEY,
    _redo.KEY,
    _readOnly.KEY,
    _alignment.KEY,
    _separator.KEY,
    _noItems.KEY
];
const _predefinedItems = {
    [_separator.KEY]: _separator.default,
    [_noItems.KEY]: _noItems.default,
    [_rowAbove.KEY]: _rowAbove.default,
    [_rowBelow.KEY]: _rowBelow.default,
    [_columnLeft.KEY]: _columnLeft.default,
    [_columnRight.KEY]: _columnRight.default,
    [_clearColumn.KEY]: _clearColumn.default,
    [_removeRow.KEY]: _removeRow.default,
    [_removeColumn.KEY]: _removeColumn.default,
    [_undo.KEY]: _undo.default,
    [_redo.KEY]: _redo.default,
    [_readOnly.KEY]: _readOnly.default,
    [_alignment.KEY]: _alignment.default
};
function predefinedItems() {
    const items = {};
    (0, _object.objectEach)(_predefinedItems, (itemFactory, key)=>{
        items[key] = itemFactory();
    });
    return items;
}
function addItem(key, item) {
    if (ITEMS.indexOf(key) === -1) {
        _predefinedItems[key] = item;
    }
}
