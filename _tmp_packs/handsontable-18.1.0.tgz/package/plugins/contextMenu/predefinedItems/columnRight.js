"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get KEY () {
        return KEY;
    },
    get /**
 * @returns {object}
 */ default () {
        return columnRightItem;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const KEY = 'col_right';
function columnRightItem() {
    return {
        key: KEY,
        name () {
            const label = this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_INSERT_RIGHT);
            return label;
        },
        callback () {
            const range = this.getSelectedRangeActive();
            if (!range) {
                return;
            }
            const activeSelection = range.getTopRightCorner();
            const alterAction = this.isRtl() ? 'insert_col_start' : 'insert_col_end';
            if (activeSelection.col === null) {
                return;
            }
            this.alter(alterAction, activeSelection.col, 1, 'ContextMenu.columnRight');
        },
        disabled () {
            if (!this.isColumnModificationAllowed()) {
                return true;
            }
            const range = this.getSelectedRangeActive();
            if (!range || this.selection.isSelectedByRowHeader() || range.isSingleHeader() && (range.highlight.col ?? 0) < 0 || this.countSourceCols() >= (this.getSettings().maxCols ?? Infinity)) {
                return true;
            }
            return false;
        },
        hidden () {
            return !this.getSettings().allowInsertColumn;
        }
    };
}
