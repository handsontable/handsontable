"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get KEY () {
        return KEY;
    },
    get /**
 * @returns {object}
 */ default () {
        return alignmentItem;
    }
});
const _utils = require("../utils");
const _separator = require("./separator");
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const KEY = 'alignment';
function alignmentItem() {
    return {
        key: KEY,
        name () {
            return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ALIGNMENT);
        },
        disabled () {
            if (this.countRows() === 0 || this.countCols() === 0) {
                return true;
            }
            const range = this.getSelectedRangeActive();
            if (!range) {
                return true;
            }
            if (range.isSingleHeader()) {
                return true;
            }
            return !(this.getSelectedRange() && !this.selection.isSelectedByCorner());
        },
        submenu: {
            items: [
                {
                    key: `${KEY}:left`,
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT);
                    },
                    callback () {
                        const selectedRange = this.getSelectedRange() ?? [];
                        const stateBefore = (0, _utils.getAlignmentClasses)(selectedRange, (row, col)=>this.getCellMetaTransient(row, col).className);
                        const type = 'horizontal';
                        const alignment = 'htLeft';
                        this.runHooks('beforeCellAlignment', stateBefore, selectedRange, type, alignment);
                        (0, _utils.align)(selectedRange, type, alignment, (row, col)=>this.getCellMetaTransient(row, col), (row, col, key, value)=>this.setCellMeta(row, col, key, value));
                        this.render();
                    },
                    disabled: false
                },
                {
                    key: `${KEY}:center`,
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER);
                    },
                    callback () {
                        const selectedRange = this.getSelectedRange() ?? [];
                        const stateBefore = (0, _utils.getAlignmentClasses)(selectedRange, (row, col)=>this.getCellMetaTransient(row, col).className);
                        const type = 'horizontal';
                        const alignment = 'htCenter';
                        this.runHooks('beforeCellAlignment', stateBefore, selectedRange, type, alignment);
                        (0, _utils.align)(selectedRange, type, alignment, (row, col)=>this.getCellMetaTransient(row, col), (row, col, key, value)=>this.setCellMeta(row, col, key, value));
                        this.render();
                    },
                    disabled: false
                },
                {
                    key: `${KEY}:right`,
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT);
                    },
                    callback () {
                        const selectedRange = this.getSelectedRange() ?? [];
                        const stateBefore = (0, _utils.getAlignmentClasses)(selectedRange, (row, col)=>this.getCellMetaTransient(row, col).className);
                        const type = 'horizontal';
                        const alignment = 'htRight';
                        this.runHooks('beforeCellAlignment', stateBefore, selectedRange, type, alignment);
                        (0, _utils.align)(selectedRange, type, alignment, (row, col)=>this.getCellMetaTransient(row, col), (row, col, key, value)=>this.setCellMeta(row, col, key, value));
                        this.render();
                    },
                    disabled: false
                },
                {
                    key: `${KEY}:justify`,
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY);
                    },
                    callback () {
                        const selectedRange = this.getSelectedRange() ?? [];
                        const stateBefore = (0, _utils.getAlignmentClasses)(selectedRange, (row, col)=>this.getCellMetaTransient(row, col).className);
                        const type = 'horizontal';
                        const alignment = 'htJustify';
                        this.runHooks('beforeCellAlignment', stateBefore, selectedRange, type, alignment);
                        (0, _utils.align)(selectedRange, type, alignment, (row, col)=>this.getCellMetaTransient(row, col), (row, col, key, value)=>this.setCellMeta(row, col, key, value));
                        this.render();
                    },
                    disabled: false
                },
                {
                    name: _separator.KEY
                },
                {
                    key: `${KEY}:top`,
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ALIGNMENT_TOP);
                    },
                    callback () {
                        const selectedRange = this.getSelectedRange() ?? [];
                        const stateBefore = (0, _utils.getAlignmentClasses)(selectedRange, (row, col)=>this.getCellMetaTransient(row, col).className);
                        const type = 'vertical';
                        const alignment = 'htTop';
                        this.runHooks('beforeCellAlignment', stateBefore, selectedRange, type, alignment);
                        (0, _utils.align)(selectedRange, type, alignment, (row, col)=>this.getCellMetaTransient(row, col), (row, col, key, value)=>this.setCellMeta(row, col, key, value));
                        this.render();
                    },
                    disabled: false
                },
                {
                    key: `${KEY}:middle`,
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE);
                    },
                    callback () {
                        const selectedRange = this.getSelectedRange() ?? [];
                        const stateBefore = (0, _utils.getAlignmentClasses)(selectedRange, (row, col)=>this.getCellMetaTransient(row, col).className);
                        const type = 'vertical';
                        const alignment = 'htMiddle';
                        this.runHooks('beforeCellAlignment', stateBefore, selectedRange, type, alignment);
                        (0, _utils.align)(selectedRange, type, alignment, (row, col)=>this.getCellMetaTransient(row, col), (row, col, key, value)=>this.setCellMeta(row, col, key, value));
                        this.render();
                    },
                    disabled: false
                },
                {
                    key: `${KEY}:bottom`,
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM);
                    },
                    callback () {
                        const selectedRange = this.getSelectedRange() ?? [];
                        const stateBefore = (0, _utils.getAlignmentClasses)(selectedRange, (row, col)=>this.getCellMetaTransient(row, col).className);
                        const type = 'vertical';
                        const alignment = 'htBottom';
                        this.runHooks('beforeCellAlignment', stateBefore, selectedRange, type, alignment);
                        (0, _utils.align)(selectedRange, type, alignment, (row, col)=>this.getCellMetaTransient(row, col), (row, col, key, value)=>this.setCellMeta(row, col, key, value));
                        this.render();
                    },
                    disabled: false
                }
            ]
        }
    };
}
