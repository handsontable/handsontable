"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get KEY () {
        return KEY;
    },
    get /**
 * @returns {object}
 */ default () {
        return clearColumnItem;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const KEY = 'clear_column';
function clearColumnItem() {
    return {
        key: KEY,
        name () {
            return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_CLEAR_COLUMN);
        },
        callback (key, selection) {
            const startColumn = selection[0].start.col;
            const endColumn = selection[0].end.col;
            if (this.countRows()) {
                this.populateFromArray(0, startColumn, [
                    [
                        null
                    ]
                ], Math.max(selection[0].start.row, selection[0].end.row), endColumn, 'ContextMenu.clearColumn');
            }
        },
        disabled () {
            const range = this.getSelectedRangeActive();
            if (!range || range.isSingleHeader() && (range.highlight.col === null || range.highlight.col < 0) || !this.selection.isSelectedByColumnHeader()) {
                return true;
            }
            let atLeastOneNonReadOnly = false;
            range.forAll((row, col)=>{
                if (row < 0 || col < 0) {
                    return true;
                }
                const { readOnly } = this.getCellMetaTransient(row, col);
                if (!readOnly) {
                    atLeastOneNonReadOnly = true;
                    return false;
                }
                return true;
            });
            return !atLeastOneNonReadOnly;
        }
    };
}
