"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ContextMenu () {
        return _contextMenu.ContextMenu;
    },
    get PLUGIN_KEY () {
        return _contextMenu.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _contextMenu.PLUGIN_PRIORITY;
    }
});
const _contextMenu = require("./contextMenu");
