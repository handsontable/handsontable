"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ContextMenu () {
        return ContextMenu;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _hooks = require("../../core/hooks");
const _array = require("../../helpers/array");
const _object = require("../../helpers/object");
const _commandExecutor = require("./commandExecutor");
const _itemsFactory = require("./itemsFactory");
const _menu = require("./menu");
const _utils = require("./utils");
const _element = require("../../helpers/dom/element");
const _predefinedItems = require("./predefinedItems");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
const PLUGIN_KEY = 'contextMenu';
const PLUGIN_PRIORITY = 70;
const SHORTCUTS_GROUP = PLUGIN_KEY;
_hooks.Hooks.getSingleton().register('afterContextMenuDefaultOptions');
_hooks.Hooks.getSingleton().register('beforeContextMenuShow');
_hooks.Hooks.getSingleton().register('afterContextMenuShow');
_hooks.Hooks.getSingleton().register('afterContextMenuHide');
_hooks.Hooks.getSingleton().register('afterContextMenuExecute');
var /**
   * On contextmenu listener.
   *
   * @param {Event} event The mouse event object.
   */ _onAfterOnCellContextMenu = /*#__PURE__*/ new WeakMap(), /**
   * On menu after open listener.
   */ _onMenuAfterOpen = /*#__PURE__*/ new WeakMap(), /**
   * On menu after close listener.
   */ _onMenuAfterClose = /*#__PURE__*/ new WeakMap();
class ContextMenu extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns the list of plugin dependencies required before this plugin can be initialized.
   */ static get PLUGIN_DEPS() {
        return [
            'plugin:AutoColumnSize'
        ];
    }
    /**
   * The item descriptor that identifies a menu separator. Use it as a value in a custom
   * `items` configuration object to insert a separator line at that key.
   *
   * @returns {MenuItemConfig}
   */ static get SEPARATOR() {
        return {
            name: _predefinedItems.SEPARATOR
        };
    }
    /**
   * Context menu default items order when `contextMenu` options is set as `true`.
   *
   * @returns {string[]}
   */ static get DEFAULT_ITEMS() {
        return [
            _predefinedItems.ROW_ABOVE,
            _predefinedItems.ROW_BELOW,
            _predefinedItems.SEPARATOR,
            _predefinedItems.COLUMN_LEFT,
            _predefinedItems.COLUMN_RIGHT,
            _predefinedItems.SEPARATOR,
            _predefinedItems.REMOVE_ROW,
            _predefinedItems.REMOVE_COLUMN,
            _predefinedItems.SEPARATOR,
            _predefinedItems.UNDO,
            _predefinedItems.REDO,
            _predefinedItems.SEPARATOR,
            _predefinedItems.READ_ONLY,
            _predefinedItems.SEPARATOR,
            _predefinedItems.ALIGNMENT
        ];
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link ContextMenu#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[PLUGIN_KEY];
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        const settings = this.hot.getSettings()[PLUGIN_KEY];
        const settingsObj = typeof settings === 'object' && settings !== null && !Array.isArray(settings) ? settings : null;
        if (settingsObj && typeof settingsObj.callback === 'function') {
            this.commandExecutor.setCommonCallback(settingsObj.callback);
        }
        this.menu = new _menu.Menu(this.hot, {
            className: 'htContextMenu',
            keepInViewport: true,
            container: settingsObj?.uiContainer || this.hot.rootPortalElement
        });
        this.menu.addLocalHook('afterOpen', _class_private_field_get(this, _onMenuAfterOpen));
        this.menu.addLocalHook('afterClose', _class_private_field_get(this, _onMenuAfterClose));
        this.menu.addLocalHook('executeCommand', (...params)=>{
            this.executeCommand.call(this, ...params);
        });
        this.addHook('afterOnCellContextMenu', _class_private_field_get(this, _onAfterOnCellContextMenu));
        this.addHook('beforeDialogShow', ()=>this.close());
        this.registerShortcuts();
        super.enablePlugin();
    }
    /**
   * Updates the plugin's state.
   *
   * This method is executed when [`updateSettings()`](@/api/core.md#updatesettings) is invoked with any of the following configuration options:
   *  - [`contextMenu`](@/api/options.md#contextmenu)
   */ updatePlugin() {
        this.disablePlugin();
        this.enablePlugin();
        super.updatePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        this.close();
        if (this.menu) {
            this.menu.destroy();
            this.menu = null;
        }
        this.unregisterShortcuts();
        super.disablePlugin();
    }
    /**
   * Register shortcuts responsible for toggling context menu.
   *
   * @private
   */ registerShortcuts() {
        this.hot.getShortcutManager().getContext('grid')?.addShortcut({
            keys: [
                [
                    'Control/Meta',
                    'Shift',
                    'Backslash'
                ],
                [
                    'Shift',
                    'F10'
                ]
            ],
            callback: ()=>{
                const activeRange = this.hot.getSelectedRangeActive();
                if (!activeRange) {
                    return;
                }
                const { highlight } = activeRange;
                if (highlight.row === null || highlight.col === null) {
                    return;
                }
                this.hot.scrollToFocusedCell();
                const cell = this.hot.getCell(highlight.row, highlight.col, true);
                if (!cell) {
                    return;
                }
                const rect = cell.getBoundingClientRect();
                const offset = (0, _utils.getDocumentOffsetByElement)(this.menu.container, this.hot.rootDocument);
                this.open({
                    left: rect.left + offset.left,
                    top: rect.top + offset.top - 1 + rect.height
                }, {
                    left: rect.width,
                    above: -rect.height
                }, ()=>{
                    const anchorCell = this.hot.getCell(highlight.row, highlight.col, true);
                    return anchorCell ? anchorCell.getBoundingClientRect() : null;
                });
                // Make sure the first item is selected (role=menuitem). Otherwise, screen readers
                // will block the Esc key for the whole menu.
                this.menu.getNavigator().toFirstItem();
            },
            runOnlyIf: ()=>{
                const highlight = this.hot.getSelectedRangeActive()?.highlight;
                return !!highlight && this.hot.selection.isCellVisible(highlight) && !this.menu.isOpened();
            },
            group: SHORTCUTS_GROUP
        });
    }
    /**
   * Unregister shortcuts responsible for toggling context menu.
   *
   * @private
   */ unregisterShortcuts() {
        this.hot.getShortcutManager().getContext('grid')?.removeShortcutsByGroup(SHORTCUTS_GROUP);
    }
    /**
   * Opens the menu and positions it based on the passed coordinates.
   *
   * @param {{ top: number, left: number }|Event} position An object with `top` and `left` properties
   * (coordinates relative to the browser viewport, without scroll offsets), or a native browser
   * `Event` instance (e.g., a `MouseEvent`).
   * @param {{ above: number, below: number, left: number, right: number }} offset An object that applies
   * an offset to the menu position.
   * @param {Function} [anchorRectProvider] Returns the current anchor rectangle for
   * scroll-follow repositioning, or `null` when the anchor is no longer rendered.
   * @fires Hooks#beforeContextMenuShow
   * @fires Hooks#afterContextMenuShow
   * @example
   * ```js
   * const menu = hot.getPlugin('contextMenu');
   *
   * hot.selectCell(0, 0);
   * menu.open({ top: 50, left: 50 });
   * ```
   */ open(position, offset = {
        above: 0,
        below: 0,
        left: 0,
        right: 0
    }, anchorRectProvider) {
        if (this.menu?.isOpened()) {
            return;
        }
        // Fire the user-facing hook before any menu state is committed. If a listener calls
        // `updateSettings({ contextMenu })`, the plugin reinitializes synchronously, and the
        // open flow below proceeds on the fresh `this.menu` instance with the new items.
        this.hot.runHooks('beforeContextMenuShow', this);
        this.prepareMenuItems();
        this.menu.open();
        (0, _object.objectEach)(offset, (value, key)=>{
            this.menu.setOffset(key, value);
        });
        this.menu.setPosition(position, anchorRectProvider);
    }
    /**
   * Closes the menu.
   */ close() {
        this.menu?.close();
        this.itemsFactory = null;
    }
    /**
   * Execute context menu command.
   *
   * The `executeCommand()` method works only for selected cells.
   *
   * When no cells are selected, `executeCommand()` doesn't do anything.
   *
   * You can execute all predefined commands:
   *  * `'row_above'` - Insert row above
   *  * `'row_below'` - Insert row below
   *  * `'col_left'` - Insert column left
   *  * `'col_right'` - Insert column right
   *  * `'clear_column'` - Clear selected column
   *  * `'remove_row'` - Remove row
   *  * `'remove_col'` - Remove column
   *  * `'undo'` - Undo last action
   *  * `'redo'` - Redo last action
   *  * `'make_read_only'` - Make cell read only
   *  * `'alignment:left'` - Alignment to the left
   *  * `'alignment:top'` - Alignment to the top
   *  * `'alignment:right'` - Alignment to the right
   *  * `'alignment:bottom'` - Alignment to the bottom
   *  * `'alignment:middle'` - Alignment to the middle
   *  * `'alignment:center'` - Alignment to the center (justify).
   *
   * Or you can execute command registered in settings where `key` is your command name.
   *
   * @param {string} commandName The command name to be executed.
   * @param {*} params Additional parameters passed to command executor module.
   */ executeCommand(commandName, ...params) {
        if (this.itemsFactory === null) {
            this.prepareMenuItems();
        }
        this.commandExecutor.execute(commandName, ...params);
    }
    /**
   * Prepares available contextMenu's items list and registers them in commandExecutor.
   *
   * @private
   * @fires Hooks#afterContextMenuDefaultOptions
   * @fires Hooks#beforeContextMenuSetItems
   */ prepareMenuItems() {
        this.itemsFactory = new _itemsFactory.ItemsFactory(this.hot, ContextMenu.DEFAULT_ITEMS);
        const settings = this.hot.getSettings()[PLUGIN_KEY];
        const predefinedItems = {
            items: this.itemsFactory.getItems(settings)
        };
        this.hot.runHooks('afterContextMenuDefaultOptions', predefinedItems);
        this.itemsFactory.setPredefinedItems(predefinedItems.items);
        const menuItems = this.itemsFactory.getItems(settings);
        this.hot.runHooks('beforeContextMenuSetItems', menuItems);
        this.menu.setMenuItems(menuItems);
        // Register all commands. Predefined and added by user or by plugins
        (0, _array.arrayEach)(menuItems, (command)=>{
            this.commandExecutor.registerCommand(String(command.key ?? ''), command);
        });
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        this.close();
        if (this.menu) {
            this.menu.destroy();
        }
        super.destroy();
    }
    constructor(...args){
        super(...args), _class_private_field_init(this, _onAfterOnCellContextMenu, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onMenuAfterOpen, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onMenuAfterClose, {
            writable: true,
            value: void 0
        }), /**
   * Instance of {@link CommandExecutor}.
   *
   * @private
   * @type {CommandExecutor}
   */ this.commandExecutor = new _commandExecutor.CommandExecutor(this.hot), /**
   * Instance of {@link ItemsFactory}.
   *
   * @private
   * @type {ItemsFactory}
   */ this.itemsFactory = null, /**
   * Instance of {@link Menu}.
   *
   * @private
   * @type {Menu}
   */ this.menu = null, _class_private_field_set(this, _onAfterOnCellContextMenu, (event)=>{
            const settings = this.hot.getSettings();
            const showRowHeaders = settings.rowHeaders;
            const showColHeaders = settings.colHeaders;
            /**
     * @private
     * @param {HTMLElement} element The element to validate.
     * @returns {boolean}
     */ function isValidElement(element) {
                const parent = element.parentNode;
                return element.nodeName === 'TD' || (0, _element.isHTMLElement)(parent) && parent.nodeName === 'TD';
            }
            const element = (0, _element.eventTargetEl)(event);
            this.close();
            if ((0, _element.hasClass)(element, 'handsontableInput')) {
                return;
            }
            event.preventDefault();
            event.stopPropagation();
            if (!(showRowHeaders || showColHeaders)) {
                if (!isValidElement(element) && !((0, _element.hasClass)(element, 'current') && (0, _element.hasClass)(element, 'wtBorder'))) {
                    return;
                }
            }
            const offset = (0, _utils.getDocumentOffsetByElement)(this.menu.container, this.hot.rootDocument);
            const anchorCell = element.closest('td, th');
            let anchorRectProvider;
            if (anchorCell) {
                const cellCoords = this.hot.getCoords(anchorCell);
                if (cellCoords && cellCoords.row !== null && cellCoords.col !== null) {
                    const { row, col } = cellCoords;
                    anchorRectProvider = ()=>{
                        const cell = this.hot.getCell(row, col, true);
                        return cell ? cell.getBoundingClientRect() : null;
                    };
                }
            }
            this.open({
                top: event.clientY + offset.top,
                left: event.clientX + offset.left
            }, undefined, anchorRectProvider);
        }), _class_private_field_set(this, _onMenuAfterOpen, ()=>{
            this.hot.runHooks('afterContextMenuShow', this);
        }), _class_private_field_set(this, _onMenuAfterClose, ()=>{
            this.hot.listen();
            this.hot.runHooks('afterContextMenuHide', this);
        });
    }
}
