"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "CommandExecutor", {
    enumerable: true,
    get: function() {
        return CommandExecutor;
    }
});
const _array = require("../../helpers/array");
const _errors = require("../../helpers/errors");
const _object = require("../../helpers/object");
class CommandExecutor {
    /**
   * Register command.
   *
   * @param {string} name Command name.
   * @param {object} commandDescriptor Command descriptor object with properties like `key` (command id),
   *                                   `callback` (task to execute), `name` (command name), `disabled` (command availability).
   */ registerCommand(name, commandDescriptor) {
        this.commands[name] = commandDescriptor;
    }
    /**
   * Set common callback which will be trigger on every executed command.
   *
   * @param {Function} callback Function which will be fired on every command execute.
   */ setCommonCallback(callback) {
        this.commonCallback = callback;
    }
    /**
   * Execute command by its name.
   *
   * @param {string} commandName Command id.
   * @param {*} params Arguments passed to command task.
   */ execute(commandName, ...params) {
        const commandSplit = commandName.split(':');
        const commandNamePrimary = commandSplit[0];
        const subCommandName = commandSplit.length === 2 ? commandSplit[1] : null;
        let command = this.commands[commandNamePrimary];
        if (!command) {
            (0, _errors.throwWithCause)(`Menu command '${commandNamePrimary}' not exists.`);
        }
        if (subCommandName && command.submenu) {
            command = findSubCommand(subCommandName, command.submenu.items);
        }
        if (command.disabled === true) {
            return;
        }
        if (typeof command.disabled === 'function' && command.disabled.call(this.hot) === true) {
            return;
        }
        if ((0, _object.hasOwnProperty)(command, 'submenu')) {
            return;
        }
        const callbacks = [];
        if (typeof command.callback === 'function') {
            callbacks.push(command.callback);
        }
        if (typeof this.commonCallback === 'function') {
            callbacks.push(this.commonCallback);
        }
        params.unshift(commandSplit.join(':'));
        (0, _array.arrayEach)(callbacks, (callback)=>callback.apply(this.hot, params));
    }
    /**
   * Initializes the command executor with a reference to the Handsontable instance.
   */ constructor(hotInstance){
        /**
   * @type {object}
   */ this.commands = {};
        /**
   * @type {Function}
   */ this.commonCallback = null;
        this.hot = hotInstance;
    }
}
/**
 * @param {string} subCommandName The subcommand name.
 * @param {string[]} subCommands The collection of the commands.
 * @returns {boolean}
 */ function findSubCommand(subCommandName, subCommands) {
    let command;
    (0, _array.arrayEach)(subCommands, (cmd)=>{
        const cmds = cmd.key ? cmd.key.split(':') : null;
        if (Array.isArray(cmds) && cmds[1] === subCommandName) {
            command = cmd;
            return false;
        }
    });
    return command;
}
