"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Notification () {
        return _notification.Notification;
    },
    get PLUGIN_KEY () {
        return _notification.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _notification.PLUGIN_PRIORITY;
    }
});
const _notification = require("./notification");
