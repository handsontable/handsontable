/**
 * Root CSS class name for the notification plugin overlay host.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get NOTIFICATION_CLASS_NAME () {
        return NOTIFICATION_CLASS_NAME;
    },
    get NOTIFICATION_POSITIONS () {
        return NOTIFICATION_POSITIONS;
    },
    get NOTIFICATION_VARIANTS () {
        return NOTIFICATION_VARIANTS;
    }
});
const NOTIFICATION_CLASS_NAME = 'ht-notification';
const NOTIFICATION_POSITIONS = [
    'top-start',
    'top-end',
    'bottom-start',
    'bottom-end'
];
const NOTIFICATION_VARIANTS = [
    'info',
    'success',
    'warning',
    'error'
];
