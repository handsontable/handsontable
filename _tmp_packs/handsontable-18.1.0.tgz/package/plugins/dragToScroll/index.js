"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DragToScroll () {
        return _dragToScroll.DragToScroll;
    },
    get PLUGIN_KEY () {
        return _dragToScroll.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _dragToScroll.PLUGIN_PRIORITY;
    }
});
const _dragToScroll = require("./dragToScroll");
