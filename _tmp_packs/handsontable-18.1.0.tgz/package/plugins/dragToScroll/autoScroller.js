"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AutoScroller", {
    enumerable: true,
    get: function() {
        return AutoScroller;
    }
});
const _object = require("../../helpers/object");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../mixins/localHooks"));
const _scrollTimer = require("./scrollTimer");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * Horizontal scroll timer.
   *
   * @type {ScrollTimer}
   */ _horizontal = /*#__PURE__*/ new WeakMap(), /**
   * Vertical scroll timer.
   *
   * @type {ScrollTimer}
   */ _vertical = /*#__PURE__*/ new WeakMap();
class AutoScroller {
    /**
   * Whether any axis is currently scrolling.
   *
   * @type {boolean}
   */ get isActive() {
        return _class_private_field_get(this, _horizontal).isActive || _class_private_field_get(this, _vertical).isActive;
    }
    /**
   * Whether the horizontal axis is currently scrolling.
   *
   * @type {boolean}
   */ get isHorizontalActive() {
        return _class_private_field_get(this, _horizontal).isActive;
    }
    /**
   * Whether the vertical axis is currently scrolling.
   *
   * @type {boolean}
   */ get isVerticalActive() {
        return _class_private_field_get(this, _vertical).isActive;
    }
    /**
   * Configures scroll timing settings for both axes.
   *
   * @param {object} settings Scroll settings.
   * @param {object} settings.intervalRange Interval range in milliseconds.
   * @param {object} settings.intervalRange.min Minimum interval in milliseconds.
   * @param {object} settings.intervalRange.max Maximum interval in milliseconds.
   * @param {number} settings.rampDistance Distance at which interval reaches minimum.
   */ configure(settings) {
        _class_private_field_get(this, _horizontal).configure(settings);
        _class_private_field_get(this, _vertical).configure(settings);
    }
    /**
   * Updates scroll state based on cursor overflow from viewport boundaries.
   *
   * @param {{ x: number, y: number }} overflow Distance past viewport edges (0 = inside, N >0 || N < 0 = pixels outside).
   */ update({ x, y }) {
        _class_private_field_get(this, _horizontal).update(x);
        _class_private_field_get(this, _vertical).update(y);
    }
    /**
   * Stops all scrolling.
   */ stop() {
        _class_private_field_get(this, _horizontal).stop();
        _class_private_field_get(this, _vertical).stop();
    }
    /**
   * Stops the horizontal axis scrolling only.
   */ stopHorizontal() {
        _class_private_field_get(this, _horizontal).stop();
    }
    /**
   * Stops the vertical axis scrolling only.
   */ stopVertical() {
        _class_private_field_get(this, _vertical).stop();
    }
    /**
   * Destroys the scroll looper.
   */ destroy() {
        this.stop();
        _class_private_field_set(this, _horizontal, null);
        _class_private_field_set(this, _vertical, null);
    }
    /**
   * @param {Function} registerTimeout Timeout registration function (typically `hot._registerTimeout`).
   */ constructor(registerTimeout){
        _class_private_field_init(this, _horizontal, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _vertical, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _horizontal, new _scrollTimer.ScrollTimer(registerTimeout));
        _class_private_field_set(this, _vertical, new _scrollTimer.ScrollTimer(registerTimeout));
        _class_private_field_get(this, _horizontal).addLocalHook('tick', (distance)=>this.runLocalHooks('scrollHorizontal', distance));
        _class_private_field_get(this, _vertical).addLocalHook('tick', (distance)=>this.runLocalHooks('scrollVertical', distance));
    }
}
(0, _object.mixin)(AutoScroller, _localHooks.default);
