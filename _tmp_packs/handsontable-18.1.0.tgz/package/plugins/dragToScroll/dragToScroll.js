"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DragToScroll () {
        return DragToScroll;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _event = require("../../helpers/dom/event");
const _element = require("../../helpers/dom/element");
const _cellCoords = require("../../helpers/dom/cellCoords");
const _autoScroller = require("./autoScroller");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
const PLUGIN_KEY = 'dragToScroll';
const PLUGIN_PRIORITY = 100;
var /**
   * Auto scroller for managing independent horizontal and vertical scroll timers.
   *
   * @type {AutoScroller}
   */ _autoScroller1 = /*#__PURE__*/ new WeakMap(), /**
   * Flag indicates if the mouse is outside the viewport.
   *
   * @type {boolean}
   */ _isOutsideViewport = /*#__PURE__*/ new WeakMap(), /**
   * Kind of drag currently active. Cell drags extend the selection directly. Corner,
   * move, and handle drags only use the auto-scroll timers because their owning plugins
   * update their state through the `afterScroll` hook.
   *
   * @type {('cell'|'corner'|'move'|'handle'|null)}
   */ _activeDragKind = /*#__PURE__*/ new WeakMap(), /**
   * Last observed mouse X coordinate (client space). Cached so that the viewport
   * can recompute the edge cell on each `afterScroll` tick even when the mouse
   * stays stationary outside the viewport.
   *
   * @type {number | null}
   */ _lastClientX = /*#__PURE__*/ new WeakMap(), /**
   * Last observed mouse Y coordinate (client space).
   *
   * @type {number | null}
   */ _lastClientY = /*#__PURE__*/ new WeakMap(), /**
   * Reference to the controller object from `beforeOnCellMouseDown`. The
   * object is mutated in-place by all hook handlers, so by the time
   * `#onAfterScroll` reads it the flags are fully set.
   *
   * @type {object | null}
   */ _mouseDownController = /*#__PURE__*/ new WeakMap(), /**
   * `Touch.identifier` of the finger that started a touch drag, so later touch events can be told
   * apart from any other finger on the screen.
   *
   * @type {number | null}
   */ _dragTouchId = /*#__PURE__*/ new WeakMap(), /**
   * On after on cell/cellCorner mouse down listener.
   *
   * @param {('cell'|'corner'|'move'|'handle')} kind The active drag interaction.
   * @param {Event} event The pointer event that started the drag - a `mousedown` on desktop, a
   * `touchstart` on mobile.
   * @param {object} [controller] The controller object from `beforeOnCellMouseDown`.
   */ _setupListening = /*#__PURE__*/ new WeakSet(), /**
   * Starts auto-scrolling for a move-zone drag, but only if MoveCells actually began one.
   *
   * The `afterOnSelectionEdgeMouseDown` hook fires unconditionally from `TableView`, while MoveCells
   * may reject the press (no movable range, a drag already running). MoveCells owns the drag and its
   * listener runs first — plugins initialize in ascending `PLUGIN_PRIORITY` order, and MoveCells is
   * 25 against this plugin's 100 — so the drag state is already settled by the time this runs.
   * Without the check, auto-scroll would run with no drag in progress.
   *
   * @param {MouseEvent} event The move-zone mouse event.
   */ _onSelectionEdgeMouseDown = /*#__PURE__*/ new WeakMap(), /**
   * Starts auto-scrolling for a selection-handle drag, but only if SelectionHandles actually began
   * one. Same ordering guarantee as `#onSelectionEdgeMouseDown` (SelectionHandles is priority 24).
   *
   * @param {MouseEvent} event The selection-handle mouse event.
   */ _onSelectionHandleMouseDown = /*#__PURE__*/ new WeakMap(), /**
   * Starts auto-scrolling for a mobile selection-handle drag.
   *
   * The mobile handles run entirely on touch events, so no `mousedown` reaches them and the
   * `afterOnSelectionHandleMouseDown` hook never fires - hence this separate entry point. The
   * ordering is guaranteed by DOM bubbling rather than by plugin priority: MultipleSelectionHandles
   * listens on `rootElement`, a descendant of the document this listener sits on, so it has already
   * recorded the drag by the time this runs.
   *
   * @param {Event} event The `touchstart` event.
   */ _onTouchStart = /*#__PURE__*/ new WeakMap(), /**
   * Feeds the moving finger's position to the auto-scroller.
   *
   * @param {Event} event The `touchmove` event.
   */ _onTouchMove = /*#__PURE__*/ new WeakMap(), /**
   * Stops auto-scrolling once the finger that started the drag leaves the screen.
   *
   * `touchend` and `touchcancel` fire once per finger, so "a finger lifted" is not the same question
   * as "the dragging finger lifted". Answering the first would let a palm or a second finger stop a
   * drag still in progress - and nothing re-arms short of a new `touchstart`, so auto-scroll would
   * stay dead for the rest of it.
   *
   * @param {Event} event The `touchend` or `touchcancel` event.
   */ _onTouchEnd = /*#__PURE__*/ new WeakMap(), /**
   * Scrolls the viewport horizontally by one column. Stops the horizontal axis
   * of the auto-scroller when `scrollViewportTo` reports that no scroll
   * happened — meaning the viewport is already pegged against the first or
   * last column.
   *
   * Under RTL, the screen-x → column-index mapping is visually inverted:
   * a mouse past the screen-right edge wants to reveal LOWER column indexes
   * (which are visually to the right of the current viewport), and past the
   * screen-left edge wants HIGHER column indexes.
   *
   * @param {number} distance Horizontal distance from viewport edge (positive = right, negative = left).
   */ _scrollHorizontal = /*#__PURE__*/ new WeakSet(), /**
   * Scrolls the viewport vertically by one row. Stops the vertical axis of the
   * auto-scroller when `scrollViewportTo` reports that no scroll happened.
   *
   * @param {number} distance Vertical distance from viewport edge (positive = down, negative = up).
   */ _scrollVertical = /*#__PURE__*/ new WeakSet(), /**
   * Prevents viewport scroll when the cursor is outside the viewport during
   * an active drag-scroll. Limited to the active-drag window so that ordinary
   * `selectCell` / mouse-click selections still scroll-into-view normally.
   *
   * @param {number} row Selection start visual row index.
   * @param {number} column Selection start visual column index.
   * @param {number} endRow Selection end visual row index.
   * @param {number} endColumn Selection end visual column index.
   * @param {object} preventScrolling A reference to the observable object with the `value` property.
   *                                  Property `preventScrolling.value` expects a boolean value that
   *                                  Handsontable uses to control scroll behavior after selection.
   */ _onAfterSelection = /*#__PURE__*/ new WeakMap(), /**
   * 'mouseMove' event callback.
   *
   * @private
   * @param {MouseEvent} event `mousemove` event properties.
   */ _onMouseMove = /*#__PURE__*/ new WeakSet(), /**
   * Records the latest pointer position and runs the viewport-boundary check that drives the
   * auto-scroller. Shared by the mouse and the touch input paths.
   *
   * @param {number} clientX The pointer's viewport X coordinate.
   * @param {number} clientY The pointer's viewport Y coordinate.
   */ _trackPointer = /*#__PURE__*/ new WeakSet(), /**
   * Extends the regular drag-select selection to the cell at the clamped mouse position
   * after each viewport auto-scroll tick. Autofill drags are skipped — the autofill plugin
   * owns its own selection extension via its `afterScroll` hook.
   */ _onAfterScroll = /*#__PURE__*/ new WeakMap();
class DragToScroll extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns the default settings applied when the plugin is enabled without explicit configuration.
   */ static get DEFAULT_SETTINGS() {
        return {
            interval: {
                min: 20,
                max: 500
            },
            rampDistance: 120
        };
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link DragToScroll#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[PLUGIN_KEY];
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        _class_private_field_get(this, _autoScroller1).configure({
            intervalRange: this.getSetting('interval'),
            rampDistance: this.getSetting('rampDistance')
        });
        this.addHook('beforeOnCellMouseDown', (event, _coords, _TD, controller)=>{
            const typedController = typeof controller === 'object' && controller !== null ? controller : null;
            _class_private_method_get(this, _setupListening, setupListening).call(this, 'cell', event, typedController);
        });
        this.addHook('afterOnCellCornerMouseDown', (event)=>_class_private_method_get(this, _setupListening, setupListening).call(this, 'corner', event));
        this.addHook('afterOnSelectionEdgeMouseDown', _class_private_field_get(this, _onSelectionEdgeMouseDown));
        this.addHook('afterOnSelectionHandleMouseDown', _class_private_field_get(this, _onSelectionHandleMouseDown));
        this.addHook('afterSelection', _class_private_field_get(this, _onAfterSelection));
        this.addHook('afterScroll', _class_private_field_get(this, _onAfterScroll));
        this.registerEvents();
        super.enablePlugin();
    }
    /**
   * Updates the plugin's state.
   *
   * This method is executed when [`updateSettings()`](@/api/core.md#updatesettings) is invoked with any of the following configuration options:
   *  - [`dragToScroll`](@/api/options.md#dragtoscroll)
   */ updatePlugin() {
        this.disablePlugin();
        this.enablePlugin();
        super.updatePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        _class_private_field_get(this, _autoScroller1).stop();
        this.unregisterEvents();
        super.disablePlugin();
    }
    /**
   * Sets the boundaries/dimensions of the scrollable viewport.
   *
   * @param {DOMRect|{left: number, right: number, top: number, bottom: number}} [boundaries] An object with
   * coordinates. Contains the window boundaries by default. The object is compatible with DOMRect.
   */ setBoundaries(boundaries = {
        left: 0,
        right: this.hot.rootWindow.innerWidth,
        top: 0,
        bottom: this.hot.rootWindow.innerHeight
    }) {
        this.boundaries = boundaries;
    }
    /**
   * Changes callback function.
   *
   * @param {Function} callback The callback function.
   */ setCallback(callback) {
        this.callback = callback;
    }
    /**
   * Checks if the mouse position (X, Y) is outside the viewport and fires a callback with calculated X an Y diffs
   * between passed boundaries.
   *
   * @param {number} x Mouse X coordinate to check.
   * @param {number} y Mouse Y coordinate to check.
   */ check(x, y) {
        let diffX = 0;
        let diffY = 0;
        const { boundaries } = this;
        if (boundaries) {
            if (y < boundaries.top) {
                // y is less than top
                diffY = y - boundaries.top;
            } else if (y > boundaries.bottom) {
                // y is more than bottom
                diffY = y - boundaries.bottom;
            }
            if (x < boundaries.left) {
                // x is less than left
                diffX = x - boundaries.left;
            } else if (x > boundaries.right) {
                // x is more than right
                diffX = x - boundaries.right;
            }
        }
        _class_private_field_set(this, _isOutsideViewport, diffY !== 0 || diffX !== 0);
        if (this.callback) {
            this.callback(diffX, diffY);
        }
    }
    /**
   * Enables listening on the `mousemove` and `touchmove` events.
   *
   * @private
   */ listen() {
        this.listening = true;
    }
    /**
   * Disables listening on the `mousemove` and `touchmove` events.
   *
   * @private
   */ unlisten() {
        this.listening = false;
        _class_private_field_set(this, _activeDragKind, null);
        _class_private_field_set(this, _dragTouchId, null);
        _class_private_field_set(this, _lastClientX, null);
        _class_private_field_set(this, _lastClientY, null);
        _class_private_field_set(this, _isOutsideViewport, false);
        _class_private_field_set(this, _mouseDownController, null);
        _class_private_field_get(this, _autoScroller1).stop();
    }
    /**
   * Returns current state of listening.
   *
   * @private
   * @returns {boolean}
   */ isListening() {
        return this.listening;
    }
    /**
   * Registers dom listeners.
   *
   * @private
   */ registerEvents() {
        const { rootWindow } = this.hot;
        let frame = rootWindow;
        while(frame){
            this.eventManager.addEventListener(frame.document, 'contextmenu', ()=>this.unlisten());
            this.eventManager.addEventListener(frame.document, 'mouseup', ()=>this.unlisten());
            this.eventManager.addEventListener(frame.document, 'keydown', (event)=>{
                if ('key' in event && event.key === 'Escape') {
                    this.unlisten();
                }
            });
            this.eventManager.addEventListener(frame.document, 'mousemove', (event)=>{
                _class_private_method_get(this, _onMouseMove, onMouseMove).call(this, event);
            });
            // Touch input needs its own listeners: a browser fires no `mousemove` while a finger is
            // down, so without these the auto-scroller never receives a position on mobile (#11658).
            this.eventManager.addEventListener(frame.document, 'touchstart', _class_private_field_get(this, _onTouchStart));
            this.eventManager.addEventListener(frame.document, 'touchmove', _class_private_field_get(this, _onTouchMove));
            this.eventManager.addEventListener(frame.document, 'touchend', _class_private_field_get(this, _onTouchEnd));
            this.eventManager.addEventListener(frame.document, 'touchcancel', _class_private_field_get(this, _onTouchEnd));
            frame = (0, _element.getParentWindow)(frame);
        }
    }
    /**
   * Unbinds the events used by the plugin.
   *
   * @private
   */ unregisterEvents() {
        this.eventManager.clear();
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        _class_private_field_get(this, _autoScroller1).destroy();
        super.destroy();
    }
    constructor(...args){
        super(...args), _class_private_method_init(this, _setupListening), _class_private_method_init(this, _scrollHorizontal), _class_private_method_init(this, _scrollVertical), _class_private_method_init(this, _onMouseMove), _class_private_method_init(this, _trackPointer), _class_private_field_init(this, _autoScroller1, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _isOutsideViewport, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _activeDragKind, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _lastClientX, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _lastClientY, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _mouseDownController, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _dragTouchId, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onSelectionEdgeMouseDown, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onSelectionHandleMouseDown, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onTouchStart, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onTouchMove, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onTouchEnd, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterSelection, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterScroll, {
            writable: true,
            value: void 0
        }), /**
   * Size of an element and its position relative to the viewport,
   * e.g. {bottom: 449, height: 441, left: 8, right: 814, top: 8, width: 806, x: 8, y:8}.
   *
   * @type {DOMRect}
   */ this.boundaries = null, /**
   * Callback function.
   *
   * @private
   * @type {Function}
   */ this.callback = null, /**
   * Flag indicates mouseDown/mouseUp.
   *
   * @private
   * @type {boolean}
   */ this.listening = false, _class_private_field_set(this, _autoScroller1, new _autoScroller.AutoScroller((fn, delay)=>this.hot._registerTimeout(fn, delay)).addLocalHook('scrollHorizontal', (distance)=>_class_private_method_get(this, _scrollHorizontal, scrollHorizontal).call(this, distance)).addLocalHook('scrollVertical', (distance)=>_class_private_method_get(this, _scrollVertical, scrollVertical).call(this, distance))), _class_private_field_set(this, _isOutsideViewport, false), _class_private_field_set(this, _activeDragKind, null), _class_private_field_set(this, _lastClientX, null), _class_private_field_set(this, _lastClientY, null), _class_private_field_set(this, _mouseDownController, null), _class_private_field_set(this, _dragTouchId, null), _class_private_field_set(this, _onSelectionEdgeMouseDown, (event)=>{
            if (this.hot.getPlugin('moveCells')?.isDragActive() !== true) {
                return;
            }
            _class_private_method_get(this, _setupListening, setupListening).call(this, 'move', event);
        }), _class_private_field_set(this, _onSelectionHandleMouseDown, (event)=>{
            if (this.hot.getPlugin('selectionHandles')?.isDragActive() !== true) {
                return;
            }
            _class_private_method_get(this, _setupListening, setupListening).call(this, 'handle', event);
        }), _class_private_field_set(this, _onTouchStart, (event)=>{
            // Every later finger lands while the handle drag is still running, so this fires again for each
            // one. Keep following the finger that started the drag - taking the newest instead would leave
            // auto-scroll chasing a resting thumb, and would end the drag when that thumb lifted.
            if (_class_private_field_get(this, _dragTouchId) !== null) {
                return;
            }
            const touch = (0, _event.getFirstChangedTouch)(event);
            // No identifier means no way to tell this finger from any other later on, so there would be no
            // safe moment to stop. Better not to start: `#dragTouchId` stays in step with being touch-armed,
            // which is what `#onTouchEnd` relies on.
            if (touch === null) {
                return;
            }
            // Ask about THIS finger, not merely whether some drag is running. A drag can outlive the
            // auto-scroller - `unlisten()` also runs on Escape and on `contextmenu` - and `isDragged()`
            // alone would then let the next touch anywhere in the document start scrolling the grid.
            if (this.hot.getPlugin('multipleSelectionHandles')?.isDraggedBy(touch.identifier) !== true) {
                return;
            }
            _class_private_field_set(this, _dragTouchId, touch.identifier);
            _class_private_method_get(this, _setupListening, setupListening).call(this, 'handle', event);
        }), _class_private_field_set(this, _onTouchMove, (event)=>{
            if (!this.isListening() || _class_private_field_get(this, _dragTouchId) === null) {
                return;
            }
            const point = (0, _event.getTouchPointById)(event, _class_private_field_get(this, _dragTouchId));
            if (point === null) {
                return;
            }
            _class_private_method_get(this, _trackPointer, trackPointer).call(this, point.clientX, point.clientY);
        }), _class_private_field_set(this, _onTouchEnd, (event)=>{
            // Nothing of ours is running on touch. A mouse drag can be, though - these listeners sit on the
            // document, and a hybrid device fires touch events during one - and it is not this handler's to
            // end.
            if (_class_private_field_get(this, _dragTouchId) === null) {
                return;
            }
            if ((0, _event.getTouchPointById)(event, _class_private_field_get(this, _dragTouchId)) !== null) {
                return;
            }
            this.unlisten();
        }), _class_private_field_set(this, _onAfterSelection, (row, column, endRow, endColumn, preventScrolling)=>{
            if (this.listening && _class_private_field_get(this, _isOutsideViewport)) {
                preventScrolling.value = true;
            }
        }), _class_private_field_set(this, _onAfterScroll, ()=>{
            if (_class_private_field_get(this, _activeDragKind) !== 'cell') {
                return;
            }
            if (!_class_private_field_get(this, _isOutsideViewport)) {
                return;
            }
            if (_class_private_field_get(this, _lastClientX) === null || _class_private_field_get(this, _lastClientY) === null) {
                return;
            }
            if (this.hot.getSettings().selectionMode === 'single') {
                return;
            }
            // When another plugin claimed the drag via the controller (e.g. manualRowMove
            // sets controller.row = true), skip selection extension. The controller object
            // is captured by reference in #setupListening and mutated in-place by later
            // handlers, so by now the flags reflect the final state.
            if (_class_private_field_get(this, _mouseDownController)?.row || _class_private_field_get(this, _mouseDownController)?.column) {
                return;
            }
            const { selection, view } = this.hot;
            const edgeCell = (0, _cellCoords.getCellCoordsFromMousePosition)(this.hot, _class_private_field_get(this, _lastClientX), _class_private_field_get(this, _lastClientY));
            if (!edgeCell) {
                return;
            }
            let targetRow = edgeCell.row ?? 0;
            let targetCol = edgeCell.col ?? 0;
            // Clamp the target to the last fully visible row/column so that the
            // selection border stays inside the viewport. Without this, the target
            // could land on a partially visible row/column whose border is clipped
            // by the viewport edge.
            const firstFullyVisibleRow = view.getFirstFullyVisibleRow() ?? 0;
            const lastFullyVisibleRow = view.getLastFullyVisibleRow() ?? 0;
            const firstFullyVisibleColumn = view.getFirstFullyVisibleColumn() ?? 0;
            const lastFullyVisibleColumn = view.getLastFullyVisibleColumn() ?? 0;
            if (targetRow > lastFullyVisibleRow) {
                targetRow = lastFullyVisibleRow;
            } else if (targetRow < firstFullyVisibleRow) {
                targetRow = firstFullyVisibleRow;
            }
            if (targetCol > lastFullyVisibleColumn) {
                targetCol = lastFullyVisibleColumn;
            } else if (targetCol < firstFullyVisibleColumn) {
                targetCol = firstFullyVisibleColumn;
            }
            // Preserve "whole row" / "whole column" semantics for header-based selections.
            // This mirrors the logic in mouseEventHandler.js mouseOver().
            if (selection.isSelectedByRowHeader()) {
                targetCol = this.hot.countCols() - 1;
            }
            if (selection.isSelectedByColumnHeader()) {
                targetRow = this.hot.countRows() - 1;
            }
            const target = this.hot._createCellCoords(targetRow, targetCol);
            const currentRange = this.hot.getSelectedRangeLast();
            // Skip the setRangeEnd call when the edge cell matches the current
            // selection end. Avoids a redundant `afterSelection` firing and re-render
            // on each tick.
            if (currentRange && currentRange.to.row === target.row && currentRange.to.col === target.col) {
                return;
            }
            selection.setRangeEnd(target);
        });
    }
}
function setupListening(kind, event, controller = null) {
    if ((0, _event.isRightClick)(event)) {
        return;
    }
    // Regular drag-select is a no-op when selectionMode is 'single'. Autofill
    // drag is unaffected.
    if (kind === 'cell' && this.hot.getSettings().selectionMode === 'single') {
        return;
    }
    _class_private_field_set(this, _activeDragKind, kind);
    _class_private_field_set(this, _mouseDownController, controller);
    const scrollHandler = this.hot.view._wt.wtOverlays.topOverlay.mainTableScrollableElement;
    if (scrollHandler === this.hot.rootWindow) {
        this.setBoundaries();
    } else {
        const boundaries = scrollHandler.getBoundingClientRect();
        this.setBoundaries({
            left: boundaries.left + this.hot.view.getRowHeaderWidth(),
            right: boundaries.right,
            top: boundaries.top + this.hot.view.getColumnHeaderHeight(),
            bottom: boundaries.bottom
        });
    }
    this.setCallback((scrollX, scrollY)=>{
        const { selection } = this.hot;
        // Suppress the irrelevant scroll axis for header-based selections:
        // row header drags only need vertical scrolling, column header drags only horizontal.
        const x = selection.isSelectedByRowHeader() ? 0 : scrollX;
        const y = selection.isSelectedByColumnHeader() ? 0 : scrollY;
        // Always call update — passing (0, 0) stops the timers when the mouse
        // returns inside the viewport.
        _class_private_field_get(this, _autoScroller1).update({
            x,
            y
        });
    });
    this.listen();
}
function scrollHorizontal(distance) {
    const shouldAdvance = this.hot.isRtl() ? distance < 0 : distance > 0;
    // Advance (right in LTR / left in RTL): target the first column past the last fully visible one.
    // Retreat (left in LTR / right in RTL): target the column before the first partially visible one.
    // No explicit horizontalSnap — auto-snapping in scrollViewportHorizontally detects which side the
    // target column is on and snaps accordingly: off-screen right → 'end' (right edge), off-screen
    // left → 'start' (left edge). This keeps the selection stuck to whichever viewport edge the
    // mouse pushed past, and works correctly for both LTR and RTL layouts.
    const scrollColumn = shouldAdvance ? this.hot.getLastFullyVisibleColumn() + 1 : this.hot.getFirstPartiallyVisibleColumn() - 1;
    // The no-op callback causes hot.scrollViewportTo to call view.render() after scrolling,
    // which ensures afterScroll fires even in environments where programmatic window.scrollTo()
    // does not emit a native `scroll` DOM event (e.g. headless Chrome without scroll-event support).
    const isScrolled = this.hot.scrollViewportTo({
        col: scrollColumn
    }, ()=>{});
    if (!isScrolled) {
        _class_private_field_get(this, _autoScroller1).stopHorizontal();
    }
}
function scrollVertical(distance) {
    const firstVisibleRow = this.hot.getFirstFullyVisibleRow();
    const lastVisibleRow = this.hot.getLastFullyVisibleRow();
    const scrollRow = distance > 0 ? lastVisibleRow + 1 : firstVisibleRow - 1;
    // See the comment in #scrollHorizontal for why a no-op callback is passed.
    const isScrolled = this.hot.scrollViewportTo({
        row: scrollRow
    }, ()=>{});
    if (!isScrolled) {
        _class_private_field_get(this, _autoScroller1).stopVertical();
    }
}
function onMouseMove(event) {
    if (!this.isListening()) {
        return;
    }
    _class_private_method_get(this, _trackPointer, trackPointer).call(this, event.clientX, event.clientY);
}
function trackPointer(clientX, clientY) {
    _class_private_field_set(this, _lastClientX, clientX);
    _class_private_field_set(this, _lastClientY, clientY);
    this.check(clientX, clientY);
}
