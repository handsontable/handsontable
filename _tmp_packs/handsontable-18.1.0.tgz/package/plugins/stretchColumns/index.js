"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get PLUGIN_KEY () {
        return _stretchColumns.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _stretchColumns.PLUGIN_PRIORITY;
    },
    get StretchColumns () {
        return _stretchColumns.StretchColumns;
    }
});
const _stretchColumns = require("./stretchColumns");
