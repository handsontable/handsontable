"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AutoColumnSize () {
        return AutoColumnSize;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _feature = require("../../helpers/feature");
const _ghostTable = /*#__PURE__*/ _interop_require_default(require("../../utils/ghostTable"));
const _hooks = require("../../core/hooks");
const _object = require("../../helpers/object");
const _number = require("../../helpers/number");
const _samplesGenerator = /*#__PURE__*/ _interop_require_default(require("../../utils/samplesGenerator"));
const _string = require("../../helpers/string");
const _renderCell = require("../../renderers/renderCell");
const _src = require("../../3rdparty/walkontable/src");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
_hooks.Hooks.getSingleton().register('modifyAutoColumnSizeSeed');
const PLUGIN_KEY = 'autoColumnSize';
const PLUGIN_PRIORITY = 10;
const COLUMN_SIZE_MAP_NAME = 'autoColumnSize';
var /**
   * `true` value indicates that the #onInit() function has been already called.
   *
   * @type {boolean}
   */ _isInitialized = /*#__PURE__*/ new WeakMap(), /**
   * Cached column header names. It is used to diff current column headers with previous state and detect which
   * columns width should be updated.
   *
   * @type {Array}
   */ _cachedColumnHeaders = /*#__PURE__*/ new WeakMap(), /**
   * Pending width refresh requests keyed by visual column index, consumed before the next render.
   * A `null` value means the column needs a full row-range rescan. An array value holds the
   * changed cells (visual row index and the previous cell value) used by the width-determiner
   * probe, which measures only the changed cells and skips the full rescan when the edit could
   * not have changed the column's width.
   *
   * @type {Map<number, Array<object>|null>}
   */ _columnWidthsToRefresh = /*#__PURE__*/ new WeakMap(), /**
   * Caches the sampled values (a handful of bucketed strings per column) collected by the last
   * full row-range scan, keyed by physical column index. Forced renders re-measure the visible
   * columns by re-rendering these samples through the ghost table — picking up CSS or renderer
   * changes — instead of re-walking the whole row range. The cache is dropped whenever the row
   * set or the source data changes in a way the width refresh queue cannot describe, which
   * makes the next re-measure fall back to a full scan.
   *
   * @type {Map<number, Map>}
   */ _columnSamplesCache = /*#__PURE__*/ new WeakMap(), /**
   * Disposer function for the column widths map observer. Called on disable to clean up.
   *
   * @type {Function|null}
   */ _disposeMapObserver = /*#__PURE__*/ new WeakMap(), /**
   * Consumes the width refresh queue. Columns queued with change details go through the
   * width-determiner probe first; columns queued for a full refresh (and columns whose probe
   * was inconclusive) are rescanned over the whole row range, like before.
   */ _refreshQueuedColumnsWidth = /*#__PURE__*/ new WeakSet(), /**
   * Measures only the changed cells of the queued columns and decides, per column, whether the
   * cached width is still valid, can be grown in place, or whether the column needs a full
   * row-range rescan (appended to `fullRescanColumns`).
   *
   * The probe measures pure cell widths (ghost table headers disabled) and reasons as follows:
   * - when a new value renders wider than the cached width, that value is the new widest cell
   *   and the width is grown in place, without a rescan;
   * - otherwise, when every previous value renders narrower than the cached width, the changed
   *   cells were not the width determiners and the cached width stays valid;
   * - otherwise a previous value could have determined the cached width, so the column is
   *   rescanned to find the new widest cell (this is what allows the column to shrink).
   *
   * @param {object[]} probes The queued columns with their changed cells and cached widths.
   * @param {number[]} fullRescanColumns The list that columns needing a full rescan are appended to.
   */ _probeChangedCellsWidth = /*#__PURE__*/ new WeakSet(), /**
   * Keeps the column's cached samples usable after an in-place decision: strings sampled from
   * the changed rows are evicted (their values are stale now) and the freshly probed samples
   * of the changed cells are merged in, so a later re-measure (e.g. after a CSS change) still
   * sees the current values — including the one that grew the column. Columns without a cache
   * entry are left without one — an incomplete entry would make a later re-measure compute the
   * width from the changed cells alone.
   *
   * @param {object} probe The probed column with its changed cells.
   * @param {Map} [samples] Freshly probed samples of the changed cells to merge in.
   */ _updateCachedSamples = /*#__PURE__*/ new WeakSet(), /**
   * Measures the rendered width of the given per-column sample maps with the ghost table, with
   * headers disabled — a header rendered next to the samples would put a floor under every
   * measurement and mask the comparison against the cached width.
   *
   * @param {object[]} items An array of `{ visualColumn, samples }` objects to measure.
   * @returns {Map<number, number>} Measured widths keyed by visual column index.
   */ _measureCellsWidth = /*#__PURE__*/ new WeakSet(), /**
   * Formats a probed value the way the render path would — cell-level `valueFormatter` first,
   * then the renderer's own static — so the measured string matches what the renderer produces.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {*} value The raw value to format.
   * @returns {*}
   */ _formatProbeValue = /*#__PURE__*/ new WeakSet(), /**
   * Generates content samples for the given column within the row range, adds each sample
   * to the ghost table so its rendered width can be measured, and refreshes the column's
   * samples cache.
   */ _fillGhostTableWithSamples = /*#__PURE__*/ new WeakSet(), /**
   * Adds a column to the ghost table, passing a shallow clone of the samples map — the ghost
   * table's `clean()` empties the last map it received, which must never wipe a map that is
   * kept in the samples cache.
   *
   * @param {number} visualColumn Visual column index.
   * @param {Map} samples The samples map to measure.
   */ _addGhostTableColumn = /*#__PURE__*/ new WeakSet(), /**
   * Updates the column widths map with calculated widths from the ghost table.
   *
   */ _updateColumnWidthsMapBasedOnGhostTable = /*#__PURE__*/ new WeakSet(), /**
   * Recalculates widths for currently visible columns (cache misses only) and consumes the
   * width refresh queue populated by data, header, or row-set changes.
   */ _onBeforeRender = /*#__PURE__*/ new WeakMap(), /**
   * Triggers a full column width recalculation after new data is loaded, skipping the initial
   * load since `#onInit` already handles it.
   */ _onAfterLoadData = /*#__PURE__*/ new WeakMap(), /**
   * Queues the cells affected by the incoming changes, keyed by their visual column, so the
   * width-determiner probe can decide before the next render whether each column's width
   * actually needs a refresh.
   */ _onBeforeChange = /*#__PURE__*/ new WeakMap(), /**
   * Drops the cached samples after a source-data write. Source-level changes bypass
   * `beforeChangeRender`, so there is no per-cell change information to refresh the samples
   * with — the render that follows falls back to full scans for the visible columns.
   */ _onAfterSetSourceDataAtCell = /*#__PURE__*/ new WeakMap(), /**
   * Drops the cached samples of a column whose cell meta changed. Meta keys like
   * `valueFormatter`, `renderer`, `className`, or `type` affect the rendered width, and the
   * cached sample strings (formatted when they were sampled) would replay the previous meta
   * on the next re-measure — the next full render re-walks the column instead.
   */ _onAfterSetCellMeta = /*#__PURE__*/ new WeakMap(), /**
   * Drops the cached samples when the set of rows that feeds the width calculation changes
   * (rows inserted, removed, moved, trimmed, or hidden). Sampling skips hidden rows and the
   * samples carry row coordinates, so a changed row set invalidates them — the next re-measure
   * falls back to a full scan, which lets a column shrink when its widest cell disappears.
   */ _onRowIndexMapperCacheUpdate = /*#__PURE__*/ new WeakMap(), /**
   * Drops the cached samples when the column sequence changes (columns inserted, removed, or
   * moved) — the cache is keyed by physical column index, and a structural change would leave
   * the samples associated with the wrong columns.
   */ _onColumnIndexMapperCacheUpdate = /*#__PURE__*/ new WeakMap(), /**
   * Recalculates the column width from content on a double-click and returns it as the new
   * size; returns the user-dragged size otherwise.
   */ _onBeforeColumnResize = /*#__PURE__*/ new WeakMap(), /**
   * Initializes the column header cache and triggers the first full column width recalculation
   * after Handsontable has finished initializing.
   */ _onInit = /*#__PURE__*/ new WeakMap(), /**
   * Queues cells whose formula results changed so their columns' widths are refreshed before
   * the next render. The engine does not carry previous values, so the probe can only grow the
   * width in place — a potential shrink falls back to a full column rescan. Skips changes
   * belonging to a different sheet.
   */ _onAfterFormulasValuesUpdate = /*#__PURE__*/ new WeakMap();
class AutoColumnSize extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns `true` so the plugin updates on every `updateSettings` call, regardless of config object contents.
   */ static get SETTING_KEYS() {
        return true;
    }
    /**
   * Returns the default settings applied when the plugin is enabled without explicit configuration.
   */ static get DEFAULT_SETTINGS() {
        return {
            useHeaders: true,
            samplingRatio: null,
            allowSampleDuplicates: false
        };
    }
    /**
   * Returns the number of columns processed in a single calculation step during asynchronous sizing.
   */ static get CALCULATION_STEP() {
        return 50;
    }
    /**
   * Returns the maximum number of columns whose widths are calculated synchronously before switching to async mode.
   */ static get SYNC_CALCULATION_LIMIT() {
        return 50;
    }
    /**
   * Returns the maximum number of cells sampled in a single asynchronous calculation step. Together
   * with {@link AutoColumnSize.CALCULATION_STEP} it bounds the work done per animation frame: a
   * column whose row range exceeds the budget is swept across multiple frames, and its width is
   * written once, when the sweep completes.
   */ static get CALCULATION_CELLS_BUDGET() {
        return 100000;
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link #enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        return this.hot.getSettings()[PLUGIN_KEY] !== false && !this.hot.getSettings().colWidths;
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        this.ghostTable.setSetting('useHeaders', this.getSetting('useHeaders'));
        this.samplesGenerator.setAllowDuplicates(this.getSetting('allowSampleDuplicates'));
        const samplingRatio = this.getSetting('samplingRatio');
        if (samplingRatio && !isNaN(samplingRatio)) {
            this.samplesGenerator.setSampleCount(parseInt(String(samplingRatio), 10));
        }
        this.addHook('afterLoadData', _class_private_field_get(this, _onAfterLoadData));
        this.addHook('beforeChangeRender', _class_private_field_get(this, _onBeforeChange));
        this.addHook('afterSetCellMeta', _class_private_field_get(this, _onAfterSetCellMeta));
        this.addHook('afterSetSourceDataAtCell', _class_private_field_get(this, _onAfterSetSourceDataAtCell));
        this.addHook('afterFormulasValuesUpdate', _class_private_field_get(this, _onAfterFormulasValuesUpdate));
        this.addHook('beforeRender', _class_private_field_get(this, _onBeforeRender));
        this.addHook('modifyColWidth', (width, col)=>this.getColumnWidth(col, width), -10);
        this.addHook('init', _class_private_field_get(this, _onInit));
        this.hot.rowIndexMapper.addLocalHook('cacheUpdated', _class_private_field_get(this, _onRowIndexMapperCacheUpdate));
        this.hot.columnIndexMapper.addLocalHook('cacheUpdated', _class_private_field_get(this, _onColumnIndexMapperCacheUpdate));
        _class_private_field_set(this, _disposeMapObserver, this.hot.columnIndexMapper.observeMapChange(this.columnWidthsMap, ()=>{
            this.hot.view?.invalidateColumnWidthCache();
        }));
        super.enablePlugin();
    }
    /**
   * Updates the plugin's state. This method is executed when {@link Core#updateSettings} is invoked.
   */ updatePlugin() {
        this.findColumnsWhereHeaderWasChanged().forEach((visualColumn)=>{
            _class_private_field_get(this, _columnWidthsToRefresh).set(visualColumn, null);
        });
        // Settings may remap the data that feeds the samples (e.g. a new `columns` definition), so
        // the cached samples cannot be trusted — the next re-measure falls back to a full scan.
        _class_private_field_get(this, _columnSamplesCache).clear();
        super.updatePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        if (_class_private_field_get(this, _disposeMapObserver)) {
            _class_private_field_get(this, _disposeMapObserver).call(this);
            _class_private_field_set(this, _disposeMapObserver, null);
        }
        this.hot.rowIndexMapper.removeLocalHook('cacheUpdated', _class_private_field_get(this, _onRowIndexMapperCacheUpdate));
        this.hot.columnIndexMapper.removeLocalHook('cacheUpdated', _class_private_field_get(this, _onColumnIndexMapperCacheUpdate));
        super.disablePlugin();
        // Leave the listener active to allow auto-sizing the columns when the plugin is disabled.
        // This is necessary for width recalculation for resize handler doubleclick (ManualColumnResize).
        this.addHook('beforeColumnResize', _class_private_field_get(this, _onBeforeColumnResize));
    }
    /**
   * Calculates widths for visible columns in the viewport only.
   */ calculateVisibleColumnsWidth() {
        // Keep last column widths unchanged for situation when all rows was deleted or trimmed (pro #6)
        if (!this.hot.countRows()) {
            return;
        }
        const firstVisibleColumn = this.getFirstVisibleColumn();
        const lastVisibleColumn = this.getLastVisibleColumn();
        if (firstVisibleColumn === -1 || lastVisibleColumn === -1) {
            return;
        }
        const overwriteCache = this.hot.forceFullRender;
        this.calculateColumnsWidth({
            from: firstVisibleColumn,
            to: lastVisibleColumn
        }, undefined, overwriteCache);
    }
    /**
   * Calculates a columns width.
   *
   * @param {number|object} colRange Visual column index or an object with `from` and `to` visual indexes as a range.
   * @param {number|object} rowRange Visual row index or an object with `from` and `to` visual indexes as a range.
   * @param {boolean} [overwriteCache=false] If `true` the calculation will be processed regardless of whether the width exists in the cache.
   */ calculateColumnsWidth(colRange = {
        from: 0,
        to: this.hot.countCols() - 1
    }, rowRange = {
        from: 0,
        to: this.hot.countRows() - 1
    }, overwriteCache = false) {
        const columnsRange = typeof colRange === 'number' ? {
            from: colRange,
            to: colRange
        } : colRange;
        const rowsRange = typeof rowRange === 'number' ? {
            from: rowRange,
            to: rowRange
        } : rowRange;
        (0, _number.rangeEach)(columnsRange.from, columnsRange.to, (visualColumn)=>{
            let physicalColumn = this.hot.toPhysicalColumn(visualColumn);
            if (physicalColumn === null) {
                physicalColumn = visualColumn;
            }
            if (overwriteCache || this.columnWidthsMap.getValueAtIndex(physicalColumn) === null && !this.hot._getColWidthFromSettings(physicalColumn)) {
                const cachedSamples = overwriteCache ? _class_private_field_get(this, _columnSamplesCache).get(physicalColumn) : undefined;
                // A re-measure (cache overwrite) with an intact samples cache re-renders the previously
                // sampled values — picking up CSS or renderer changes — without re-walking the row range.
                // Data changes refresh or drop the cached samples, so a full scan runs only when needed.
                if (cachedSamples !== undefined) {
                    _class_private_method_get(this, _addGhostTableColumn, addGhostTableColumn).call(this, visualColumn, cachedSamples);
                } else {
                    _class_private_method_get(this, _fillGhostTableWithSamples, fillGhostTableWithSamples).call(this, visualColumn, rowsRange);
                }
            }
        });
        if (this.ghostTable.columns.length) {
            _class_private_method_get(this, _updateColumnWidthsMapBasedOnGhostTable, updateColumnWidthsMapBasedOnGhostTable).call(this);
            this.measuredColumns = columnsRange.to + 1;
            this.ghostTable.clean();
        }
    }
    /**
   * Calculates all columns width. The calculated column will be cached in the {@link AutoColumnSize#widths} property.
   * To retrieve width for specified column use {@link AutoColumnSize#getColumnWidth} method.
   *
   * @param {object|number} rowRange Row index or an object with `from` and `to` properties which define row range.
   * @param {boolean} [overwriteCache] If `true` the calculation will be processed regardless of whether the width exists in the cache.
   */ calculateAllColumnsWidth(rowRange = {
        from: 0,
        to: this.hot.countRows() - 1
    }, overwriteCache = false) {
        const rowsRange = typeof rowRange === 'number' ? {
            from: rowRange,
            to: rowRange
        } : rowRange;
        const lastColumn = this.hot.countCols() - 1;
        let currentColumn = 0;
        let currentRowCursor = rowsRange.from;
        let columnSamples = null;
        let timer = 0;
        this.inProgress = true;
        const shouldMeasureColumn = (visualColumn)=>{
            let physicalColumn = this.hot.toPhysicalColumn(visualColumn);
            if (physicalColumn === null) {
                physicalColumn = visualColumn;
            }
            return overwriteCache || this.columnWidthsMap.getValueAtIndex(physicalColumn) === null && !this.hot._getColWidthFromSettings(physicalColumn);
        };
        /**
     * Sweeps up to `columnsBudget` columns, sampling at most `cellsBudget` cells. A column whose
     * remaining row range exceeds the cells budget is left mid-sweep (its samples accumulate in
     * `columnSamples`) and is continued by the next call. Returns `true` when every column has
     * been processed.
     *
     * @param {number} columnsBudget The maximum number of columns to process in this chunk.
     * @param {number} cellsBudget The maximum number of cells to sample in this chunk.
     * @returns {boolean}
     */ const processChunk = (columnsBudget, cellsBudget)=>{
            let remainingColumns = columnsBudget;
            let remainingCells = cellsBudget;
            while(remainingColumns > 0 && currentColumn <= lastColumn){
                if (columnSamples === null) {
                    if (!shouldMeasureColumn(currentColumn)) {
                        currentColumn += 1;
                        remainingColumns -= 1;
                        continue;
                    }
                    columnSamples = new Map();
                    currentRowCursor = rowsRange.from;
                }
                if (currentRowCursor <= rowsRange.to) {
                    if (remainingCells <= 0) {
                        return false;
                    }
                    const sliceTo = Math.min(rowsRange.to, currentRowCursor + remainingCells - 1);
                    this.samplesGenerator.generateSample('col', {
                        from: currentRowCursor,
                        to: sliceTo
                    }, currentColumn, columnSamples);
                    remainingCells -= sliceTo - currentRowCursor + 1;
                    currentRowCursor = sliceTo + 1;
                }
                if (currentRowCursor > rowsRange.to) {
                    const physicalColumn = this.hot.toPhysicalColumn(currentColumn);
                    _class_private_method_get(this, _addGhostTableColumn, addGhostTableColumn).call(this, currentColumn, columnSamples);
                    _class_private_field_get(this, _columnSamplesCache).set(physicalColumn === null ? currentColumn : physicalColumn, columnSamples);
                    columnSamples = null;
                    currentColumn += 1;
                    remainingColumns -= 1;
                }
            }
            return currentColumn > lastColumn;
        };
        const flushGhostTable = ()=>{
            if (this.ghostTable.columns.length) {
                _class_private_method_get(this, _updateColumnWidthsMapBasedOnGhostTable, updateColumnWidthsMapBasedOnGhostTable).call(this);
                this.measuredColumns = currentColumn;
                this.ghostTable.clean();
            }
        };
        const loop = ()=>{
            // When hot was destroyed after calculating finished cancel frame
            if (!this.hot) {
                (0, _feature.cancelIdleTask)(timer);
                this.inProgress = false;
                return;
            }
            const isDone = processChunk(AutoColumnSize.CALCULATION_STEP + 1, AutoColumnSize.CALCULATION_CELLS_BUDGET);
            flushGhostTable();
            if (!isDone) {
                timer = (0, _feature.requestIdleTask)(loop);
            } else {
                (0, _feature.cancelIdleTask)(timer);
                this.inProgress = false;
                // @TODO Should call once per render cycle, currently fired separately in different plugins
                this.hot.view.adjustElementsSize();
            }
        };
        const syncLimit = this.getSyncCalculationLimit();
        // sync — the `syncLimit` columns are calculated exactly (whole row range) before the first
        // paint, preserving the `syncLimit` contract.
        if (syncLimit >= 0) {
            processChunk(syncLimit + 1, Infinity);
            flushGhostTable();
        }
        // async
        if (currentColumn <= lastColumn) {
            loop();
        } else {
            this.inProgress = false;
        }
    }
    /**
   * Recalculates all columns width (overwrite cache values).
   */ recalculateAllColumnsWidth() {
        if (this.hot.view.isVisible()) {
            // Every queued width refinement is subsumed by the full overwrite sweep — entries
            // queued after this point (e.g. edits made while the asynchronous part is running)
            // accumulate again and are consumed as usual.
            _class_private_field_get(this, _columnWidthsToRefresh).clear();
            this.calculateAllColumnsWidth({
                from: 0,
                to: this.hot.countRows() - 1
            }, true);
            // The synchronous part of the sweep runs inside `init`/`afterLoadData` hook cascades,
            // before other plugins re-apply their cell meta (e.g. MergeCells' `spanned`/`hidden`
            // flags), so the samples it collected cannot be trusted for later re-measures. Dropping
            // them makes the next full render re-walk the visible columns with the settled meta,
            // like it always did. Samples stored by the asynchronous part run after the cascade
            // and stay.
            _class_private_field_get(this, _columnSamplesCache).clear();
        }
    }
    /**
   * Gets value which tells how many columns should be calculated synchronously (rest of the columns will be calculated
   * asynchronously). The limit is calculated based on `syncLimit` set to `autoColumnSize` option (see {@link Options#autoColumnSize}).
   *
   * @returns {number}
   */ getSyncCalculationLimit() {
        const settings = this.hot.getSettings()[PLUGIN_KEY];
        /* eslint-disable no-bitwise */ let limit = AutoColumnSize.SYNC_CALCULATION_LIMIT;
        const colsLimit = this.hot.countCols() - 1;
        if ((0, _object.isObject)(settings)) {
            const syncLimit = settings.syncLimit;
            if (typeof syncLimit === 'string' && (0, _string.isPercentValue)(syncLimit)) {
                limit = (0, _number.valueAccordingPercent)(colsLimit, syncLimit);
            } else {
                // Force to integer (NaN — e.g. when syncLimit is undefined — falls back to 0)
                const numericSyncLimit = Number(syncLimit);
                limit = Number.isFinite(numericSyncLimit) ? Math.trunc(numericSyncLimit) : 0;
            }
        }
        return Math.min(limit, colsLimit);
    }
    /**
   * Gets the calculated column width.
   *
   * @param {number} column Visual column index.
   * @param {number} [defaultWidth] Default column width. It will be picked up if no calculated width found.
   * @param {boolean} [keepMinimum=true] If `true` then returned value won't be smaller then 50 (default column width).
   * @returns {number}
   */ getColumnWidth(column, defaultWidth, keepMinimum = true) {
        let width = defaultWidth;
        if (width === undefined) {
            width = this.columnWidthsMap.getValueAtIndex(this.hot.toPhysicalColumn(column));
            if (keepMinimum && typeof width === 'number') {
                width = Math.max(width, _src.DEFAULT_COLUMN_WIDTH);
            }
        }
        return width;
    }
    /**
   * Gets the first visible column.
   *
   * When the {@link MergeCells} plugin is enabled with its default `virtualized: false` setting, a merged
   * cell that crosses the viewport edge extends the rendered column range. In that case this method can
   * return a column index outside the strictly visible viewport. To read the actual visible viewport, use
   * {@link Core#getFirstFullyVisibleColumn} or {@link Core#getFirstPartiallyVisibleColumn}.
   *
   * @returns {number} Returns visual column index, -1 if table is not rendered or if there are no columns to base the the calculations on.
   */ getFirstVisibleColumn() {
        return this.hot.getFirstRenderedVisibleColumn() ?? -1;
    }
    /**
   * Gets the last visible column.
   *
   * When the {@link MergeCells} plugin is enabled with its default `virtualized: false` setting, a merged
   * cell that crosses the viewport edge extends the rendered column range. In that case this method can
   * return a column index outside the strictly visible viewport. To read the actual visible viewport, use
   * {@link Core#getLastFullyVisibleColumn} or {@link Core#getLastPartiallyVisibleColumn}.
   *
   * @returns {number} Returns visual column index or -1 if table is not rendered.
   */ getLastVisibleColumn() {
        return this.hot.getLastRenderedVisibleColumn() ?? -1;
    }
    /**
   * Collects all columns which titles has been changed in comparison to the previous state.
   *
   * @private
   * @returns {Array} It returns an array of visual column indexes.
   */ findColumnsWhereHeaderWasChanged() {
        const columnHeaders = this.hot.getColHeader();
        const changedColumns = columnHeaders.reduce((acc, columnTitle, physicalColumn)=>{
            const cachedColumnsLength = _class_private_field_get(this, _cachedColumnHeaders).length;
            if (cachedColumnsLength - 1 < physicalColumn || _class_private_field_get(this, _cachedColumnHeaders)[physicalColumn] !== columnTitle) {
                const visualColumn = this.hot.toVisualColumn(physicalColumn);
                if (visualColumn !== null) {
                    acc.push(visualColumn);
                }
            }
            if (cachedColumnsLength - 1 < physicalColumn) {
                _class_private_field_get(this, _cachedColumnHeaders).push(columnTitle);
            } else {
                _class_private_field_get(this, _cachedColumnHeaders)[physicalColumn] = columnTitle;
            }
            return acc;
        }, []);
        return changedColumns;
    }
    /**
   * Clears cache of calculated column widths. If you want to clear only selected columns pass an array with their indexes.
   * Otherwise whole cache will be cleared.
   *
   * @param {number[]} [physicalColumns] List of physical column indexes to clear.
   */ clearCache(physicalColumns) {
        if (Array.isArray(physicalColumns)) {
            this.hot.batchExecution(()=>{
                physicalColumns.forEach((physicalIndex)=>{
                    this.columnWidthsMap.setValueAtIndex(physicalIndex, null);
                    _class_private_field_get(this, _columnSamplesCache).delete(physicalIndex);
                });
            }, true);
        } else {
            this.columnWidthsMap.clear();
            _class_private_field_get(this, _columnSamplesCache).clear();
        }
    }
    /**
   * Checks if all widths were calculated. If not then return `true` (need recalculate).
   *
   * @returns {boolean}
   */ isNeedRecalculate() {
        return !!this.columnWidthsMap.getValues().slice(0, this.measuredColumns).filter((item)=>item === null).length;
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        this.hot?.rowIndexMapper.removeLocalHook('cacheUpdated', _class_private_field_get(this, _onRowIndexMapperCacheUpdate));
        this.hot?.columnIndexMapper.removeLocalHook('cacheUpdated', _class_private_field_get(this, _onColumnIndexMapperCacheUpdate));
        this.ghostTable.clean();
        super.destroy();
    }
    /**
   * Initializes the plugin, registers the column widths map, and sets up the column resize hook.
   */ constructor(hotInstance){
        super(hotInstance), _class_private_method_init(this, _refreshQueuedColumnsWidth), _class_private_method_init(this, _probeChangedCellsWidth), _class_private_method_init(this, _updateCachedSamples), _class_private_method_init(this, _measureCellsWidth), _class_private_method_init(this, _formatProbeValue), _class_private_method_init(this, _fillGhostTableWithSamples), _class_private_method_init(this, _addGhostTableColumn), _class_private_method_init(this, _updateColumnWidthsMapBasedOnGhostTable), _class_private_field_init(this, _isInitialized, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _cachedColumnHeaders, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _columnWidthsToRefresh, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _columnSamplesCache, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _disposeMapObserver, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeRender, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterLoadData, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeChange, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterSetSourceDataAtCell, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterSetCellMeta, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onRowIndexMapperCacheUpdate, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onColumnIndexMapperCacheUpdate, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeColumnResize, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onInit, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterFormulasValuesUpdate, {
            writable: true,
            value: void 0
        }), /**
   * Instance of {@link GhostTable} for rows and columns size calculations.
   *
   * @private
   * @type {GhostTable}
   */ this.ghostTable = new _ghostTable.default(this.hot), /**
   * Instance of {@link SamplesGenerator} for generating samples necessary for columns width calculations.
   *
   * @private
   * @type {SamplesGenerator}
   * @fires Hooks#modifyAutoColumnSizeSeed
   */ this.samplesGenerator = new _samplesGenerator.default((row, column)=>{
            const physicalRow = this.hot.toPhysicalRow(row);
            const physicalColumn = this.hot.toPhysicalColumn(column);
            if (this.hot.rowIndexMapper.isHidden(physicalRow) || this.hot.columnIndexMapper.isHidden(physicalColumn)) {
                return false;
            }
            // The transient read resolves the full dynamic meta (hooks + `cells`, so `hidden`/`spanned`
            // from merged cells work) without storing anything - this sampler sweeps the whole row range
            // per column, and the eager `getCellMeta` would permanently materialize one meta per visited
            // cell (O(rows x columns) retention on init).
            const cellMeta = this.hot.getCellMetaTransient(row, column);
            let cellValue = '';
            let seedValue = '';
            if (cellMeta.hidden) {
                // do not generate samples for cells that are covered by merged cell (null values)
                return false;
            }
            if (!cellMeta.spanned) {
                // Format through the same precedence as the render path (cell-level `valueFormatter`, then
                // the renderer's own static), so the measured string matches what the renderer produces.
                cellValue = (0, _renderCell.formatCellValue)(this.hot.getDataAtCell(row, column), cellMeta, this.hot.getCellRenderer(cellMeta));
                seedValue = cellValue;
            }
            let bundleSeed = '';
            if (this.hot.hasHook('modifyAutoColumnSizeSeed')) {
                bundleSeed = String(this.hot.runHooks('modifyAutoColumnSizeSeed', bundleSeed, cellMeta, seedValue) ?? bundleSeed);
            }
            return {
                value: cellValue,
                bundleSeed
            };
        }), /**
   * `true` if the size calculation is in progress.
   *
   * @type {boolean}
   */ this.inProgress = false, /**
   * Number of already measured columns (we already know their sizes).
   *
   * @type {number}
   */ this.measuredColumns = 0, _class_private_field_set(this, _isInitialized, false), _class_private_field_set(this, _cachedColumnHeaders, []), _class_private_field_set(this, _columnWidthsToRefresh, new Map()), _class_private_field_set(this, _columnSamplesCache, new Map()), _class_private_field_set(this, _disposeMapObserver, null), _class_private_field_set(this, _onBeforeRender, ()=>{
            this.calculateVisibleColumnsWidth();
            if (!this.inProgress) {
                _class_private_method_get(this, _refreshQueuedColumnsWidth, refreshQueuedColumnsWidth).call(this);
            }
        }), _class_private_field_set(this, _onAfterLoadData, (_sourceData, isFirstLoad)=>{
            // Queued cells describe the previous dataset — their rows and previous values are
            // meaningless once the data is replaced. Cleared unconditionally (even when the view is
            // not visible and no sweep runs), so a pending entry that survived a suspended render
            // can never feed the width-determiner probe with stale coordinates.
            _class_private_field_get(this, _columnWidthsToRefresh).clear();
            if (!isFirstLoad) {
                this.recalculateAllColumnsWidth();
            }
        }), _class_private_field_set(this, _onBeforeChange, (changes)=>{
            changes.forEach(([row, columnProperty, oldValue])=>{
                if (typeof columnProperty === 'function') {
                    return;
                }
                const visualColumn = this.hot.propToCol(columnProperty);
                if (visualColumn === null || !Number.isInteger(visualColumn)) {
                    return;
                }
                const entry = _class_private_field_get(this, _columnWidthsToRefresh).get(visualColumn);
                // The column is already queued for a full rescan.
                if (entry === null) {
                    return;
                }
                const cell = {
                    row,
                    oldValue,
                    hasOldValue: true
                };
                if (entry === undefined) {
                    _class_private_field_get(this, _columnWidthsToRefresh).set(visualColumn, [
                        cell
                    ]);
                } else {
                    entry.push(cell);
                }
            });
        }), _class_private_field_set(this, _onAfterSetSourceDataAtCell, ()=>{
            _class_private_field_get(this, _columnSamplesCache).clear();
        }), _class_private_field_set(this, _onAfterSetCellMeta, (_row, column)=>{
            const physicalColumn = this.hot.toPhysicalColumn(column);
            if (physicalColumn !== null) {
                _class_private_field_get(this, _columnSamplesCache).delete(physicalColumn);
            }
        }), _class_private_field_set(this, _onRowIndexMapperCacheUpdate, (indexesChangesState)=>{
            const { indexesSequenceChanged, trimmedIndexesChanged, hiddenIndexesChanged } = indexesChangesState;
            if (indexesSequenceChanged || trimmedIndexesChanged || hiddenIndexesChanged) {
                _class_private_field_get(this, _columnSamplesCache).clear();
            }
        }), _class_private_field_set(this, _onColumnIndexMapperCacheUpdate, (indexesChangesState)=>{
            if (indexesChangesState.indexesSequenceChanged) {
                _class_private_field_get(this, _columnSamplesCache).clear();
            }
        }), _class_private_field_set(this, _onBeforeColumnResize, (size, column, isDblClick)=>{
            let newSize = size;
            if (isDblClick) {
                this.calculateColumnsWidth(column, undefined, true);
                newSize = this.getColumnWidth(column, undefined, false) ?? newSize;
            }
            return newSize;
        }), _class_private_field_set(this, _onInit, ()=>{
            _class_private_field_set(this, _cachedColumnHeaders, this.hot.getColHeader());
            this.recalculateAllColumnsWidth();
            _class_private_field_set(this, _isInitialized, true);
        }), _class_private_field_set(this, _onAfterFormulasValuesUpdate, (changes)=>{
            if (!_class_private_field_get(this, _isInitialized)) {
                return;
            }
            const formulasPlugin = this.hot.getPlugin('formulas');
            const sheetId = formulasPlugin?.sheetId;
            changes.forEach((change)=>{
                const changeRecord = change;
                const address = changeRecord.address;
                if (sheetId !== null && sheetId !== undefined && address?.sheet !== sheetId) {
                    return;
                }
                const physicalColumn = Number(address?.col);
                const physicalRow = Number(address?.row);
                if (!Number.isInteger(physicalColumn)) {
                    return;
                }
                const visualColumn = this.hot.toVisualColumn(physicalColumn);
                if (visualColumn === null) {
                    return;
                }
                const entry = _class_private_field_get(this, _columnWidthsToRefresh).get(visualColumn);
                // The column is already queued for a full rescan.
                if (entry === null) {
                    return;
                }
                const visualRow = Number.isInteger(physicalRow) ? this.hot.toVisualRow(physicalRow) : null;
                // Without an addressable row the probe cannot measure the changed cell — fall back to
                // a full column rescan.
                if (visualRow === null) {
                    _class_private_field_get(this, _columnWidthsToRefresh).set(visualColumn, null);
                    return;
                }
                const cell = {
                    row: visualRow,
                    oldValue: undefined,
                    hasOldValue: false
                };
                if (entry === undefined) {
                    _class_private_field_get(this, _columnWidthsToRefresh).set(visualColumn, [
                        cell
                    ]);
                } else {
                    entry.push(cell);
                }
            });
        });
        // The map holds numbers only, so re-writing an unchanged width is a no-op that must not
        // invalidate the column-width position cache (every render re-measures the visible columns).
        this.columnWidthsMap = this.hot.columnIndexMapper.createAndRegisterIndexMap(COLUMN_SIZE_MAP_NAME, 'physicalIndexToValue', null, {
            skipUnchangedWrites: true
        });
        // Leave the listener active to allow auto-sizing the columns when the plugin is disabled.
        // This is necessary for width recalculation for resize handler doubleclick (ManualColumnResize).
        this.addHook('beforeColumnResize', _class_private_field_get(this, _onBeforeColumnResize));
    }
}
function refreshQueuedColumnsWidth() {
    if (_class_private_field_get(this, _columnWidthsToRefresh).size === 0) {
        return;
    }
    const queue = _class_private_field_get(this, _columnWidthsToRefresh);
    _class_private_field_set(this, _columnWidthsToRefresh, new Map());
    const totalRows = this.hot.countRows();
    const fullRescanColumns = [];
    const probes = [];
    queue.forEach((cells, visualColumn)=>{
        const physicalColumn = this.hot.toPhysicalColumn(visualColumn);
        if (physicalColumn === null || this.hot._getColWidthFromSettings(physicalColumn)) {
            return;
        }
        const cachedWidth = this.columnWidthsMap.getValueAtIndex(physicalColumn);
        // A full rescan is needed when it was requested explicitly, when there is no cached width
        // to compare the probe against, or when so many cells changed that probing them costs
        // about as much as the rescan itself.
        if (cells === null || cachedWidth === null || cachedWidth === undefined || cells.length * 2 >= totalRows) {
            fullRescanColumns.push(visualColumn);
        } else {
            probes.push({
                visualColumn,
                cells,
                cachedWidth
            });
        }
    });
    _class_private_method_get(this, _probeChangedCellsWidth, probeChangedCellsWidth).call(this, probes, fullRescanColumns);
    if (fullRescanColumns.length > 0) {
        const rowsRange = {
            from: 0,
            to: totalRows - 1
        };
        fullRescanColumns.forEach((visualColumn)=>{
            _class_private_method_get(this, _fillGhostTableWithSamples, fillGhostTableWithSamples).call(this, visualColumn, rowsRange);
        });
    }
    if (this.ghostTable.columns.length) {
        _class_private_method_get(this, _updateColumnWidthsMapBasedOnGhostTable, updateColumnWidthsMapBasedOnGhostTable).call(this);
        this.ghostTable.clean();
    }
}
function probeChangedCellsWidth(probes, fullRescanColumns) {
    if (probes.length === 0) {
        return;
    }
    const growths = new Map();
    const oldValueProbes = [];
    const probeItems = probes.map(({ visualColumn, cells })=>({
            visualColumn,
            samples: this.samplesGenerator.generateSample('col', cells.map((cell)=>cell.row), visualColumn)
        }));
    const samplesByColumn = new Map(probeItems.map(({ visualColumn, samples })=>[
            visualColumn,
            samples
        ]));
    const newWidths = _class_private_method_get(this, _measureCellsWidth, measureCellsWidth).call(this, probeItems);
    probes.forEach((probe)=>{
        const newWidth = newWidths.get(probe.visualColumn);
        if (newWidth !== undefined && newWidth > probe.cachedWidth) {
            growths.set(probe.visualColumn, newWidth);
            _class_private_method_get(this, _updateCachedSamples, updateCachedSamples).call(this, probe, samplesByColumn.get(probe.visualColumn));
        } else if (probe.cells.some((cell)=>!cell.hasOldValue)) {
            fullRescanColumns.push(probe.visualColumn);
        } else {
            oldValueProbes.push(probe);
            _class_private_method_get(this, _updateCachedSamples, updateCachedSamples).call(this, probe, samplesByColumn.get(probe.visualColumn));
        }
    });
    if (oldValueProbes.length > 0) {
        const oldWidths = _class_private_method_get(this, _measureCellsWidth, measureCellsWidth).call(this, oldValueProbes.map(({ visualColumn, cells })=>({
                visualColumn,
                samples: this.samplesGenerator.generateSampleFromValues('col', cells.map((cell)=>({
                        index: cell.row,
                        value: _class_private_method_get(this, _formatProbeValue, formatProbeValue).call(this, cell.row, visualColumn, cell.oldValue)
                    })))
            })));
        oldValueProbes.forEach(({ visualColumn, cachedWidth })=>{
            const oldWidth = oldWidths.get(visualColumn);
            if (oldWidth !== undefined && oldWidth >= cachedWidth) {
                fullRescanColumns.push(visualColumn);
            }
        });
    }
    if (growths.size > 0) {
        this.hot.batchExecution(()=>{
            growths.forEach((width, visualColumn)=>{
                this.columnWidthsMap.setValueAtIndex(this.hot.toPhysicalColumn(visualColumn), width);
            });
        }, true);
    }
}
function updateCachedSamples(probe, samples) {
    const physicalColumn = this.hot.toPhysicalColumn(probe.visualColumn);
    const cachedSamples = physicalColumn === null ? undefined : _class_private_field_get(this, _columnSamplesCache).get(physicalColumn);
    if (cachedSamples === undefined) {
        return;
    }
    const changedRows = new Set(probe.cells.map((cell)=>cell.row));
    cachedSamples.forEach((cachedSample, seed)=>{
        const strings = cachedSample.strings.filter(({ row })=>row === undefined || !changedRows.has(row));
        if (strings.length === 0) {
            cachedSamples.delete(seed);
        } else {
            cachedSample.strings = strings;
        }
    });
    if (samples === undefined) {
        return;
    }
    const sampleCount = this.samplesGenerator.getSampleCount();
    let bucketOverflowed = false;
    samples.forEach((sample, seed)=>{
        const cachedSample = cachedSamples.get(seed);
        if (cachedSample === undefined) {
            cachedSamples.set(seed, sample);
            return;
        }
        cachedSample.strings.push(...sample.strings);
        if (cachedSample.strings.length > sampleCount * 2) {
            bucketOverflowed = true;
        }
    });
    // Trimming an overgrown bucket would have to guess which string is the widest — the
    // width determiner can sit anywhere in it. Instead of risking its eviction (and a column
    // that renders narrower than its content), the whole entry is dropped: the next
    // re-measure falls back to one full scan that rebuilds it.
    if (bucketOverflowed && physicalColumn !== null) {
        _class_private_field_get(this, _columnSamplesCache).delete(physicalColumn);
    }
}
function measureCellsWidth(items) {
    const widths = new Map();
    const measurableItems = items.filter(({ samples })=>samples.size > 0);
    if (measurableItems.length === 0) {
        return widths;
    }
    const useHeaders = this.ghostTable.getSetting('useHeaders');
    this.ghostTable.setSetting('useHeaders', false);
    try {
        measurableItems.forEach(({ visualColumn, samples })=>{
            _class_private_method_get(this, _addGhostTableColumn, addGhostTableColumn).call(this, visualColumn, samples);
        });
        this.ghostTable.getWidths((visualColumn, width)=>{
            widths.set(visualColumn, width);
        });
    } finally{
        // A throwing custom renderer must not leave the ghost table with headers disabled (or
        // with the probe's columns still attached) for every later full-scan measurement.
        this.ghostTable.clean();
        this.ghostTable.setSetting('useHeaders', useHeaders);
    }
    return widths;
}
function formatProbeValue(row, column, value) {
    const cellMeta = this.hot.getCellMetaTransient(row, column);
    return (0, _renderCell.formatCellValue)(value, cellMeta, this.hot.getCellRenderer(cellMeta));
}
function fillGhostTableWithSamples(visualColumn, rowsRange) {
    const samples = this.samplesGenerator.generateColumnSamples(visualColumn, rowsRange);
    samples.forEach((sample, column)=>{
        const physicalColumn = this.hot.toPhysicalColumn(column);
        _class_private_method_get(this, _addGhostTableColumn, addGhostTableColumn).call(this, column, sample);
        _class_private_field_get(this, _columnSamplesCache).set(physicalColumn === null ? column : physicalColumn, sample);
    });
}
function addGhostTableColumn(visualColumn, samples) {
    this.ghostTable.addColumn(visualColumn, new Map(samples));
}
function updateColumnWidthsMapBasedOnGhostTable() {
    this.hot.batchExecution(()=>{
        this.ghostTable.getWidths((visualColumn, width)=>{
            const physicalColumn = this.hot.toPhysicalColumn(visualColumn);
            this.columnWidthsMap.setValueAtIndex(physicalColumn, width);
        });
    }, true);
}
