"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AutoColumnSize () {
        return _autoColumnSize.AutoColumnSize;
    },
    get PLUGIN_KEY () {
        return _autoColumnSize.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _autoColumnSize.PLUGIN_PRIORITY;
    }
});
const _autoColumnSize = require("./autoColumnSize");
