"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BindRowsWithHeaders () {
        return _bindRowsWithHeaders.BindRowsWithHeaders;
    },
    get PLUGIN_KEY () {
        return _bindRowsWithHeaders.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _bindRowsWithHeaders.PLUGIN_PRIORITY;
    }
});
const _bindRowsWithHeaders = require("./bindRowsWithHeaders");
