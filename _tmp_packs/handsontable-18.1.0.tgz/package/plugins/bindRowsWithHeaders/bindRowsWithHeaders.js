"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BindRowsWithHeaders () {
        return BindRowsWithHeaders;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _looseBindsMap = /*#__PURE__*/ _interop_require_default(require("./maps/looseBindsMap"));
const _strictBindsMap = /*#__PURE__*/ _interop_require_default(require("./maps/strictBindsMap"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const PLUGIN_KEY = 'bindRowsWithHeaders';
const PLUGIN_PRIORITY = 210;
const DEFAULT_BIND = 'loose';
const bindTypeToMapStrategy = new Map([
    [
        'loose',
        _looseBindsMap.default
    ],
    [
        'strict',
        _strictBindsMap.default
    ]
]);
var /**
   * On modify row header listener.
   *
   * @param {number} row Row index.
   * @returns {number}
   */ _onModifyRowHeader = /*#__PURE__*/ new WeakMap();
class BindRowsWithHeaders extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link BindRowsWithHeaders#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[PLUGIN_KEY];
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        const selfWithGetSetting = this;
        const MapStrategy = bindTypeToMapStrategy.get(selfWithGetSetting.getSetting()) ?? bindTypeToMapStrategy.get(DEFAULT_BIND);
        if (!MapStrategy) {
            return;
        }
        this.headerIndexes = this.hot.rowIndexMapper.registerMap('bindRowsWithHeaders', new MapStrategy());
        this.addHook('modifyRowHeader', _class_private_field_get(this, _onModifyRowHeader));
        super.enablePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        this.hot.rowIndexMapper.unregisterMap('bindRowsWithHeaders');
        super.disablePlugin();
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        super.destroy();
    }
    constructor(...args){
        super(...args), _class_private_field_init(this, _onModifyRowHeader, {
            writable: true,
            value: void 0
        }), /**
   * Plugin indexes cache.
   *
   * @private
   * @type {null|IndexMap}
   */ this.headerIndexes = null, _class_private_field_set(this, _onModifyRowHeader, (row)=>{
            return this.headerIndexes.getValueAtIndex(this.hot.toPhysicalRow(row));
        });
    }
}
