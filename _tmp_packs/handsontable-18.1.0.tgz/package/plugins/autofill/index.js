"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Autofill () {
        return _autofill.Autofill;
    },
    get PLUGIN_KEY () {
        return _autofill.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _autofill.PLUGIN_PRIORITY;
    }
});
const _autofill = require("./autofill");
