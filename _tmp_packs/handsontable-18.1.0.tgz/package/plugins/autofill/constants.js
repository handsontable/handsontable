"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DIRECTIONS", {
    enumerable: true,
    get: function() {
        return DIRECTIONS;
    }
});
const DIRECTIONS = Object.freeze({
    horizontal: 'horizontal',
    vertical: 'vertical'
});
