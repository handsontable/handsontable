"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get HiddenRows () {
        return _hiddenRows.HiddenRows;
    },
    get PLUGIN_KEY () {
        return _hiddenRows.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _hiddenRows.PLUGIN_PRIORITY;
    }
});
const _hiddenRows = require("./hiddenRows");
