"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get applyFiltersFromFiltersPluginToQueryParameters () {
        return applyFiltersFromFiltersPluginToQueryParameters;
    },
    get cloneDataProviderFiltersPayload () {
        return cloneDataProviderFiltersPayload;
    },
    get conditionsStackToFiltersPayload () {
        return conditionsStackToFiltersPayload;
    },
    get filtersPayloadToConditionsStack () {
        return filtersPayloadToConditionsStack;
    },
    get handleBeforeFilterForServer () {
        return handleBeforeFilterForServer;
    }
});
const _function = require("../../../helpers/function");
const FILTERS_PLUGIN_KEY = 'filters';
function cloneDataProviderFiltersPayload(filters) {
    if (filters === null) {
        return null;
    }
    return filters.map((col)=>({
            prop: col.prop,
            operation: col.operation,
            conditions: (col.conditions || []).map((c)=>({
                    name: c.name,
                    args: Array.isArray(c.args) ? [
                        ...c.args
                    ] : []
                }))
        }));
}
function conditionsStackToFiltersPayload(hot, conditionsStack) {
    if (!Array.isArray(conditionsStack) || conditionsStack.length === 0) {
        return null;
    }
    const payload = [];
    for(let i = 0; i < conditionsStack.length; i++){
        const stack = conditionsStack[i];
        const visualCol = hot.toVisualColumn(stack.column);
        const prop = hot.colToProp(visualCol);
        if (prop === null || prop === undefined) {
            continue;
        }
        payload.push({
            prop: String(prop),
            operation: stack.operation,
            conditions: stack.conditions.map((c)=>({
                    name: c.name,
                    args: Array.isArray(c.args) ? [
                        ...c.args
                    ] : []
                }))
        });
    }
    return payload.length === 0 ? null : payload;
}
function filtersPayloadToConditionsStack(hot, filtersPayload) {
    if (filtersPayload === null || filtersPayload === undefined) {
        return [];
    }
    if (!Array.isArray(filtersPayload) || filtersPayload.length === 0) {
        return [];
    }
    const stack = [];
    for(let i = 0; i < filtersPayload.length; i++){
        const col = filtersPayload[i];
        const visualCol = hot.propToCol(col.prop);
        if (visualCol === null || visualCol === undefined || visualCol < 0) {
            continue;
        }
        const physicalColumn = hot.toPhysicalColumn(visualCol);
        stack.push({
            column: physicalColumn,
            operation: col.operation,
            conditions: (col.conditions || []).map((c)=>({
                    name: c.name ?? '',
                    args: Array.isArray(c.args) ? [
                        ...c.args
                    ] : []
                }))
        });
    }
    return stack;
}
function applyFiltersFromFiltersPluginToQueryParameters(hot, queryParameters, getFetchFn) {
    if (!(0, _function.isFunction)(getFetchFn())) {
        return;
    }
    const filtersPlugin = hot.getPlugin(FILTERS_PLUGIN_KEY);
    if (!filtersPlugin || !filtersPlugin.enabled) {
        return;
    }
    const filtersForProvider = conditionsStackToFiltersPayload(hot, filtersPlugin.exportConditions());
    queryParameters.filters = filtersForProvider ?? null;
}
function handleBeforeFilterForServer(ctx, conditionsStack) {
    const { hot, hasFetchFn, applyFiltersAndRefetch } = ctx;
    if (!hasFetchFn()) {
        return;
    }
    const filtersForProvider = conditionsStackToFiltersPayload(hot, conditionsStack);
    applyFiltersAndRefetch(filtersForProvider);
    return false;
}
