"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ABORT_REASON_MESSAGE () {
        return ABORT_REASON_MESSAGE;
    },
    get DATA_PROVIDER_BATCH_UPDATE_SOURCES () {
        return DATA_PROVIDER_BATCH_UPDATE_SOURCES;
    },
    get DATA_PROVIDER_ERROR_REMOVE_ROWS_MISSING_ID () {
        return DATA_PROVIDER_ERROR_REMOVE_ROWS_MISSING_ID;
    },
    get DATA_PROVIDER_ERROR_UPDATE_MISSING_ROW_ID () {
        return DATA_PROVIDER_ERROR_UPDATE_MISSING_ROW_ID;
    },
    get DATA_PROVIDER_ERROR_UPDATE_ROWS_MISSING_ID () {
        return DATA_PROVIDER_ERROR_UPDATE_ROWS_MISSING_ID;
    },
    get DEFAULT_PAGE_SIZE () {
        return DEFAULT_PAGE_SIZE;
    },
    get DEFAULT_SETTINGS () {
        return DEFAULT_SETTINGS;
    },
    get INITIAL_QUERY_PARAMETERS () {
        return INITIAL_QUERY_PARAMETERS;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    },
    get SETTINGS_VALIDATORS () {
        return SETTINGS_VALIDATORS;
    },
    get dataProviderErrorRemoveMissingRowId () {
        return dataProviderErrorRemoveMissingRowId;
    }
});
const _function = require("../../helpers/function");
const PLUGIN_KEY = 'dataProvider';
const PLUGIN_PRIORITY = 950;
const DEFAULT_PAGE_SIZE = 10;
const DEFAULT_SETTINGS = {
    rowId: undefined,
    fetchRows: undefined,
    onRowsCreate: undefined,
    onRowsUpdate: undefined,
    onRowsRemove: undefined
};
const SETTINGS_VALIDATORS = {
    rowId: (value)=>typeof value === 'string' || (0, _function.isFunction)(value),
    fetchRows: (value)=>(0, _function.isFunction)(value),
    onRowsCreate: (value)=>(0, _function.isFunction)(value),
    onRowsUpdate: (value)=>(0, _function.isFunction)(value),
    onRowsRemove: (value)=>(0, _function.isFunction)(value)
};
const ABORT_REASON_MESSAGE = 'DataProvider fetch superseded by a newer request';
const INITIAL_QUERY_PARAMETERS = Object.freeze({
    page: 1,
    pageSize: DEFAULT_PAGE_SIZE,
    sort: null,
    filters: null
});
const DATA_PROVIDER_BATCH_UPDATE_SOURCES = new Set([
    'edit',
    undefined,
    'CopyPaste.paste',
    'CopyPaste.cut',
    'Autofill.fill',
    'ContextMenu.clearColumn',
    /** Revert after failed `onRowsUpdate`; skipped for server enqueue and omitted from undo stack. */ 'DataProvider.revert'
]);
const DATA_PROVIDER_ERROR_UPDATE_MISSING_ROW_ID = 'DataProvider: cannot send row update because `rowId` resolves to null or undefined for that row.';
function dataProviderErrorRemoveMissingRowId(visualIndex) {
    return `DataProvider: cannot remove row at visual index ${visualIndex} because \`rowId\` ` + 'resolves to null or undefined.';
}
const DATA_PROVIDER_ERROR_UPDATE_ROWS_MISSING_ID = 'DataProvider: `updateRows` requires every entry to include a non-null `id`.';
const DATA_PROVIDER_ERROR_REMOVE_ROWS_MISSING_ID = 'DataProvider: `removeRows` requires every id to be non-null.';
