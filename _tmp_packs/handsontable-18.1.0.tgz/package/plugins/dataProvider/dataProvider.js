"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DataProvider () {
        return DataProvider;
    },
    get PLUGIN_KEY () {
        return _constants1.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _constants1.PLUGIN_PRIORITY;
    }
});
const _function = require("../../helpers/function");
const _console = require("../../helpers/console");
const _errors = require("../../helpers/errors");
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../i18n/constants"));
const _base = require("../base");
const _constants1 = require("./constants");
const _crud = require("./query/crud");
const _filtering = require("./query/filtering");
const _pagination = require("./query/pagination");
const _sorting = require("./query/sorting");
const _utils = require("./utils");
const _conflictRegistry = require("../base/conflictRegistry");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
(0, _conflictRegistry.registerConflict)('dataProvider', [
    'manualRowMove',
    'manualColumnMove',
    'trimRows',
    'multiColumnSorting'
]);
var /**
   * Last request params passed to `fetchRows` (`page`, `pageSize`, `sort`, `filters`).
   * Same shape as `DataProviderQueryParameters` in `types/plugins/dataProvider/dataProvider.d.ts`.
   *
   * @type {DataProviderQueryParameters}
   */ _queryParameters = /*#__PURE__*/ new WeakMap(), /**
   * Aborts in-flight fetch when superseded or on disable/destroy.
   *
   * @type {AbortController|null}
   */ _abortController = /*#__PURE__*/ new WeakMap(), _mutationQueue = /*#__PURE__*/ new WeakMap(), /**
   * Raw `dataProvider` setting (config object only).
   *
   * @returns {object|undefined}
   */ _getConfig = /*#__PURE__*/ new WeakSet(), /**
   * `rowId` from config (string path or function).
   *
   * @returns {string|Function|undefined|null}
   */ _getRowIdOption = /*#__PURE__*/ new WeakSet(), /**
   * @returns {Function|undefined}
   */ _getFetchFn = /*#__PURE__*/ new WeakSet(), /**
   * @returns {Function|undefined}
   */ _getOnRowsCreate = /*#__PURE__*/ new WeakSet(), /**
   * @returns {Function|undefined}
   */ _getOnRowsUpdate = /*#__PURE__*/ new WeakSet(), /**
   * @returns {Function|undefined}
   */ _getOnRowsRemove = /*#__PURE__*/ new WeakSet(), /**
   * @param {DataProviderQueryParameters} p Query parameters object.
   * @returns {DataProviderQueryParameters} Snapshot safe for comparisons and external use (`sort` and `filters` cloned when non-null).
   */ _snapshotQueryParameters = /*#__PURE__*/ new WeakSet(), /**
   * Fills `#queryParameters` from Pagination, ColumnSorting, and (when `fetchRows` exists) Filters so `fetchRows`
   * matches plugin UI state after enable or before a server-driven refetch.
   *
   * @returns {void}
   */ _applyQueryParametersFromPlugins = /*#__PURE__*/ new WeakSet(), /**
   * Aborts an in-flight `fetchRows` call so a new request can start.
   *
   * @returns {void}
   */ _abortInFlightFetch = /*#__PURE__*/ new WeakSet(), /**
   * Merges overrides into `#queryParameters` and normalizes sort / page for `fetchRows`.
   *
   * @param {object} overrides Partial query overrides (subset of [[DataProviderQueryParameters]] keys).
   * @returns {DataProviderQueryParameters} Query parameters object for `fetchRows`.
   */ _mergeAndNormalizeFetchParams = /*#__PURE__*/ new WeakSet(), /**
   * Replaces `#abortController` with a new controller for the next fetch.
   *
   * @returns {AbortController}
   */ _createFetchAbortController = /*#__PURE__*/ new WeakSet(), /**
   * @param {object} params Query parameters for the aborted `fetchRows` call.
   * @param {Error|undefined} reason `AbortError` (or subclass) when `fetchRows` rejected; omit the argument when the promise settled after superseding.
   * @returns {void}
   */ _runAfterDataProviderFetchAbort = /*#__PURE__*/ new WeakSet(), /**
   * Aborts any pending `fetchRows` and clears the controller.
   *
   * @returns {void}
   */ _resetAbortController = /*#__PURE__*/ new WeakSet(), /**
   * Appends a mutation onto the queue so concurrent CRUD runs sequentially.
   *
   * @param {function(): Promise<void>} fn Async work for one mutation.
   * @returns {Promise<void>}
   */ _enqueueMutation = /*#__PURE__*/ new WeakSet(), /**
   * Shows an error toast in the [[Options#notification]] plugin when it is enabled.
   * For `fetch` failures only, the toast includes a primary **Refetch** action (`duration: 0` until dismissed) that hides the toast and calls [[DataProvider#fetchData]] again.
   *
   * @param {'fetch'|'create'|'update'|'remove'} kind Which request failed.
   * @param {Error|*} err Rejection reason from the user callback or `fetchRows`.
   * @returns {void}
   */ _showDataProviderRequestErrorNotification = /*#__PURE__*/ new WeakSet(), /**
   * Calls `onRowsUpdate`, success/error hooks, then re-fetches or re-renders.
   *
   * @param {object[]} rowPayloads Per-row `{ id, changes, rowData }` payloads.
   * @param {object} [options] Optional flags.
   * @param {function(): void} [options.revertOptimistic] Restores previous cell values when the request fails.
   * @returns {Promise<void>}
   */ _commitRowsUpdate = /*#__PURE__*/ new WeakSet(), /**
   * Queues create/remove (or similar) server calls with before/after mutation hooks.
   *
   * @param {string} operation `'create'` or `'remove'`.
   * @param {object} payload Hook payload (`{ rowsCreate }` or `{ rowsRemove }`).
   * @param {function(): Promise<*>} userPromiseFn Server callback invocation.
   * @param {function(): Promise<void>|void} onSuccess Runs after success (e.g. `fetchData`).
   * @returns {Promise<void>}
   */ _queueCrud = /*#__PURE__*/ new WeakSet(), /**
   * Runs [[#fetchData]] for internal fire-and-forget refetches (initial load, `updatePlugin`, sort, filter, and the
   * Refetch notification action). [[#fetchData]] already surfaces the failure – it fires
   * [[Hooks#afterDataProviderFetchError]] and shows the error notification – before rethrowing for its public callers,
   * so here the rejection is only logged and settled. Without this, `fetchRows` failures reach the page as
   * `unhandledrejection` events.
   *
   * @param {object} [overrides] Partial query overrides passed to [[#fetchData]].
   * @returns {Promise<{ rows: Array<*>, totalRows: number }|null>} Resolves to `null` when the fetch fails.
   */ _fetchDataSilently = /*#__PURE__*/ new WeakSet(), _onHasExternalDataSource = /*#__PURE__*/ new WeakMap(), _onAfterInit = /*#__PURE__*/ new WeakMap(), _onAfterPageChangeExternalPagination = /*#__PURE__*/ new WeakMap(), _onAfterPageSizeChangeExternalPagination = /*#__PURE__*/ new WeakMap(), _onBeforeFilter = /*#__PURE__*/ new WeakMap(), _onBeforeColumnSort = /*#__PURE__*/ new WeakMap(), _onModifyRowHeader = /*#__PURE__*/ new WeakMap(), _onBeforeUndoStackChange = /*#__PURE__*/ new WeakMap(), _onAfterChangeForServerUpdate = /*#__PURE__*/ new WeakMap(), _onBeforeAlter = /*#__PURE__*/ new WeakMap();
class DataProvider extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return _constants1.PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return _constants1.PLUGIN_PRIORITY;
    }
    /**
   * Returns the setting keys that trigger a plugin update when changed via `updateSettings`.
   */ static get SETTING_KEYS() {
        return [
            _constants1.PLUGIN_KEY
        ];
    }
    /**
   * Returns the default settings applied when the plugin is enabled without explicit configuration.
   */ static get DEFAULT_SETTINGS() {
        return _constants1.DEFAULT_SETTINGS;
    }
    /**
   * Returns validator functions for each plugin setting to verify their values are valid before applying them.
   */ static get SETTINGS_VALIDATORS() {
        return _constants1.SETTINGS_VALIDATORS;
    }
    /**
   * Check if the plugin is enabled in the handsontable settings.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[_constants1.PLUGIN_KEY];
    }
    /**
   * Enables the plugin, syncs query parameters from Pagination, ColumnSorting, and Filters, and registers hooks.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        _class_private_method_get(this, _applyQueryParametersFromPlugins, applyQueryParametersFromPlugins).call(this);
        this.addHook('hasExternalDataSource', _class_private_field_get(this, _onHasExternalDataSource));
        this.addHook('afterInit', _class_private_field_get(this, _onAfterInit));
        this.addHook('modifyRowHeader', _class_private_field_get(this, _onModifyRowHeader));
        this.addHook('beforeColumnSort', _class_private_field_get(this, _onBeforeColumnSort));
        this.addHook('beforeUndoStackChange', _class_private_field_get(this, _onBeforeUndoStackChange));
        this.addHook('afterChange', _class_private_field_get(this, _onAfterChangeForServerUpdate));
        this.addHook('beforeAlter', _class_private_field_get(this, _onBeforeAlter));
        this.addHook('afterPageChange', _class_private_field_get(this, _onAfterPageChangeExternalPagination));
        this.addHook('afterPageSizeChange', _class_private_field_get(this, _onAfterPageSizeChangeExternalPagination));
        this.addHook('beforeFilter', _class_private_field_get(this, _onBeforeFilter));
        super.enablePlugin();
    }
    /**
   * Re-applies settings and refetches when the instance is already initialized.
   */ updatePlugin() {
        this.disablePlugin();
        this.enablePlugin();
        if (this.hot.view) {
            void _class_private_method_get(this, _fetchDataSilently, fetchDataSilently).call(this);
        }
        super.updatePlugin();
    }
    /**
   * Disables the plugin, aborts fetch, resets query state.
   * Hook listeners registered with `addHook` are removed by `super.disablePlugin()` via `clearHooks()`.
   * The constructor registers [[Hooks#hasExternalDataSource]] for the period before the first `enablePlugin()`;
   * `enablePlugin()` registers it again so it survives each `updatePlugin()` cycle.
   */ disablePlugin() {
        _class_private_method_get(this, _resetAbortController, resetAbortController).call(this);
        _class_private_field_set(this, _queryParameters, {
            ..._constants1.INITIAL_QUERY_PARAMETERS
        });
        super.disablePlugin();
    }
    /**
   * @returns {DataProviderQueryParameters} Copy of current query parameters (`sort` and `filters` are cloned when non-null).
   */ getQueryParameters() {
        return _class_private_method_get(this, _snapshotQueryParameters, snapshotQueryParameters).call(this, _class_private_field_get(this, _queryParameters));
    }
    /**
   * @param {number} visualRow Visual row index.
   * @returns {*} Row id from `rowId` option, or undefined.
   */ getRowId(visualRow) {
        return (0, _crud.getRowIdByVisualRow)(this.hot, _class_private_method_get(this, _getRowIdOption, getRowIdOption).call(this), visualRow);
    }
    /**
   * Fetches rows from `fetchRows` with current or overridden query parameters.
   *
   * @param {object} [overrides] Partial query overrides (e.g. `{ page: 2 }`, `{ pageSize: 20, page: 1 }`, `{ sort }`, `{ filters }`).
   * Pass `{ skipLoading: true }` to mark internal refetches (for example sort or CRUD); [[Hooks#beforeDataProviderFetch]] receives it, and it is not passed to `fetchRows`.
   * Numeric `page` is clamped to at least 1.
   * When the response `totalRows` implies fewer pages than the requested `page`, fetches again at the last valid page without applying the out-of-range result (avoids redundant `afterPageChange` loads and aborted duplicate requests after row removal on the last page).
   * @returns {Promise<{ rows: Array<*>, totalRows: number }|null>}
   *
   * @fires Hooks#afterDataProviderFetch when data loads.
   * @fires Hooks#afterDataProviderFetchError when `fetchRows` throws a non-abort error.
   * @fires Hooks#afterDataProviderFetchAbort when the request is superseded, aborted, or ends with `AbortError`.
   */ async fetchData(overrides = {}) {
        const fetchFn = _class_private_method_get(this, _getFetchFn, getFetchFn).call(this);
        if (!(0, _function.isFunction)(fetchFn)) {
            this.hot.render();
            return null;
        }
        const params = _class_private_method_get(this, _mergeAndNormalizeFetchParams, mergeAndNormalizeFetchParams).call(this, overrides);
        const controller = _class_private_method_get(this, _createFetchAbortController, createFetchAbortController).call(this);
        const { signal } = controller;
        if (this.hot.runHooks('beforeDataProviderFetch', params) === false) {
            _class_private_field_set(this, _abortController, null);
            this.hot.render();
            return null;
        }
        const fetchRowsParams = _class_private_method_get(this, _snapshotQueryParameters, snapshotQueryParameters).call(this, params);
        try {
            const result = await fetchFn(fetchRowsParams, {
                signal
            });
            if (signal.aborted) {
                _class_private_method_get(this, _runAfterDataProviderFetchAbort, runAfterDataProviderFetchAbort).call(this, params, undefined);
                return null;
            }
            const rows = Array.isArray(result?.rows) ? result.rows : [];
            const totalRows = typeof result?.totalRows === 'number' && result.totalRows >= 0 ? result.totalRows : rows.length;
            const persistedParams = _class_private_method_get(this, _snapshotQueryParameters, snapshotQueryParameters).call(this, params);
            const clampedPage = (0, _utils.clampDataProviderPageToTotalRows)(persistedParams.page, persistedParams.pageSize, totalRows);
            if (clampedPage !== persistedParams.page) {
                return this.fetchData({
                    ...overrides,
                    page: clampedPage,
                    skipLoading: overrides.skipLoading
                });
            }
            _class_private_field_set(this, _queryParameters, persistedParams);
            this.hot.loadData(rows, _constants1.PLUGIN_KEY);
            const columnSortConfig = (0, _sorting.sortingPayloadToSort)(this.hot, persistedParams.sort ?? null);
            const filtersConditionsStack = (0, _filtering.filtersPayloadToConditionsStack)(this.hot, persistedParams.filters ?? null);
            this.hot.runHooks('afterDataProviderFetch', {
                ...result,
                rows,
                totalRows,
                queryParameters: persistedParams,
                columnSortConfig,
                filtersConditionsStack
            });
            this.hot.render();
            return {
                rows,
                totalRows
            };
        } catch (err) {
            if (signal.aborted || err instanceof Error && err.name === 'AbortError') {
                _class_private_method_get(this, _runAfterDataProviderFetchAbort, runAfterDataProviderFetchAbort).call(this, params, err);
                return null;
            }
            this.hot.runHooks('afterDataProviderFetchError', err, _class_private_method_get(this, _snapshotQueryParameters, snapshotQueryParameters).call(this, params));
            _class_private_method_get(this, _showDataProviderRequestErrorNotification, showDataProviderRequestErrorNotification).call(this, 'fetch', err);
            throw err;
        } finally{
            if (_class_private_field_get(this, _abortController) === controller) {
                _class_private_field_set(this, _abortController, null);
            }
        }
    }
    /**
   * Server create via `onRowsCreate`. Use `rowsAmount` to insert more than one row in one call.
   *
   * @param {object} [options] `position`, `referenceRowId`, `rowsAmount`.
   * @returns {Promise<void>}
   */ async createRows(options = {}) {
        const onRowsCreate = _class_private_method_get(this, _getOnRowsCreate, getOnRowsCreate).call(this);
        if (!(0, _function.isFunction)(onRowsCreate)) {
            return;
        }
        const rowsCreatePayload = {
            position: options.position ?? 'below',
            referenceRowId: options.referenceRowId,
            rowsAmount: options.rowsAmount ?? 1
        };
        const payload = {
            rowsCreate: rowsCreatePayload
        };
        return _class_private_method_get(this, _queueCrud, queueCrud).call(this, 'create', payload, ()=>Promise.resolve(onRowsCreate(rowsCreatePayload)), async ()=>{
            await this.fetchData({
                skipLoading: true
            });
        });
    }
    /**
   * Server remove via `onRowsRemove`. Pass one row id or an array of ids.
   *
   * After a successful `onRowsRemove`, refetches from the server. When the remove clears every row currently
   * loaded (typical when emptying the last page) and the current page is greater than 1, loads the previous page
   * in one request. Otherwise refetches the current page, then loads the previous page when that response is empty
   * and the current page is still greater than 1.
   *
   * @param {Array<*>|*} rowIds Row id or ids.
   * @returns {Promise<void>}
   * @throws {Error} When any id is `null` or `undefined`.
   */ async removeRows(rowIds) {
        const onRowsRemove = _class_private_method_get(this, _getOnRowsRemove, getOnRowsRemove).call(this);
        if (!(0, _function.isFunction)(onRowsRemove)) {
            return;
        }
        const ids = Array.isArray(rowIds) ? rowIds : [
            rowIds
        ];
        ids.forEach((id)=>{
            if ((0, _crud.isMissingRowId)(id)) {
                (0, _errors.throwWithCause)(_constants1.DATA_PROVIDER_ERROR_REMOVE_ROWS_MISSING_ID);
            }
        });
        const payload = {
            rowsRemove: ids
        };
        return _class_private_method_get(this, _queueCrud, queueCrud).call(this, 'remove', payload, ()=>onRowsRemove(ids), async ()=>{
            const pageBeforeFetch = _class_private_field_get(this, _queryParameters).page;
            const rowsLoaded = this.hot.countRows();
            const removesEveryLoadedRow = ids.length >= rowsLoaded && rowsLoaded >= 1;
            if (removesEveryLoadedRow && pageBeforeFetch > 1) {
                await this.fetchData({
                    page: pageBeforeFetch - 1,
                    skipLoading: true
                });
                return;
            }
            const result = await this.fetchData({
                skipLoading: true
            });
            if (result?.rows.length === 0 && pageBeforeFetch > 1) {
                await this.fetchData({
                    page: pageBeforeFetch - 1,
                    skipLoading: true
                });
            }
        });
    }
    /**
   * Server update via `onRowsUpdate`. Pass an array of `{ id, changes, rowData? }` (same shape as `onRowsUpdate`).
   *
   * @param {object[]} rows Row update payloads (one or more).
   * @returns {Promise<void>}
   * @throws {Error} When any payload omits `id` or `id` is `null`.
   */ async updateRows(rows) {
        if (!(0, _function.isFunction)(_class_private_method_get(this, _getOnRowsUpdate, getOnRowsUpdate).call(this)) || !Array.isArray(rows) || rows.length === 0) {
            return;
        }
        rows.forEach((p)=>{
            if ((0, _crud.isMissingRowId)(p.id)) {
                (0, _errors.throwWithCause)(_constants1.DATA_PROVIDER_ERROR_UPDATE_ROWS_MISSING_ID);
            }
        });
        const rowPayloads = (0, _crud.buildManualUpdateRowPayloads)(this.hot, _class_private_method_get(this, _getRowIdOption, getRowIdOption).call(this), rows);
        return _class_private_method_get(this, _enqueueMutation, enqueueMutation).call(this, ()=>(0, _crud.runManualUpdateRowsMutation)(this.hot, {
                getRowIdOption: ()=>_class_private_method_get(this, _getRowIdOption, getRowIdOption).call(this),
                commitRowsUpdate: (payloads)=>_class_private_method_get(this, _commitRowsUpdate, commitRowsUpdate).call(this, payloads)
            }, rowPayloads));
    }
    /**
   * Destroys the plugin.
   */ destroy() {
        _class_private_method_get(this, _resetAbortController, resetAbortController).call(this);
        super.destroy();
    }
    /**
   * @param {object} hotInstance Handsontable instance.
   */ constructor(hotInstance){
        super(hotInstance), _class_private_method_init(this, _getConfig), _class_private_method_init(this, _getRowIdOption), _class_private_method_init(this, _getFetchFn), _class_private_method_init(this, _getOnRowsCreate), _class_private_method_init(this, _getOnRowsUpdate), _class_private_method_init(this, _getOnRowsRemove), _class_private_method_init(this, _snapshotQueryParameters), _class_private_method_init(this, _applyQueryParametersFromPlugins), _class_private_method_init(this, _abortInFlightFetch), _class_private_method_init(this, _mergeAndNormalizeFetchParams), _class_private_method_init(this, _createFetchAbortController), _class_private_method_init(this, _runAfterDataProviderFetchAbort), _class_private_method_init(this, _resetAbortController), _class_private_method_init(this, _enqueueMutation), _class_private_method_init(this, _showDataProviderRequestErrorNotification), _class_private_method_init(this, _commitRowsUpdate), _class_private_method_init(this, _queueCrud), _class_private_method_init(this, _fetchDataSilently), _class_private_field_init(this, _queryParameters, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _abortController, {
            writable: true,
            value: void 0
        }), /**
   * Serializes create/update/remove mutations so they run one after another.
   *
   * @type {{ tail: Promise<void> }}
   */ _class_private_field_init(this, _mutationQueue, {
            writable: true,
            value: void 0
        }), /**
   * Default handler for [[Hooks#hasExternalDataSource]]: `true` when this instance has a complete server-backed
   * `dataProvider` configuration. Registered in the constructor (early lifecycle) and in `enablePlugin()` after each
   * `disablePlugin()` clears `addHook` listeners.
   *
   * @returns {boolean}
   */ _class_private_field_init(this, _onHasExternalDataSource, {
            writable: true,
            value: void 0
        }), /**
   * @returns {void}
   */ _class_private_field_init(this, _onAfterInit, {
            writable: true,
            value: void 0
        }), /**
   * Loads the requested page when Pagination runs in external paged mode.
   * Skips when `#queryParameters` already matches the Pagination UI (e.g. right after a successful fetch).
   *
   * @param {number} oldPage Previous 1-based page.
   * @param {number} newPage New 1-based page.
   * @returns {void}
   */ _class_private_field_init(this, _onAfterPageChangeExternalPagination, {
            writable: true,
            value: void 0
        }), /**
   * Loads page 1 with the new page size when Pagination runs in external paged mode.
   * Skips when `#queryParameters` already match (e.g. duplicate `afterPageSizeChange` from Pagination sync).
   *
   * @param {number | 'auto'} oldPageSize Previous page size.
   * @param {number | 'auto'} newPageSize New page size.
   * @returns {void}
   */ _class_private_field_init(this, _onAfterPageSizeChangeExternalPagination, {
            writable: true,
            value: void 0
        }), /**
   * Intercepts filter action when `fetchRows` is set: applies server-side filters and refetches; returns false so Filters skip client-side trimming.
   * Without `fetchRows`, returns nothing so Filters run client-side trimming (same guard pattern as [[#onBeforeColumnSort]]).
   *
   * @param {Array} conditionsStack Exported filter conditions (column = physical index).
   * @returns {boolean|void} False when filtering is handled server-side.
   */ _class_private_field_init(this, _onBeforeFilter, {
            writable: true,
            value: void 0
        }), /**
   * @param {Array} currentSortConfig Current sort config.
   * @param {Array} destinationSortConfigs Destination sort config.
   * @param {boolean} sortPossible Whether sort is allowed.
   * @returns {boolean|undefined}
   */ _class_private_field_init(this, _onBeforeColumnSort, {
            writable: true,
            value: void 0
        }), /**
   * @param {number} visualRowIndex Visual row index.
   * @returns {number} Global row index for headers.
   */ _class_private_field_init(this, _onModifyRowHeader, {
            writable: true,
            value: void 0
        }), /**
   * Skips the local undo stack for edits that batch to `onRowsUpdate` (same sources as `shouldIgnoreAfterChangeForServerUpdate`).
   *
   * @param {Array} doneActionsCopy Snapshot of the undo stack before the new action.
   * @param {string} [source] Change source for the action being pushed onto the stack.
   * @returns {boolean|void} Return `false` to block stacking (see [[Hooks#beforeUndoStackChange]]).
   */ _class_private_field_init(this, _onBeforeUndoStackChange, {
            writable: true,
            value: void 0
        }), /**
   * After a valid edit applies locally, queues `onRowsUpdate`. On failure, cells revert to previous values.
   *
   * @param {Array} changes `[visualRow, prop, oldVal, newVal][]`.
   * @param {string} [source] Change source.
   * @returns {void}
   */ _class_private_field_init(this, _onAfterChangeForServerUpdate, {
            writable: true,
            value: void 0
        }), /**
   * @param {string} action Alter action name.
   * @param {number|Array} index Row index or index groups.
   * @param {number} amount Row count.
   * @returns {boolean|undefined}
   */ _class_private_field_init(this, _onBeforeAlter, {
            writable: true,
            value: void 0
        }), _class_private_field_set(this, _queryParameters, {
            ..._constants1.INITIAL_QUERY_PARAMETERS
        }), _class_private_field_set(this, _abortController, null), _class_private_field_set(this, _mutationQueue, {
            tail: Promise.resolve()
        }), _class_private_field_set(this, _onHasExternalDataSource, ()=>(0, _utils.isCompleteDataProviderConfig)(this.hot.getSettings().dataProvider)), _class_private_field_set(this, _onAfterInit, ()=>{
            void _class_private_method_get(this, _fetchDataSilently, fetchDataSilently).call(this);
        }), _class_private_field_set(this, _onAfterPageChangeExternalPagination, (oldPage, newPage)=>{
            (0, _pagination.handleAfterPageChangeExternalPagination)({
                hot: this.hot,
                getQueryPage: ()=>_class_private_field_get(this, _queryParameters).page,
                goToPage: async (page)=>{
                    await this.fetchData({
                        page
                    });
                }
            }, oldPage, newPage);
        }), _class_private_field_set(this, _onAfterPageSizeChangeExternalPagination, (oldPageSize, newPageSize)=>{
            (0, _pagination.handleAfterPageSizeChangeExternalPagination)({
                hot: this.hot,
                getQueryPage: ()=>_class_private_field_get(this, _queryParameters).page,
                getQueryPageSize: ()=>_class_private_field_get(this, _queryParameters).pageSize,
                setPageSize: async (pageSize)=>{
                    await this.fetchData({
                        pageSize,
                        page: 1
                    });
                }
            }, oldPageSize, newPageSize);
        }), _class_private_field_set(this, _onBeforeFilter, (conditionsStack)=>(0, _filtering.handleBeforeFilterForServer)({
                hot: this.hot,
                hasFetchFn: ()=>(0, _function.isFunction)(_class_private_method_get(this, _getFetchFn, getFetchFn).call(this)),
                applyFiltersAndRefetch: (filtersForProvider)=>{
                    _class_private_field_get(this, _queryParameters).filters = filtersForProvider ?? null;
                    _class_private_field_get(this, _queryParameters).page = 1;
                    void _class_private_method_get(this, _fetchDataSilently, fetchDataSilently).call(this);
                }
            }, conditionsStack)), _class_private_field_set(this, _onBeforeColumnSort, (currentSortConfig, destinationSortConfigs, sortPossible)=>(0, _sorting.handleBeforeColumnSortForServer)({
                hot: this.hot,
                hasFetchFn: ()=>(0, _function.isFunction)(_class_private_method_get(this, _getFetchFn, getFetchFn).call(this)),
                applyQueryParametersFromPlugins: ()=>_class_private_method_get(this, _applyQueryParametersFromPlugins, applyQueryParametersFromPlugins).call(this),
                fetchData: (overrides)=>_class_private_method_get(this, _fetchDataSilently, fetchDataSilently).call(this, overrides)
            }, currentSortConfig, destinationSortConfigs, sortPossible)), _class_private_field_set(this, _onModifyRowHeader, (visualRowIndex)=>(0, _pagination.getPagedRowHeaderIndex)(_class_private_field_get(this, _queryParameters), visualRowIndex)), _class_private_field_set(this, _onBeforeUndoStackChange, (doneActionsCopy, source)=>{
            if (!(0, _function.isFunction)(_class_private_method_get(this, _getOnRowsUpdate, getOnRowsUpdate).call(this))) {
                return;
            }
            if (!_constants1.DATA_PROVIDER_BATCH_UPDATE_SOURCES.has(source)) {
                return;
            }
            return false;
        }), _class_private_field_set(this, _onAfterChangeForServerUpdate, (changes, source)=>{
            if ((0, _crud.shouldIgnoreAfterChangeForServerUpdate)((0, _function.isFunction)(_class_private_method_get(this, _getOnRowsUpdate, getOnRowsUpdate).call(this)), changes, source)) {
                return;
            }
            const valid = (0, _crud.filterChangesForBatchedServerUpdate)(this.hot, changes);
            if (valid.length === 0) {
                return;
            }
            void _class_private_method_get(this, _enqueueMutation, enqueueMutation).call(this, ()=>(0, _crud.runUpdateFromChanges)(this.hot, {
                    getRowIdOption: ()=>_class_private_method_get(this, _getRowIdOption, getRowIdOption).call(this),
                    commitRowsUpdate: (payloads, opts)=>_class_private_method_get(this, _commitRowsUpdate, commitRowsUpdate).call(this, payloads, opts)
                }, valid));
        }), _class_private_field_set(this, _onBeforeAlter, (action, index, amount)=>(0, _crud.handleBeforeAlterForCrud)({
                hot: this.hot,
                getOnRowsCreate: ()=>_class_private_method_get(this, _getOnRowsCreate, getOnRowsCreate).call(this),
                getOnRowsRemove: ()=>_class_private_method_get(this, _getOnRowsRemove, getOnRowsRemove).call(this),
                getRowIdOption: ()=>_class_private_method_get(this, _getRowIdOption, getRowIdOption).call(this),
                getRowId: (vr)=>this.getRowId(vr),
                createRows: (opts)=>this.createRows(opts),
                removeRows: (ids)=>this.removeRows(ids)
            }, action, index, amount));
        // Before `enablePlugin()` runs (`afterPluginsInitialized`), core may call `runHooks('hasExternalDataSource')`
        // (for example during `updateSettings`). `disablePlugin()` clears all `addHook` listeners, so `enablePlugin()`
        // registers this hook again.
        this.addHook('hasExternalDataSource', _class_private_field_get(this, _onHasExternalDataSource));
    }
}
function getConfig() {
    const c = this.hot.getSettings()[_constants1.PLUGIN_KEY];
    return c && typeof c === 'object' ? c : undefined;
}
function getRowIdOption() {
    const c = _class_private_method_get(this, _getConfig, getConfig).call(this);
    return c ? c.rowId : undefined;
}
function getFetchFn() {
    const c = _class_private_method_get(this, _getConfig, getConfig).call(this);
    return c && (0, _function.isFunction)(c.fetchRows) ? c.fetchRows : undefined;
}
function getOnRowsCreate() {
    const c = _class_private_method_get(this, _getConfig, getConfig).call(this);
    return c && (0, _function.isFunction)(c.onRowsCreate) ? c.onRowsCreate : undefined;
}
function getOnRowsUpdate() {
    const c = _class_private_method_get(this, _getConfig, getConfig).call(this);
    return c && (0, _function.isFunction)(c.onRowsUpdate) ? c.onRowsUpdate : undefined;
}
function getOnRowsRemove() {
    const c = _class_private_method_get(this, _getConfig, getConfig).call(this);
    return c && (0, _function.isFunction)(c.onRowsRemove) ? c.onRowsRemove : undefined;
}
function snapshotQueryParameters(p) {
    return {
        page: p.page,
        pageSize: p.pageSize,
        sort: p.sort === null ? null : {
            ...p.sort
        },
        filters: (0, _filtering.cloneDataProviderFiltersPayload)(p.filters)
    };
}
function applyQueryParametersFromPlugins() {
    (0, _pagination.applyPaginationToQueryFromPlugin)(this.hot, _class_private_field_get(this, _queryParameters));
    (0, _sorting.applyColumnSortToQueryFromPlugin)(this.hot, _class_private_field_get(this, _queryParameters));
    (0, _filtering.applyFiltersFromFiltersPluginToQueryParameters)(this.hot, _class_private_field_get(this, _queryParameters), ()=>_class_private_method_get(this, _getFetchFn, getFetchFn).call(this));
}
function abortInFlightFetch() {
    if (!_class_private_field_get(this, _abortController)) {
        return;
    }
    const reason = new Error(_constants1.ABORT_REASON_MESSAGE);
    reason.name = 'AbortError';
    _class_private_field_get(this, _abortController).abort(reason);
}
function mergeAndNormalizeFetchParams(overrides) {
    const params = {
        ..._class_private_field_get(this, _queryParameters),
        ...overrides
    };
    (0, _sorting.normalizeSortInFetchParams)(params, this.hot);
    if (typeof params.page === 'number' && !Number.isNaN(params.page)) {
        params.page = Math.max(1, params.page);
    }
    return params;
}
function createFetchAbortController() {
    _class_private_method_get(this, _abortInFlightFetch, abortInFlightFetch).call(this);
    const controller = new AbortController();
    _class_private_field_set(this, _abortController, controller);
    return controller;
}
function runAfterDataProviderFetchAbort(params, reason) {
    const queryParameters = _class_private_method_get(this, _snapshotQueryParameters, snapshotQueryParameters).call(this, params);
    this.hot.runHooks('afterDataProviderFetchAbort', queryParameters, reason);
}
function resetAbortController() {
    _class_private_field_get(this, _abortController)?.abort();
    _class_private_field_set(this, _abortController, null);
}
function enqueueMutation(fn) {
    return (0, _crud.enqueueMutation)(_class_private_field_get(this, _mutationQueue), fn);
}
function showDataProviderRequestErrorNotification(kind, err) {
    const notificationPlugin = this.hot.getPlugin('notification');
    if (!notificationPlugin?.enabled) {
        return;
    }
    const titleKeys = {
        fetch: _constants.DATA_PROVIDER_ERRORS_FETCH,
        create: _constants.DATA_PROVIDER_ERRORS_CREATE,
        update: _constants.DATA_PROVIDER_ERRORS_UPDATE,
        remove: _constants.DATA_PROVIDER_ERRORS_REMOVE
    };
    const title = this.hot.getTranslatedPhrase(titleKeys[kind] ?? _constants.DATA_PROVIDER_ERRORS_REQUEST_FAILED);
    const message = (0, _utils.getDataProviderRequestErrorDescription)(err);
    let toastId = '';
    const options = {
        variant: 'error',
        title,
        message
    };
    if (kind === 'fetch') {
        options.duration = 0;
        options.actions = [
            {
                label: this.hot.getTranslatedPhrase(_constants.DATA_PROVIDER_BUTTONS_REFETCH),
                type: 'primary',
                callback: ()=>{
                    if (toastId) {
                        notificationPlugin.hide(toastId);
                    }
                    void _class_private_method_get(this, _fetchDataSilently, fetchDataSilently).call(this);
                }
            }
        ];
    }
    toastId = notificationPlugin.showMessage(options);
}
function commitRowsUpdate(rowPayloads, options = {}) {
    return (0, _crud.commitRowsUpdate)(this.hot, {
        getOnRowsUpdate: ()=>_class_private_method_get(this, _getOnRowsUpdate, getOnRowsUpdate).call(this),
        fetchData: ()=>this.fetchData({
                skipLoading: true
            }),
        logError: _console.error,
        onRequestFailed: (kind, err)=>_class_private_method_get(this, _showDataProviderRequestErrorNotification, showDataProviderRequestErrorNotification).call(this, kind, err)
    }, rowPayloads, options);
}
function queueCrud(operation, payload, userPromiseFn, onSuccess) {
    return (0, _crud.queueCrud)({
        enqueueMutation: (fn)=>_class_private_method_get(this, _enqueueMutation, enqueueMutation).call(this, fn),
        runBeforeRowsMutation: (op, p)=>(0, _crud.runBeforeRowsMutation)(this.hot, op, p),
        runAfterRowsMutation: (op, p)=>(0, _crud.runAfterRowsMutation)(this.hot, op, p),
        runAfterRowsMutationError: (op, err, p)=>(0, _crud.runAfterRowsMutationError)(this.hot, op, err, p),
        logError: _console.error,
        onRequestFailed: (kind, err)=>_class_private_method_get(this, _showDataProviderRequestErrorNotification, showDataProviderRequestErrorNotification).call(this, kind, err)
    }, operation, payload, userPromiseFn, onSuccess);
}
function fetchDataSilently(overrides = {}) {
    return this.fetchData(overrides).catch((err)=>{
        (0, _console.error)('Data fetch failed:', err);
        return null;
    });
}
