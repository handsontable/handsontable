"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CopyPaste () {
        return _copyPaste.CopyPaste;
    },
    get PLUGIN_KEY () {
        return _copyPaste.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _copyPaste.PLUGIN_PRIORITY;
    }
});
const _copyPaste = require("./copyPaste");
