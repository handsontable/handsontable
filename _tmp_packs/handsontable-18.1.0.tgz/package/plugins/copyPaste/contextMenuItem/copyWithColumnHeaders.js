"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, /**
 *
 */ "default", {
    enumerable: true,
    get: function() {
        return copyWithColumnHeadersItem;
    }
});
const _constants = require("../../../i18n/constants");
const _number = require("../../../helpers/number");
function copyWithColumnHeadersItem(copyPastePlugin) {
    return {
        key: 'copy_with_column_headers',
        name () {
            const activeSelectedRange = this.getSelectedRangeActive();
            const nounForm = activeSelectedRange ? (0, _number.clamp)(activeSelectedRange.getWidth() - 1, 0, 1) : 0;
            return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, nounForm);
        },
        callback () {
            copyPastePlugin.copyWithColumnHeaders();
        },
        disabled () {
            if (!this.hasColHeaders()) {
                return true;
            }
            const range = this.getSelectedRangeActive();
            if (!range) {
                return true;
            }
            if (range.isSingleHeader()) {
                return true;
            }
            const selected = this.getSelected();
            // Disable for no selection or for non-contiguous selection.
            if (!selected || selected.length > 1) {
                return true;
            }
            return false;
        },
        hidden: false
    };
}
