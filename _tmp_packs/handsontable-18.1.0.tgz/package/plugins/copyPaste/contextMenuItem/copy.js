"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, /**
 *
 */ "default", {
    enumerable: true,
    get: function() {
        return copyItem;
    }
});
const _constants = require("../../../i18n/constants");
function copyItem(copyPastePlugin) {
    return {
        key: 'copy',
        name () {
            return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_COPY);
        },
        callback () {
            copyPastePlugin.copyCellsOnly();
        },
        disabled () {
            if (this.countRows() === 0 || this.countCols() === 0) {
                return true;
            }
            const range = this.getSelectedRangeActive();
            if (!range) {
                return true;
            }
            if (range.isSingleHeader()) {
                return true;
            }
            const selected = this.getSelected();
            // Disable for no selection or for non-contiguous selection.
            if (!selected || selected.length > 1) {
                return true;
            }
            return false;
        },
        hidden: false
    };
}
