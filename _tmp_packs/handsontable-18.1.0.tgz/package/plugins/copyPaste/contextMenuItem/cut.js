"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, /**
 *
 */ "default", {
    enumerable: true,
    get: function() {
        return cutItem;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
function cutItem(copyPastePlugin) {
    return {
        key: 'cut',
        name () {
            return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_CUT);
        },
        callback () {
            copyPastePlugin.cut();
        },
        disabled () {
            if (this.countRows() === 0 || this.countCols() === 0) {
                return true;
            }
            const range = this.getSelectedRangeActive();
            if (!range) {
                return true;
            }
            if (range.isSingleHeader()) {
                return true;
            }
            const selected = this.getSelected();
            // Disable for no selection or for non-contiquous selection.
            if (!selected || selected.length > 1) {
                return true;
            }
            return false;
        },
        hidden: false
    };
}
