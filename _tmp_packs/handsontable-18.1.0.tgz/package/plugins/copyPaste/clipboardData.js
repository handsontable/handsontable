/**
 * @private
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return ClipboardData;
    }
});
class ClipboardData {
    /**
   * Stores a value in the clipboard data under the given MIME type key.
   */ setData(type, value) {
        this.data[type] = value;
    }
    /**
   * Returns the clipboard data stored under the given MIME type key, or `undefined` if absent.
   */ getData(type) {
        return this.data[type] || void 0;
    }
    /**
   * Initializes the clipboard data store as an empty object.
   */ constructor(){
        this.data = {};
    }
}
