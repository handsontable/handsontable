"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get PLUGIN_KEY () {
        return _undoRedo.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _undoRedo.PLUGIN_PRIORITY;
    },
    get UndoRedo () {
        return _undoRedo.UndoRedo;
    }
});
const _undoRedo = require("./undoRedo");
