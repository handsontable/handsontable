"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BaseAction", {
    enumerable: true,
    get: function() {
        return BaseAction;
    }
});
const _errors = require("../../../helpers/errors");
class BaseAction {
    /**
   * Reverts the action, restoring the previous state. Subclasses must override this method.
   */ undo(..._args) {
        (0, _errors.throwWithCause)('Not implemented');
    }
    /**
   * Reapplies the action after it has been undone. Subclasses must override this method.
   */ redo(..._args) {
        (0, _errors.throwWithCause)('Not implemented');
    }
    /**
   * Initializes the action with the given action type identifier.
   */ constructor(actionType){
        /**
   * @param {string} actionType The action type.
   */ this.actionType = '';
        this.actionType = actionType;
    }
}
