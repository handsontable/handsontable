"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "CellAlignmentAction", {
    enumerable: true,
    get: function() {
        return CellAlignmentAction;
    }
});
const _base = require("./_base");
const _utils = require("../../contextMenu/utils");
const _array = require("../../../helpers/array");
class CellAlignmentAction extends _base.BaseAction {
    /**
   * Registers the `beforeCellAlignment` hook listener that records a new CellAlignmentAction whenever alignment changes.
   */ static startRegisteringEvents(hot, undoRedoPlugin) {
        hot.addHook('beforeCellAlignment', (stateBefore, range, type, alignment)=>{
            undoRedoPlugin.done(()=>new CellAlignmentAction({
                    stateBefore: stateBefore,
                    range,
                    type,
                    alignment: alignment
                }));
        });
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} undoneCallback The callback to be called after the action is undone.
   */ undo(hot, undoneCallback) {
        (0, _array.arrayEach)(this.range, (range)=>{
            range.forAll((row, col)=>{
                // Alignment classes should only collected within cell ranges. We skip header coordinates.
                if (row >= 0 && col >= 0) {
                    hot.setCellMeta(row, col, 'className', this.stateBefore[row][col] || ' htLeft');
                }
                return true;
            });
        });
        hot.addHookOnce('afterViewRender', undoneCallback);
        hot.render();
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} redoneCallback The callback to be called after the action is redone.
   */ redo(hot, redoneCallback) {
        (0, _utils.align)(this.range, this.type, this.alignment, (row, col)=>hot.getCellMetaTransient(row, col), (row, col, key, value)=>hot.setCellMeta(row, col, key, value));
        hot.addHookOnce('afterViewRender', redoneCallback);
        hot.render();
    }
    /**
   * Initializes the cell alignment action with the previous state, cell range, alignment axis, and CSS alignment class.
   */ constructor({ stateBefore, range, type, alignment }){
        super('cell_alignment');
        this.stateBefore = stateBefore;
        this.range = range;
        this.type = type;
        this.alignment = alignment;
    }
}
