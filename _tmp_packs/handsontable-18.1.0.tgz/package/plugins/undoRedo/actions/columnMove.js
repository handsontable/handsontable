"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ColumnMoveAction", {
    enumerable: true,
    get: function() {
        return ColumnMoveAction;
    }
});
const _base = require("./_base");
const _moves = require("../../../helpers/moves");
class ColumnMoveAction extends _base.BaseAction {
    /**
   * Registers the `beforeColumnMove` hook listener that records a new ColumnMoveAction whenever columns are moved.
   */ static startRegisteringEvents(hot, undoRedoPlugin) {
        hot.addHook('beforeColumnMove', (columns, finalIndex)=>{
            if (columns === false) {
                return;
            }
            undoRedoPlugin.done(()=>new ColumnMoveAction({
                    columns: columns,
                    finalIndex: finalIndex
                }));
        });
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} undoneCallback The callback to be called after the action is undone.
   */ undo(hot, undoneCallback) {
        const manualColumnMove = hot.getPlugin('manualColumnMove');
        hot.addHookOnce('afterViewRender', undoneCallback);
        const columnMoves = (0, _moves.getMoves)(this.columns, this.finalColumnIndex, hot.columnIndexMapper.getNumberOfIndexes());
        columnMoves.reverse().forEach(({ from, to })=>{
            if (from < to) {
                to -= 1;
            }
            manualColumnMove.moveColumn(to, from);
        });
        hot.render();
        hot.deselectCell();
        hot.selectColumns(this.columns[0], this.columns[0] + this.columns.length - 1);
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} redoneCallback The callback to be called after the action is redone.
   */ redo(hot, redoneCallback) {
        const manualColumnMove = hot.getPlugin('manualColumnMove');
        hot.addHookOnce('afterViewRender', redoneCallback);
        manualColumnMove.moveColumns(this.columns.slice(), this.finalColumnIndex);
        hot.render();
        hot.deselectCell();
        hot.selectColumns(this.finalColumnIndex, this.finalColumnIndex + this.columns.length - 1);
    }
    /**
   * Initializes the column move action with the array of moved column indexes and their destination index.
   */ constructor({ columns, finalIndex }){
        super('col_move');
        this.columns = columns.slice();
        this.finalColumnIndex = finalIndex;
    }
}
