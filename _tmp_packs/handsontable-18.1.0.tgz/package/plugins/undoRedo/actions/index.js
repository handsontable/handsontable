"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "registerActions", {
    enumerable: true,
    get: function() {
        return registerActions;
    }
});
const _cellAlignment = require("./cellAlignment");
const _columnMove = require("./columnMove");
const _columnSort = require("./columnSort");
const _createColumn = require("./createColumn");
const _createRow = require("./createRow");
const _dataChange = require("./dataChange");
const _filters = require("./filters");
const _mergeCells = require("./mergeCells");
const _moveCells = require("./moveCells");
const _removeColumn = require("./removeColumn");
const _removeRow = require("./removeRow");
const _rowMove = require("./rowMove");
const _unmergeCells = require("./unmergeCells");
function registerActions(hot, undoRedoPlugin) {
    [
        _cellAlignment.CellAlignmentAction,
        _columnMove.ColumnMoveAction,
        _columnSort.ColumnSortAction,
        _createColumn.CreateColumnAction,
        _createRow.CreateRowAction,
        _dataChange.DataChangeAction,
        _filters.FiltersAction,
        _mergeCells.MergeCellsAction,
        _moveCells.MoveCellsAction,
        _removeColumn.RemoveColumnAction,
        _removeRow.RemoveRowAction,
        _rowMove.RowMoveAction,
        _unmergeCells.UnmergeCellsAction
    ].forEach((action)=>action.startRegisteringEvents(hot, undoRedoPlugin));
}
