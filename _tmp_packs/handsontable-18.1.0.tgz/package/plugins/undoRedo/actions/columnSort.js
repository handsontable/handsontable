"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ColumnSortAction", {
    enumerable: true,
    get: function() {
        return ColumnSortAction;
    }
});
const _base = require("./_base");
class ColumnSortAction extends _base.BaseAction {
    /**
   * Registers the `beforeColumnSort` hook listener that records a new ColumnSortAction whenever sorting changes.
   */ static startRegisteringEvents(hot, undoRedoPlugin) {
        hot.addHook('beforeColumnSort', (currentSortState, newSortState, sortPossible)=>{
            if (!sortPossible) {
                return;
            }
            undoRedoPlugin.done(()=>new ColumnSortAction({
                    currentSortState,
                    newSortState
                }));
        });
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} undoneCallback The callback to be called after the action is undone.
   */ undo(hot, undoneCallback) {
        const sortPlugin = hot.getPlugin('columnSorting');
        const multiSortPlugin = hot.getPlugin('multiColumnSorting');
        const enabledSortPlugin = multiSortPlugin.isEnabled() ? multiSortPlugin : sortPlugin;
        if (this.previousSortState.length) {
            enabledSortPlugin.sort(this.previousSortState);
        } else {
            enabledSortPlugin.clearSort();
        }
        undoneCallback();
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} redoneCallback The callback to be called after the action is redone.
   */ redo(hot, redoneCallback) {
        const sortPlugin = hot.getPlugin('columnSorting');
        const multiSortPlugin = hot.getPlugin('multiColumnSorting');
        const enabledSortPlugin = multiSortPlugin.isEnabled() ? multiSortPlugin : sortPlugin;
        enabledSortPlugin.sort(this.nextSortState);
        redoneCallback();
    }
    /**
   * Initializes the column sort action with the previous and next sort state snapshots.
   */ constructor({ currentSortState, newSortState }){
        super('col_sort');
        this.previousSortState = currentSortState;
        this.nextSortState = newSortState;
    }
}
