"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get FIXED_COLUMN_COUNTS () {
        return FIXED_COLUMN_COUNTS;
    },
    get FIXED_ROW_COUNTS () {
        return FIXED_ROW_COUNTS;
    },
    get removeAndKeepFixedCounts () {
        return removeAndKeepFixedCounts;
    }
});
const FIXED_ROW_COUNTS = [
    {
        readKey: 'fixedRowsTop',
        writeKey: 'fixedRowsTop'
    },
    {
        readKey: 'fixedRowsBottom',
        writeKey: 'fixedRowsBottom'
    }
];
const FIXED_COLUMN_COUNTS = [
    {
        readKey: 'fixedColumnsStart',
        writeKey: '_fixedColumnsStart'
    }
];
function removeAndKeepFixedCounts(hot, counts, removeCallback) {
    // Changing by the reference as `updateSettings` doesn't work the best.
    const settings = hot.getSettings();
    const countsBefore = counts.map(({ readKey })=>settings[readKey] ?? 0);
    const restore = ()=>{
        let wasRestored = false;
        counts.forEach(({ readKey, writeKey }, index)=>{
            if ((settings[readKey] ?? 0) < countsBefore[index]) {
                settings[writeKey] = countsBefore[index];
                wasRestored = true;
            }
        });
        return wasRestored;
    };
    const onBeforeRender = ()=>{
        restore();
    };
    // `alter` lowers the counters after the rows or columns are gone, but before it renders the grid.
    hot.addHookOnce('beforeRender', onBeforeRender);
    removeCallback();
    hot.removeHook('beforeRender', onBeforeRender);
    // The hook doesn't run while the rendering is suspended, so the counters are restored here instead.
    if (restore()) {
        hot.render();
    }
}
