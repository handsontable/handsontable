"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DataChangeAction", {
    enumerable: true,
    get: function() {
        return DataChangeAction;
    }
});
const _base = require("./_base");
const _object = require("../../../helpers/object");
class DataChangeAction extends _base.BaseAction {
    /**
   * Registers the `beforeChange` hook listener that captures effective cell value changes and records them as DataChangeActions.
   */ static startRegisteringEvents(hot, undoRedoPlugin) {
        const plugin = undoRedoPlugin;
        // Run after other beforeChange hooks (e.g. user's) so we see nullified entries and only record effective changes.
        hot.addHook('beforeChange', function(changes, source) {
            const changesLen = changes && changes.length;
            if (!changesLen) {
                return;
            }
            // Only record changes that were not nullified by other beforeChange hooks (e.g. user setting changes[i] = null).
            const effectiveChanges = changes.filter((change)=>change !== null && change !== undefined && Array.isArray(change));
            if (effectiveChanges.length === 0) {
                return;
            }
            const hasDifferences = effectiveChanges.find((change)=>{
                const [, , oldValue, newValue] = change;
                return oldValue !== newValue;
            });
            const effectiveLen = effectiveChanges.length;
            const wrappedAction = ()=>{
                const clonedChanges = effectiveChanges.map((change)=>[
                        ...change
                    ]);
                clonedChanges.forEach((change)=>{
                    change[1] = hot.propToCol(change[1]);
                });
                const selected = effectiveLen > 1 ? this.getSelected() : [
                    [
                        clonedChanges[0][0],
                        clonedChanges[0][1]
                    ]
                ];
                return new DataChangeAction({
                    changes: clonedChanges,
                    selected,
                    countCols: hot.countCols(),
                    countRows: hot.countRows()
                });
            };
            plugin.done(wrappedAction, source);
        }, 1000);
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} undoneCallback The callback to be called after the action is undone.
   */ undo(hot, undoneCallback) {
        const data = (0, _object.deepClone)(this.changes);
        for(let i = 0, len = data.length; i < len; i++){
            data[i].splice(3, 1);
        }
        hot.addHookOnce('afterChange', ()=>{
            const rowsToRemove = hot.countRows() - this.countRows;
            if (rowsToRemove > 0) {
                hot.alter('remove_row', undefined, rowsToRemove, 'UndoRedo.undo');
            }
            const columnsToRemove = hot.countCols() - this.countCols;
            if (columnsToRemove > 0 && hot.isColumnModificationAllowed()) {
                hot.alter('remove_col', undefined, columnsToRemove, 'UndoRedo.undo');
            }
            hot.scrollToFocusedCell();
            hot.selectCells(this.selected, false, false);
            undoneCallback();
        });
        hot.setDataAtCell(data, null, null, 'UndoRedo.undo');
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} redoneCallback The callback to be called after the action is redone.
   */ redo(hot, redoneCallback) {
        const data = (0, _object.deepClone)(this.changes);
        for(let i = 0, len = data.length; i < len; i++){
            data[i].splice(2, 1);
        }
        hot.addHookOnce('afterChange', ()=>{
            hot.selectCells(this.selected, false, false);
            redoneCallback();
        });
        hot.setDataAtCell(data, null, null, 'UndoRedo.redo');
    }
    /**
   * Initializes the data change action with the recorded cell changes, selection state, and grid dimensions at the time of the change.
   */ constructor({ changes, selected, countCols, countRows }){
        super('change');
        this.changes = changes;
        this.selected = selected;
        this.countCols = countCols;
        this.countRows = countRows;
    }
}
