"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "CreateColumnAction", {
    enumerable: true,
    get: function() {
        return CreateColumnAction;
    }
});
const _base = require("./_base");
const _fixedCounts = require("./fixedCounts");
class CreateColumnAction extends _base.BaseAction {
    /**
   * Registers the `afterCreateCol` hook listener that records a new CreateColumnAction after columns are inserted.
   */ static startRegisteringEvents(hot, undoRedoPlugin) {
        hot.addHook('afterCreateCol', (index, amount, source)=>{
            undoRedoPlugin.done(()=>new CreateColumnAction({
                    index,
                    amount
                }), source);
        });
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} undoneCallback The callback to be called after the action is undone.
   */ undo(hot, undoneCallback) {
        hot.addHookOnce('afterRemoveCol', undoneCallback);
        (0, _fixedCounts.removeAndKeepFixedCounts)(hot, _fixedCounts.FIXED_COLUMN_COUNTS, ()=>{
            hot.alter('remove_col', this.index, this.amount, 'UndoRedo.undo');
        });
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} redoneCallback The callback to be called after the action is redone.
   */ redo(hot, redoneCallback) {
        hot.addHookOnce('afterCreateCol', redoneCallback);
        hot.alter('insert_col_start', this.index, this.amount, 'UndoRedo.redo');
    }
    /**
   * Initializes the create column action with the visual insertion index and the number of columns created.
   */ constructor({ index, amount }){
        super('insert_col');
        this.index = index;
        this.amount = amount;
    }
}
