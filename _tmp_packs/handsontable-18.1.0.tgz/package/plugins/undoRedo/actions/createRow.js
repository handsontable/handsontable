"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "CreateRowAction", {
    enumerable: true,
    get: function() {
        return CreateRowAction;
    }
});
const _base = require("./_base");
const _fixedCounts = require("./fixedCounts");
class CreateRowAction extends _base.BaseAction {
    /**
   * Registers the `afterCreateRow` hook listener that records a new CreateRowAction after rows are inserted.
   */ static startRegisteringEvents(hot, undoRedoPlugin) {
        hot.addHook('afterCreateRow', (index, amount, source)=>{
            undoRedoPlugin.done(()=>new CreateRowAction({
                    index,
                    amount
                }), source);
        });
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} undoneCallback The callback to be called after the action is undone.
   */ undo(hot, undoneCallback) {
        const rowCount = hot.countRows();
        const minSpareRows = hot.getSettings().minSpareRows;
        if (this.index >= rowCount && this.index - (minSpareRows ?? 0) < rowCount) {
            this.index -= minSpareRows ?? 0; // work around the situation where the needed row was removed due to an 'undo' of a made change
        }
        hot.addHookOnce('afterRemoveRow', undoneCallback);
        (0, _fixedCounts.removeAndKeepFixedCounts)(hot, _fixedCounts.FIXED_ROW_COUNTS, ()=>{
            hot.alter('remove_row', this.index, this.amount, 'UndoRedo.undo');
        });
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} redoneCallback The callback to be called after the action is redone.
   */ redo(hot, redoneCallback) {
        hot.addHookOnce('afterCreateRow', redoneCallback);
        hot.alter('insert_row_above', this.index, this.amount, 'UndoRedo.redo');
    }
    /**
   * Initializes the create row action with the visual insertion index and the number of rows created.
   */ constructor({ index, amount }){
        super('insert_row');
        this.index = index;
        this.amount = amount;
    }
}
