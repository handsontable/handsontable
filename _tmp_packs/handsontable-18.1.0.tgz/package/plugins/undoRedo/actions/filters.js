"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "FiltersAction", {
    enumerable: true,
    get: function() {
        return FiltersAction;
    }
});
const _base = require("./_base");
class FiltersAction extends _base.BaseAction {
    /**
   * Registers the `beforeFilter` hook listener that records a new FiltersAction whenever filter conditions change.
   */ static startRegisteringEvents(hot, undoRedoPlugin) {
        hot.addHook('beforeFilter', (conditionsStack, previousConditionsStack)=>{
            undoRedoPlugin.done(()=>new FiltersAction({
                    conditionsStack,
                    previousConditionsStack
                }));
        });
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} undoneCallback The callback to be called after the action is undone.
   */ undo(hot, undoneCallback) {
        const filters = hot.getPlugin('filters');
        hot.addHookOnce('afterViewRender', undoneCallback);
        filters.importConditions(this.previousConditionsStack);
        filters.filter();
    }
    /**
   * @param {Core} hot The Handsontable instance.
   * @param {function(): void} redoneCallback The callback to be called after the action is redone.
   */ redo(hot, redoneCallback) {
        const filters = hot.getPlugin('filters');
        hot.addHookOnce('afterViewRender', redoneCallback);
        filters.importConditions(this.conditionsStack);
        filters.filter();
    }
    /**
   * Initializes the filters action with the current and previous filter condition stacks.
   */ constructor({ conditionsStack, previousConditionsStack }){
        super('filter');
        this.conditionsStack = conditionsStack;
        this.previousConditionsStack = previousConditionsStack;
    }
}
