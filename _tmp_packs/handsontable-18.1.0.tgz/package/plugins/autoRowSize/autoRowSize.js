"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AutoRowSize () {
        return AutoRowSize;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _feature = require("../../helpers/feature");
const _ghostTable = /*#__PURE__*/ _interop_require_default(require("../../utils/ghostTable"));
const _object = require("../../helpers/object");
const _number = require("../../helpers/number");
const _samplesGenerator = /*#__PURE__*/ _interop_require_default(require("../../utils/samplesGenerator"));
const _string = require("../../helpers/string");
const _renderCell = require("../../renderers/renderCell");
const _element = require("../../helpers/dom/element");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const PLUGIN_KEY = 'autoRowSize';
const PLUGIN_PRIORITY = 40;
const ROW_WIDTHS_MAP_NAME = 'autoRowSize';
const FIRST_COLUMN_NOT_RENDERED_CLASS_NAME = 'htFirstDatasetColumnNotRendered';
const AUTO_ROW_SIZE_CLASS_NAME = 'htAutoRowSize';
var /**
   * An array of row indexes whose height will be recalculated.
   *
   * @type {number[]}
   */ _visualRowsToRefresh = /*#__PURE__*/ new WeakMap(), /**
   * Disposer function for the row heights map observer. Called on disable to clean up.
   *
   * @type {Function|null}
   */ _disposeMapObserver = /*#__PURE__*/ new WeakMap(), /**
   * `true` value indicates that the #onInit() function has been already called.
   *
   * @type {boolean}
   */ _isInitialized = /*#__PURE__*/ new WeakMap(), /**
   * `true` when a full row-height recalculation is already scheduled for the current
   * column-resize gesture. Resizing several selected columns fires `beforeColumnResize` once
   * per column in one synchronous loop — the flag coalesces those calls into a single
   * recalculation that runs after every new width has been applied.
   *
   * @type {boolean}
   */ _columnResizeRecalcScheduled = /*#__PURE__*/ new WeakMap(), /**
   * Calculates specific rows height (overwrite cache values).
   *
   * @param {number[]} visualRows List of visual rows to calculate.
   */ _calculateSpecificRowsHeight = /*#__PURE__*/ new WeakSet(), /**
   * Toggles the "first dataset column not rendered" class name.
   * Used to apply special styling when the first column is visible (used only in the classic (legacy) theme, with the AutoRowSize plugin enabled).
   *
   * @param {boolean} [forceState] Force the class to be added or removed (`true` to add, `false` to remove).
   */ _toggleFirstDatasetColumnRenderedClassName = /*#__PURE__*/ new WeakSet(), /**
   * Toggles the `htFirstDatasetColumnNotRendered` CSS class based on whether the first
   * physical column is currently in the renderable viewport.
   */ _onBeforeViewRender = /*#__PURE__*/ new WeakMap(), /**
   * Recalculates heights for currently visible rows and processes any rows queued by data
   * changes before the next render.
   */ _onBeforeRender = /*#__PURE__*/ new WeakMap(), /**
   * Schedules a single full row-height recalculation per column-resize gesture. The hook fires
   * once per selected column, so the recalculation is deferred until the gesture's synchronous
   * loop (and the render that applies the new widths) has finished — the heights are then
   * measured once, against the final column widths.
   */ _onBeforeColumnResize = /*#__PURE__*/ new WeakMap(), /**
   * Recalculates the row height from content on a double-click and returns it as the new
   * size; returns the user-dragged size otherwise.
   */ _onBeforeRowResize = /*#__PURE__*/ new WeakMap(), /**
   * Triggers a full row height recalculation after new data is loaded, skipping the initial
   * load since `#onInit` already handles it.
   */ _onAfterLoadData = /*#__PURE__*/ new WeakMap(), /**
   * Queues the visual row indexes affected by the incoming changes so their heights are
   * recalculated on the next render.
   */ _onBeforeChange = /*#__PURE__*/ new WeakMap(), /**
   * Triggers the first full row height recalculation after Handsontable has finished initializing.
   */ _onInit = /*#__PURE__*/ new WeakMap(), /**
   * Queues visual row indexes whose formula results changed so their heights are recalculated
   * before the next render. Skips changes belonging to a different sheet.
   */ _onAfterFormulasValuesUpdate = /*#__PURE__*/ new WeakMap();
class AutoRowSize extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns `true` so the plugin updates on every `updateSettings` call, regardless of config object contents.
   */ static get SETTING_KEYS() {
        return true;
    }
    /**
   * Returns the default settings applied when the plugin is enabled without explicit configuration.
   */ static get DEFAULT_SETTINGS() {
        return {
            useHeaders: true,
            samplingRatio: null,
            allowSampleDuplicates: false
        };
    }
    /**
   * Returns the number of rows processed in a single calculation step during asynchronous sizing.
   */ static get CALCULATION_STEP() {
        return 50;
    }
    /**
   * Returns the maximum number of rows whose heights are calculated synchronously before switching to async mode.
   */ static get SYNC_CALCULATION_LIMIT() {
        return 500;
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link AutoRowSize#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        const settings = this.hot.getSettings()[PLUGIN_KEY];
        return settings === true || (0, _object.isObject)(settings);
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        this.samplesGenerator.setAllowDuplicates(this.getSetting('allowSampleDuplicates'));
        const samplingRatio = this.getSetting('samplingRatio');
        if (samplingRatio && !isNaN(samplingRatio)) {
            this.samplesGenerator.setSampleCount(samplingRatio);
        }
        this.addHook('afterLoadData', _class_private_field_get(this, _onAfterLoadData));
        this.addHook('beforeChangeRender', _class_private_field_get(this, _onBeforeChange));
        this.addHook('beforeColumnResize', _class_private_field_get(this, _onBeforeColumnResize));
        this.addHook('afterFormulasValuesUpdate', _class_private_field_get(this, _onAfterFormulasValuesUpdate));
        this.addHook('beforeViewRender', _class_private_field_get(this, _onBeforeViewRender));
        this.addHook('beforeRender', _class_private_field_get(this, _onBeforeRender));
        this.addHook('modifyRowHeight', (height, row)=>this.getRowHeight(row, height));
        this.addHook('init', _class_private_field_get(this, _onInit));
        this.addHook('modifyColumnHeaderHeight', ()=>this.getColumnHeaderHeight());
        _class_private_field_set(this, _disposeMapObserver, this.hot.rowIndexMapper.observeMapChange(this.rowHeightsMap, ()=>{
            this.hot.view?.invalidateRowHeightCache();
        }));
        (0, _element.addClass)(this.hot.rootElement, AUTO_ROW_SIZE_CLASS_NAME);
        super.enablePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        if (_class_private_field_get(this, _disposeMapObserver)) {
            _class_private_field_get(this, _disposeMapObserver).call(this);
            _class_private_field_set(this, _disposeMapObserver, null);
        }
        this.headerHeight = null;
        (0, _element.removeClass)(this.hot.rootElement, AUTO_ROW_SIZE_CLASS_NAME);
        super.disablePlugin();
        // Remove the "first dataset column not rendered" class name when the plugin is disabled.
        _class_private_method_get(this, _toggleFirstDatasetColumnRenderedClassName, toggleFirstDatasetColumnRenderedClassName).call(this, false);
        // Leave the listener active to allow auto-sizing the rows when the plugin is disabled.
        // This is necessary for height recalculation for resize handler doubleclick (ManualRowResize).
        this.addHook('beforeRowResize', _class_private_field_get(this, _onBeforeRowResize));
    }
    /**
   * Calculates heights for visible rows in the viewport only.
   */ calculateVisibleRowsHeight() {
        // Keep last row heights unchanged for situation when all columns was deleted or trimmed
        if (!this.hot.countCols()) {
            return;
        }
        const firstVisibleRow = this.getFirstVisibleRow();
        const lastVisibleRow = this.getLastVisibleRow();
        if (firstVisibleRow === -1 || lastVisibleRow === -1) {
            return;
        }
        const overwriteCache = this.hot.forceFullRender;
        this.calculateRowsHeight({
            from: firstVisibleRow,
            to: lastVisibleRow
        }, undefined, overwriteCache);
    }
    /**
   * Calculate a given rows height.
   *
   * @param {number|object} rowRange Row index or an object with `from` and `to` indexes as a range.
   * @param {number|object} colRange Column index or an object with `from` and `to` indexes as a range.
   * @param {boolean} [overwriteCache=false] If `true` the calculation will be processed regardless of whether the width exists in the cache.
   */ calculateRowsHeight(rowRange = {
        from: 0,
        to: this.hot.countRows() - 1
    }, colRange = {
        from: 0,
        to: this.hot.countCols() - 1
    }, overwriteCache = false) {
        const rowsRange = typeof rowRange === 'number' ? {
            from: rowRange,
            to: rowRange
        } : rowRange;
        const columnsRange = typeof colRange === 'number' ? {
            from: colRange,
            to: colRange
        } : colRange;
        // The cached header height is reused unless the caller explicitly overwrites the cache
        // (full renders triggered by data or settings changes do). Without this guard, every
        // render — including selection-driven ones — would re-sample the header row across all
        // columns and force a ghost-table reflow even when every height is already cached.
        if ((overwriteCache || this.headerHeight === null) && this.hot.getColHeader(0) !== null) {
            const samples = this.samplesGenerator.generateRowSamples(-1, columnsRange);
            this.ghostTable.addColumnHeadersRow(samples.get(-1));
        }
        (0, _number.rangeEach)(rowsRange.from, rowsRange.to, (visualRow)=>{
            let physicalRow = this.hot.toPhysicalRow(visualRow);
            if (physicalRow === null) {
                physicalRow = visualRow;
            }
            // For rows we must calculate row height even when user had set height value manually.
            // We can shrink column but cannot shrink rows!
            if (overwriteCache || this.rowHeightsMap.getValueAtIndex(physicalRow) === null) {
                const samples = this.samplesGenerator.generateRowSamples(visualRow, columnsRange);
                samples.forEach((sample, row)=>this.ghostTable.addRow(row, sample));
            }
        });
        if (this.ghostTable.rows.length) {
            this.hot.batchExecution(()=>{
                this.ghostTable.getHeights((row, height)=>{
                    if (row < 0) {
                        this.headerHeight = height;
                    } else {
                        this.rowHeightsMap.setValueAtIndex(this.hot.toPhysicalRow(row), height);
                    }
                });
            }, true);
            this.measuredRows = rowsRange.to + 1;
            this.ghostTable.clean();
        }
    }
    /**
   * Calculate all rows heights. The calculated row will be cached in the {@link AutoRowSize#heights} property.
   * To retrieve height for specified row use {@link AutoRowSize#getRowHeight} method.
   *
   * @param {object|number} colRange Row index or an object with `from` and `to` properties which define row range.
   * @param {boolean} [overwriteCache] If `true` the calculation will be processed regardless of whether the width exists in the cache.
   */ calculateAllRowsHeight(colRange = {
        from: 0,
        to: this.hot.countCols() - 1
    }, overwriteCache = false) {
        let current = 0;
        const length = this.hot.countRows() - 1;
        let timer = 0;
        this.inProgress = true;
        const loop = ()=>{
            // When hot was destroyed after calculating finished cancel frame
            if (!this.hot) {
                (0, _feature.cancelIdleTask)(timer);
                this.inProgress = false;
                return;
            }
            this.calculateRowsHeight({
                from: current,
                to: Math.min(current + AutoRowSize.CALCULATION_STEP, length)
            }, colRange, overwriteCache);
            current = current + AutoRowSize.CALCULATION_STEP + 1;
            if (current < length) {
                timer = (0, _feature.requestIdleTask)(loop);
            } else {
                (0, _feature.cancelIdleTask)(timer);
                this.inProgress = false;
                // @TODO Should call once per render cycle, currently fired separately in different plugins
                this.hot.view.adjustElementsSize();
            }
        };
        const syncLimit = this.getSyncCalculationLimit();
        // sync
        if (syncLimit >= 0) {
            this.calculateRowsHeight({
                from: 0,
                to: syncLimit
            }, colRange, overwriteCache);
            current = syncLimit + 1;
        }
        // async
        if (current < length) {
            loop();
        } else {
            this.inProgress = false;
            this.hot.view.adjustElementsSize();
        }
    }
    /**
   * Recalculates all rows height (overwrite cache values).
   */ recalculateAllRowsHeight() {
        if (this.hot.view.isVisible()) {
            this.calculateAllRowsHeight({
                from: 0,
                to: this.hot.countCols() - 1
            }, true);
        }
    }
    /**
   * Gets value which tells how many rows should be calculated synchronously (rest of the rows will be calculated
   * asynchronously). The limit is calculated based on `syncLimit` set to autoRowSize option (see {@link Options#autoRowSize}).
   *
   * @returns {number}
   */ getSyncCalculationLimit() {
        const settings = this.hot.getSettings()[PLUGIN_KEY];
        /* eslint-disable no-bitwise */ let limit = AutoRowSize.SYNC_CALCULATION_LIMIT;
        const rowsLimit = this.hot.countRows() - 1;
        if ((0, _object.isObject)(settings)) {
            limit = this.getSetting('syncLimit');
            if ((0, _string.isPercentValue)(limit)) {
                limit = (0, _number.valueAccordingPercent)(rowsLimit, limit);
            } else {
                // Force to integer (NaN — e.g. when syncLimit is undefined — falls back to 0)
                const numericLimit = Number(limit);
                limit = Number.isFinite(numericLimit) ? Math.trunc(numericLimit) : 0;
            }
        }
        return Math.min(limit, rowsLimit);
    }
    /**
   * Get a row's height, as measured in the DOM.
   *
   * The height returned includes 1 px of the row's bottom border.
   *
   * Mind that this method is different from the
   * [`getRowHeight()`](@/api/core.md#getrowheight) method
   * of Handsontable's [Core](@/api/core.md).
   *
   * @param {number} row A visual row index.
   * @param {number} [defaultHeight] If no height is found, `defaultHeight` is returned instead.
   * @returns {number} The height of the specified row, in pixels.
   */ getRowHeight(row, defaultHeight = this.hot.stylesHandler.getDefaultRowHeight(row) ?? 0) {
        if (row < 0) {
            return this.headerHeight ?? defaultHeight;
        }
        const physicalRow = this.hot.toPhysicalRow(row);
        if (this.hot.rowIndexMapper.isHidden(physicalRow)) {
            return defaultHeight;
        }
        const cachedHeight = this.rowHeightsMap.getValueAtIndex(physicalRow);
        let height = defaultHeight;
        if (cachedHeight !== undefined && cachedHeight !== null && cachedHeight > defaultHeight) {
            height = cachedHeight;
            if (row === this.hot.view.getFirstRenderedVisibleRow()) {
                // add 1px border-top-width compensation for the first rendered row
                height += 1;
            }
        }
        return height;
    }
    /**
   * Get the calculated column header height.
   *
   * @returns {number|undefined}
   */ getColumnHeaderHeight() {
        return this.headerHeight;
    }
    /**
   * Get the first visible row.
   *
   * When the {@link MergeCells} plugin is enabled with its default `virtualized: false` setting, a merged
   * cell that crosses the viewport edge extends the rendered row range. In that case this method can
   * return a row index outside the strictly visible viewport. To read the actual visible viewport, use
   * {@link Core#getFirstFullyVisibleRow} or {@link Core#getFirstPartiallyVisibleRow}.
   *
   * @returns {number} Returns row index, -1 if table is not rendered or if there are no rows to base the the calculations on.
   */ getFirstVisibleRow() {
        return this.hot.getFirstRenderedVisibleRow() ?? -1;
    }
    /**
   * Gets the last visible row.
   *
   * When the {@link MergeCells} plugin is enabled with its default `virtualized: false` setting, a merged
   * cell that crosses the viewport edge extends the rendered row range. In that case this method can
   * return a row index outside the strictly visible viewport. To read the actual visible viewport, use
   * {@link Core#getLastFullyVisibleRow} or {@link Core#getLastPartiallyVisibleRow}.
   *
   * @returns {number} Returns row index or -1 if table is not rendered.
   */ getLastVisibleRow() {
        return this.hot.getLastRenderedVisibleRow() ?? -1;
    }
    /**
   * Clears cache of calculated row heights. If you want to clear only selected rows pass an array with their indexes.
   * Otherwise whole cache will be cleared.
   *
   * @param {number[]} [physicalRows] List of physical row indexes to clear.
   */ clearCache(physicalRows) {
        this.headerHeight = null;
        if (Array.isArray(physicalRows)) {
            this.hot.batchExecution(()=>{
                physicalRows.forEach((physicalIndex)=>{
                    this.rowHeightsMap.setValueAtIndex(physicalIndex, null);
                });
            }, true);
        } else {
            this.rowHeightsMap.clear();
        }
    }
    /**
   * Clears cache by range.
   *
   * @param {object|number} range Row index or an object with `from` and `to` properties which define row range.
   */ clearCacheByRange(range) {
        const { from, to } = typeof range === 'number' ? {
            from: range,
            to: range
        } : range;
        this.hot.batchExecution(()=>{
            (0, _number.rangeEach)(Math.min(from, to), Math.max(from, to), (row)=>{
                this.rowHeightsMap.setValueAtIndex(row, null);
            });
        }, true);
    }
    /**
   * Checks if all heights were calculated. If not then return `true` (need recalculate).
   *
   * @returns {boolean}
   */ isNeedRecalculate() {
        return !!this.rowHeightsMap.getValues().slice(0, this.measuredRows).filter((item)=>item === null).length;
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        this.ghostTable.clean();
        super.destroy();
    }
    /**
   * Initializes the plugin, registers the row heights map, and sets up the row resize hook.
   */ constructor(hotInstance){
        super(hotInstance), _class_private_method_init(this, _calculateSpecificRowsHeight), _class_private_method_init(this, _toggleFirstDatasetColumnRenderedClassName), _class_private_field_init(this, _visualRowsToRefresh, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _disposeMapObserver, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _isInitialized, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _columnResizeRecalcScheduled, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeViewRender, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeRender, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeColumnResize, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeRowResize, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterLoadData, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeChange, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onInit, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterFormulasValuesUpdate, {
            writable: true,
            value: void 0
        }), /**
   * Columns header's height cache.
   *
   * @private
   * @type {number}
   */ this.headerHeight = null, /**
   * Instance of {@link GhostTable} for rows and columns size calculations.
   *
   * @private
   * @type {GhostTable}
   */ this.ghostTable = new _ghostTable.default(this.hot), /**
   * Instance of {@link SamplesGenerator} for generating samples necessary for rows height calculations.
   *
   * @private
   * @type {SamplesGenerator}
   */ this.samplesGenerator = new _samplesGenerator.default((row, column)=>{
            const physicalColumn = this.hot.toPhysicalColumn(column);
            if (this.hot.columnIndexMapper.isHidden(physicalColumn)) {
                return false;
            }
            let cellMeta;
            if (row >= 0 && column >= 0) {
                // The transient read resolves the full dynamic meta (hooks + `cells`, so `hidden` from
                // merged cells works) without storing anything - this sampler sweeps every row, and the
                // eager `getCellMeta` would permanently materialize one meta per visited cell.
                cellMeta = this.hot.getCellMetaTransient(row, column);
                if (cellMeta.hidden) {
                    // do not generate samples for cells that are covered by merged cell (null values)
                    return false;
                }
            }
            let cellValue;
            if (row >= 0) {
                cellValue = this.hot.getDataAtCell(row, column);
                if (cellMeta) {
                    // Format through the same precedence as the render path (cell-level `valueFormatter`, then
                    // the renderer's own static), so the measured string matches what the renderer produces.
                    cellValue = (0, _renderCell.formatCellValue)(cellValue, cellMeta, this.hot.getCellRenderer(cellMeta));
                }
            } else if (row === -1) {
                cellValue = this.hot.getColHeader(column);
            }
            return {
                value: cellValue
            };
        }), /**
   * `true` if the size calculation is in progress.
   *
   * @type {boolean}
   */ this.inProgress = false, /**
   * Number of already measured rows (we already know their sizes).
   *
   * @type {number}
   */ this.measuredRows = 0, _class_private_field_set(this, _visualRowsToRefresh, []), _class_private_field_set(this, _disposeMapObserver, null), _class_private_field_set(this, _isInitialized, false), _class_private_field_set(this, _columnResizeRecalcScheduled, false), _class_private_field_set(this, _onBeforeViewRender, ()=>{
            _class_private_method_get(this, _toggleFirstDatasetColumnRenderedClassName, toggleFirstDatasetColumnRenderedClassName).call(this);
        }), _class_private_field_set(this, _onBeforeRender, ()=>{
            this.calculateVisibleRowsHeight();
            if (!this.inProgress) {
                _class_private_method_get(this, _calculateSpecificRowsHeight, calculateSpecificRowsHeight).call(this, _class_private_field_get(this, _visualRowsToRefresh));
                _class_private_field_set(this, _visualRowsToRefresh, []);
            }
        }), _class_private_field_set(this, _onBeforeColumnResize, ()=>{
            if (_class_private_field_get(this, _columnResizeRecalcScheduled)) {
                return;
            }
            _class_private_field_set(this, _columnResizeRecalcScheduled, true);
            this.hot._registerTimeout(()=>{
                _class_private_field_set(this, _columnResizeRecalcScheduled, false);
                this.recalculateAllRowsHeight();
            }, 0);
        }), _class_private_field_set(this, _onBeforeRowResize, (size, row, isDblClick)=>{
            let newSize = size;
            if (isDblClick) {
                this.calculateRowsHeight(row, undefined, true);
                newSize = this.getRowHeight(row);
            }
            return newSize;
        }), _class_private_field_set(this, _onAfterLoadData, (_sourceData, isFirstLoad)=>{
            if (!isFirstLoad) {
                this.recalculateAllRowsHeight();
            }
        }), _class_private_field_set(this, _onBeforeChange, (changes)=>{
            const changedRows = new Set();
            changes.forEach(([row])=>{
                changedRows.add(Number(row));
            });
            changedRows.forEach((rowIndex)=>{
                _class_private_field_get(this, _visualRowsToRefresh).push(rowIndex);
            });
        }), _class_private_field_set(this, _onInit, ()=>{
            this.recalculateAllRowsHeight();
            _class_private_field_set(this, _isInitialized, true);
        }), _class_private_field_set(this, _onAfterFormulasValuesUpdate, (changes)=>{
            if (!_class_private_field_get(this, _isInitialized)) {
                return;
            }
            const formulasPlugin = this.hot.getPlugin('formulas');
            const sheetId = formulasPlugin?.sheetId;
            const changedRows = changes.reduce((acc, change)=>{
                const changeRecord = change;
                if (sheetId !== null && sheetId !== undefined && changeRecord.address?.sheet !== sheetId) {
                    return acc;
                }
                const physicalRow = Number(changeRecord.address?.row);
                if (Number.isInteger(physicalRow)) {
                    const visualRow = this.hot.toVisualRow(physicalRow);
                    if (visualRow !== null && acc.indexOf(visualRow) === -1) {
                        acc.push(visualRow);
                    }
                }
                return acc;
            }, []);
            _class_private_field_get(this, _visualRowsToRefresh).push(...changedRows);
        });
        // The map holds numbers only, so re-writing an unchanged height is a no-op that must not
        // invalidate the row-height position cache.
        this.rowHeightsMap = this.hot.rowIndexMapper.createAndRegisterIndexMap(ROW_WIDTHS_MAP_NAME, 'physicalIndexToValue', null, {
            skipUnchangedWrites: true
        });
        // Leave the listener active to allow auto-sizing the rows when the plugin is disabled.
        // This is necessary for height recalculation for resize handler doubleclick (ManualRowResize).
        this.addHook('beforeRowResize', _class_private_field_get(this, _onBeforeRowResize));
    }
}
function calculateSpecificRowsHeight(visualRows) {
    const columnsRange = {
        from: 0,
        to: this.hot.countCols() - 1
    };
    visualRows.forEach((visualRow)=>{
        // For rows we must calculate row height even when user had set height value manually.
        // We can shrink column but cannot shrink rows!
        const samples = this.samplesGenerator.generateRowSamples(visualRow, columnsRange);
        samples.forEach((sample, row)=>this.ghostTable.addRow(row, sample));
    });
    if (this.ghostTable.rows.length) {
        this.hot.batchExecution(()=>{
            this.ghostTable.getHeights((visualRow, height)=>{
                const physicalRow = this.hot.toPhysicalRow(visualRow);
                this.rowHeightsMap.setValueAtIndex(physicalRow, height);
            });
        }, true);
        this.ghostTable.clean();
    }
}
function toggleFirstDatasetColumnRenderedClassName(forceState) {
    const firstRenderedColumnVisualIndex = this.hot.getFirstRenderedVisibleColumn();
    const firstRenderedColumnPhysicalIndex = this.hot.columnIndexMapper.getPhysicalFromVisualIndex(firstRenderedColumnVisualIndex);
    if (forceState === false || firstRenderedColumnPhysicalIndex === this.hot.columnIndexMapper.getPhysicalFromRenderableIndex(0)) {
        (0, _element.removeClass)(this.hot.rootElement, FIRST_COLUMN_NOT_RENDERED_CLASS_NAME);
    } else {
        (0, _element.addClass)(this.hot.rootElement, FIRST_COLUMN_NOT_RENDERED_CLASS_NAME);
    }
}
