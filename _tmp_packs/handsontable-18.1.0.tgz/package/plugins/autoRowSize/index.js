"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AutoRowSize () {
        return _autoRowSize.AutoRowSize;
    },
    get PLUGIN_KEY () {
        return _autoRowSize.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _autoRowSize.PLUGIN_PRIORITY;
    }
});
const _autoRowSize = require("./autoRowSize");
