"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, /**
 * Returns the ExportFile context menu item descriptor with a submenu
 * containing "To CSV" and "To Excel" sub-items.
 *
 * The parent item is hidden when `exportFile` is not explicitly configured
 * in the Handsontable settings.
 * The "To Excel" sub-item is hidden when no XLSX engine is configured.
 *
 * @param {ExportFile} exportFilePlugin The plugin instance.
 * @returns {object}
 */ "default", {
    enumerable: true,
    get: function() {
        return exportItem;
    }
});
const _console = require("../../../helpers/console");
const _constants = require("../../../i18n/constants");
const _exportFile = require("../exportFile");
const _utils = require("./utils");
function exportItem(exportFilePlugin) {
    return {
        key: 'export_file',
        name () {
            return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_EXPORT);
        },
        hidden () {
            return this.getSettings()[_exportFile.PLUGIN_KEY] === undefined;
        },
        submenu: {
            items: [
                {
                    key: 'export_file:csv',
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV);
                    },
                    callback () {
                        exportFilePlugin.downloadFile('csv', (0, _utils.getExportOptions)(this));
                    },
                    disabled: false
                },
                {
                    key: 'export_file:xlsx',
                    name () {
                        return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX);
                    },
                    callback () {
                        exportFilePlugin.downloadFileAsync('xlsx', (0, _utils.getExportOptions)(this)).catch((err)=>{
                            (0, _console.error)('ExportFile: XLSX export failed.', err);
                        });
                    },
                    hidden () {
                        return !exportFilePlugin.supportsExportFormat('xlsx');
                    }
                }
            ]
        }
    };
}
