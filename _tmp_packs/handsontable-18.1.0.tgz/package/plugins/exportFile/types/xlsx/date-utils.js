"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get getDateNumFmt () {
        return getDateNumFmt;
    },
    get getDateTimeNumFmt () {
        return getDateTimeNumFmt;
    },
    get getTimeNumFmt () {
        return getTimeNumFmt;
    },
    get parseIsoDateTimeStringToSerial () {
        return parseIsoDateTimeStringToSerial;
    },
    get parseIsoStringToSerial () {
        return parseIsoStringToSerial;
    },
    get parseTimeStringToSerial () {
        return parseTimeStringToSerial;
    },
    get toExcelDateSerial () {
        return toExcelDateSerial;
    }
});
const EXCEL_EPOCH_UTC = Date.UTC(1899, 11, 30);
const MS_PER_DAY = 86400000;
function toExcelDateSerial(date) {
    const localDateUtc = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate());
    return Math.round((localDateUtc - EXCEL_EPOCH_UTC) / MS_PER_DAY);
}
function parseIsoStringToSerial(value) {
    if (!value) {
        return null;
    }
    const match = String(value).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) {
        return null;
    }
    const year = parseInt(match[1], 10);
    const month = parseInt(match[2], 10);
    const day = parseInt(match[3], 10);
    const date = new Date(year, month - 1, day);
    if (Number.isNaN(date.getTime())) {
        return null;
    }
    return toExcelDateSerial(date);
}
function parseTimeStringToSerial(value) {
    if (!value) {
        return null;
    }
    const str = String(value).trim();
    const match24 = str.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
    if (match24) {
        const hours = parseInt(match24[1], 10);
        const minutes = parseInt(match24[2], 10);
        const seconds = match24[3] ? parseInt(match24[3], 10) : 0;
        if (hours > 23 || minutes > 59 || seconds > 59) {
            return null;
        }
        return (hours * 3600 + minutes * 60 + seconds) / 86400;
    }
    const match12 = str.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)$/i);
    if (match12) {
        let hours = parseInt(match12[1], 10);
        const minutes = parseInt(match12[2], 10);
        const seconds = match12[3] ? parseInt(match12[3], 10) : 0;
        const period = match12[4].toUpperCase();
        if (hours > 12 || minutes > 59 || seconds > 59) {
            return null;
        }
        if (period === 'AM' && hours === 12) {
            hours = 0;
        } else if (period === 'PM' && hours !== 12) {
            hours += 12;
        }
        return (hours * 3600 + minutes * 60 + seconds) / 86400;
    }
    return null;
}
function getDateNumFmt() {
    return 'mm-dd-yy';
}
function getTimeNumFmt() {
    return 'h:mm:ss';
}
function parseIsoDateTimeStringToSerial(value) {
    if (!value) {
        return null;
    }
    // Mirrors ISO_DATETIME_REGEX in helpers/dateTime.ts, but captures the year for local parsing.
    const match = String(value).match(/^(\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])(?:[T ]([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d)(?:\.\d{1,3})?)?)?$/);
    if (!match) {
        return null;
    }
    const year = parseInt(match[1], 10);
    const month = parseInt(match[2], 10);
    const day = parseInt(match[3], 10);
    const hours = match[4] ? parseInt(match[4], 10) : 0;
    const minutes = match[5] ? parseInt(match[5], 10) : 0;
    const seconds = match[6] ? parseInt(match[6], 10) : 0;
    const date = new Date(year, month - 1, day);
    if (Number.isNaN(date.getTime())) {
        return null;
    }
    const timeSerial = (hours * 3600 + minutes * 60 + seconds) / 86400;
    return toExcelDateSerial(date) + timeSerial;
}
function getDateTimeNumFmt() {
    return 'mm-dd-yy h:mm:ss';
}
