"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _object = require("../../../helpers/object");
const _string = require("../../../helpers/string");
const _errors = require("../../../helpers/errors");
const _utils = require("../utils");
/**
 * @private
 */ class BaseType {
    /**
   * Default options.
   *
   * @returns {object}
   */ static get DEFAULT_OPTIONS() {
        return {
            mimeType: 'text/plain',
            fileExtension: 'txt',
            filename: 'Handsontable [YYYY]-[MM]-[DD]',
            encoding: 'utf-8',
            bom: false,
            colHeaders: false,
            rowHeaders: false,
            exportHiddenColumns: false,
            exportHiddenRows: false,
            range: []
        };
    }
    /**
   * Whether the format produces binary (asynchronous) output.
   *
   * @returns {boolean}
   */ get binary() {
        return false;
    }
    /**
   * Type predicate: narrows this formatter to a binary (asynchronous) one.
   *
   * @returns {boolean}
   */ isBinary() {
        return this.binary;
    }
    /**
   * Type predicate: narrows this formatter to a text (synchronous) one.
   *
   * @returns {boolean}
   */ isText() {
        return !this.binary;
    }
    /**
   * Performs the actual export and returns the data as a string or a Promise.
   */ export() {
        (0, _errors.throwWithCause)('export() must be implemented by subclass');
    }
    /**
   * Merge options provided by users with defaults.
   *
   * @param {object} options An object with options to merge with.
   * @returns {object} Returns new options object.
   */ _mergeOptions(options) {
        const ctorDefaults = this.constructor.DEFAULT_OPTIONS;
        let _options = (0, _object.clone)(ctorDefaults);
        const date = new Date();
        _options = (0, _object.extend)((0, _object.clone)(BaseType.DEFAULT_OPTIONS), _options);
        // Deprecated alias: `columnHeaders` was renamed to `colHeaders`. Promote it here, before the
        // merge with the defaults, so the rest of the code only ever reads `colHeaders`.
        _options = (0, _object.extend)(_options, (0, _utils.normalizeExportOptions)(options));
        _options.filename = (0, _string.substitute)(_options.filename, {
            YYYY: date.getFullYear(),
            MM: `${date.getMonth() + 1}`.padStart(2, '0'),
            DD: `${date.getDate()}`.padStart(2, '0')
        });
        return _options;
    }
    /**
   * Initializes the export type with the data provider and merges the given options with the class defaults.
   */ constructor(dataProvider, options){
        this.dataProvider = dataProvider;
        this.options = this._mergeOptions(options);
        this.dataProvider.setOptions(this.options);
    }
}
const _default = BaseType;
