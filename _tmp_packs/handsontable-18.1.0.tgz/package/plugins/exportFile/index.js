"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ExportFile () {
        return _exportFile.ExportFile;
    },
    get PLUGIN_KEY () {
        return _exportFile.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _exportFile.PLUGIN_PRIORITY;
    }
});
const _exportFile = require("./exportFile");
