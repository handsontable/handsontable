/**
 * The main class name for the dialog-related modal elements.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DIALOG_CLASS_NAME", {
    enumerable: true,
    get: function() {
        return DIALOG_CLASS_NAME;
    }
});
const DIALOG_CLASS_NAME = 'ht-dialog';
