"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "TEMPLATES", {
    enumerable: true,
    get: function() {
        return TEMPLATES;
    }
});
const _base = require("./base");
const _confirm = require("./confirm");
// eslint-disable-next-line no-spaced-func, func-call-spacing
const TEMPLATES = new Map([
    [
        'base',
        _base.baseTemplate
    ],
    [
        'confirm',
        _confirm.confirmTemplate
    ]
]);
