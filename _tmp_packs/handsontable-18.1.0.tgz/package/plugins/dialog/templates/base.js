"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "baseTemplate", {
    enumerable: true,
    get: function() {
        return baseTemplate;
    }
});
const _constants = require("../constants");
const _errors = require("../../../helpers/errors");
const _templateLiteralTag = require("../../../helpers/templateLiteralTag");
function baseTemplate() {
    /**
   * Returns the HTML string for the template.
   *
   * @returns {string}
   */ function template() {
        return `
      <div data-ref="contentElement" class="${_constants.DIALOG_CLASS_NAME}__content"></div>
    `;
    }
    let fragment = null;
    const refs = {};
    /**
   * Compiles the template.
   *
   * @returns {object} The compiled template.
   */ function compile() {
        const elements = (0, _templateLiteralTag.html)`${template()}`;
        Object.assign(refs, elements.refs);
        fragment = elements.fragment;
        return elements;
    }
    /**
   * Gets the focusable elements of the template.
   *
   * @returns {HTMLElement[]} The focusable elements.
   */ function focusableElements() {
        if (fragment === null) {
            (0, _errors.throwWithCause)('Compile the template first.');
        }
        return [];
    }
    return {
        TEMPLATE_NAME: 'base',
        dialogA11YOptions () {
            return {
                role: 'dialog'
            };
        },
        compile,
        focusableElements
    };
}
