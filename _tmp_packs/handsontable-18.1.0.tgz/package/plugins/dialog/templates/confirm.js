"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "confirmTemplate", {
    enumerable: true,
    get: function() {
        return confirmTemplate;
    }
});
const _constants = require("../constants");
const _errors = require("../../../helpers/errors");
const _string = require("../../../helpers/string");
const _templateLiteralTag = require("../../../helpers/templateLiteralTag");
const _uiButton = require("../../../helpers/uiButton");
function confirmTemplate({ id = '', title = '', description = '', buttons = [] }) {
    /**
   * Returns the HTML string for the template.
   *
   * @returns {string}
   */ function template() {
        return `
      <div tabindex="-1" data-ref="contentElement" class="${_constants.DIALOG_CLASS_NAME}__content-wrapper-inner">
        <div class="${_constants.DIALOG_CLASS_NAME}__content">
          <h2
            id="${id}-dialog-confirm-title"
            class="${_constants.DIALOG_CLASS_NAME}__title">${(0, _string.stripTags)(title)}</h2>
          <p
            id="${id}-dialog-confirm-description"
            class="${_constants.DIALOG_CLASS_NAME}__description">${(0, _string.stripTags)(description)}</p>
        </div>
        ${buttons.length > 0 ? `
          <div data-ref="buttonsContainer" class="${_constants.DIALOG_CLASS_NAME}__buttons">
            ${buttons.map((button)=>`
              <button class="ht-button ht-button--${(0, _uiButton.resolveButtonType)(button.type)}">${(0, _string.stripTags)(button.text)}</button>
            `).join('')}
          </div>
        ` : ''}
      </div>
    `;
    }
    let fragment = null;
    const refs = {};
    /**
   * Compiles the template.
   *
   * @returns {object} The compiled template.
   */ function compile() {
        const elements = (0, _templateLiteralTag.html)`${template()}`;
        Object.assign(refs, elements.refs);
        fragment = elements.fragment;
        return elements;
    }
    /**
   * Gets the focusable elements of the template.
   *
   * @returns {HTMLElement[]} The focusable elements.
   */ function focusableElements() {
        if (fragment === null) {
            (0, _errors.throwWithCause)('Compile the template first.');
        }
        const { contentElement, buttonsContainer } = refs;
        const elements = [];
        if (buttonsContainer) {
            elements.push(...Array.from(buttonsContainer.children));
        } else {
            elements.push(contentElement);
        }
        return elements;
    }
    return {
        TEMPLATE_NAME: 'confirm',
        dialogA11YOptions () {
            return {
                role: 'alertdialog',
                ariaLabelledby: `${id}-dialog-confirm-title`,
                ariaDescribedby: description ? `${id}-dialog-confirm-description` : undefined
            };
        },
        compile,
        focusableElements
    };
}
