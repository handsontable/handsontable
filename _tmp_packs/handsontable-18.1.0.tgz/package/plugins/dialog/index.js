"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Dialog () {
        return _dialog.Dialog;
    },
    get PLUGIN_KEY () {
        return _dialog.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _dialog.PLUGIN_PRIORITY;
    }
});
const _dialog = require("./dialog");
