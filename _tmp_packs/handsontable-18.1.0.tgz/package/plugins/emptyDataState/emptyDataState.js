"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EmptyDataState () {
        return EmptyDataState;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _ui = require("./ui");
const _object = require("../../helpers/object");
const _uiButton = require("../../helpers/uiButton");
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../i18n/constants"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
/**
 * Local type-guard narrowing `unknown` to `Record<string, unknown>`.
 * The public `isObject` is intentionally non-narrowing, so we wrap it here.
 *
 * @param {unknown} v The value to check.
 * @returns {boolean}
 */ function isPlainRecord(v) {
    return (0, _object.isObject)(v);
}
const PLUGIN_KEY = 'emptyDataState';
const PLUGIN_PRIORITY = 370;
const SOURCE = Object.freeze({
    UNKNOWN: 'unknown',
    FILTERS: 'filters',
    LOADING: 'loading'
});
const SHORTCUTS_CONTEXT_NAME = `plugin:${PLUGIN_KEY}`;
var /**
   * Flag indicating if emptyDataState is currently visible.
   *
   * @type {boolean}
   */ _isVisible = /*#__PURE__*/ new WeakMap(), /**
   * UI instance of the emptyDataState plugin.
   *
   * @type {EmptyDataStateUI}
   */ _ui1 = /*#__PURE__*/ new WeakMap(), /**
   * Flag indicating if there are filter conditions.
   *
   * @type {boolean}
   */ _hasFilterConditions = /*#__PURE__*/ new WeakMap(), /**
   * Keeps the selection state that will be restored after the overlay is closed.
   *
   * @type {SelectionState | null}
   */ _selectionState = /*#__PURE__*/ new WeakMap(), /**
   * Whether the DataProvider-driven loading branch of the overlay is active.
   *
   * @type {boolean}
   */ _loadingActive = /*#__PURE__*/ new WeakMap(), /**
   * Registers the DOM listeners.
   */ _registerEvents = /*#__PURE__*/ new WeakSet(), /**
   * Sets the loading active flag and toggles the emptyDataState.
   */ _setLoadingActive = /*#__PURE__*/ new WeakSet(), /**
   * Clears the loading active flag and hides the emptyDataState.
   */ _clearLoadingActive = /*#__PURE__*/ new WeakSet(), /**
   * Registers the focus scope for the emptyDataState plugin.
   */ _registerFocusScope = /*#__PURE__*/ new WeakSet(), /**
   * Unregisters the focus scope for the emptyDataState plugin.
   */ _unregisterFocusScope = /*#__PURE__*/ new WeakSet(), /**
   * Get the message by the source for the emptyDataState.
   *
   * @param {string} source - The source.
   * @returns {object} The message.
   */ _getMessage = /*#__PURE__*/ new WeakSet(), /**
   * Toggle visibility and content of the emptyDataState.
   *
   * Shows emptyDataState when table has no data or when all data is hidden by filters.
   * When DataProvider loading is active, the overlay can show over non-empty data.
   */ _toggleEmptyDataState = /*#__PURE__*/ new WeakSet(), /**
   * Shows the emptyDataState overlay.
   */ _show = /*#__PURE__*/ new WeakSet(), /**
   * Updates the content of the emptyDataState overlay.
   */ _update = /*#__PURE__*/ new WeakSet(), /**
   * Hides the emptyDataState overlay.
   */ _hide = /*#__PURE__*/ new WeakSet(), /**
   * Handles the mouse wheel event.
   *
   * @param {WheelEvent} event - The wheel event.
   */ _onMouseWheel = /*#__PURE__*/ new WeakSet(), /**
   * Called after the initialization of the table is completed.
   * It toggles the emptyDataState.
   */ _onAfterInit = /*#__PURE__*/ new WeakMap(), /**
   * Called after the rendering of the table is completed.
   * It updates the height and class names of the emptyDataState element.
   */ _onAfterRender = /*#__PURE__*/ new WeakMap(), /**
   * Called before the filtering of the table is completed.
   * It updates the flag indicating if there are filter conditions.
   *
   * @param {Array} conditions - The filter conditions.
   */ _onBeforeFilter = /*#__PURE__*/ new WeakMap();
class EmptyDataState extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns the default settings applied when the plugin is enabled without explicit configuration.
   */ static get DEFAULT_SETTINGS() {
        return {
            message: undefined
        };
    }
    /**
   * Returns validator functions for each plugin setting to verify their values are valid before applying them.
   */ static get SETTINGS_VALIDATORS() {
        return {
            message: (value)=>{
                if (typeof value === 'string' || typeof value === 'function' || value === undefined) {
                    return true;
                }
                if (!isPlainRecord(value)) {
                    return false;
                }
                return (typeof value.title === 'undefined' || typeof value.title === 'string') && (typeof value.description === 'undefined' || typeof value.description === 'string') && (typeof value.buttons === 'undefined' || Array.isArray(value.buttons) && value.buttons.every((item)=>typeof item === 'object' && typeof item.text === 'string' && (0, _uiButton.isButtonType)(item.type) && typeof item.callback === 'function'));
            }
        };
    }
    /**
   * Check if the plugin is enabled in the handsontable settings.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[PLUGIN_KEY];
    }
    /**
   * Enable plugin for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        if (!_class_private_field_get(this, _ui1)) {
            _class_private_field_set(this, _ui1, new _ui.EmptyDataStateUI({
                gridContainer: this.hot.rootGridElement,
                rootDocument: this.hot.rootDocument
            }));
            _class_private_method_get(this, _registerFocusScope, registerFocusScope).call(this);
            _class_private_method_get(this, _registerEvents, registerEvents).call(this);
        }
        this.addHook('afterInit', _class_private_field_get(this, _onAfterInit));
        this.addHook('afterRender', _class_private_field_get(this, _onAfterRender));
        this.addHook('afterRowSequenceCacheUpdate', ()=>{
            _class_private_method_get(this, _toggleEmptyDataState, toggleEmptyDataState).call(this);
        });
        this.addHook('afterColumnSequenceCacheUpdate', ()=>{
            _class_private_method_get(this, _toggleEmptyDataState, toggleEmptyDataState).call(this);
        });
        this.addHook('beforeFilter', _class_private_field_get(this, _onBeforeFilter));
        this.addHook('beforeDataProviderFetch', (queryParameters)=>{
            if (!queryParameters.skipLoading) {
                _class_private_method_get(this, _setLoadingActive, setLoadingActive).call(this);
            }
        });
        this.addHook('afterDataProviderFetch', ()=>_class_private_method_get(this, _clearLoadingActive, clearLoadingActive).call(this));
        this.addHook('afterDataProviderFetchError', ()=>_class_private_method_get(this, _clearLoadingActive, clearLoadingActive).call(this));
        super.enablePlugin();
        _class_private_method_get(this, _toggleEmptyDataState, toggleEmptyDataState).call(this);
    }
    /**
   * Update plugin state after Handsontable settings update.
   */ updatePlugin() {
        this.disablePlugin();
        this.enablePlugin();
        _class_private_method_get(this, _update, update).call(this);
        if (this.isVisible()) {
            _class_private_field_get(this, _ui1)?.show();
        }
        super.updatePlugin();
    }
    /**
   * Disable plugin for this Handsontable instance.
   */ disablePlugin() {
        _class_private_field_set(this, _loadingActive, false);
        _class_private_method_get(this, _unregisterFocusScope, unregisterFocusScope).call(this);
        _class_private_field_get(this, _ui1)?.destroy();
        _class_private_field_set(this, _ui1, null);
        super.disablePlugin();
    }
    /**
   * Check if the plugin is currently visible.
   *
   * @returns {boolean}
   */ isVisible() {
        return _class_private_field_get(this, _isVisible);
    }
    /**
   * Destroy plugin instance.
   */ destroy() {
        _class_private_field_set(this, _loadingActive, false);
        _class_private_field_set(this, _isVisible, false);
        _class_private_field_get(this, _ui1)?.destroy();
        _class_private_field_set(this, _ui1, null);
        _class_private_field_set(this, _hasFilterConditions, false);
        _class_private_field_set(this, _selectionState, null);
        super.destroy();
    }
    constructor(...args){
        super(...args), _class_private_method_init(this, _registerEvents), _class_private_method_init(this, _setLoadingActive), _class_private_method_init(this, _clearLoadingActive), _class_private_method_init(this, _registerFocusScope), _class_private_method_init(this, _unregisterFocusScope), _class_private_method_init(this, _getMessage), _class_private_method_init(this, _toggleEmptyDataState), _class_private_method_init(this, _show), _class_private_method_init(this, _update), _class_private_method_init(this, _hide), _class_private_method_init(this, _onMouseWheel), _class_private_field_init(this, _isVisible, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _ui1, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _hasFilterConditions, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _selectionState, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _loadingActive, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterInit, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterRender, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeFilter, {
            writable: true,
            value: void 0
        }), _class_private_field_set(this, _isVisible, false), _class_private_field_set(this, _ui1, null), _class_private_field_set(this, _hasFilterConditions, false), _class_private_field_set(this, _selectionState, null), _class_private_field_set(this, _loadingActive, false), _class_private_field_set(this, _onAfterInit, ()=>{
            _class_private_method_get(this, _toggleEmptyDataState, toggleEmptyDataState).call(this);
            this.hot.render();
        }), _class_private_field_set(this, _onAfterRender, ()=>{
            if (_class_private_field_get(this, _ui1)?.getElement() && this.isVisible() && this.hot.view) {
                _class_private_field_get(this, _ui1).updateSize(this.hot.view, _class_private_field_get(this, _loadingActive));
                _class_private_field_get(this, _ui1).updateClassNames(this.hot.view);
            }
        }), _class_private_field_set(this, _onBeforeFilter, (conditions)=>{
            _class_private_field_set(this, _hasFilterConditions, conditions?.length > 0);
            if (this.isVisible()) {
                _class_private_method_get(this, _update, update).call(this);
            }
        });
    }
}
function registerEvents() {
    this.eventManager.addEventListener(_class_private_field_get(this, _ui1).getElement(), 'wheel', (event)=>{
        _class_private_method_get(this, _onMouseWheel, onMouseWheel).call(this, event);
    });
}
function setLoadingActive() {
    if (_class_private_field_get(this, _loadingActive)) {
        return;
    }
    _class_private_field_set(this, _loadingActive, true);
    _class_private_method_get(this, _toggleEmptyDataState, toggleEmptyDataState).call(this);
}
function clearLoadingActive() {
    if (!_class_private_field_get(this, _loadingActive)) {
        return;
    }
    _class_private_field_set(this, _loadingActive, false);
    _class_private_method_get(this, _hide, hide).call(this);
    _class_private_method_get(this, _toggleEmptyDataState, toggleEmptyDataState).call(this);
    this.hot.render();
}
function registerFocusScope() {
    this.hot.getFocusScopeManager().registerScope(PLUGIN_KEY, _class_private_field_get(this, _ui1).getElement(), {
        shortcutsContextName: SHORTCUTS_CONTEXT_NAME,
        runOnlyIf: ()=>this.isVisible(),
        onActivate: (focusSource)=>{
            const focusableElements = _class_private_field_get(this, _ui1)?.getFocusableElements() ?? [];
            if (focusableElements.length > 0) {
                if (focusSource === 'tab_from_above') {
                    focusableElements[0]?.focus();
                } else if (focusSource === 'tab_from_below') {
                    focusableElements[focusableElements.length - 1]?.focus();
                }
            }
        }
    });
}
function unregisterFocusScope() {
    this.hot.getFocusScopeManager().unregisterScope(PLUGIN_KEY);
}
function getMessage(source) {
    const messageSetting = this.getSetting('message');
    let message;
    if (typeof messageSetting === 'function') {
        message = messageSetting(source);
    } else {
        message = messageSetting;
    }
    // If the message is a string, set the title
    if (typeof message === 'string') {
        message = {
            title: message
        };
    }
    // If the message is not set, set the default message object
    if (!message?.title && !message?.description && !message?.buttons) {
        const result = {};
        if (source === SOURCE.FILTERS) {
            result.title = this.hot.getTranslatedPhrase(_constants.EMPTY_DATA_STATE_TITLE_FILTERS);
            result.description = this.hot.getTranslatedPhrase(_constants.EMPTY_DATA_STATE_DESCRIPTION_FILTERS);
            result.buttons = [
                {
                    text: this.hot.getTranslatedPhrase(_constants.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET),
                    type: 'secondary',
                    callback: ()=>{
                        const filtersPlugin = this.hot.getPlugin('filters');
                        if (filtersPlugin) {
                            filtersPlugin.clearConditions();
                            filtersPlugin.filter();
                        }
                    }
                }
            ];
        } else if (source === SOURCE.LOADING) {
            result.title = this.hot.getTranslatedPhrase(_constants.EMPTY_DATA_STATE_TITLE_LOADING);
            result.description = this.hot.getTranslatedPhrase(_constants.EMPTY_DATA_STATE_DESCRIPTION_LOADING);
        } else {
            result.title = this.hot.getTranslatedPhrase(_constants.EMPTY_DATA_STATE_TITLE);
            result.description = this.hot.getTranslatedPhrase(_constants.EMPTY_DATA_STATE_DESCRIPTION);
        }
        return result;
    }
    // At this point message is a Record<string, unknown> (string was already converted above).
    // The union type is narrowed to Record<string, unknown> by the checks above.
    return message;
}
function toggleEmptyDataState() {
    if (!this.hot.view) {
        return;
    }
    if (_class_private_field_get(this, _loadingActive)) {
        if (_class_private_field_get(this, _isVisible)) {
            _class_private_method_get(this, _update, update).call(this);
        } else {
            _class_private_method_get(this, _show, show).call(this);
        }
        return;
    }
    if (this.hot.view.countRenderableColumns() === 0 || this.hot.view.countRenderableRows() === 0) {
        _class_private_method_get(this, _show, show).call(this);
    } else {
        _class_private_method_get(this, _hide, hide).call(this);
    }
}
function show() {
    if (_class_private_field_get(this, _isVisible)) {
        return;
    }
    this.hot.runHooks('beforeEmptyDataStateShow');
    _class_private_method_get(this, _update, update).call(this);
    _class_private_field_get(this, _ui1)?.show();
    _class_private_field_set(this, _isVisible, true);
    _class_private_field_set(this, _selectionState, this.hot.selection.exportSelection());
    this.hot.getFocusScopeManager().activateScope(PLUGIN_KEY);
    this.hot.runHooks('afterEmptyDataStateShow');
}
function update() {
    if (_class_private_field_get(this, _loadingActive)) {
        _class_private_field_get(this, _ui1)?.updateContent(_class_private_method_get(this, _getMessage, getMessage).call(this, SOURCE.LOADING), true);
    } else if (_class_private_field_get(this, _hasFilterConditions)) {
        _class_private_field_get(this, _ui1)?.updateContent(_class_private_method_get(this, _getMessage, getMessage).call(this, SOURCE.FILTERS), false);
    } else {
        _class_private_field_get(this, _ui1)?.updateContent(_class_private_method_get(this, _getMessage, getMessage).call(this, SOURCE.UNKNOWN), false);
    }
}
function hide() {
    if (!_class_private_field_get(this, _isVisible)) {
        return;
    }
    this.hot.runHooks('beforeEmptyDataStateHide');
    _class_private_field_get(this, _ui1)?.hide();
    _class_private_field_set(this, _isVisible, false);
    this.hot.getFocusScopeManager().deactivateScope(PLUGIN_KEY);
    if (_class_private_field_get(this, _selectionState) && _class_private_field_get(this, _selectionState).ranges.length > 0) {
        this.hot.selection.importSelection({
            ..._class_private_field_get(this, _selectionState),
            activeRange: _class_private_field_get(this, _selectionState).activeRange
        });
        this.hot.view.render();
        _class_private_field_set(this, _selectionState, null);
    } else {
        this.hot.selectCell(0, 0, undefined, undefined, false);
    }
    this.hot.runHooks('afterEmptyDataStateHide');
}
function onMouseWheel(event) {
    // wheelDeltaX is a non-standard property present in some browsers (e.g. Safari)
    const extendedEvent = event;
    const wheelDeltaX = extendedEvent.wheelDeltaX ?? 0;
    const deltaX = Number.isNaN(event.deltaX) ? -1 * wheelDeltaX : event.deltaX;
    if (deltaX !== 0 && this.hot.view.hasHorizontalScroll() && !this.hot.view.isHorizontallyScrollableByWindow()) {
        this.hot.view.setTableScrollPosition({
            left: this.hot.view.getTableScrollPosition().left + deltaX
        });
        event.preventDefault();
    }
}
