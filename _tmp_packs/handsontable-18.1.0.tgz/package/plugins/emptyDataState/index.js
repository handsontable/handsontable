"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EmptyDataState () {
        return _emptyDataState.EmptyDataState;
    },
    get PLUGIN_KEY () {
        return _emptyDataState.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _emptyDataState.PLUGIN_PRIORITY;
    }
});
const _emptyDataState = require("./emptyDataState");
