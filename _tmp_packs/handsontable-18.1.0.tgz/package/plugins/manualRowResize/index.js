"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ManualRowResize () {
        return _manualRowResize.ManualRowResize;
    },
    get PLUGIN_KEY () {
        return _manualRowResize.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _manualRowResize.PLUGIN_PRIORITY;
    }
});
const _manualRowResize = require("./manualRowResize");
