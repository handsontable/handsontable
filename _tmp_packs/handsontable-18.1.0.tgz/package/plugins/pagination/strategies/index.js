"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createPaginatorStrategy", {
    enumerable: true,
    get: function() {
        return createPaginatorStrategy;
    }
});
const _fixedPageSize = require("./fixedPageSize");
const _errors = require("../../../helpers/errors");
const _autoPageSize = require("./autoPageSize");
const strategies = new Map([
    [
        'fixed',
        _fixedPageSize.FixedPageSizeStrategy
    ],
    [
        'auto',
        _autoPageSize.AutoPageSizeStrategy
    ]
]);
function createPaginatorStrategy(strategyType) {
    if (!strategies.has(strategyType)) {
        (0, _errors.throwWithCause)(`Unknown pagination strategy type: ${strategyType}`);
    }
    const Strategy = strategies.get(strategyType);
    return new Strategy();
}
