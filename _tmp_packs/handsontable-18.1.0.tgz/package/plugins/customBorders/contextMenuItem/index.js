"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get bottom () {
        return _bottom.default;
    },
    get left () {
        return _left.default;
    },
    get noBorders () {
        return _noBorders.default;
    },
    get right () {
        return _right.default;
    },
    get top () {
        return _top.default;
    }
});
const _bottom = /*#__PURE__*/ _interop_require_default(require("./bottom"));
const _left = /*#__PURE__*/ _interop_require_default(require("./left"));
const _noBorders = /*#__PURE__*/ _interop_require_default(require("./noBorders"));
const _right = /*#__PURE__*/ _interop_require_default(require("./right"));
const _top = /*#__PURE__*/ _interop_require_default(require("./top"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
