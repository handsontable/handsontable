"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, /**
 * @param {CustomBorders} customBordersPlugin The plugin instance.
 * @returns {object}
 */ "default", {
    enumerable: true,
    get: function() {
        return bottom;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
const _utils = require("../utils");
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
function bottom(customBordersPlugin) {
    return {
        key: 'borders:bottom',
        name () {
            let label = this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_BORDERS_BOTTOM);
            const hasBorder = (0, _utils.checkSelectionBorders)(this, 'bottom');
            if (hasBorder) {
                label = (0, _utils.markSelected)(label);
            }
            return label;
        },
        callback (key, selected) {
            const hasBorder = (0, _utils.checkSelectionBorders)(this, 'bottom');
            customBordersPlugin.prepareBorder(selected, 'bottom', hasBorder);
        }
    };
}
