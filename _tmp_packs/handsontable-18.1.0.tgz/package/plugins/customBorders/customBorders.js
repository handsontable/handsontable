"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CustomBorders () {
        return CustomBorders;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _errors = require("../../helpers/errors");
const _object = require("../../helpers/object");
const _console = require("../../helpers/console");
const _number = require("../../helpers/number");
const _array = require("../../helpers/array");
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../i18n/constants"));
const _contextMenuItem = require("./contextMenuItem");
const _utils = require("./utils");
const _selection = require("../../selection");
const _mixed = require("../../helpers/mixed");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const PLUGIN_KEY = 'customBorders';
const PLUGIN_PRIORITY = 90;
/**
 * Type guard returning true when the given value is a non-null object.
 *
 * @param {unknown} value The value to test.
 * @returns {boolean}
 */ function isRecord(value) {
    return typeof value === 'object' && value !== null;
}
/**
 * Type guard returning true when the value is a BorderObject (has `id`, `row`, `col` string/number fields).
 *
 * @param {unknown} value The value to test.
 * @returns {boolean}
 */ function isBorderObject(value) {
    return isRecord(value) && typeof value.id === 'string' && typeof value.row === 'number' && typeof value.col === 'number';
}
/**
 * Type guard for cell coordinate objects with `row` and `col` number properties.
 *
 * @param {unknown} value The value to test.
 * @returns {boolean}
 */ function isCellCoord(value) {
    return isRecord(value) && typeof value.row === 'number' && typeof value.col === 'number';
}
const SUPPORTED_STYLES = [
    'dashed',
    'dotted',
    'solid'
];
/**
 * Default number of border configuration entries applied per background batch when
 * `customBordersProgressive` is enabled. Sized so a batch stays within a frame budget.
 */ const DEFAULT_PROGRESSIVE_CHUNK_SIZE = 5000;
var /**
   * Positions of the saved borders in the `savedBorders` array, keyed by the border id.
   * Lets bulk border operations locate an existing border in O(1) instead of scanning the array.
   */ _savedBordersIndex = /*#__PURE__*/ new WeakMap(), /**
   * Cache of the plugin-created custom selections keyed by the border id. Under viewport
   * virtualization this holds only the selections currently in the rendered range.
   */ _customSelectionsCache = /*#__PURE__*/ new WeakMap(), /**
   * Visual-row index of the saved borders: maps a visual row to the borders on that row. Lets the
   * viewport sync collect only the borders inside the rendered range in O(viewport) instead of
   * scanning every saved border each render. Rebuilt lazily from `savedBorders` when marked stale.
   */ _bordersByRow = /*#__PURE__*/ new WeakMap(), /**
   * When `true`, `#bordersByRow` is stale and rebuilt on the next viewport sync. Set whenever the
   * `savedBorders` model changes; keeps the per-frame sync cost bounded by the viewport, not the
   * total border count.
   */ _bordersByRowDirty = /*#__PURE__*/ new WeakMap(), /**
   * During a `createCustomBorders` pass, holds the `row,col` keys already written in this pass, so a
   * cell touched for the first time can skip the existing-meta merge read (there is nothing to merge
   * on a fresh cell - the pass starts after the previous borders' meta is cleared). Only cells hit by
   * an overlapping range are re-read. Outside a config pass this is `null`, so every other code path
   * (e.g. `setBorders`) keeps reading existing meta and merges as before. Cuts a full O(N)
   * `getCellMeta` pass out of applying a large, non-overlapping `customBorders` config.
   *
   * A progressive load keeps the Set alive across its batches (see {@link #inConfigPass} for why
   * that does not leak the skip into the gaps between them).
   */ _configPassTouched = /*#__PURE__*/ new WeakMap(), /**
   * `true` only while `createCustomBorders` is running. A progressive load must keep
   * {@link #configPassTouched} alive across all of its batches, so that ranges overlapping across a
   * batch boundary still merge - but the Set alone cannot gate the first-touch skip, because the
   * batches are separated by timeouts during which application code can call the public API. Without
   * this flag a `setBorders` call landing in such a gap would treat the cell as a first touch, skip
   * the existing-meta read, and silently drop the sides already on that cell.
   */ _inConfigPass = /*#__PURE__*/ new WeakMap(), /**
   * Guards the plugin's own `borders` cell-meta writes so the `afterSetCellMeta` /
   * `afterRemoveCellMeta` listeners react only to external writes (UndoRedo restoring meta, user
   * code calling `setCellMeta` directly). Without it every internal write would re-enter the model
   * upsert it originated from.
   */ _isInternalMetaWrite = /*#__PURE__*/ new WeakMap(), /**
   * Whether a render following external `borders` cell-meta writes is already scheduled. External
   * writes arrive one cell at a time (UndoRedo restores the meta of an undone row/column removal
   * cell by cell), so the render is coalesced into a single pass for the whole synchronous batch
   * instead of one full render per cell.
   */ _isMetaSyncRenderScheduled = /*#__PURE__*/ new WeakMap(), /**
   * Pending border configuration entries for a progressive (background-batched) application, or
   * `null` when no progressive load is in flight. Set when `customBordersProgressive` is enabled.
   */ _progressiveQueue = /*#__PURE__*/ new WeakMap(), /**
   * Index of the next entry in `#progressiveQueue` to apply.
   */ _progressiveIndex = /*#__PURE__*/ new WeakMap(), /**
   * Number of entries applied per progressive batch.
   */ _progressiveChunkSize = /*#__PURE__*/ new WeakMap(), /**
   * Monotonic generation token for the active progressive load. Bumped on start, finish, flush, and
   * cancel; a scheduled batch aborts if its captured token no longer matches, so stale timers become
   * no-ops without needing to track and clear individual timeout handles.
   */ _progressiveToken = /*#__PURE__*/ new WeakMap(), /**
   * Physical row index of each saved border captured before a row move, parallel to `savedBorders`.
   * Used to re-derive each border's visual row after the move reorders the visual index mapping.
   * `null` when no move is in progress.
   */ _rowMoveSnapshot = /*#__PURE__*/ new WeakMap(), /**
   * Physical column index of each saved border captured before a column move, parallel to
   * `savedBorders`. Used to re-derive each border's visual column after the move reorders the
   * visual index mapping. `null` when no move is in progress.
   */ _columnMoveSnapshot = /*#__PURE__*/ new WeakMap(), /**
   * Reads the cell's existing borders for a merge, unless this is the first time the cell is touched
   * within a `createCustomBorders` pass - in which case the cell is known to be border-free (the pass
   * runs after the previous borders' meta is cleared), so the read is skipped and `undefined` is
   * returned. Outside a config pass (`#configPassTouched` is `null`) it always reads, preserving the
   * merge behavior of `setBorders` and other callers. Skipping the first-touch read removes a full
   * O(N) `getCellMeta` pass from applying a large, non-overlapping config.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @returns {unknown} The existing `borders` meta value, or `undefined` when the read is skipped.
   */ _readExistingBordersForMerge = /*#__PURE__*/ new WeakSet(), /**
   * Writes or removes the plugin-owned `borders` cell meta with the re-entrancy guard raised, so
   * the external-write listeners ignore it. Pass `null` to remove the meta.
   *
   * Both `setCellMeta` and `removeCellMeta` are vetoable - a `beforeSetCellMeta` /
   * `beforeRemoveCellMeta` listener returning `false` makes them a no-op (an app blocking border
   * edits on locked cells, for example). The write is therefore verified against the resulting meta
   * and reported back, so callers can leave the border model untouched instead of recording a border
   * that has no cell meta behind it. The verification only runs when a matching `before*` listener
   * is registered - without one no veto is possible, and skipping the read keeps the
   * config-application path free of a per-border `getCellMeta` resolution.
   *
   * The removal is verified against the own property, not the resolved value: a `borders` key
   * cascading from the grid or column level survives `removeCellMeta` (which deletes the own key
   * only), so a resolved read would report a veto that never happened. The check covers the
   * cascade; a `borders` key supplied by a `cells` function is written back as an own property and
   * is unsupported - such values are not plugin-owned and never enter the border model.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {object|null} value The denormalized border object, or `null` to remove.
   * @returns {boolean} `true` when the meta now matches the requested write, `false` when it was vetoed.
   */ _writeBordersMeta = /*#__PURE__*/ new WeakSet(), /**
   * Builds the border object for a single cell of a range configuration. The cell's existing
   * borders are merged first, so a cell touched by several overlapping ranges keeps every side.
   * Each side that lies on a range edge is resolved through {@link resolveRangeBorderSide}, so an
   * empty side inherits the range-level `border` style instead of the default.
   *
   * @param {number} rowIndex Visual row index of the cell.
   * @param {number} colIndex Visual column index of the cell.
   * @param {object} customBorder The range configuration object.
   * @param {object} range The `{ from, to }` range the configuration applies to.
   * @returns {object} The merged border and the number of sides applied to this cell.
   */ _buildRangeCellBorder = /*#__PURE__*/ new WeakSet(), /**
   * Destroys every plugin-owned custom selection and clears the rendered working set. Selections
   * added to `highlight.customSelections` by other code are left untouched - the plugin only owns
   * the entries tracked in its working-set cache. Does not touch the `savedBorders` model.
   */ _destroyAllSelections = /*#__PURE__*/ new WeakSet(), /**
   * Clears the entire border model and its rendered working set: cancels any in-flight progressive
   * load, removes the `borders` meta from every previously bordered cell, empties `savedBorders` and
   * its indexes, and destroys the rendered selections. Shared by `clearBorders()` (clear all) and
   * `changeBorderSettings()` (a fresh array config / `updateSettings` replace). Does not render.
   */ _resetBorderModel = /*#__PURE__*/ new WeakSet(), /**
   * Rebuilds the visual-row index (`#bordersByRow`) from `savedBorders`. Runs at most once per model
   * change (guarded by `#bordersByRowDirty`), never per render, so the per-frame viewport sync stays
   * bounded by the viewport rather than the total border count.
   */ _rebuildBordersByRow = /*#__PURE__*/ new WeakSet(), /**
   * Patches a single border into the visual-row index, replacing any entry the row bucket already
   * holds for the same id (a style edit re-inserts a fresh border object for the same cell). Runs
   * only when the index is current - while it is dirty the next sync rebuilds it from scratch, so
   * patching it would be wasted work.
   *
   * @param {object} border The border to index.
   */ _indexBorderByRow = /*#__PURE__*/ new WeakSet(), /**
   * Drops a single border from the visual-row index. Runs only when the index is current, for the
   * same reason as {@link #indexBorderByRow}.
   *
   * @param {number} row Visual row index the border sits on.
   * @param {string} borderId The id of the border to drop.
   */ _unindexBorderByRow = /*#__PURE__*/ new WeakSet(), /**
   * Synchronizes the rendered custom selections with the current viewport. Creates selections for
   * bordered cells that entered the rendered range and destroys those that left it, so the selection
   * manager only ever iterates and draws O(viewport) borders regardless of how many are configured.
   * Called on every view render (`beforeViewRender`), before the selection borders are drawn.
   */ _syncViewportSelections = /*#__PURE__*/ new WeakSet(), /**
   * Creates and registers a rendered custom selection for a single border, keyed by its id in the
   * working-set cache. The `Border` DOM itself is created lazily by the selection manager when the
   * cell is inside the overlay's rendered range.
   *
   * @param {object} border The border model to render.
   */ _addSelectionForBorder = /*#__PURE__*/ new WeakSet(), /**
   * Rebuilds the id-to-position index of the saved borders after positions have shifted.
   */ _rebuildSavedBordersIndex = /*#__PURE__*/ new WeakSet(), /**
   * Reads and normalizes the `customBordersProgressive` setting.
   *
   * @returns {{ enabled: boolean, chunkSize: number }}
   */ _resolveProgressiveSetting = /*#__PURE__*/ new WeakSet(), /**
   * Starts a progressive (background-batched) application of a border configuration. The first batch
   * is scheduled asynchronously so the initial grid render is not blocked.
   *
   * @param {Array} borders The border configuration entries to apply.
   * @param {number} chunkSize The number of entries to apply per batch.
   */ _startProgressiveApply = /*#__PURE__*/ new WeakSet(), /**
   * Schedules the next progressive batch on a timeout so the browser can paint between batches.
   * `_registerTimeout` auto-clears on `destroy`; the generation token guards against stale runs.
   *
   * @param {number} token The generation token captured when the load started.
   */ _scheduleProgressiveChunk = /*#__PURE__*/ new WeakSet(), /**
   * Applies one progressive batch, renders so the newly in-viewport borders appear, then schedules
   * the next batch or finishes. Aborts if the load was cancelled/superseded (token mismatch).
   *
   * @param {number} token The generation token captured when the load started.
   */ _processProgressiveChunk = /*#__PURE__*/ new WeakSet(), /**
   * Applies all remaining progressive batches synchronously and finishes. Used when the border model
   * must be complete immediately - e.g. before a structural change remaps coordinates.
   */ _flushProgressiveApply = /*#__PURE__*/ new WeakSet(), /**
   * Finalizes a progressive load: clears the queue and pass state, invalidates any pending batch
   * (token bump), and fires `afterCustomBordersUpdate` to signal the borders are complete.
   */ _finishProgressiveApply = /*#__PURE__*/ new WeakSet(), /**
   * Cancels an in-flight progressive load without firing the completion hook (the borders are being
   * discarded/replaced). Invalidates pending batches via the token bump.
   */ _cancelProgressiveApply = /*#__PURE__*/ new WeakSet(), /**
   * Validate the style settings. If the style value is not supported, the property is removed from the configuration.
   *
   * @private
   * @param {object[]} customBorders The user defined custom border objects array.
   */ _validateStyleSettings = /*#__PURE__*/ new WeakSet(), /**
   * Re-synchronizes the saved borders and their rendered custom selections after rows or columns
   * are inserted or removed. Each saved border's coordinate on the given axis is passed through
   * `mapIndex`; a result of `-1` means the border's cell no longer exists and the border is dropped,
   * otherwise the border moves to the new coordinate. The cell meta is left untouched - Handsontable
   * already shifts it, and this method only realigns the plugin's own bookkeeping to that meta.
   *
   * @param {string} axis The coordinate axis to shift - `'row'` or `'col'`.
   * @param {Function} mapIndex Maps an old visual index to its new index, or `-1` when removed.
   */ _shiftBorders = /*#__PURE__*/ new WeakSet(), /**
   * Re-synchronizes the saved borders and their rendered custom selections after a row or column
   * move. Each border's new visual index on the given axis is derived from the physical index
   * captured before the move, so the border follows the cell it was applied to.
   *
   * @param {string} axis The coordinate axis to remap - `'row'` or `'col'`.
   * @param {Array} snapshot Physical indexes captured before the move, parallel to `savedBorders`.
   * @param {Function} toVisualIndex Translates a physical index to its current visual index.
   */ _applyMoveSnapshot = /*#__PURE__*/ new WeakSet(), /**
   * Reindexes the model after a structural change has rewritten border coordinates and ids, then
   * drops and re-renders the working set so the viewport sync rebuilds it from the updated model.
   * Tearing the selections down first also avoids transient id collisions (a shifted border's new id
   * can equal another border's not-yet-shifted old id). Shared by `#shiftBorders` and
   * `#applyMoveSnapshot`.
   *
   * @param {boolean} [render=true] If `true`, a render is forced so `#syncViewportSelections`
   * rebuilds the working set. Pass `false` when the caller runs inside an operation that renders on
   * its own afterwards - rendering from within such an operation paints a half-updated grid.
   */ _rebuildWorkingSetFromModel = /*#__PURE__*/ new WeakSet(), /**
   * Destroys the custom selection for the given border id and removes it from the highlight
   * collection and the id cache. Used when a border's cell is removed from the table.
   *
   * @param {string} borderId The id of the border whose selection should be destroyed.
   */ _destroyBorderSelection = /*#__PURE__*/ new WeakSet(), /**
   * Add border options to context menu.
   *
   * @param {object} defaultOptions Context menu items.
   */ _onAfterContextMenuDefaultOptions = /*#__PURE__*/ new WeakSet(), /**
   * `init` hook callback. Builds the border model without forcing a render: the `init` hook fires
   * right before the core's first render, and a render forced from here would paint the grid
   * before later-priority plugins (e.g. NestedHeaders) run their own `init` setup, leaving
   * corrupted header DOM behind (#11031 regression). The core's first render syncs and draws the
   * master overlay's borders; the freshly-bootstrapped overlay clones need one more selection
   * pass, so that render is scheduled for `afterInit` - still inside the same synchronous init
   * sequence, but after every plugin finished its initialization.
   */ _onAfterInit = /*#__PURE__*/ new WeakSet(), /**
   * `beforeViewRender` hook callback. Synchronizes the rendered custom-border selections with the
   * current viewport so only visible borders are materialized and drawn.
   *
   * The sync runs *before* the draw, not after it. The draw resolves the new rendered range
   * (`createCalculators`) before firing `beforeViewRender`, so the range this reads is already the
   * one about to be painted; the overlay clones then draw their selections, and the master draws
   * its own at the end of the same cycle. Syncing from `afterViewRender` instead would land between
   * those two, so a selection created there reached the master but missed the clones - a border
   * scrolled back into a frozen row or column stayed invisible until an unrelated render.
   */ _onBeforeViewRender = /*#__PURE__*/ new WeakMap(), /**
   * `afterSetCellMeta` hook callback. Follows an external write of the `borders` cell meta (e.g.
   * UndoRedo restoring the meta of an undone row/column removal, or user code calling
   * `setCellMeta` directly) by upserting the matching entry in the border model, so the model and
   * the meta cannot diverge. The plugin's own writes are excluded by the re-entrancy guard.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {string} key The meta key that was written.
   * @param {*} value The written value.
   */ _onAfterSetCellMeta = /*#__PURE__*/ new WeakMap(), /**
   * Schedules a single render for a batch of external `borders` cell-meta writes.
   *
   * The writes arrive per cell (`setCellMetaObject` fans a restored meta object out into one
   * `setCellMeta` call per key, and UndoRedo replays one entry per removed cell), so rendering
   * from the listener itself would run a full render for every bordered cell of the restored
   * range. The microtask runs after the synchronous write batch but before the browser can paint,
   * so the borders are still rebuilt within the same frame - no intermediate blank state. The
   * microtask is registered through the core, which cancels pending ones on `destroy`.
   */ _scheduleMetaSyncRender = /*#__PURE__*/ new WeakSet(), /**
   * `afterRemoveCellMeta` hook callback. Follows an external removal of the `borders` cell meta by
   * dropping the matching entry from the border model and its rendered selection.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {string} key The removed meta key.
   */ _onAfterRemoveCellMeta = /*#__PURE__*/ new WeakMap(), /**
   * Applies any in-flight progressive load synchronously, so the border model is complete and its
   * coordinates still describe the grid as the configuration meant them. Every structural change
   * runs this from its `before*` hook: the core shifts the cell meta before firing the matching
   * `after*` hook, so a queue drained from there would write its `borders` meta onto cells the
   * configuration never targeted, leaving the meta and the model permanently out of step. The
   * row/column move handlers flush from their `before*` hooks for the same reason.
   *
   * Auto-inserted rows and columns (`minSpareRows` / `minSpareCols`) append at the end and shift
   * nothing, so they keep the load progressive instead of forcing it to complete.
   *
   * The `before*` hooks are vetoable, and the flush runs before the veto outcome is known - a
   * later listener may still cancel the operation. A vetoed attempt therefore completes the load:
   * nothing shifts, so the flushed model stays correct, but the remaining configuration is applied
   * synchronously in that call. This is a deliberate trade-off - draining from the `after*` side
   * corrupts the meta coordinates (the reason the flush lives here), and an already-applied queue
   * cannot be re-armed.
   *
   * @param {string} [source] Source that triggered the structural change.
   */ _flushBeforeStructuralChange = /*#__PURE__*/ new WeakSet(), /**
   * `beforeCreateRow` hook callback.
   *
   * @param {number} index Visual index of the first row about to be created.
   * @param {number} amount Number of rows about to be created.
   * @param {string} [source] Source that triggered the row creation.
   */ _onBeforeCreateRow = /*#__PURE__*/ new WeakMap(), /**
   * `beforeRemoveRow` hook callback.
   *
   * @param {number} index Visual index of the first row about to be removed.
   * @param {number} amount Number of rows about to be removed.
   * @param {Array} physicalRows Physical indexes of the rows about to be removed.
   * @param {string} [source] Source that triggered the row removal.
   */ _onBeforeRemoveRow = /*#__PURE__*/ new WeakMap(), /**
   * `beforeCreateCol` hook callback.
   *
   * @param {number} index Visual index of the first column about to be created.
   * @param {number} amount Number of columns about to be created.
   * @param {string} [source] Source that triggered the column creation.
   */ _onBeforeCreateCol = /*#__PURE__*/ new WeakMap(), /**
   * `beforeRemoveCol` hook callback.
   *
   * @param {number} index Visual index of the first column about to be removed.
   * @param {number} amount Number of columns about to be removed.
   * @param {Array} physicalColumns Physical indexes of the columns about to be removed.
   * @param {string} [source] Source that triggered the column removal.
   */ _onBeforeRemoveCol = /*#__PURE__*/ new WeakMap(), /**
   * `afterCreateRow` hook callback. Shifts every border at or below the insertion point down.
   *
   * @param {number} index Visual index of the first newly created row.
   * @param {number} amount Number of created rows.
   * @param {string} [source] Source that triggered the row creation.
   */ _onAfterCreateRow = /*#__PURE__*/ new WeakMap(), /**
   * `afterRemoveRow` hook callback. Drops borders on removed rows and shifts the rest up.
   *
   * @param {number} index Visual index of the first removed row.
   * @param {number} amount Number of removed rows.
   */ _onAfterRemoveRow = /*#__PURE__*/ new WeakMap(), /**
   * `afterCreateCol` hook callback. Shifts every border at or after the insertion point right.
   *
   * @param {number} index Visual index of the first newly created column.
   * @param {number} amount Number of created columns.
   * @param {string} [source] Source that triggered the column creation.
   */ _onAfterCreateCol = /*#__PURE__*/ new WeakMap(), /**
   * `afterRemoveCol` hook callback. Drops borders on removed columns and shifts the rest left.
   *
   * @param {number} index Visual index of the first removed column.
   * @param {number} amount Number of removed columns.
   */ _onAfterRemoveCol = /*#__PURE__*/ new WeakMap(), /**
   * `beforeRowMove` hook callback. Snapshots each saved border's physical row so it can be
   * re-derived after the move reorders the visual index mapping.
   *
   * @param {Array} movedRows Visual row indexes being moved.
   * @param {number} finalIndex Target start index for the moved rows.
   * @param {number|undefined} dropIndex Drop index of the move.
   * @param {boolean} movePossible Whether the move is possible.
   */ _onBeforeRowMove = /*#__PURE__*/ new WeakMap(), /**
   * `afterRowMove` hook callback. Re-derives each border's visual row from the pre-move snapshot.
   *
   * @param {Array} movedRows Visual row indexes that were moved.
   * @param {number} finalIndex Target start index for the moved rows.
   * @param {number|undefined} dropIndex Drop index of the move.
   * @param {boolean} movePossible Whether the move was possible.
   * @param {boolean} orderChanged Whether the move changed the row order.
   */ _onAfterRowMove = /*#__PURE__*/ new WeakMap(), /**
   * `beforeColumnMove` hook callback. Snapshots each saved border's physical column so it can be
   * re-derived after the move reorders the visual index mapping.
   *
   * @param {Array} movedColumns Visual column indexes being moved.
   * @param {number} finalIndex Target start index for the moved columns.
   * @param {number|undefined} dropIndex Drop index of the move.
   * @param {boolean} movePossible Whether the move is possible.
   */ _onBeforeColumnMove = /*#__PURE__*/ new WeakMap(), /**
   * `afterColumnMove` hook callback. Re-derives each border's visual column from the pre-move
   * snapshot.
   *
   * @param {Array} movedColumns Visual column indexes that were moved.
   * @param {number} finalIndex Target start index for the moved columns.
   * @param {number|undefined} dropIndex Drop index of the move.
   * @param {boolean} movePossible Whether the move was possible.
   * @param {boolean} orderChanged Whether the move changed the column order.
   */ _onAfterColumnMove = /*#__PURE__*/ new WeakMap();
class CustomBorders extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns the settings keys that trigger the plugin update on `updateSettings()`. Beside the
   * plugin key itself this covers `customBordersProgressive`, which changes how the very same
   * configuration is applied - without it, switching only that option would stay inert until some
   * unrelated `customBorders` update happened to come along.
   */ static get SETTING_KEYS() {
        return [
            PLUGIN_KEY,
            'customBordersProgressive'
        ];
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link CustomBorders#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[PLUGIN_KEY];
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        this.addHook('afterContextMenuDefaultOptions', (options)=>_class_private_method_get(this, _onAfterContextMenuDefaultOptions, onAfterContextMenuDefaultOptions).call(this, options));
        this.addHook('init', ()=>_class_private_method_get(this, _onAfterInit, onAfterInit).call(this));
        this.addHook('beforeCreateRow', _class_private_field_get(this, _onBeforeCreateRow));
        this.addHook('afterCreateRow', _class_private_field_get(this, _onAfterCreateRow));
        this.addHook('beforeRemoveRow', _class_private_field_get(this, _onBeforeRemoveRow));
        this.addHook('afterRemoveRow', _class_private_field_get(this, _onAfterRemoveRow));
        this.addHook('beforeCreateCol', _class_private_field_get(this, _onBeforeCreateCol));
        this.addHook('afterCreateCol', _class_private_field_get(this, _onAfterCreateCol));
        this.addHook('beforeRemoveCol', _class_private_field_get(this, _onBeforeRemoveCol));
        this.addHook('afterRemoveCol', _class_private_field_get(this, _onAfterRemoveCol));
        this.addHook('beforeRowMove', _class_private_field_get(this, _onBeforeRowMove));
        this.addHook('afterRowMove', _class_private_field_get(this, _onAfterRowMove));
        this.addHook('beforeColumnMove', _class_private_field_get(this, _onBeforeColumnMove));
        this.addHook('afterColumnMove', _class_private_field_get(this, _onAfterColumnMove));
        this.addHook('beforeViewRender', _class_private_field_get(this, _onBeforeViewRender));
        this.addHook('afterSetCellMeta', _class_private_field_get(this, _onAfterSetCellMeta));
        this.addHook('afterRemoveCellMeta', _class_private_field_get(this, _onAfterRemoveCellMeta));
        super.enablePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        _class_private_method_get(this, _cancelProgressiveApply, cancelProgressiveApply).call(this);
        this.hideBorders();
        super.disablePlugin();
    }
    /**
   * Updates the plugin's state.
   *
   * This method is executed when [`updateSettings()`](@/api/core.md#updatesettings) is invoked with any of the following configuration options:
   *  - [`customBorders`](@/api/options.md#customborders)
   */ updatePlugin() {
        this.disablePlugin();
        this.enablePlugin();
        this.changeBorderSettings();
        super.updatePlugin();
    }
    /**
   * Set custom borders.
   *
   * @example
   * ```js
   * const customBordersPlugin = hot.getPlugin('customBorders');
   *
   * // Using an array of arrays (produced by `.getSelected()` method).
   * customBordersPlugin.setBorders([[1, 1, 2, 2], [6, 2, 0, 2]], {start: {width: 2, color: 'blue'}});
   *
   * // Using an array of CellRange objects (produced by `.getSelectedRange()` method).
   * //  Selecting a cell range.
   * hot.selectCell(0, 0, 2, 2);
   * // Returning selected cells' range with the getSelectedRange method.
   * customBordersPlugin.setBorders(hot.getSelectedRange(), {start: {hide: false, width: 2, color: 'blue'}});
   * ```
   *
   * @param {Array[]|CellRange[]} selectionRanges Array of selection ranges.
   * @param {object} borderObject Object with `top`, `bottom`, `start`, and `end` properties.
   * Each side object can include:
   * - `width` (`number`) Border width in pixels (default: `1`).
   * - `color` (`string`) CSS border color value (default: `'#000'`).
   * - `hide` (`boolean`) Hides a border side when set to `true`.
   * Legacy aliases `left` and `right` are also supported and are normalized to `start` and `end`.
   */ setBorders(selectionRanges, borderObject) {
        let borderKeys = [
            'top',
            'bottom',
            'start',
            'end'
        ];
        let normBorder = null;
        if (borderObject) {
            this.checkSettingsCohesion([
                borderObject
            ]);
            borderKeys = Object.keys(borderObject);
            normBorder = (0, _utils.normalizeBorder)(borderObject);
        }
        const selectionType = (0, _selection.detectSelectionType)(selectionRanges);
        const selectionSchemaNormalizer = (0, _selection.normalizeSelectionFactory)(selectionType, {
            createCellCoords: this.hot._createCellCoords.bind(this.hot),
            createCellRange: this.hot._createCellRange.bind(this.hot)
        });
        (0, _array.arrayEach)(selectionRanges, (selection)=>{
            selectionSchemaNormalizer(selection).forAll((row, col)=>{
                (0, _array.arrayEach)(borderKeys, (borderKey)=>{
                    this.prepareBorderFromCustomAdded(row, col, normBorder, (0, _utils.toInlinePropName)(borderKey));
                });
                return true;
            });
        });
        /*
    A forced render is used (not a fast `view.render()`) so the `beforeViewRender` hook fires and
    `#syncViewportSelections` materializes the custom selections for the just-changed, in-viewport
    borders before the selection borders are drawn. A fast draw can be skipped when Walkontable
    detects no cell/viewport change, which would leave the new border model unrendered.
    */ this.hot.render();
    }
    /**
   * Get custom borders.
   *
   * @example
   * ```js
   * const customBordersPlugin = hot.getPlugin('customBorders');
   *
   * // Using an array of arrays (produced by `.getSelected()` method).
   * customBordersPlugin.getBorders([[1, 1, 2, 2], [6, 2, 0, 2]]);
   * // Using an array of CellRange objects (produced by `.getSelectedRange()` method).
   * customBordersPlugin.getBorders(hot.getSelectedRange());
   * // Using without param - return all customBorders.
   * customBordersPlugin.getBorders();
   * ```
   *
   * @param {Array[]|CellRange[]} selectionRanges Array of selection ranges.
   * @returns {object[]} Returns array of border objects.
   */ getBorders(selectionRanges) {
        if (!Array.isArray(selectionRanges)) {
            return this.savedBorders;
        }
        const selectionType = (0, _selection.detectSelectionType)(selectionRanges);
        const selectionSchemaNormalizer = (0, _selection.normalizeSelectionFactory)(selectionType, {
            createCellCoords: this.hot._createCellCoords.bind(this.hot),
            createCellRange: this.hot._createCellRange.bind(this.hot)
        });
        const selectedBorders = [];
        (0, _array.arrayEach)(selectionRanges, (selection)=>{
            selectionSchemaNormalizer(selection).forAll((row, col)=>{
                (0, _array.arrayEach)(this.savedBorders, (border)=>{
                    if (border.row === row && border.col === col) {
                        selectedBorders.push((0, _utils.denormalizeBorder)(border));
                    }
                });
                return true;
            });
        });
        return selectedBorders;
    }
    /**
   * Clear custom borders.
   *
   * @example
   * ```js
   * const customBordersPlugin = hot.getPlugin('customBorders');
   *
   * // Using an array of arrays (produced by `.getSelected()` method).
   * customBordersPlugin.clearBorders([[1, 1, 2, 2], [6, 2, 0, 2]]);
   * // Using an array of CellRange objects (produced by `.getSelectedRange()` method).
   * customBordersPlugin.clearBorders(hot.getSelectedRange());
   * // Using without param - clear all customBorders.
   * customBordersPlugin.clearBorders();
   * ```
   *
   * @param {Array[]|CellRange[]} selectionRanges Array of selection ranges.
   */ clearBorders(selectionRanges) {
        if (selectionRanges) {
            this.setBorders(selectionRanges);
        } else {
            _class_private_method_get(this, _resetBorderModel, resetBorderModel).call(this);
            this.hot.render();
        }
    }
    /**
   * Insert WalkontableSelection instance into Walkontable settings.
   *
   * @private
   * @param {object} border Object with `row` and `col`, `start`, `end`, `top` and `bottom`, `id` and `border` ({Object} with `color`, `width` and `cornerVisible` property) properties.
   * @param {string} [place] Coordinate where add/remove border - `top`, `bottom`, `start`, `end`.
   */ insertBorderIntoSettings(border, place) {
        const hasSavedBorders = this.checkSavedBorders(border);
        if (!hasSavedBorders) {
            this.savedBorders.push(border);
            _class_private_field_get(this, _savedBordersIndex).set(border.id, this.savedBorders.length - 1);
        }
        // Only the model is updated here; the rendered custom selection is created (or refreshed) by
        // `#syncViewportSelections` on the next view render, and only if the border is inside the
        // rendered range. This is what makes the plugin scale: selections and their border DOM are
        // materialized for the viewport, not for every bordered cell. `place` is accepted for backward
        // compatibility but no longer drives an incremental per-side toggle - the sync rebuilds the
        // visible selection from the (already updated) border model, which carries the final side styles.
        //
        // The row index is patched for this one border rather than invalidated wholesale. Marking it
        // dirty would make the next render rebuild it from the whole of `savedBorders`, so a progressive
        // load - which renders once per batch - would rebuild a growing array once per batch and cost
        // O(borders² / chunkSize) over the load, in the exact path the batching exists to speed up.
        _class_private_method_get(this, _indexBorderByRow, indexBorderByRow).call(this, border);
        // Drop any selection currently rendering this cell so the sync recreates it from the updated
        // border object. The border id is coordinate-based and unchanged by a style edit, so without this
        // the sync would keep the stale selection (it only adds/removes by id). No-op during bulk config
        // load, when nothing is rendered yet.
        _class_private_method_get(this, _destroyBorderSelection, destroyBorderSelection).call(this, border.id);
    }
    /**
   * Prepare borders from setting (single cell).
   *
   * @private
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {object} borderDescriptor Object with `row` and `col`, `start`, `end`, `top` and `bottom` properties.
   * @param {string} [place] Coordinate where add/remove border - `top`, `bottom`, `start`, `end`.
   */ prepareBorderFromCustomAdded(row, column, borderDescriptor, place) {
        const nrOfRows = this.hot.countRows();
        const nrOfColumns = this.hot.countCols();
        if (row >= nrOfRows || column >= nrOfColumns) {
            return;
        }
        let border = (0, _utils.createEmptyBorders)(row, column);
        if (borderDescriptor) {
            // A descriptor means "update these sides": start from the cell's existing borders so the
            // sides it does not mention are kept, then layer the descriptor on top. With no descriptor
            // the border stays all-hidden, which is the "clear this cell" intent handled below.
            const existing = _class_private_method_get(this, _readExistingBordersForMerge, readExistingBordersForMerge).call(this, row, column);
            if (isBorderObject(existing)) {
                border = (0, _utils.normalizeBorder)((0, _object.deepClone)(existing));
                // The merge base describes THIS cell regardless of the bookkeeping fields the stored meta
                // carries - they can be stale when the meta is a detached snapshot (e.g. UndoRedo restoring
                // borders captured at pre-shift coordinates).
                border.row = row;
                border.col = column;
                border.id = (0, _utils.createId)(row, column);
            }
            border = (0, _utils.extendDefaultBorder)(border, borderDescriptor);
        }
        // When every side is hidden (e.g. `setBorders(range)` with no style object, used to clear a
        // cell) the border is removed entirely - dropped from the model and its cell meta - rather than
        // stored as an all-hidden object. The rendered selection is reconciled by the viewport sync.
        if (this.countHide(border) === 4) {
            this.removeAllBorders(row, column);
            return;
        }
        // A vetoed meta write must not reach the model - otherwise `getBorders()` would report a border
        // that `getCellMeta().borders` knows nothing about, and clearing the model later would try to
        // remove a meta key that was never written.
        if (!_class_private_method_get(this, _writeBordersMeta, writeBordersMeta).call(this, row, column, (0, _utils.denormalizeBorder)(border))) {
            return;
        }
        this.insertBorderIntoSettings(border, place);
    }
    /**
   * Prepare borders from setting (object).
   *
   * @private
   * @param {object} range {CellRange} The CellRange object.
   * @param {object} customBorder Object with `start`, `end`, `top` and `bottom` properties.
   */ prepareBorderFromCustomAddedRange(range, customBorder) {
        const lastRowIndex = Math.min(range.to.row, this.hot.countRows() - 1);
        const lastColumnIndex = Math.min(range.to.col, this.hot.countCols() - 1);
        (0, _number.rangeEach)(range.from.row, lastRowIndex, (rowIndex)=>{
            (0, _number.rangeEach)(range.from.col, lastColumnIndex, (colIndex)=>{
                const { border, add } = _class_private_method_get(this, _buildRangeCellBorder, buildRangeCellBorder).call(this, rowIndex, colIndex, customBorder, range);
                // `#buildRangeCellBorder` already merged this cell's existing borders, so overlapping
                // ranges accumulate their sides in the model. The rendered selection is (re)built from the
                // merged model by `#syncViewportSelections` on the next view render. A cell whose meta
                // write is vetoed is skipped entirely, so the model never gets ahead of the meta.
                if (add > 0 && _class_private_method_get(this, _writeBordersMeta, writeBordersMeta).call(this, rowIndex, colIndex, (0, _utils.denormalizeBorder)(border))) {
                    this.insertBorderIntoSettings(border, undefined);
                }
            });
        });
    }
    /**
   * Remove border (triggered from context menu).
   *
   * @private
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   */ removeAllBorders(row, column) {
        // The meta removal is vetoable, so it runs first: when a `beforeRemoveCellMeta` listener blocks
        // it the cell keeps its `borders` meta, and dropping the border from the model anyway would
        // leave `getBorders()` and `getCellMeta().borders` disagreeing.
        if (!_class_private_method_get(this, _writeBordersMeta, writeBordersMeta).call(this, row, column, null)) {
            return;
        }
        const borderId = (0, _utils.createId)(row, column);
        this.spliceBorder(borderId);
        _class_private_method_get(this, _unindexBorderByRow, unindexBorderByRow).call(this, row, borderId);
        // Destroy the rendered selection if this border is currently in the viewport working set; if it
        // is off-screen there is nothing rendered to remove.
        _class_private_method_get(this, _destroyBorderSelection, destroyBorderSelection).call(this, borderId);
    }
    /**
   * Set borders for each cell re. To border position.
   *
   * @private
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {string} place Coordinate where add/remove border - `top`, `bottom`, `start`, `end` and `noBorders`.
   * @param {boolean} remove True when remove borders, and false when add borders.
   */ setBorder(row, column, place, remove) {
        const meta = this.hot.getCellMeta(row, column).borders;
        let bordersMeta;
        if (isBorderObject(meta)) {
            bordersMeta = (0, _utils.normalizeBorder)(meta);
        } else {
            bordersMeta = (0, _utils.createEmptyBorders)(row, column);
        }
        if (remove) {
            bordersMeta[place] = (0, _utils.createSingleEmptyBorder)();
            const hideCount = this.countHide(bordersMeta);
            if (hideCount === 4) {
                this.removeAllBorders(row, column);
            } else if (_class_private_method_get(this, _writeBordersMeta, writeBordersMeta).call(this, row, column, (0, _utils.denormalizeBorder)(bordersMeta))) {
                this.insertBorderIntoSettings(bordersMeta, undefined);
            }
        } else {
            bordersMeta[place] = (0, _utils.createDefaultCustomBorder)();
            // The meta is written first so a vetoed write leaves the model untouched.
            if (_class_private_method_get(this, _writeBordersMeta, writeBordersMeta).call(this, row, column, (0, _utils.denormalizeBorder)(bordersMeta))) {
                this.insertBorderIntoSettings(bordersMeta, undefined);
            }
        }
    }
    /**
   * Prepare borders based on cell and border position.
   *
   * @private
   * @param {CellRange[]} selected An array of CellRange objects.
   * @param {string} place Coordinate where add/remove border - `top`, `bottom`, `left`, `right` and `noBorders`.
   * @param {boolean} remove True when remove borders, and false when add borders.
   */ prepareBorder(selected, place, remove) {
        (0, _array.arrayEach)(selected, (item)=>{
            if (!isCellCoord(item.start) || !isCellCoord(item.end)) {
                return;
            }
            const { start, end } = {
                start: item.start,
                end: item.end
            };
            if (start.row === end.row && start.col === end.col) {
                if (place === 'noBorders') {
                    this.removeAllBorders(start.row, start.col);
                } else {
                    this.setBorder(start.row, start.col, place, remove);
                }
            } else {
                switch(place){
                    case 'noBorders':
                        (0, _number.rangeEach)(start.col, end.col, (colIndex)=>{
                            (0, _number.rangeEach)(start.row, end.row, (rowIndex)=>{
                                this.removeAllBorders(rowIndex, colIndex);
                            });
                        });
                        break;
                    case 'top':
                        (0, _number.rangeEach)(start.col, end.col, (topCol)=>{
                            this.setBorder(start.row, topCol, place, remove);
                        });
                        break;
                    case 'bottom':
                        (0, _number.rangeEach)(start.col, end.col, (bottomCol)=>{
                            this.setBorder(end.row, bottomCol, place, remove);
                        });
                        break;
                    case 'start':
                        (0, _number.rangeEach)(start.row, end.row, (rowStart)=>{
                            this.setBorder(rowStart, start.col, place, remove);
                        });
                        break;
                    case 'end':
                        (0, _number.rangeEach)(start.row, end.row, (rowEnd)=>{
                            this.setBorder(rowEnd, end.col, place, remove);
                        });
                        break;
                    default:
                        break;
                }
            }
        });
        // Border changes above only updated the model; render so `#syncViewportSelections` materializes
        // the visible selections for the changed cells.
        this.hot.render();
    }
    /**
   * Create borders from settings.
   *
   * @private
   * @param {Array} customBorders Object with `row` and `col`, `start`, `end`, `top` and `bottom` properties.
   */ createCustomBorders(customBorders) {
        // Own the first-touch tracking Set only when one is not already active. A progressive load keeps
        // a single Set across all its batches (so overlapping ranges split across batches still merge
        // correctly); a plain synchronous call owns and clears it here.
        const ownsPass = _class_private_field_get(this, _configPassTouched) === null;
        const wasInConfigPass = _class_private_field_get(this, _inConfigPass);
        if (ownsPass) {
            _class_private_field_set(this, _configPassTouched, new Set());
        }
        _class_private_field_set(this, _inConfigPass, true);
        try {
            (0, _array.arrayEach)(customBorders, (customBorder)=>{
                const normCustomBorder = (0, _utils.normalizeBorder)(customBorder);
                if (normCustomBorder.range) {
                    this.prepareBorderFromCustomAddedRange(normCustomBorder.range, normCustomBorder);
                } else {
                    this.prepareBorderFromCustomAdded(normCustomBorder.row ?? 0, normCustomBorder.col ?? 0, normCustomBorder, undefined);
                }
            });
        } finally{
            _class_private_field_set(this, _inConfigPass, wasInConfigPass);
            if (ownsPass) {
                _class_private_field_set(this, _configPassTouched, null);
            }
        }
    }
    /**
   * Count hide property in border object.
   *
   * @private
   * @param {object} border Object with `row` and `col`, `start`, `end`, `top` and `bottom`, `id` and
   *                        `border` ({Object} with `color`, `width` and `cornerVisible` property) properties.
   * @returns {number}
   */ countHide(border) {
        const { top, bottom, start, end } = border;
        const values = [
            top,
            bottom,
            start,
            end
        ];
        return (0, _array.arrayReduce)(values, (accumulator, value)=>{
            let result = accumulator;
            if (value && value.hide) {
                result += 1;
            }
            return result;
        }, 0);
    }
    /**
   * Hide custom borders. Destroys the rendered working-set selections; the `savedBorders` model is
   * kept so the borders can be re-materialized if the plugin is re-enabled.
   *
   * @private
   */ hideBorders() {
        _class_private_method_get(this, _destroyAllSelections, destroyAllSelections).call(this);
    }
    /**
   * Splice border from savedBorders.
   *
   * @private
   * @param {string} borderId Border id name as string.
   */ spliceBorder(borderId) {
        const index = _class_private_field_get(this, _savedBordersIndex).get(borderId) ?? -1;
        if (index > -1) {
            this.savedBorders.splice(index, 1);
            _class_private_method_get(this, _rebuildSavedBordersIndex, rebuildSavedBordersIndex).call(this);
        }
    }
    /**
   * Check if an border already exists in the savedBorders array, and if true update border in savedBorders.
   *
   * @private
   * @param {object} border Object with `row` and `col`, `start`, `end`, `top` and `bottom`, `id` and
   *                        `border` ({Object} with `color`, `width` and `cornerVisible` property) properties.
   *
   * @returns {boolean}
   */ checkSavedBorders(border) {
        let check = false;
        const hideCount = this.countHide(border);
        if (hideCount === 4) {
            this.spliceBorder(border.id);
            check = true;
        } else {
            const index = _class_private_field_get(this, _savedBordersIndex).get(border.id);
            if (index !== undefined) {
                this.savedBorders[index] = border;
                check = true;
            }
        }
        return check;
    }
    /**
   * Change borders from settings.
   *
   * @private
   * @param {boolean} [render=true] If `true`, a render is forced after the border model is rebuilt
   * so `#syncViewportSelections` materializes the visible selections. Pass `false` on the `init`
   * path: the `init` hook fires before the core's own first render, so that render performs the
   * sync - and rendering here would paint the grid before later-priority plugins (e.g.
   * NestedHeaders) finish their `init` setup, leaving corrupted header DOM behind.
   */ changeBorderSettings(render = true) {
        const customBorders = this.hot.getSettings()[PLUGIN_KEY];
        if (Array.isArray(customBorders)) {
            const bordersClone = (0, _object.deepClone)(customBorders.filter(isRecord));
            this.checkSettingsCohesion(bordersClone);
            // A fresh array config replaces the previous borders (this is also the `updateSettings` path).
            // Reset the model and clear the previous cells' meta first so `prepareBorderFromCustomAdded`
            // starts from a clean slate instead of merging the new config onto stale meta.
            _class_private_method_get(this, _resetBorderModel, resetBorderModel).call(this);
            const progressive = _class_private_method_get(this, _resolveProgressiveSetting, resolveProgressiveSetting).call(this);
            if (progressive.enabled && bordersClone.length > 0) {
                // Apply borders in background batches: render the (border-less) grid now so it is
                // interactive immediately; batches fill in and `afterCustomBordersUpdate` fires on drain.
                _class_private_method_get(this, _startProgressiveApply, startProgressiveApply).call(this, bordersClone, progressive.chunkSize);
                if (render) {
                    this.hot.render();
                }
                return;
            }
            this.createCustomBorders(bordersClone);
        } else if (customBorders !== undefined) {
            this.createCustomBorders(this.savedBorders);
        }
        if (render) {
            this.hot.render();
        }
        this.hot.runHooks('afterCustomBordersUpdate');
    }
    /**
   * Checks the settings cohesion. The properties such like "left"/"right" are supported only
   * in the LTR mode and the "left"/"right" options can not be used together with "start"/"end" properties.
   *
   * @private
   * @param {object[]} customBorders The user defined custom border objects array.
   */ checkSettingsCohesion(customBorders) {
        const hasLeftOrRight = (0, _utils.hasLeftRightTypeOptions)(customBorders);
        const hasStartOrEnd = (0, _utils.hasStartEndTypeOptions)(customBorders);
        if (hasLeftOrRight && hasStartOrEnd) {
            (0, _errors.throwWithCause)('The "left"/"right" and "start"/"end" options should not be used together. ' + 'Please use only the option "start"/"end".');
        }
        if (this.hot.isRtl() && hasLeftOrRight) {
            (0, _errors.throwWithCause)('The "left"/"right" properties are not supported for RTL. Please use option "start"/"end".');
        }
        _class_private_method_get(this, _validateStyleSettings, validateStyleSettings).call(this, customBorders);
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        // Cancel any in-flight progressive load and release the border model / working-set graphs so a
        // destroyed instance does not retain them for the page lifetime.
        _class_private_method_get(this, _cancelProgressiveApply, cancelProgressiveApply).call(this);
        this.savedBorders = [];
        _class_private_field_get(this, _savedBordersIndex).clear();
        _class_private_field_get(this, _bordersByRow).clear();
        _class_private_field_get(this, _customSelectionsCache).clear();
        _class_private_field_set(this, _rowMoveSnapshot, null);
        _class_private_field_set(this, _columnMoveSnapshot, null);
        super.destroy();
    }
    constructor(...args){
        super(...args), _class_private_method_init(this, _readExistingBordersForMerge), _class_private_method_init(this, _writeBordersMeta), _class_private_method_init(this, _buildRangeCellBorder), _class_private_method_init(this, _destroyAllSelections), _class_private_method_init(this, _resetBorderModel), _class_private_method_init(this, _rebuildBordersByRow), _class_private_method_init(this, _indexBorderByRow), _class_private_method_init(this, _unindexBorderByRow), _class_private_method_init(this, _syncViewportSelections), _class_private_method_init(this, _addSelectionForBorder), _class_private_method_init(this, _rebuildSavedBordersIndex), _class_private_method_init(this, _resolveProgressiveSetting), _class_private_method_init(this, _startProgressiveApply), _class_private_method_init(this, _scheduleProgressiveChunk), _class_private_method_init(this, _processProgressiveChunk), _class_private_method_init(this, _flushProgressiveApply), _class_private_method_init(this, _finishProgressiveApply), _class_private_method_init(this, _cancelProgressiveApply), _class_private_method_init(this, _validateStyleSettings), _class_private_method_init(this, _shiftBorders), _class_private_method_init(this, _applyMoveSnapshot), _class_private_method_init(this, _rebuildWorkingSetFromModel), _class_private_method_init(this, _destroyBorderSelection), _class_private_method_init(this, _onAfterContextMenuDefaultOptions), _class_private_method_init(this, _onAfterInit), _class_private_method_init(this, _scheduleMetaSyncRender), _class_private_method_init(this, _flushBeforeStructuralChange), _class_private_field_init(this, _savedBordersIndex, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _customSelectionsCache, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _bordersByRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _bordersByRowDirty, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _configPassTouched, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _inConfigPass, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _isInternalMetaWrite, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _isMetaSyncRenderScheduled, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _progressiveQueue, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _progressiveIndex, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _progressiveChunkSize, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _progressiveToken, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _rowMoveSnapshot, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _columnMoveSnapshot, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeViewRender, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterSetCellMeta, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterRemoveCellMeta, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeCreateRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeRemoveRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeCreateCol, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeRemoveCol, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterCreateRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterRemoveRow, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterCreateCol, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterRemoveCol, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeRowMove, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterRowMove, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeColumnMove, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterColumnMove, {
            writable: true,
            value: void 0
        }), /**
   * Saved borders.
   *
   * @private
   * @type {Array}
   */ this.savedBorders = [], _class_private_field_set(this, _savedBordersIndex, new Map()), _class_private_field_set(this, _customSelectionsCache, new Map()), _class_private_field_set(this, _bordersByRow, new Map()), _class_private_field_set(this, _bordersByRowDirty, true), _class_private_field_set(this, _configPassTouched, null), _class_private_field_set(this, _inConfigPass, false), _class_private_field_set(this, _isInternalMetaWrite, false), _class_private_field_set(this, _isMetaSyncRenderScheduled, false), _class_private_field_set(this, _progressiveQueue, null), _class_private_field_set(this, _progressiveIndex, 0), _class_private_field_set(this, _progressiveChunkSize, DEFAULT_PROGRESSIVE_CHUNK_SIZE), _class_private_field_set(this, _progressiveToken, 0), _class_private_field_set(this, _rowMoveSnapshot, null), _class_private_field_set(this, _columnMoveSnapshot, null), _class_private_field_set(this, _onBeforeViewRender, ()=>{
            _class_private_method_get(this, _syncViewportSelections, syncViewportSelections).call(this);
        }), _class_private_field_set(this, _onAfterSetCellMeta, (row, column, key, value)=>{
            if (_class_private_field_get(this, _isInternalMetaWrite) || key !== 'borders' || !isRecord(value)) {
                return;
            }
            // The written value may be a complete plugin-shaped border object (UndoRedo restoring the meta
            // of an undone removal) or a partial user-authored one (e.g. `{ top: { width: 2 } }` passed to
            // `setCellMeta` directly), so it must not be required to carry the internal `id`/`row`/`col`
            // bookkeeping fields. Routing it through `prepareBorderFromCustomAdded` treats it as a border
            // descriptor for the write's coordinates. The meta key was already replaced by this write (the
            // previous sides are gone), so the descriptor defines the cell's borders: the canonical
            // (complete, denormalized) object is written back to the meta, an all-hidden result clears the
            // cell, and the model entry is upserted - so meta and model cannot diverge.
            this.prepareBorderFromCustomAdded(row, column, (0, _utils.normalizeBorder)((0, _object.deepClone)(value)), undefined);
            // `setCellMeta` does not render, and the model update above dropped the cell's previous rendered
            // selection so the viewport sync can rebuild it. Without a render the old border DOM is gone
            // and the new one waits for some unrelated render - the cell would appear to lose its border.
            _class_private_method_get(this, _scheduleMetaSyncRender, scheduleMetaSyncRender).call(this);
        }), _class_private_field_set(this, _onAfterRemoveCellMeta, (row, column, key)=>{
            if (_class_private_field_get(this, _isInternalMetaWrite) || key !== 'borders') {
                return;
            }
            const borderId = (0, _utils.createId)(row, column);
            this.spliceBorder(borderId);
            _class_private_method_get(this, _unindexBorderByRow, unindexBorderByRow).call(this, row, borderId);
            _class_private_method_get(this, _destroyBorderSelection, destroyBorderSelection).call(this, borderId);
        }), _class_private_field_set(this, _onBeforeCreateRow, (index, amount, source)=>{
            _class_private_method_get(this, _flushBeforeStructuralChange, flushBeforeStructuralChange).call(this, source);
        }), _class_private_field_set(this, _onBeforeRemoveRow, (index, amount, physicalRows, source)=>{
            _class_private_method_get(this, _flushBeforeStructuralChange, flushBeforeStructuralChange).call(this, source);
        }), _class_private_field_set(this, _onBeforeCreateCol, (index, amount, source)=>{
            _class_private_method_get(this, _flushBeforeStructuralChange, flushBeforeStructuralChange).call(this, source);
        }), _class_private_field_set(this, _onBeforeRemoveCol, (index, amount, physicalColumns, source)=>{
            _class_private_method_get(this, _flushBeforeStructuralChange, flushBeforeStructuralChange).call(this, source);
        }), _class_private_field_set(this, _onAfterCreateRow, (index, amount, source)=>{
            if (source === 'auto') {
                return;
            }
            _class_private_method_get(this, _shiftBorders, shiftBorders).call(this, 'row', (currentIndex)=>(0, _utils.getShiftedIndexAfterInsert)(currentIndex, index, amount));
        }), _class_private_field_set(this, _onAfterRemoveRow, (index, amount)=>{
            _class_private_method_get(this, _shiftBorders, shiftBorders).call(this, 'row', (currentIndex)=>(0, _utils.getShiftedIndexAfterRemove)(currentIndex, index, amount));
        }), _class_private_field_set(this, _onAfterCreateCol, (index, amount, source)=>{
            // Auto-inserted columns (e.g. `minSpareCols`) append at the end and, like auto rows, do NOT
            // shift cell meta in the core (`DataMap#createCol` skips `metaManager.createColumn` for
            // `source === 'auto'`). Shifting the border model here would then diverge from the meta, so skip
            // it - mirrors `#onAfterCreateRow`.
            if (source === 'auto') {
                return;
            }
            _class_private_method_get(this, _shiftBorders, shiftBorders).call(this, 'col', (currentIndex)=>(0, _utils.getShiftedIndexAfterInsert)(currentIndex, index, amount));
        }), _class_private_field_set(this, _onAfterRemoveCol, (index, amount)=>{
            _class_private_method_get(this, _shiftBorders, shiftBorders).call(this, 'col', (currentIndex)=>(0, _utils.getShiftedIndexAfterRemove)(currentIndex, index, amount));
        }), _class_private_field_set(this, _onBeforeRowMove, (movedRows, finalIndex, dropIndex, movePossible)=>{
            // Snapshot needs the complete model; finish any in-flight progressive load first.
            _class_private_method_get(this, _flushProgressiveApply, flushProgressiveApply).call(this);
            _class_private_field_set(this, _rowMoveSnapshot, movePossible ? this.savedBorders.map((border)=>this.hot.toPhysicalRow(border.row)) : null);
        }), _class_private_field_set(this, _onAfterRowMove, (movedRows, finalIndex, dropIndex, movePossible, orderChanged)=>{
            const snapshot = _class_private_field_get(this, _rowMoveSnapshot);
            _class_private_field_set(this, _rowMoveSnapshot, null);
            if (!snapshot || !orderChanged) {
                return;
            }
            _class_private_method_get(this, _applyMoveSnapshot, applyMoveSnapshot).call(this, 'row', snapshot, (physicalIndex)=>this.hot.toVisualRow(physicalIndex));
        }), _class_private_field_set(this, _onBeforeColumnMove, (movedColumns, finalIndex, dropIndex, movePossible)=>{
            // Snapshot needs the complete model; finish any in-flight progressive load first.
            _class_private_method_get(this, _flushProgressiveApply, flushProgressiveApply).call(this);
            _class_private_field_set(this, _columnMoveSnapshot, movePossible ? this.savedBorders.map((border)=>this.hot.toPhysicalColumn(border.col)) : null);
        }), _class_private_field_set(this, _onAfterColumnMove, (movedColumns, finalIndex, dropIndex, movePossible, orderChanged)=>{
            const snapshot = _class_private_field_get(this, _columnMoveSnapshot);
            _class_private_field_set(this, _columnMoveSnapshot, null);
            if (!snapshot || !orderChanged) {
                return;
            }
            _class_private_method_get(this, _applyMoveSnapshot, applyMoveSnapshot).call(this, 'col', snapshot, (physicalIndex)=>this.hot.toVisualColumn(physicalIndex));
        });
    }
}
function readExistingBordersForMerge(row, column) {
    const seen = _class_private_field_get(this, _configPassTouched);
    if (seen === null || !_class_private_field_get(this, _inConfigPass)) {
        return this.hot.getCellMeta(row, column).borders;
    }
    const key = `${row},${column}`;
    const shouldRead = seen.has(key);
    seen.add(key);
    return shouldRead ? this.hot.getCellMeta(row, column).borders : undefined;
}
function writeBordersMeta(row, column, value) {
    // Sampled before the write: a `runOnce` veto listener removes itself the moment it fires, so
    // probing afterwards would read `false` for a write that was in fact vetoed.
    const isVetoable = this.hot.hasHook(value === null ? 'beforeRemoveCellMeta' : 'beforeSetCellMeta');
    _class_private_field_set(this, _isInternalMetaWrite, true);
    try {
        if (value === null) {
            this.hot.removeCellMeta(row, column, 'borders');
        } else {
            this.hot.setCellMeta(row, column, 'borders', value);
        }
    } finally{
        _class_private_field_set(this, _isInternalMetaWrite, false);
    }
    if (!isVetoable) {
        return true;
    }
    // Same effective resolution as `getCellMeta`; the cell already holds stored meta after the
    // write above, so the transient read returns that stored object with its own properties
    // observable.
    const written = this.hot.getCellMetaTransient(row, column);
    return value === null ? !(0, _object.hasOwnProperty)(written, 'borders') : written.borders === value;
}
function buildRangeCellBorder(rowIndex, colIndex, customBorder, range) {
    const existing = _class_private_method_get(this, _readExistingBordersForMerge, readExistingBordersForMerge).call(this, rowIndex, colIndex);
    const border = isBorderObject(existing) ? (0, _utils.normalizeBorder)((0, _object.deepClone)(existing)) : (0, _utils.createEmptyBorders)(rowIndex, colIndex);
    let add = 0;
    const applyEdge = (isEdge, sideKey)=>{
        // `range.to.row`/`range.to.col` may lie beyond the table; those cells are never iterated.
        if (isEdge && (0, _object.hasOwnProperty)(customBorder, sideKey)) {
            border[sideKey] = (0, _utils.resolveRangeBorderSide)(customBorder[sideKey], customBorder.border);
            add += 1;
        }
    };
    applyEdge(rowIndex === range.from.row, 'top');
    applyEdge(rowIndex === range.to.row, 'bottom');
    applyEdge(colIndex === range.from.col, 'start');
    applyEdge(colIndex === range.to.col, 'end');
    if (isRecord(customBorder.border)) {
        border.border = customBorder.border;
    }
    return {
        border,
        add
    };
}
function destroyAllSelections() {
    const { customSelections } = this.hot.selection.highlight;
    const owned = new Set(_class_private_field_get(this, _customSelectionsCache).values());
    for(let index = customSelections.length - 1; index >= 0; index--){
        if (owned.has(customSelections[index])) {
            customSelections[index].destroy();
            customSelections.splice(index, 1);
        }
    }
    _class_private_field_get(this, _customSelectionsCache).clear();
}
function resetBorderModel() {
    _class_private_method_get(this, _cancelProgressiveApply, cancelProgressiveApply).call(this);
    // A `beforeRemoveCellMeta` listener can veto the removal. Those cells keep their `borders` meta,
    // so they keep their model entry too - clearing the model around them would leave `getBorders()`
    // and `getCellMeta().borders` disagreeing.
    const kept = [];
    (0, _array.arrayEach)(this.savedBorders, (border)=>{
        if (!_class_private_method_get(this, _writeBordersMeta, writeBordersMeta).call(this, border.row, border.col, null)) {
            kept.push(border);
        }
    });
    this.savedBorders = kept;
    _class_private_method_get(this, _rebuildSavedBordersIndex, rebuildSavedBordersIndex).call(this);
    _class_private_field_get(this, _bordersByRow).clear();
    _class_private_field_set(this, _bordersByRowDirty, true);
    _class_private_method_get(this, _destroyAllSelections, destroyAllSelections).call(this);
}
function rebuildBordersByRow() {
    _class_private_field_get(this, _bordersByRow).clear();
    (0, _array.arrayEach)(this.savedBorders, (border)=>{
        const rowBorders = _class_private_field_get(this, _bordersByRow).get(border.row);
        if (rowBorders) {
            rowBorders.push(border);
        } else {
            _class_private_field_get(this, _bordersByRow).set(border.row, [
                border
            ]);
        }
    });
    _class_private_field_set(this, _bordersByRowDirty, false);
}
function indexBorderByRow(border) {
    if (_class_private_field_get(this, _bordersByRowDirty)) {
        return;
    }
    // A border removed by `checkSavedBorders` (all four sides hidden) is no longer in the model, so
    // it must leave the index rather than enter it.
    if (!_class_private_field_get(this, _savedBordersIndex).has(border.id)) {
        _class_private_method_get(this, _unindexBorderByRow, unindexBorderByRow).call(this, border.row, border.id);
        return;
    }
    const rowBorders = _class_private_field_get(this, _bordersByRow).get(border.row);
    if (!rowBorders) {
        _class_private_field_get(this, _bordersByRow).set(border.row, [
            border
        ]);
        return;
    }
    const at = rowBorders.findIndex((indexed)=>indexed.id === border.id);
    if (at === -1) {
        rowBorders.push(border);
    } else {
        rowBorders[at] = border;
    }
}
function unindexBorderByRow(row, borderId) {
    if (_class_private_field_get(this, _bordersByRowDirty)) {
        return;
    }
    const rowBorders = _class_private_field_get(this, _bordersByRow).get(row);
    if (!rowBorders) {
        return;
    }
    const at = rowBorders.findIndex((indexed)=>indexed.id === borderId);
    if (at === -1) {
        return;
    }
    rowBorders.splice(at, 1);
    if (rowBorders.length === 0) {
        _class_private_field_get(this, _bordersByRow).delete(row);
    }
}
function syncViewportSelections() {
    if (_class_private_field_get(this, _bordersByRowDirty)) {
        _class_private_method_get(this, _rebuildBordersByRow, rebuildBordersByRow).call(this);
    }
    const view = this.hot.view;
    const firstRow = view.getFirstRenderedVisibleRow();
    const lastRow = view.getLastRenderedVisibleRow();
    const firstColumn = view.getFirstRenderedVisibleColumn();
    const lastColumn = view.getLastRenderedVisibleColumn();
    // Nothing rendered (e.g. detached table or headers only) - drop the whole working set.
    if (firstRow === null || lastRow === null || firstColumn === null || lastColumn === null) {
        if (_class_private_field_get(this, _customSelectionsCache).size > 0) {
            _class_private_method_get(this, _destroyAllSelections, destroyAllSelections).call(this);
        }
        return;
    }
    // Frozen rows/columns are rendered by the overlay clones even when the master rendered range
    // excludes them, so the working window is the union of the frozen areas and the master range.
    const settings = this.hot.getSettings();
    const fixedRowsTop = Number(settings.fixedRowsTop) || 0;
    const fixedRowsBottom = Number(settings.fixedRowsBottom) || 0;
    const fixedColumnsStart = Number(settings.fixedColumnsStart) || 0;
    const totalRows = this.hot.countRows();
    const totalColumns = this.hot.countCols();
    const rowRanges = (0, _utils.getViewportUnionRanges)(firstRow, lastRow, fixedRowsTop, fixedRowsBottom, totalRows);
    const shouldBeVisible = new Set();
    (0, _array.arrayEach)(rowRanges, ([fromRow, toRow])=>{
        for(let row = fromRow; row <= toRow; row++){
            const rowBorders = _class_private_field_get(this, _bordersByRow).get(row);
            if (!rowBorders) {
                continue; // eslint-disable-line no-continue
            }
            (0, _array.arrayEach)(rowBorders, (border)=>{
                if ((0, _utils.isIndexInViewportUnion)(border.col, firstColumn, lastColumn, fixedColumnsStart, 0, totalColumns)) {
                    shouldBeVisible.add(border.id);
                    if (!_class_private_field_get(this, _customSelectionsCache).has(border.id)) {
                        _class_private_method_get(this, _addSelectionForBorder, addSelectionForBorder).call(this, border);
                    }
                }
            });
        }
    });
    // Remove selections that scrolled out of the rendered range.
    (0, _array.arrayEach)(Array.from(_class_private_field_get(this, _customSelectionsCache).keys()), (borderId)=>{
        if (!shouldBeVisible.has(borderId)) {
            _class_private_method_get(this, _destroyBorderSelection, destroyBorderSelection).call(this, borderId);
        }
    });
}
function addSelectionForBorder(border) {
    const borderCoords = this.hot._createCellCoords(border.row, border.col);
    const visualCellRange = this.hot._createCellRange(borderCoords, borderCoords, borderCoords);
    const { customSelections } = this.hot.selection.highlight;
    this.hot.selection.highlight.addCustomSelection({
        border,
        visualCellRange
    });
    _class_private_field_get(this, _customSelectionsCache).set(border.id, customSelections[customSelections.length - 1]);
}
function rebuildSavedBordersIndex() {
    _class_private_field_get(this, _savedBordersIndex).clear();
    (0, _array.arrayEach)(this.savedBorders, (border, index)=>{
        _class_private_field_get(this, _savedBordersIndex).set(border.id, index);
    });
}
function resolveProgressiveSetting() {
    const setting = this.hot.getSettings().customBordersProgressive;
    if (setting === true) {
        return {
            enabled: true,
            chunkSize: DEFAULT_PROGRESSIVE_CHUNK_SIZE
        };
    }
    if (isRecord(setting)) {
        const size = typeof setting.chunkSize === 'number' && setting.chunkSize > 0 ? Math.floor(setting.chunkSize) : DEFAULT_PROGRESSIVE_CHUNK_SIZE;
        return {
            enabled: true,
            chunkSize: size
        };
    }
    return {
        enabled: false,
        chunkSize: DEFAULT_PROGRESSIVE_CHUNK_SIZE
    };
}
function startProgressiveApply(borders, chunkSize) {
    _class_private_field_set(this, _progressiveToken, _class_private_field_get(this, _progressiveToken) + 1);
    _class_private_field_set(this, _progressiveQueue, borders);
    _class_private_field_set(this, _progressiveIndex, 0);
    _class_private_field_set(this, _progressiveChunkSize, chunkSize);
    // One first-touch tracking Set shared across every batch (overlap-merge correctness).
    _class_private_field_set(this, _configPassTouched, new Set());
    _class_private_method_get(this, _scheduleProgressiveChunk, scheduleProgressiveChunk).call(this, _class_private_field_get(this, _progressiveToken));
}
function scheduleProgressiveChunk(token) {
    this.hot._registerTimeout(()=>_class_private_method_get(this, _processProgressiveChunk, processProgressiveChunk).call(this, token), 0);
}
function processProgressiveChunk(token) {
    if (token !== _class_private_field_get(this, _progressiveToken) || _class_private_field_get(this, _progressiveQueue) === null) {
        return;
    }
    const queue = _class_private_field_get(this, _progressiveQueue);
    const end = Math.min(_class_private_field_get(this, _progressiveIndex) + _class_private_field_get(this, _progressiveChunkSize), queue.length);
    this.createCustomBorders(queue.slice(_class_private_field_get(this, _progressiveIndex), end));
    _class_private_field_set(this, _progressiveIndex, end);
    this.hot.render();
    if (_class_private_field_get(this, _progressiveIndex) >= queue.length) {
        _class_private_method_get(this, _finishProgressiveApply, finishProgressiveApply).call(this);
    } else {
        _class_private_method_get(this, _scheduleProgressiveChunk, scheduleProgressiveChunk).call(this, token);
    }
}
function flushProgressiveApply() {
    if (_class_private_field_get(this, _progressiveQueue) === null) {
        return;
    }
    const queue = _class_private_field_get(this, _progressiveQueue);
    while(_class_private_field_get(this, _progressiveIndex) < queue.length){
        const end = Math.min(_class_private_field_get(this, _progressiveIndex) + _class_private_field_get(this, _progressiveChunkSize), queue.length);
        this.createCustomBorders(queue.slice(_class_private_field_get(this, _progressiveIndex), end));
        _class_private_field_set(this, _progressiveIndex, end);
    }
    _class_private_method_get(this, _finishProgressiveApply, finishProgressiveApply).call(this);
}
function finishProgressiveApply() {
    _class_private_field_set(this, _progressiveToken, _class_private_field_get(this, _progressiveToken) + 1);
    _class_private_field_set(this, _progressiveQueue, null);
    _class_private_field_set(this, _progressiveIndex, 0);
    _class_private_field_set(this, _configPassTouched, null);
    this.hot.runHooks('afterCustomBordersUpdate');
}
function cancelProgressiveApply() {
    if (_class_private_field_get(this, _progressiveQueue) === null) {
        return;
    }
    _class_private_field_set(this, _progressiveToken, _class_private_field_get(this, _progressiveToken) + 1);
    _class_private_field_set(this, _progressiveQueue, null);
    _class_private_field_set(this, _progressiveIndex, 0);
    _class_private_field_set(this, _configPassTouched, null);
}
function validateStyleSettings(customBorders) {
    customBorders.forEach((customBorder)=>{
        Object.keys(customBorder).forEach((key)=>{
            const side = customBorder[key];
            if (!isRecord(side)) {
                return;
            }
            const { style } = side;
            if ((0, _mixed.isDefined)(style) && typeof style === 'string' && !SUPPORTED_STYLES.includes(style)) {
                // eslint-disable-next-line max-len
                (0, _console.warn)(`The "${style}" border style is not supported. Please use one of the following styles: ${SUPPORTED_STYLES.join(', ')}.
The border style will be ignored.`);
                delete side.style;
            } else if ((0, _mixed.isDefined)(style) && style === 'solid') {
                // 'solid' is the default style
                delete side.style;
            }
        });
    });
}
function shiftBorders(axis, mapIndex) {
    // The in-flight progressive load was already flushed from the matching `before*` hook, while the
    // queue's coordinates still matched the grid. Flushing here instead would be too late: the core
    // shifts the cell meta before it fires the `after*` hooks, so the flushed entries would write
    // their `borders` meta onto post-shift cells the configuration never targeted.
    const survivors = [];
    (0, _array.arrayEach)(this.savedBorders, (border)=>{
        const nextIndex = mapIndex(border[axis]);
        if (nextIndex === -1) {
            return;
        }
        border[axis] = nextIndex;
        border.id = (0, _utils.createId)(border.row, border.col);
        survivors.push(border);
    });
    this.savedBorders.length = 0;
    (0, _array.arrayEach)(survivors, (border)=>this.savedBorders.push(border));
    // No render here: the `afterCreate*`/`afterRemove*` hooks fire from inside `alter()`, before it
    // finishes rewriting the column/row headers, and `alter()` renders once it is done. Forcing a
    // render mid-`alter()` paints a header row the closing render then treats as up to date, so the
    // labels stay bound to their pre-insert columns while the new column is appended at the end -
    // clicking a header then selects a different column than the one the label sits on (#11031).
    _class_private_method_get(this, _rebuildWorkingSetFromModel, rebuildWorkingSetFromModel).call(this, false);
}
function applyMoveSnapshot(axis, snapshot, toVisualIndex) {
    (0, _array.arrayEach)(this.savedBorders, (border, index)=>{
        const physicalIndex = snapshot[index];
        if (typeof physicalIndex !== 'number') {
            return;
        }
        const visualIndex = toVisualIndex(physicalIndex);
        if (typeof visualIndex !== 'number') {
            return;
        }
        border[axis] = visualIndex;
        border.id = (0, _utils.createId)(border.row, border.col);
    });
    _class_private_method_get(this, _rebuildWorkingSetFromModel, rebuildWorkingSetFromModel).call(this);
}
function rebuildWorkingSetFromModel(render = true) {
    _class_private_method_get(this, _rebuildSavedBordersIndex, rebuildSavedBordersIndex).call(this);
    _class_private_field_set(this, _bordersByRowDirty, true);
    _class_private_method_get(this, _destroyAllSelections, destroyAllSelections).call(this);
    if (render) {
        this.hot.render();
    }
}
function destroyBorderSelection(borderId) {
    const customSelection = _class_private_field_get(this, _customSelectionsCache).get(borderId);
    if (!customSelection) {
        return;
    }
    const { customSelections } = this.hot.selection.highlight;
    const index = customSelections.indexOf(customSelection);
    if (index > -1) {
        customSelections.splice(index, 1);
    }
    customSelection.destroy();
    _class_private_field_get(this, _customSelectionsCache).delete(borderId);
}
function onAfterContextMenuDefaultOptions(rawOptions) {
    if (!this.hot.getSettings()[PLUGIN_KEY]) {
        return;
    }
    if (typeof rawOptions !== 'object' || rawOptions === null) {
        return;
    }
    const defaultOptions = rawOptions;
    const { items } = defaultOptions;
    if (!Array.isArray(items)) {
        return;
    }
    items.push({
        name: '---------'
    }, {
        key: 'borders',
        name () {
            return this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_BORDERS);
        },
        disabled () {
            const range = this.getSelectedRangeActive();
            if (!range) {
                return true;
            }
            if (range.isSingleHeader()) {
                return true;
            }
            return this.selection.isSelectedByCorner();
        },
        submenu: {
            items: [
                (0, _contextMenuItem.top)(this),
                (0, _contextMenuItem.right)(this),
                (0, _contextMenuItem.bottom)(this),
                (0, _contextMenuItem.left)(this),
                (0, _contextMenuItem.noBorders)(this)
            ]
        }
    });
}
function onAfterInit() {
    this.changeBorderSettings(false);
    if (this.savedBorders.length > 0) {
        this.hot.addHookOnce('afterInit', ()=>this.hot.render());
    }
}
function scheduleMetaSyncRender() {
    if (_class_private_field_get(this, _isMetaSyncRenderScheduled)) {
        return;
    }
    _class_private_field_set(this, _isMetaSyncRenderScheduled, true);
    this.hot._registerMicrotask(()=>{
        _class_private_field_set(this, _isMetaSyncRenderScheduled, false);
        this.hot.render();
    });
}
function flushBeforeStructuralChange(source) {
    if (source === 'auto') {
        return;
    }
    _class_private_method_get(this, _flushProgressiveApply, flushProgressiveApply).call(this);
}
