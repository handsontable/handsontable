"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CustomBorders () {
        return _customBorders.CustomBorders;
    },
    get PLUGIN_KEY () {
        return _customBorders.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _customBorders.PLUGIN_PRIORITY;
    }
});
const _customBorders = require("./customBorders");
