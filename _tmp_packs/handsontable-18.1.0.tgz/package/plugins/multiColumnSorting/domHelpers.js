"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get getClassesToAdd () {
        return getClassesToAdd;
    },
    get getClassesToRemove () {
        return getClassesToRemove;
    }
});
const COLUMN_ORDER_PREFIX = 'sort';
function getClassesToAdd(columnStatesManager, column, showSortIndicator) {
    const cssClasses = [];
    if (showSortIndicator === false) {
        return cssClasses;
    }
    if (columnStatesManager.isColumnSorted(column) && columnStatesManager.getNumberOfSortedColumns() > 1) {
        cssClasses.push(`${COLUMN_ORDER_PREFIX}-${columnStatesManager.getIndexOfColumnInSortQueue(column) + 1}`);
    }
    return cssClasses;
}
function getClassesToRemove(htmlElement) {
    const cssClasses = htmlElement.className.split(' ');
    const sortSequenceRegExp = new RegExp(`^${COLUMN_ORDER_PREFIX}-[0-9]{1,2}$`);
    return cssClasses.filter((cssClass)=>sortSequenceRegExp.test(cssClass));
}
