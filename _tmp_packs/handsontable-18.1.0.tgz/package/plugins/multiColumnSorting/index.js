"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get MultiColumnSorting () {
        return _multiColumnSorting.MultiColumnSorting;
    },
    get PLUGIN_KEY () {
        return _multiColumnSorting.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _multiColumnSorting.PLUGIN_PRIORITY;
    }
});
const _multiColumnSorting = require("./multiColumnSorting");
