/* eslint-disable max-len */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "loadingContent", {
    enumerable: true,
    get: function() {
        return loadingContent;
    }
});
const _loading = require("./loading");
const _string = require("../../helpers/string");
function loadingContent({ id, icon, title, description }) {
    return `
    <div class="${_loading.LOADING_CLASS_NAME}__content">
      <i class="${_loading.LOADING_CLASS_NAME}__icon">${icon}</i>
      <div class="${_loading.LOADING_CLASS_NAME}__text">
        <h2 id="${id}-${_loading.PLUGIN_KEY}-title" class="${_loading.LOADING_CLASS_NAME}__title">${(0, _string.escapeHtml)(title)}</h2>
        ${description ? `<p id="${id}-${_loading.PLUGIN_KEY}-description" class="${_loading.LOADING_CLASS_NAME}__description">${(0, _string.escapeHtml)(description)}</p>` : ''}
      </div>
    </div>
  `;
}
