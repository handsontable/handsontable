"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Loading () {
        return _loading.Loading;
    },
    get PLUGIN_KEY () {
        return _loading.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _loading.PLUGIN_PRIORITY;
    }
});
const _loading = require("./loading");
