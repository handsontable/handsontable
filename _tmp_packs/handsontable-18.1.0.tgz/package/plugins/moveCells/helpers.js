"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "clampMoveTarget", {
    enumerable: true,
    get: function() {
        return clampMoveTarget;
    }
});
function clampMoveTarget({ pointerRow, pointerCol, grabRowOffset, grabColOffset, rangeHeight, rangeWidth, totalRows, totalCols }) {
    const rawRow = pointerRow - grabRowOffset;
    const rawCol = pointerCol - grabColOffset;
    const maxRow = Math.max(0, totalRows - rangeHeight);
    const maxCol = Math.max(0, totalCols - rangeWidth);
    return {
        row: Math.min(Math.max(0, rawRow), maxRow),
        col: Math.min(Math.max(0, rawCol), maxCol)
    };
}
