"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BasePlugin () {
        return BasePlugin;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get defaultMainSettingSymbol () {
        return defaultMainSettingSymbol;
    }
});
const _object = require("../../helpers/object");
const _errors = require("../../helpers/errors");
const _array = require("../../helpers/array");
const _registry = require("../registry");
const _registry1 = require("../../cellTypes/registry");
const _registry2 = require("../../editors/registry");
const _registry3 = require("../../renderers/registry");
const _registry4 = require("../../validators/registry");
const _eventManager = /*#__PURE__*/ _interop_require_default(require("../../eventManager"));
const _console = require("../../helpers/console");
const _templateLiteralTag = require("../../helpers/templateLiteralTag");
const _conflictRegistry = require("./conflictRegistry");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
// eslint-disable-next-line no-spaced-func, func-call-spacing
const DEPS_TYPE_CHECKERS = new Map([
    [
        'plugin',
        _registry.hasPlugin
    ],
    [
        'cell-type',
        _registry1.hasCellType
    ],
    [
        'editor',
        _registry2.hasEditor
    ],
    [
        'renderer',
        _registry3.hasRenderer
    ],
    [
        'validator',
        _registry4.hasValidator
    ]
]);
const defaultMainSettingSymbol = Symbol('mainSetting');
const PLUGIN_KEY = 'base';
const missingDepsMsgs = [];
let initializedPlugins = null;
var /**
   * Plugin settings.
   *
   * @type {object|null}
   */ _pluginSettings = /*#__PURE__*/ new WeakMap(), /**
   * Collection of the reference to the plugins hooks.
   */ _hooks = /*#__PURE__*/ new WeakMap(), /**
   * Wraps a setting function with its validator, returning a guarded wrapper that emits a warning
   * and returns undefined when the validator rejects the result.
   *
   * @param {Function} settingFn The setting function to wrap.
   * @param {Function} validator The validator function for the setting.
   * @param {string} settingName The name of the setting (used in the warning message).
   * @returns {Function} A wrapped function that validates the result before returning it.
   */ _wrapSettingWithValidator = /*#__PURE__*/ new WeakSet(), /**
   * Check if any of the keys defined in SETTING_KEYS configuration of the plugin is present in the provided
   * config object, or if the SETTING_KEYS configuration states that the plugin is relevant to the config object
   * regardless of its contents.
   *
   * @private
   * @param {Handsontable.DefaultSettings} settings The config object passed to updateSettings.
   * @returns {boolean}
   */ _isRelevantToSettings = /*#__PURE__*/ new WeakSet();
class BasePlugin {
    /**
   * Returns the plugin key used to identify and look up this plugin in Handsontable settings and the plugin registry.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * The SETTING_KEYS getter defines the keys that, when present in the config object, trigger the plugin update
   * after the updateSettings calls.
   * - When it returns true, the plugin updates after all updateSettings calls, regardless of the contents of the
   * config object.
   * - When it returns false, the plugin never updates on updateSettings calls.
   *
   * @returns {string[] | boolean}
   */ static get SETTING_KEYS() {
        return [
            this.PLUGIN_KEY
        ];
    }
    /**
   * The DEFAULT_SETTINGS getter defines the plugin default settings.
   *
   * @returns {object}
   */ static get DEFAULT_SETTINGS() {
        return {};
    }
    /**
   * Validators for plugin settings.
   *
   * @type {Function|object|null}
   */ static get SETTINGS_VALIDATORS() {
        return null;
    }
    /**
   * Initializes the plugin by resolving its name, applying settings, and checking required dependencies.
   */ init() {
        this.pluginName = this.hot.getPluginName(this);
        this.updatePluginSettings(this.hot.getSettings()[this.constructor.PLUGIN_KEY]);
        const pluginDeps = this.constructor.PLUGIN_DEPS;
        const deps = Array.isArray(pluginDeps) ? pluginDeps : [];
        if (deps.length > 0) {
            const missingDependencies = [];
            deps.forEach((dependency)=>{
                const [type, moduleName] = dependency.split(':');
                if (!DEPS_TYPE_CHECKERS.has(type)) {
                    (0, _errors.throwWithCause)(`Unknown plugin dependency type "${type}" was found.`);
                }
                if (!DEPS_TYPE_CHECKERS.get(type)(moduleName)) {
                    missingDependencies.push(` - ${moduleName} (${type})`);
                }
            });
            if (missingDependencies.length > 0) {
                const errorMsg = [
                    `The ${this.pluginName} plugin requires the following modules:\n`,
                    `${missingDependencies.join('\n')}\n`
                ].join('');
                missingDepsMsgs.push(errorMsg);
            }
        }
        if (!initializedPlugins) {
            initializedPlugins = (0, _registry.getPluginsNames)();
        }
        if (initializedPlugins.indexOf(this.pluginName) >= 0) {
            initializedPlugins.splice(initializedPlugins.indexOf(this.pluginName), 1);
        }
        this.hot.addHookOnce('afterPluginsInitialized', ()=>{
            if (this.isEnabled && this.isEnabled()) {
                if (this.isHardConflictBlocked()) {
                    this.hot.getSettings()[this.constructor.PLUGIN_KEY] = false;
                    return;
                }
                this.enablePlugin();
            }
        });
        const isAllPluginsAreInitialized = initializedPlugins.length === 0;
        if (isAllPluginsAreInitialized) {
            if (missingDepsMsgs.length > 0) {
                const errorMsg = [
                    `${missingDepsMsgs.join('\n')}\n`,
                    'You have to import and register them manually.'
                ].join('');
                missingDepsMsgs.length = 0;
                (0, _errors.throwWithCause)(errorMsg);
            }
            this.hot.runHooks('afterPluginsInitialized');
        }
        this.initialized = true;
    }
    /**
   * Whether this plugin is blocked by a registered hard conflict (another top-level setting is truthy; for example
   * nestedRows blocks pagination, or manualRowMove blocks dataProvider). Emits a console warning when blocked.
   *
   * @returns {boolean} true if the plugin must not enable.
   */ isHardConflictBlocked() {
        const pluginKey = this.constructor.PLUGIN_KEY;
        const conflict = (0, _conflictRegistry.getHardConflict)(this.hot.getSettings(), pluginKey);
        if (conflict) {
            const { incompatibleSettingKey } = conflict;
            (0, _console.warn)((0, _templateLiteralTag.toSingleLine)`The \`${pluginKey}\` plugin cannot be used with the \`${incompatibleSettingKey}\` option.\x20
        This combination is not supported. The plugin will remain disabled.`);
            return true;
        }
        return false;
    }
    /**
   * Enable plugin for this Handsontable instance.
   */ enablePlugin() {
        this.enabled = true;
    }
    /**
   * Disable plugin for this Handsontable instance.
   */ disablePlugin() {
        this.eventManager?.clear();
        this.clearHooks();
        this.enabled = false;
    }
    /**
   * Gets the plugin settings. If there is no setting under the provided key, it returns the default setting
   * provided by the DEFAULT_SETTINGS static property of the class.
   *
   * @param {string} [settingName] The setting name. If the setting name is not provided, it returns
   * the whole plugin's settings object.
   * @returns {T}
   */ getSetting(settingName) {
        const defaultSettings = this.constructor.DEFAULT_SETTINGS;
        const settingsValidators = this.constructor.SETTINGS_VALIDATORS;
        if (settingName === undefined) {
            if ((0, _object.isPlainObject)(_class_private_field_get(this, _pluginSettings))) {
                return (0, _object.assignObjectDefaults)(_class_private_field_get(this, _pluginSettings), defaultSettings);
            }
            return _class_private_field_get(this, _pluginSettings);
        }
        let settingValue;
        if ((Array.isArray(_class_private_field_get(this, _pluginSettings)) || (0, _object.isPlainObject)(_class_private_field_get(this, _pluginSettings))) && defaultSettings[defaultMainSettingSymbol] === settingName) {
            if (Array.isArray(_class_private_field_get(this, _pluginSettings))) {
                settingValue = _class_private_field_get(this, _pluginSettings);
            } else {
                settingValue = _class_private_field_get(this, _pluginSettings)[settingName] ?? defaultSettings[settingName];
            }
        } else if (settingName.includes('.')) {
            const pluginValue = (0, _object.isPlainObject)(_class_private_field_get(this, _pluginSettings)) ? (0, _object.getProperty)(_class_private_field_get(this, _pluginSettings), settingName) : undefined;
            const defaultValue = (0, _object.getProperty)(defaultSettings, settingName);
            if ((0, _object.isPlainObject)(pluginValue)) {
                settingValue = (0, _object.assignObjectDefaults)(pluginValue, (0, _object.isPlainObject)(defaultValue) ? defaultValue : {});
            } else {
                settingValue = pluginValue !== undefined ? pluginValue : defaultValue;
            }
        } else if ((0, _object.isPlainObject)(_class_private_field_get(this, _pluginSettings))) {
            settingValue = (0, _object.assignObjectDefaults)(_class_private_field_get(this, _pluginSettings), defaultSettings)[settingName];
        } else {
            settingValue = defaultSettings[settingName];
        }
        if (typeof settingValue === 'function' && settingsValidators && typeof settingsValidators === 'object') {
            const validator = settingsValidators[settingName];
            if (validator && typeof validator === 'function') {
                const wrappedFn = settingValue;
                return _class_private_method_get(this, _wrapSettingWithValidator, wrapSettingWithValidator).call(this, wrappedFn, validator, settingName);
            }
        }
        return settingValue;
    }
    /**
   * Update plugin settings.
   *
   * @param {*} newSettings New settings.
   * @returns {object} Updated settings object.
   */ updatePluginSettings(newSettings) {
        const settingsValidators = this.constructor.SETTINGS_VALIDATORS;
        if (settingsValidators && typeof settingsValidators === 'function' && typeof newSettings !== 'object') {
            const isValid = settingsValidators(newSettings);
            if (isValid === false) {
                (0, _console.warn)(`${this.pluginName} Plugin: option is not valid and it will be ignored.`);
                return;
            }
            _class_private_field_set(this, _pluginSettings, newSettings);
            return _class_private_field_get(this, _pluginSettings);
        }
        if (settingsValidators && typeof settingsValidators === 'object' && (0, _object.isPlainObject)(newSettings)) {
            if (!(0, _object.isPlainObject)(_class_private_field_get(this, _pluginSettings))) {
                _class_private_field_set(this, _pluginSettings, {
                    ...this.constructor.DEFAULT_SETTINGS
                });
            }
            // isPlainObject confirms the type after the potential reset above
            const currentSettings = (0, _object.isPlainObject)(_class_private_field_get(this, _pluginSettings)) ? _class_private_field_get(this, _pluginSettings) : {};
            Object.keys(settingsValidators).forEach((key)=>{
                if (!(key in newSettings)) {
                    return;
                }
                const validator = settingsValidators[key];
                const isValid = validator ? validator(newSettings[key]) : true;
                if (isValid === false) {
                    (0, _console.warn)(`${this.pluginName} Plugin: "${key}" option is not valid and it will be ignored.`);
                    return;
                }
                currentSettings[key] = newSettings[key];
            });
            return _class_private_field_get(this, _pluginSettings);
        }
        _class_private_field_set(this, _pluginSettings, newSettings);
        return newSettings;
    }
    /**
   * Registers a hook listener and tracks it so it can be removed automatically when the plugin is disabled.
   */ addHook(name, callback, orderIndex) {
        _class_private_field_get(this, _hooks)[name] = _class_private_field_get(this, _hooks)[name] || [];
        const hooks = _class_private_field_get(this, _hooks)[name];
        this.hot.addHook(name, callback, orderIndex);
        hooks.push(callback);
        _class_private_field_get(this, _hooks)[name] = hooks;
    }
    /**
   * Remove all hooks listeners by hook name.
   *
   * @param {string} name The hook name.
   */ removeHooks(name) {
        (0, _array.arrayEach)(_class_private_field_get(this, _hooks)[name] || [], (callback)=>{
            this.hot.removeHook(name, callback);
        });
    }
    /**
   * Clear all hooks.
   */ clearHooks() {
        const hooks = _class_private_field_get(this, _hooks);
        (0, _object.objectEach)(hooks, (callbacks, name)=>this.removeHooks(name));
        Object.keys(hooks).forEach((key)=>delete hooks[key]);
    }
    /**
   * Register function which will be immediately called after all plugins initialized.
   *
   * @param {Function} callback The listener function to add.
   */ callOnPluginsReady(callback) {
        if (this.isPluginsReady) {
            callback();
        } else {
            this.pluginsInitializedCallbacks.push(callback);
        }
    }
    /**
   * On after plugins initialized listener.
   *
   * @private
   */ onAfterPluginsInitialized() {
        (0, _array.arrayEach)(this.pluginsInitializedCallbacks, (callback)=>callback());
        this.pluginsInitializedCallbacks.length = 0;
        this.isPluginsReady = true;
    }
    /**
   * On update settings listener. Re-applies hard conflict rules when settings change so a plugin that is already
   * enabled disables if a conflicting top-level setting becomes truthy, even when this plugin's SETTING_KEYS do not
   * overlap the updateSettings payload.
   *
   * @private
   * @param {object} newSettings New set of settings passed to the updateSettings method.
   */ onUpdateSettings(newSettings) {
        if (!this.isEnabled) {
            return;
        }
        const relevantToSettings = _class_private_method_get(this, _isRelevantToSettings, isRelevantToSettings).call(this, newSettings);
        if (this.enabled && !this.isEnabled()) {
            this.disablePlugin();
        }
        if (!this.enabled && this.isEnabled()) {
            if (this.isHardConflictBlocked()) {
                return;
            }
            this.enablePlugin();
        }
        if (this.enabled && this.isEnabled() && this.isHardConflictBlocked()) {
            this.disablePlugin();
            return;
        }
        if (this.enabled && this.isEnabled() && relevantToSettings) {
            this.updatePluginSettings(newSettings[this.constructor.PLUGIN_KEY]);
            this.updatePlugin(newSettings);
        }
    }
    /**
   * Updates the plugin to use the latest options you have specified.
   *
   * @private
   */ updatePlugin(newSettings) {
    // Intentionally empty
    }
    /**
   * Destroy plugin.
   */ destroy() {
        _class_private_field_set(this, _pluginSettings, null);
        this.eventManager?.destroy();
        this.clearHooks();
        (0, _object.objectEach)(this, (_value, property)=>{
            if (property !== 'hot') {
                Reflect.set(this, property, null);
            }
        });
        delete this.t;
        // `hot` is non-writable (set via defineGetter with writable: false) so Reflect.set
        // silently fails for it. Delete the own property instead so that async guards like
        // `if (!this.hot)` return `undefined` (falsy) after the plugin is destroyed.
        Reflect.deleteProperty(this, 'hot');
    }
    /**
   * @param {object} hotInstance Handsontable instance.
   */ constructor(hotInstance){
        _class_private_method_init(this, _wrapSettingWithValidator);
        _class_private_method_init(this, _isRelevantToSettings);
        _class_private_field_init(this, _pluginSettings, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _hooks, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _pluginSettings, null);
        /**
   * The instance of the EventManager class.
   *
   * @type {EventManager}
   */ this.eventManager = new _eventManager.default(this);
        /**
   * @type {string}
   */ this.pluginName = null;
        /**
   * @type {Function[]}
   */ this.pluginsInitializedCallbacks = [];
        /**
   * @type {boolean}
   */ this.isPluginsReady = false;
        /**
   * @type {boolean}
   */ this.enabled = false;
        /**
   * @type {boolean}
   */ this.initialized = false;
        _class_private_field_set(this, _hooks, {});
        /**
     * Handsontable instance.
     *
     * @type {Core}
     */ (0, _object.defineGetter)(this, 'hot', hotInstance, {
            writable: false
        });
        initializedPlugins = null;
        this.hot.addHook('afterPluginsInitialized', ()=>this.onAfterPluginsInitialized());
        this.hot.addHook('afterUpdateSettings', (newSettings)=>{
            this.onUpdateSettings(newSettings);
        });
        this.hot.addHook('beforeInit', ()=>this.init());
    }
}
function wrapSettingWithValidator(settingFn, validator, settingName) {
    return (...args)=>{
        const result = settingFn(...args);
        const isValid = validator(result);
        if (isValid === false) {
            const formattedArgs = args.map((arg)=>typeof arg === 'string' ? `"${arg}"` : '').join(', ');
            const source = args.length > 0 ? formattedArgs : '';
            (0, _console.warn)(`${this.pluginName} Plugin: "${settingName}" function (${source}) result \
               is not valid and will be ignored.`);
            return;
        }
        return result;
    };
}
function isRelevantToSettings(settings) {
    if (!settings) {
        return false;
    }
    const settingKeys = this.constructor.SETTING_KEYS;
    // If SETTING_KEYS is declared as `true` -> update the plugin regardless of the settings declared in
    // `updateSettings`.
    // If SETTING_KEYS is declared as `false` -> DON'T update the plugin regardless of the settings declared in
    // `updateSettings`.
    if (typeof settingKeys === 'boolean') {
        return settingKeys;
    }
    for(let i = 0; i < settingKeys.length; i++){
        if (settings[settingKeys[i]] !== undefined) {
            return true;
        }
    }
    return false;
}
