"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BasePlugin () {
        return _base.BasePlugin;
    },
    get PLUGIN_KEY () {
        return _base.PLUGIN_KEY;
    },
    get defaultMainSettingSymbol () {
        return _base.defaultMainSettingSymbol;
    },
    get getHardConflict () {
        return _conflictRegistry.getHardConflict;
    },
    get registerConflict () {
        return _conflictRegistry.registerConflict;
    }
});
const _base = require("./base");
const _conflictRegistry = require("./conflictRegistry");
