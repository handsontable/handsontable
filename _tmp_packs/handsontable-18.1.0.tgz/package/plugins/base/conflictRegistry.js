"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get getHardConflict () {
        return getHardConflict;
    },
    get registerConflict () {
        return registerConflict;
    }
});
const _errors = require("../../helpers/errors");
const hardConflicts = [];
/**
 * @param {Handsontable.DefaultSettings} settings Current instance settings.
 * @param {string} incompatibleSettingKey Top-level settings key to read.
 * @returns {boolean} Whether that setting is considered active (truthy).
 */ function isIncompatibleSettingActive(settings, incompatibleSettingKey) {
    return !!settings[incompatibleSettingKey];
}
function registerConflict(blockedTargetKeyOrKeys, incompatibleSettingKeys) {
    if (Array.isArray(blockedTargetKeyOrKeys)) {
        if (typeof incompatibleSettingKeys !== 'string') {
            (0, _errors.throwWithCause)('registerConflict(blockedTargetKeys[], incompatibleSettingKeys) expects incompatibleSettingKeys ' + 'to be a string.');
        }
        for(let i = 0; i < blockedTargetKeyOrKeys.length; i += 1){
            hardConflicts.push({
                blockedKey: blockedTargetKeyOrKeys[i],
                incompatibleSettingKey: incompatibleSettingKeys
            });
        }
        return;
    }
    if (typeof blockedTargetKeyOrKeys !== 'string') {
        (0, _errors.throwWithCause)('registerConflict expects a string blocked target key when the first argument is not an array.');
    }
    const blockedKey = blockedTargetKeyOrKeys;
    if (Array.isArray(incompatibleSettingKeys)) {
        for(let i = 0; i < incompatibleSettingKeys.length; i += 1){
            const incompatibleSettingKey = incompatibleSettingKeys[i];
            if (typeof incompatibleSettingKey !== 'string') {
                (0, _errors.throwWithCause)('registerConflict(blockedTargetKey, incompatibleSettingKeys) expects incompatibleSettingKeys ' + 'to be a string array.');
            }
            hardConflicts.push({
                blockedKey,
                incompatibleSettingKey
            });
        }
        return;
    }
    if (typeof incompatibleSettingKeys === 'string') {
        hardConflicts.push({
            blockedKey,
            incompatibleSettingKey: incompatibleSettingKeys
        });
        return;
    }
    (0, _errors.throwWithCause)('Invalid registerConflict arguments.');
}
function getHardConflict(settings, blockedKey) {
    for(let i = 0; i < hardConflicts.length; i += 1){
        const entry = hardConflicts[i];
        if (entry.blockedKey === blockedKey && isIncompatibleSettingActive(settings, entry.incompatibleSettingKey)) {
            return entry;
        }
    }
    return null;
}
