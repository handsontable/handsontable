"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ManualColumnResize () {
        return _manualColumnResize.ManualColumnResize;
    },
    get PLUGIN_KEY () {
        return _manualColumnResize.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _manualColumnResize.PLUGIN_PRIORITY;
    }
});
const _manualColumnResize = require("./manualColumnResize");
