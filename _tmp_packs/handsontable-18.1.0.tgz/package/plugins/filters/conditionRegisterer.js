"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get conditions () {
        return conditions;
    },
    get getCondition () {
        return getCondition;
    },
    get getConditionDescriptor () {
        return getConditionDescriptor;
    },
    get registerCondition () {
        return registerCondition;
    }
});
const _errors = require("../../helpers/errors");
const conditions = {};
function getCondition(name, args) {
    if (!conditions[name]) {
        (0, _errors.throwWithCause)(`Filter condition "${name}" does not exist.`);
    }
    const { condition, descriptor } = conditions[name];
    let conditionArguments = args;
    if (descriptor.inputValuesDecorator) {
        const decorator = descriptor.inputValuesDecorator;
        conditionArguments = decorator(conditionArguments);
    }
    return function(dataRow) {
        return condition.apply(dataRow.meta.instance, [
            dataRow,
            conditionArguments
        ]);
    };
}
function getConditionDescriptor(name) {
    if (!conditions[name]) {
        (0, _errors.throwWithCause)(`Filter condition "${name}" does not exist.`);
    }
    return conditions[name].descriptor;
}
function registerCondition(name, condition, descriptor) {
    descriptor.key = name;
    conditions[name] = {
        condition,
        descriptor
    };
}
