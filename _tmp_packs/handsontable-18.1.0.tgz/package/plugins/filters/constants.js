"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CONDITION_BEGINS_WITH () {
        return _beginsWith.CONDITION_NAME;
    },
    get CONDITION_BETWEEN () {
        return _between.CONDITION_NAME;
    },
    get CONDITION_BY_VALUE () {
        return _byValue.CONDITION_NAME;
    },
    get CONDITION_CONTAINS () {
        return _contains.CONDITION_NAME;
    },
    get CONDITION_DATE_AFTER () {
        return _after.CONDITION_NAME;
    },
    get CONDITION_DATE_AFTER_OR_EQUAL () {
        return _afterOrEqual.CONDITION_NAME;
    },
    get CONDITION_DATE_BEFORE () {
        return _before.CONDITION_NAME;
    },
    get CONDITION_DATE_BEFORE_OR_EQUAL () {
        return _beforeOrEqual.CONDITION_NAME;
    },
    get CONDITION_EMPTY () {
        return _empty.CONDITION_NAME;
    },
    get CONDITION_ENDS_WITH () {
        return _endsWith.CONDITION_NAME;
    },
    get CONDITION_EQUAL () {
        return _equal.CONDITION_NAME;
    },
    get CONDITION_FALSE () {
        return _false.CONDITION_NAME;
    },
    get CONDITION_GREATER_THAN () {
        return _greaterThan.CONDITION_NAME;
    },
    get CONDITION_GREATER_THAN_OR_EQUAL () {
        return _greaterThanOrEqual.CONDITION_NAME;
    },
    get CONDITION_LESS_THAN () {
        return _lessThan.CONDITION_NAME;
    },
    get CONDITION_LESS_THAN_OR_EQUAL () {
        return _lessThanOrEqual.CONDITION_NAME;
    },
    get CONDITION_NONE () {
        return _none.CONDITION_NAME;
    },
    get CONDITION_NOT_BETWEEN () {
        return _notBetween.CONDITION_NAME;
    },
    get CONDITION_NOT_CONTAINS () {
        return _notContains.CONDITION_NAME;
    },
    get CONDITION_NOT_EMPTY () {
        return _notEmpty.CONDITION_NAME;
    },
    get CONDITION_NOT_EQUAL () {
        return _notEqual.CONDITION_NAME;
    },
    get CONDITION_TODAY () {
        return _today.CONDITION_NAME;
    },
    get CONDITION_TOMORROW () {
        return _tomorrow.CONDITION_NAME;
    },
    get CONDITION_TRUE () {
        return _true.CONDITION_NAME;
    },
    get CONDITION_YESTERDAY () {
        return _yesterday.CONDITION_NAME;
    },
    get OPERATION_AND () {
        return _conjunction.OPERATION_ID;
    },
    get OPERATION_OR () {
        return _disjunction.OPERATION_ID;
    },
    get OPERATION_OR_THEN_VARIABLE () {
        return _disjunctionWithExtraCondition.OPERATION_ID;
    },
    get TYPES () {
        return TYPES;
    },
    get TYPE_DATE () {
        return TYPE_DATE;
    },
    get TYPE_INTL_DATE () {
        return TYPE_INTL_DATE;
    },
    get TYPE_INTL_DATETIME () {
        return TYPE_INTL_DATETIME;
    },
    get TYPE_INTL_TIME () {
        return TYPE_INTL_TIME;
    },
    get TYPE_NUMERIC () {
        return TYPE_NUMERIC;
    },
    get TYPE_TEXT () {
        return TYPE_TEXT;
    },
    get /**
 * Get options list for conditional filter by data type (e.q: `'text'`, `'numeric'`, `'date'`).
 *
 * @private
 * @param {string} type The data type.
 * @returns {object}
 */ default () {
        return getOptionsList;
    }
});
const _array = require("../../helpers/array");
const _predefinedItems = require("../contextMenu/predefinedItems");
const _conditionRegisterer = require("./conditionRegisterer");
const _none = require("./condition/none");
const _empty = require("./condition/empty");
const _notEmpty = require("./condition/notEmpty");
const _equal = require("./condition/equal");
const _notEqual = require("./condition/notEqual");
const _greaterThan = require("./condition/greaterThan");
const _greaterThanOrEqual = require("./condition/greaterThanOrEqual");
const _lessThan = require("./condition/lessThan");
const _lessThanOrEqual = require("./condition/lessThanOrEqual");
const _between = require("./condition/between");
const _notBetween = require("./condition/notBetween");
const _beginsWith = require("./condition/beginsWith");
const _endsWith = require("./condition/endsWith");
const _contains = require("./condition/contains");
const _notContains = require("./condition/notContains");
const _before = require("./condition/date/before");
const _beforeOrEqual = require("./condition/date/beforeOrEqual");
const _after = require("./condition/date/after");
const _afterOrEqual = require("./condition/date/afterOrEqual");
const _tomorrow = require("./condition/date/tomorrow");
const _today = require("./condition/date/today");
const _yesterday = require("./condition/date/yesterday");
const _before1 = require("./condition/intlDate/before");
const _beforeOrEqual1 = require("./condition/intlDate/beforeOrEqual");
const _after1 = require("./condition/intlDate/after");
const _afterOrEqual1 = require("./condition/intlDate/afterOrEqual");
const _between1 = require("./condition/intlDate/between");
const _tomorrow1 = require("./condition/intlDate/tomorrow");
const _today1 = require("./condition/intlDate/today");
const _yesterday1 = require("./condition/intlDate/yesterday");
const _before2 = require("./condition/intlTime/before");
const _beforeOrEqual2 = require("./condition/intlTime/beforeOrEqual");
const _after2 = require("./condition/intlTime/after");
const _afterOrEqual2 = require("./condition/intlTime/afterOrEqual");
const _between2 = require("./condition/intlTime/between");
const _before3 = require("./condition/intlDatetime/before");
const _beforeOrEqual3 = require("./condition/intlDatetime/beforeOrEqual");
const _after3 = require("./condition/intlDatetime/after");
const _afterOrEqual3 = require("./condition/intlDatetime/afterOrEqual");
const _between3 = require("./condition/intlDatetime/between");
const _tomorrow2 = require("./condition/intlDatetime/tomorrow");
const _today2 = require("./condition/intlDatetime/today");
const _yesterday2 = require("./condition/intlDatetime/yesterday");
const _false = require("./condition/false");
const _byValue = require("./condition/byValue");
const _true = require("./condition/true");
const _conjunction = require("./logicalOperations/conjunction");
const _disjunction = require("./logicalOperations/disjunction");
const _disjunctionWithExtraCondition = require("./logicalOperations/disjunctionWithExtraCondition");
const TYPE_NUMERIC = 'numeric';
const TYPE_TEXT = 'text';
const TYPE_DATE = 'date';
const TYPE_INTL_DATE = 'intl-date';
const TYPE_INTL_TIME = 'intl-time';
const TYPE_INTL_DATETIME = 'intl-datetime';
const TYPES = {
    [TYPE_NUMERIC]: [
        _none.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _empty.CONDITION_NAME,
        _notEmpty.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _equal.CONDITION_NAME,
        _notEqual.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _greaterThan.CONDITION_NAME,
        _greaterThanOrEqual.CONDITION_NAME,
        _lessThan.CONDITION_NAME,
        _lessThanOrEqual.CONDITION_NAME,
        _between.CONDITION_NAME,
        _notBetween.CONDITION_NAME
    ],
    [TYPE_TEXT]: [
        _none.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _empty.CONDITION_NAME,
        _notEmpty.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _equal.CONDITION_NAME,
        _notEqual.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _beginsWith.CONDITION_NAME,
        _endsWith.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _contains.CONDITION_NAME,
        _notContains.CONDITION_NAME
    ],
    [TYPE_DATE]: [
        _none.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _empty.CONDITION_NAME,
        _notEmpty.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _equal.CONDITION_NAME,
        _notEqual.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _before.CONDITION_NAME,
        _beforeOrEqual.CONDITION_NAME,
        _after.CONDITION_NAME,
        _afterOrEqual.CONDITION_NAME,
        _between.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _tomorrow.CONDITION_NAME,
        _today.CONDITION_NAME,
        _yesterday.CONDITION_NAME
    ],
    [TYPE_INTL_DATE]: [
        _none.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _empty.CONDITION_NAME,
        _notEmpty.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _equal.CONDITION_NAME,
        _notEqual.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _before1.CONDITION_NAME,
        _beforeOrEqual1.CONDITION_NAME,
        _after1.CONDITION_NAME,
        _afterOrEqual1.CONDITION_NAME,
        _between1.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _tomorrow1.CONDITION_NAME,
        _today1.CONDITION_NAME,
        _yesterday1.CONDITION_NAME
    ],
    [TYPE_INTL_TIME]: [
        _none.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _empty.CONDITION_NAME,
        _notEmpty.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _equal.CONDITION_NAME,
        _notEqual.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _beginsWith.CONDITION_NAME,
        _endsWith.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _contains.CONDITION_NAME,
        _notContains.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _before2.CONDITION_NAME,
        _beforeOrEqual2.CONDITION_NAME,
        _after2.CONDITION_NAME,
        _afterOrEqual2.CONDITION_NAME,
        _between2.CONDITION_NAME
    ],
    [TYPE_INTL_DATETIME]: [
        _none.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _empty.CONDITION_NAME,
        _notEmpty.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _equal.CONDITION_NAME,
        _notEqual.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _before3.CONDITION_NAME,
        _beforeOrEqual3.CONDITION_NAME,
        _after3.CONDITION_NAME,
        _afterOrEqual3.CONDITION_NAME,
        _between3.CONDITION_NAME,
        _predefinedItems.SEPARATOR,
        _tomorrow2.CONDITION_NAME,
        _today2.CONDITION_NAME,
        _yesterday2.CONDITION_NAME
    ]
};
function getOptionsList(type) {
    const items = [];
    let typeName = type;
    if (!TYPES[typeName]) {
        typeName = TYPE_TEXT;
    }
    (0, _array.arrayEach)(TYPES[typeName], (typeValue)=>{
        let option;
        if (typeValue === _predefinedItems.SEPARATOR) {
            option = {
                name: _predefinedItems.SEPARATOR
            };
        } else {
            option = {
                ...(0, _conditionRegisterer.getConditionDescriptor)(typeValue)
            };
        }
        items.push(option);
    });
    return items;
}
