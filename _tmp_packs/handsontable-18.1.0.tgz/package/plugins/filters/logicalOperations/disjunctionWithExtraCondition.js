"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get OPERATION_ID () {
        return OPERATION_ID;
    },
    get SHORT_NAME_FOR_COMPONENT () {
        return SHORT_NAME_FOR_COMPONENT;
    },
    get operationResult () {
        return operationResult;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
const _errors = require("../../../helpers/errors");
const _logicalOperationRegisterer = require("../logicalOperationRegisterer");
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const OPERATION_ID = 'disjunctionWithExtraCondition';
const SHORT_NAME_FOR_COMPONENT = _constants.FILTERS_LABELS_DISJUNCTION;
function operationResult(conditions, value) {
    if (conditions.length < 3) {
        (0, _errors.throwWithCause)('Operation doesn\'t work on less then three conditions.');
    }
    const lastCondition = conditions[conditions.length - 1];
    const otherConditions = conditions.slice(0, conditions.length - 1);
    return otherConditions.some((condition)=>Boolean(condition.func(value))) && Boolean(lastCondition.func(value));
}
(0, _logicalOperationRegisterer.registerOperation)(OPERATION_ID, SHORT_NAME_FOR_COMPONENT, operationResult);
