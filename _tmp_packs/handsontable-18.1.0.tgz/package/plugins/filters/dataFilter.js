"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _array = require("../../helpers/array");
/**
 * @private
 * @class DataFilter
 */ class DataFilter {
    /**
   * Filter data based on the conditions collection.
   *
   * @returns {Array}
   */ filter() {
        let filteredData = [];
        (0, _array.arrayEach)(this.conditionCollection.getFilteredColumns(), (physicalColumn, index)=>{
            let columnData;
            if (index) {
                // Materialize only the rows that survived the previous columns' conditions instead of
                // re-reading (and re-creating cell meta for) every source row once per filtered column.
                const survivingRows = (0, _array.arrayMap)(filteredData, (rowData)=>rowData.row);
                columnData = this.columnDataFactory(physicalColumn, survivingRows);
            } else {
                columnData = this.columnDataFactory(physicalColumn);
            }
            filteredData = this.filterByColumn(physicalColumn, columnData);
        });
        return filteredData;
    }
    /**
   * Filter data based on specified physical column index.
   *
   * @param {number} column The physical column index.
   * @param {Array} [dataSource] Data source as array of objects with `value` and `meta` keys (e.g. `{value: 'foo', meta: {}}`).
   * @returns {Array} Returns filtered data.
   */ filterByColumn(column, dataSource = []) {
        const filteredData = [];
        (0, _array.arrayEach)(dataSource, (dataRow)=>{
            if (dataRow !== undefined && this.conditionCollection.isMatch(dataRow, column)) {
                filteredData.push(dataRow);
            }
        });
        return filteredData;
    }
    /**
   * Initializes the data filter with a condition collection that provides filtering logic and a factory function that supplies column source data.
   */ constructor(conditionCollection, columnDataFactory = ()=>[]){
        this.conditionCollection = conditionCollection;
        this.columnDataFactory = columnDataFactory;
    }
}
const _default = DataFilter;
