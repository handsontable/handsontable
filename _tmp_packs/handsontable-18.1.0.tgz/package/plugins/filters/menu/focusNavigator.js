"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createFocusNavigator", {
    enumerable: true,
    get: function() {
        return createFocusNavigator;
    }
});
const _paginator = require("../../../utils/paginator");
const _element = require("../../../helpers/dom/element");
const _multipleSelect = require("../ui/multipleSelect");
function createFocusNavigator(elements) {
    const navigator = (0, _paginator.createPaginator)({
        initialPage: 0,
        size: ()=>elements.length,
        onItemSelect: (currentIndex, directItemChange)=>{
            const element = elements[currentIndex];
            if (element instanceof _multipleSelect.MultipleSelectUI) {
                return directItemChange;
            }
            const elementRecord = element;
            if ((0, _element.isHTMLElement)(elementRecord.element) && !(0, _element.isVisible)(elementRecord.element)) {
                return false;
            }
            element.focus();
        }
    });
    return navigator;
}
