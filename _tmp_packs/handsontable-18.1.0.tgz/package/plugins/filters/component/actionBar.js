"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ActionBarComponent", {
    enumerable: true,
    get: function() {
        return ActionBarComponent;
    }
});
const _element = require("../../../helpers/dom/element");
const _array = require("../../../helpers/array");
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
const _base = require("./_base");
const _input = require("../ui/input");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
var /**
   * On button click listener.
   *
   * @param {Event} event DOM event.
   * @param {InputUI} button InputUI object.
   */ _onButtonClick = /*#__PURE__*/ new WeakSet();
class ActionBarComponent extends _base.BaseComponent {
    /**
   * Returns the identifier string for the OK action button.
   */ static get BUTTON_OK() {
        return 'ok';
    }
    /**
   * Returns the identifier string for the Cancel action button.
   */ static get BUTTON_CANCEL() {
        return 'cancel';
    }
    /**
   * Register all necessary hooks.
   *
   * @private
   */ registerHooks() {
        (0, _array.arrayEach)(this.elements, (element)=>{
            element.addLocalHook('click', (event, button)=>_class_private_method_get(this, _onButtonClick, onButtonClick).call(this, event, button));
        });
    }
    /**
   * Get menu object descriptor.
   *
   * @returns {object}
   */ getMenuItemDescriptor() {
        return {
            key: this.id,
            name: this.name,
            isCommand: false,
            disableSelection: true,
            hidden: ()=>this.isHidden(),
            renderer: (hot, wrapper)=>{
                if ((0, _element.isHTMLElement)(wrapper.parentNode)) {
                    (0, _element.addClass)(wrapper.parentNode, 'htFiltersMenuActionBar');
                }
                (0, _array.arrayEach)(this.elements, (ui)=>{
                    const el = ui.element;
                    if (el) {
                        wrapper.appendChild(el);
                    }
                });
                return wrapper;
            }
        };
    }
    /**
   * Fire accept event.
   */ accept() {
        this.runLocalHooks('accept');
    }
    /**
   * Fire cancel event.
   */ cancel() {
        this.runLocalHooks('cancel');
    }
    /**
   * Initializes the action bar component with OK and Cancel buttons.
   */ constructor(hotInstance, options){
        super(hotInstance, {
            id: options.id,
            stateless: true
        }), _class_private_method_init(this, _onButtonClick), /**
   * The name of the component.
   *
   * @type {string}
   */ this.name = '';
        this.name = options.name;
        this.elements.push(new _input.InputUI(hotInstance, {
            type: 'button',
            value: _constants.FILTERS_BUTTONS_OK,
            className: 'htUIButton htUIButtonOK',
            identifier: ActionBarComponent.BUTTON_OK
        }));
        this.elements.push(new _input.InputUI(hotInstance, {
            type: 'button',
            value: _constants.FILTERS_BUTTONS_CANCEL,
            className: 'htUIButton htUIButtonCancel',
            identifier: ActionBarComponent.BUTTON_CANCEL
        }));
        this.registerHooks();
    }
}
function onButtonClick(event, button) {
    if (button.options.identifier === ActionBarComponent.BUTTON_OK) {
        this.accept();
    } else {
        this.cancel();
    }
}
