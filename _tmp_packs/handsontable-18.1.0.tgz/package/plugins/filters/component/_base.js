"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BaseComponent", {
    enumerable: true,
    get: function() {
        return BaseComponent;
    }
});
const _array = require("../../../helpers/array");
const _errors = require("../../../helpers/errors");
const _object = require("../../../helpers/object");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../../mixins/localHooks"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
class BaseComponent {
    /**
   * Gets the list of elements from which the component is built.
   *
   * @returns {BaseUI[]}
   */ getElements() {
        return this.elements;
    }
    /**
   * Reset elements to its initial state.
   */ reset() {
        (0, _array.arrayEach)(this.elements, (ui)=>ui.reset());
    }
    /**
   * Hide component.
   */ hide() {
        this.hidden = true;
    }
    /**
   * Show component.
   */ show() {
        this.hidden = false;
    }
    /**
   * Check if component is hidden.
   *
   * @returns {boolean}
   */ isHidden() {
        return this.hot === null || this.hidden;
    }
    /**
   * Restores the component state from the given physical column index. The method
   * internally calls the `setState` method. The state then is individually processed
   * by each component.
   *
   * @param {number} physicalColumn The physical column index.
   */ restoreState(physicalColumn) {
        if (this.state) {
            this.setState(this.state.getValueAtIndex(physicalColumn));
        }
    }
    /**
   * The custom logic for component state restoring.
   */ setState(_value) {
        (0, _errors.throwWithCause)('The state setting logic is not implemented');
    }
    /**
   * Saves the component state to the given physical column index. The method
   * internally calls the `getState` method, which returns the current state of
   * the component.
   *
   * @param {number} physicalColumn The physical column index.
   */ saveState(physicalColumn) {
        if (this.state) {
            this.state.setValueAtIndex(physicalColumn, this.getState());
        }
    }
    /**
   * The custom logic for component state gathering (for stateful components).
   */ getState() {
        (0, _errors.throwWithCause)('The state gathering logic is not implemented');
        return {};
    }
    /**
   * Returns the menu item descriptor for this component (used to add it to the dropdown menu).
   *
   * @returns {object}
   */ getMenuItemDescriptor() {
        (0, _errors.throwWithCause)('The menu item descriptor logic is not implemented');
        return {};
    }
    /**
   * Destroy element.
   */ destroy() {
        this.hot?.columnIndexMapper.unregisterMap(this.stateId);
        this.clearLocalHooks();
        (0, _array.arrayEach)(this.elements, (ui)=>ui.destroy());
        this.state = null;
        this.elements.length = 0;
        this.hot = null;
    }
    /**
   * Initializes the filter component with a Handsontable instance, assigns the component ID, and optionally registers a column index map for stateful components.
   */ constructor(hotInstance, { id, stateless = true }){
        /**
   * List of registered component UI elements.
   *
   * @type {Array}
   */ this.elements = [];
        /**
   * Flag which determines if element is hidden.
   *
   * @type {boolean}
   */ this.hidden = false;
        /**
   * The component states id.
   *
   * @type {string}
   */ this.stateId = '';
        this.hot = hotInstance;
        this.id = id;
        this.stateId = `Filters.component.${this.id}`;
        this.state = stateless ? null : this.hot.columnIndexMapper.createAndRegisterIndexMap(this.stateId, 'linkedPhysicalIndexToValue');
    }
}
(0, _object.mixin)(BaseComponent, _localHooks.default);
