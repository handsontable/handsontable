"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _array = require("../../helpers/array");
const _object = require("../../helpers/object");
const _function = require("../../helpers/function");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../mixins/localHooks"));
const _conditionCollection = /*#__PURE__*/ _interop_require_default(require("./conditionCollection"));
const _dataFilter = /*#__PURE__*/ _interop_require_default(require("./dataFilter"));
const _utils = require("./utils");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * Memoized full-column results of `columnDataFactory`, keyed by physical column index. Active
   * (non-null) only for the duration of one state update or one `flush()` batch — reading a column's
   * data map walks every source row, and one update reads the same columns several times.
   */ _columnDataCache = /*#__PURE__*/ new WeakMap(), /**
   * Runs the callback with the full-column data memo active. Source data does not change while
   * component states are recomputed, so every full-column read within one update (the edited
   * column, the first dependent column, and each column re-scanned by `DataFilter`) can share
   * one data map per column. Nested activations reuse the outer cache.
   *
   * @param {Function} callback The callback to run with the cache active.
   */ _withColumnDataCache = /*#__PURE__*/ new WeakSet(), /**
   * Reads the data map for a column through the active memo. Subset reads (with `physicalRows`)
   * are already narrowed to surviving rows, so only full-column reads are memoized.
   *
   * @param {number} physicalColumn The physical column index.
   * @param {number[]} [physicalRows] When provided, only these physical rows are read.
   * @returns {Array} Array of objects with `meta` and `value`, one per read row.
   */ _getColumnData = /*#__PURE__*/ new WeakSet(), /**
   * On before modify condition (add or remove from collection),.
   *
   * @param {number} column Column index.
   * @private
   */ _onConditionBeforeModify = /*#__PURE__*/ new WeakSet(), /**
   * Performs the actual state update for the column. Runs with the full-column data memo active.
   *
   * @param {number} column The column index.
   * @param {object} conditionArgsChange Object describing condition changes which can be handled by filters on `update` hook.
   */ _updateStatesAtColumnInternal = /*#__PURE__*/ new WeakSet(), /**
   * On before conditions clean listener.
   *
   * @private
   */ _onConditionBeforeClean = /*#__PURE__*/ new WeakSet(), /**
   * On after conditions clean listener.
   *
   * @private
   */ _onConditionAfterClean = /*#__PURE__*/ new WeakSet();
/**
 * Class which is designed for observing changes in condition collection. When condition is changed by user at specified
 * column it's necessary to update all conditions defined after this edited one.
 *
 * Object fires `update` hook for every column conditions change.
 *
 * @private
 * @class ConditionUpdateObserver
 */ class ConditionUpdateObserver {
    /**
   * Enable grouping changes. Grouping is helpful in situations when a lot of conditions is added in one moment. Instead of
   * trigger `update` hook for every condition by adding/removing you can group this changes and call `flush` method to trigger
   * it once.
   */ groupChanges() {
        this.grouping = true;
    }
    /**
   * Flush all collected changes. This trigger `update` hook for every previously collected change from condition collection.
   */ flush() {
        this.grouping = false;
        _class_private_method_get(this, _withColumnDataCache, withColumnDataCache).call(this, ()=>{
            (0, _array.arrayEach)(this.changes, (column)=>{
                this.updateStatesAtColumn(column);
            });
        });
        this.changes.length = 0;
    }
    /**
   * Update all related states which should be changed after invoking changes applied to current column.
   *
   * @param {number} column The column index.
   * @param {object} conditionArgsChange Object describing condition changes which can be handled by filters on `update` hook.
   * It contains keys `conditionKey` and `conditionValue` which refers to change specified key of condition to specified value
   * based on referred keys.
   */ updateStatesAtColumn(column, conditionArgsChange) {
        if (this.grouping) {
            if (this.changes.indexOf(column) === -1) {
                this.changes.push(column);
            }
            return;
        }
        _class_private_method_get(this, _withColumnDataCache, withColumnDataCache).call(this, ()=>_class_private_method_get(this, _updateStatesAtColumnInternal, updateStatesAtColumnInternal).call(this, column, conditionArgsChange));
    }
    /**
   * Destroy instance.
   */ destroy() {
        this.clearLocalHooks();
        (0, _object.objectEach)(this, (_value, property)=>{
            this[property] = null;
        });
    }
    /**
   * Initializes the observer with the Handsontable instance, a condition collection to watch, and an optional factory for column source data.
   */ constructor(hot, conditionCollection, columnDataFactory = ()=>[]){
        _class_private_method_init(this, _withColumnDataCache);
        _class_private_method_init(this, _getColumnData);
        _class_private_method_init(this, _onConditionBeforeModify);
        _class_private_method_init(this, _updateStatesAtColumnInternal);
        _class_private_method_init(this, _onConditionBeforeClean);
        _class_private_method_init(this, _onConditionAfterClean);
        _class_private_field_init(this, _columnDataCache, {
            writable: true,
            value: void 0
        });
        /**
   * Collected changes when grouping is enabled.
   *
   * @type {Array}
   * @default []
   */ this.changes = [];
        /**
   * Flag which determines if grouping events is enabled.
   *
   * @type {boolean}
   */ this.grouping = false;
        /**
   * The latest known position of edited conditions at specified column index.
   *
   * @type {number}
   * @default -1
   */ this.latestEditedColumnPosition = -1;
        /**
   * The latest known order of conditions stack.
   *
   * @type {Array}
   */ this.latestOrderStack = [];
        _class_private_field_set(this, _columnDataCache, null);
        this.hot = hot;
        this.conditionCollection = conditionCollection;
        this.columnDataFactory = columnDataFactory;
        this.conditionCollection.addLocalHook('beforeRemove', (column)=>_class_private_method_get(this, _onConditionBeforeModify, onConditionBeforeModify).call(this, column));
        this.conditionCollection.addLocalHook('afterRemove', (column)=>this.updateStatesAtColumn(column));
        this.conditionCollection.addLocalHook('afterAdd', (column)=>this.updateStatesAtColumn(column));
        this.conditionCollection.addLocalHook('beforeClean', ()=>_class_private_method_get(this, _onConditionBeforeClean, onConditionBeforeClean).call(this));
        this.conditionCollection.addLocalHook('afterClean', ()=>_class_private_method_get(this, _onConditionAfterClean, onConditionAfterClean).call(this));
    }
}
function withColumnDataCache(callback) {
    if (_class_private_field_get(this, _columnDataCache) !== null) {
        callback();
        return;
    }
    _class_private_field_set(this, _columnDataCache, new Map());
    try {
        callback();
    } finally{
        _class_private_field_set(this, _columnDataCache, null);
    }
}
function getColumnData(physicalColumn, physicalRows) {
    if (physicalRows || _class_private_field_get(this, _columnDataCache) === null) {
        return this.columnDataFactory(physicalColumn, physicalRows);
    }
    let columnData = _class_private_field_get(this, _columnDataCache).get(physicalColumn);
    if (!columnData) {
        columnData = this.columnDataFactory(physicalColumn);
        _class_private_field_get(this, _columnDataCache).set(physicalColumn, columnData);
    }
    return columnData;
}
function onConditionBeforeModify(column) {
    this.latestEditedColumnPosition = this.conditionCollection.getColumnStackPosition(column);
}
function updateStatesAtColumnInternal(column, conditionArgsChange) {
    const allConditions = this.conditionCollection.exportAllConditions();
    let editedColumnPosition = this.conditionCollection.getColumnStackPosition(column);
    if (editedColumnPosition === -1) {
        editedColumnPosition = this.latestEditedColumnPosition;
    }
    // Collection of all conditions defined before currently edited `column` (without edited one)
    const conditionsBefore = allConditions.slice(0, editedColumnPosition);
    // Collection of all conditions defined after currently edited `column` (with edited one)
    const conditionsAfter = allConditions.slice(editedColumnPosition);
    // Make sure that conditionAfter doesn't contain edited column conditions
    if (conditionsAfter.length && conditionsAfter[0].column === column) {
        conditionsAfter.shift();
    }
    const visibleDataFactory = (0, _function.curry)((curriedConditionsBefore, curriedColumn, conditionsStack = [])=>{
        const splitConditionCollection = new _conditionCollection.default(this.hot, false);
        const curriedConditionsBeforeArray = [].concat(curriedConditionsBefore, conditionsStack);
        // Create new condition collection to determine what rows should be visible in "filter by value" box
        // in the next conditions in the chain
        splitConditionCollection.importAllConditions(curriedConditionsBeforeArray);
        const allRows = _class_private_method_get(this, _getColumnData, getColumnData).call(this, Number(curriedColumn));
        let visibleRows;
        if (splitConditionCollection.isEmpty()) {
            visibleRows = allRows;
        } else {
            visibleRows = new _dataFilter.default(splitConditionCollection, (physicalColumn, physicalRows)=>_class_private_method_get(this, _getColumnData, getColumnData).call(this, physicalColumn, physicalRows)).filter();
        }
        // Correlate rows through the immutable `row` property of the data-map entries. The coordinate
        // stamps on `meta` are shared with every other meta reader (each read re-stamps them), so they
        // must not be used to match rows between two reads.
        visibleRows = (0, _array.arrayMap)(visibleRows, (rowData)=>rowData.row);
        const visibleRowsAssertion = (0, _utils.createArrayAssertion)(visibleRows);
        splitConditionCollection.destroy();
        return (0, _array.arrayFilter)(allRows, (rowData)=>{
            return visibleRowsAssertion(rowData.row);
        });
    })(conditionsBefore);
    const editedConditions = [
        ...this.conditionCollection.getConditions(column)
    ];
    this.runLocalHooks('update', {
        editedConditionStack: {
            column,
            conditions: editedConditions
        },
        dependentConditionStacks: conditionsAfter,
        filteredRowsFactory: visibleDataFactory,
        conditionArgsChange
    });
}
function onConditionBeforeClean() {
    this.latestOrderStack = this.conditionCollection.getFilteredColumns();
}
function onConditionAfterClean() {
    _class_private_method_get(this, _withColumnDataCache, withColumnDataCache).call(this, ()=>{
        (0, _array.arrayEach)(this.latestOrderStack, (column)=>{
            this.updateStatesAtColumn(column);
        });
    });
}
(0, _object.mixin)(ConditionUpdateObserver, _localHooks.default);
const _default = ConditionUpdateObserver;
