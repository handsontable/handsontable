"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BaseUI", {
    enumerable: true,
    get: function() {
        return BaseUI;
    }
});
const _object = require("../../../helpers/object");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../../mixins/localHooks"));
const _eventManager = /*#__PURE__*/ _interop_require_default(require("../../../eventManager"));
const _element = require("../../../helpers/dom/element");
const _array = require("../../../helpers/array");
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const STATE_BUILT = 'built';
const STATE_BUILDING = 'building';
const EVENTS_TO_REGISTER = [
    'click',
    'input',
    'keydown',
    'keypress',
    'keyup',
    'focus',
    'blur',
    'change'
];
class BaseUI {
    /**
   * Returns the default configuration options applied to a new UI component instance.
   */ static get DEFAULTS() {
        return (0, _object.clone)({
            className: '',
            value: '',
            tagName: 'div',
            children: [],
            wrapIt: true
        });
    }
    /**
   * Set the element value.
   *
   * @param {*} value Set the component value.
   */ setValue(value) {
        this.options.value = value;
        this.update();
    }
    /**
   * Get the element value.
   *
   * @returns {*}
   */ getValue() {
        return this.options.value;
    }
    /**
   * Get element as a DOM object.
   *
   * @returns {Element}
   */ get element() {
        if (this.buildState === STATE_BUILDING) {
            return this._element;
        }
        if (this.buildState === STATE_BUILT) {
            this.update();
            return this._element;
        }
        this.buildState = STATE_BUILDING;
        this.build();
        this.buildState = STATE_BUILT;
        return this._element;
    }
    /**
   * Check if element was built (built whole DOM structure).
   *
   * @returns {boolean}
   */ isBuilt() {
        return this.buildState === STATE_BUILT;
    }
    /**
   * Translate value if it is possible. It's checked if value belongs to namespace of translated phrases.
   *
   * @param {*} value Value which will may be translated.
   * @returns {*} Translated value if translation was possible, original value otherwise.
   */ translateIfPossible(value) {
        if (typeof value === 'string' && value.startsWith(_constants.FILTERS_NAMESPACE)) {
            return this.hot?.getTranslatedPhrase(value) ?? value;
        }
        return value;
    }
    /**
   * Build DOM structure.
   */ build() {
        if (!this._element || !this.hot) {
            return;
        }
        const rootElement = this._element;
        const { eventManager } = this;
        const registerEvent = (element, eventName)=>{
            eventManager?.addEventListener(element, eventName, (event)=>this.runLocalHooks(eventName, event, this));
        };
        if (!this.buildState) {
            this.buildState = STATE_BUILDING;
        }
        // prevents "hot.unlisten()" call when clicked
        // (https://github.com/handsontable/handsontable/blob/master/handsontable/src/tableView.js#L317-L321)
        rootElement.dataset.hotInput = 'true';
        if (this.options.tabIndex !== undefined) {
            rootElement.setAttribute('tabindex', String(this.options.tabIndex));
        }
        if (this.options.role !== undefined) {
            rootElement.setAttribute('role', this.options.role);
        }
        if (this.options.className) {
            (0, _element.addClass)(rootElement, this.options.className);
        }
        if (this.options.children?.length) {
            (0, _array.arrayEach)(this.options.children, (element)=>{
                const el = element.element;
                if (el) {
                    rootElement.appendChild(el);
                }
            });
        } else if (this.options.wrapIt) {
            const element = this.hot.rootDocument.createElement(this.options.tagName ?? 'div');
            // prevents "hot.unlisten()" call when clicked
            // (https://github.com/handsontable/handsontable/blob/master/handsontable/src/tableView.js#L317-L321)
            element.dataset.hotInput = 'true';
            (0, _object.objectEach)(this.options, (value, key)=>{
                if (element[key] !== undefined && key !== 'className' && key !== 'tagName' && key !== 'children') {
                    element[key] = this.translateIfPossible(value);
                }
            });
            rootElement.appendChild(element);
            (0, _array.arrayEach)(EVENTS_TO_REGISTER, (eventName)=>registerEvent(element, eventName));
        } else {
            (0, _array.arrayEach)(EVENTS_TO_REGISTER, (eventName)=>registerEvent(rootElement, eventName));
        }
    }
    /**
   * Update DOM structure.
   */ update() {
    // Intentionally empty
    }
    /**
   * Reset to initial state.
   */ reset() {
        this.options.value = '';
        this.update();
    }
    /**
   * Show element.
   */ show() {
        const el = this.element;
        if (el) {
            el.style.display = '';
        }
    }
    /**
   * Hide element.
   */ hide() {
        const el = this.element;
        if (el) {
            el.style.display = 'none';
        }
    }
    /**
   * Focus element.
   */ focus() {}
    /**
   * Destroys the UI component by releasing the event manager, nulling references, and removing the element from the DOM.
   */ destroy() {
        this.eventManager?.destroy();
        this.eventManager = null;
        this.hot = null;
        if (this._element?.parentNode) {
            this._element.parentNode.removeChild(this._element);
        }
        this._element = null;
    }
    /**
   * Initializes the UI component with the Handsontable instance and merged configuration options.
   */ constructor(hotInstance, options){
        /**
   * Instance of EventManager.
   *
   * @type {EventManager}
   */ this.eventManager = new _eventManager.default(this);
        this.hot = hotInstance;
        this.options = (0, _object.extend)(BaseUI.DEFAULTS, options);
        this._element = hotInstance.rootDocument.createElement(this.options.wrapIt ? 'div' : this.options.tagName ?? 'div');
    }
}
(0, _object.mixin)(BaseUI, _localHooks.default);
