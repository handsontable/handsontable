"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "InputUI", {
    enumerable: true,
    get: function() {
        return InputUI;
    }
});
const _element = require("../../../helpers/dom/element");
const _object = require("../../../helpers/object");
const _base = require("./_base");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var /**
   * The reference to the input element.
   *
   * @type {HTMLInputElement}
   */ _input = /*#__PURE__*/ new WeakMap(), /**
   * Synchronizes the stored value with the native input element. Listens to `keyup` for typed
   * characters and to `input`/`change` for values set without key presses, e.g. picked from the
   * native date or time picker.
   *
   * @param {Event} event The DOM event object.
   */ _onValueChange = /*#__PURE__*/ new WeakSet();
class InputUI extends _base.BaseUI {
    /**
   * Returns the default configuration options for the input UI component, including placeholder, type, and tab index.
   */ static get DEFAULTS() {
        return (0, _object.clone)({
            placeholder: '',
            type: 'text',
            tagName: 'input',
            tabIndex: -1
        });
    }
    /**
   * Register all necessary hooks.
   */ registerHooks() {
        this.addLocalHook('keyup', (event)=>_class_private_method_get(this, _onValueChange, onValueChange).call(this, event));
        this.addLocalHook('input', (event)=>_class_private_method_get(this, _onValueChange, onValueChange).call(this, event));
        this.addLocalHook('change', (event)=>_class_private_method_get(this, _onValueChange, onValueChange).call(this, event));
    }
    /**
   * Build DOM structure.
   */ build() {
        super.build();
        if (!this._element || !this.hot) {
            return;
        }
        const icon = this.hot.rootDocument.createElement('div');
        _class_private_field_set(this, _input, this._element.firstChild);
        (0, _element.addClass)(this._element, 'htUIInput');
        (0, _element.addClass)(icon, 'htUIInputIcon');
        this._element.appendChild(icon);
        this.update();
    }
    /**
   * Update element.
   */ update() {
        if (!this.isBuilt()) {
            return;
        }
        if (_class_private_field_get(this, _input)) {
            _class_private_field_get(this, _input).type = String(this.options.type ?? 'text');
            _class_private_field_get(this, _input).placeholder = String(this.translateIfPossible(this.options.placeholder) ?? '');
            _class_private_field_get(this, _input).value = String(this.translateIfPossible(this.options.value) ?? '');
        }
    }
    /**
   * Set the type of the native input element (e.g. `text`, `date`, or `time`).
   */ setType(type) {
        this.options.type = type;
        if (this.isBuilt()) {
            this.update();
        }
    }
    /**
   * Focus element.
   */ focus() {
        if (this.isBuilt()) {
            _class_private_field_get(this, _input)?.focus();
        }
    }
    /**
   * Initializes the input UI component and registers event hooks for keyboard interaction.
   */ constructor(hotInstance, options){
        super(hotInstance, (0, _object.extend)(InputUI.DEFAULTS, options)), _class_private_method_init(this, _onValueChange), _class_private_field_init(this, _input, {
            writable: true,
            value: void 0
        }), _class_private_field_set(this, _input, null);
        this.registerHooks();
    }
}
function onValueChange(event) {
    this.options.value = (0, _element.eventTargetEl)(event).value;
}
