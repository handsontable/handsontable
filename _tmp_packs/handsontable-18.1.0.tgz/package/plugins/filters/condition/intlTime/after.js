"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CONDITION_NAME () {
        return CONDITION_NAME;
    },
    get condition () {
        return condition;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../../i18n/constants"));
const _conditionRegisterer = require("../../conditionRegisterer");
const _dateTime = require("../../../../helpers/dateTime");
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const CONDITION_NAME = 'intl_time_after';
function condition(dataRow, [value]) {
    const dataTime = (0, _dateTime.parseToLocalTime)(dataRow.value);
    const inputTime = (0, _dateTime.parseToLocalTime)(value);
    if (dataTime === null || inputTime === null) {
        return false;
    }
    return dataTime > inputTime;
}
(0, _conditionRegisterer.registerCondition)(CONDITION_NAME, condition, {
    name: _constants.FILTERS_CONDITIONS_AFTER,
    inputsCount: 1,
    showOperators: true,
    inputType: 'time'
});
