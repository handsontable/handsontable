"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CONDITION_NAME () {
        return CONDITION_NAME;
    },
    get condition () {
        return condition;
    }
});
const _dateTime = require("../../../../helpers/dateTime");
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../../i18n/constants"));
const _conditionRegisterer = require("../../conditionRegisterer");
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
const CONDITION_NAME = 'date_before_or_equal';
function condition(dataRow, [value]) {
    const date = (0, _dateTime.parseToLocalDate)(dataRow.value);
    const inputDate = (0, _dateTime.parseToLocalDate)(value);
    if (date === null || inputDate === null) {
        return false;
    }
    return date.getTime() <= inputDate.getTime();
}
(0, _conditionRegisterer.registerCondition)(CONDITION_NAME, condition, {
    name: _constants.FILTERS_CONDITIONS_BEFORE_OR_EQUAL,
    inputsCount: 1,
    showOperators: true,
    inputType: 'date'
});
