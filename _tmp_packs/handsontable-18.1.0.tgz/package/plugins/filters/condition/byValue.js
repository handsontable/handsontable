"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CONDITION_NAME () {
        return CONDITION_NAME;
    },
    get condition () {
        return condition;
    }
});
const _conditionRegisterer = require("../conditionRegisterer");
const _utils = require("../utils");
const CONDITION_NAME = 'by_value';
function condition(dataRow, [value]) {
    return value(dataRow.value);
}
(0, _conditionRegisterer.registerCondition)(CONDITION_NAME, condition, {
    name: 'By value',
    inputsCount: 0,
    inputValuesDecorator ([data]) {
        return [
            (0, _utils.createArrayAssertion)(data)
        ];
    },
    showOperators: false
});
