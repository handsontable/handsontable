"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CollapsibleColumns () {
        return CollapsibleColumns;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _array = require("../../helpers/array");
const _number = require("../../helpers/number");
const _console = require("../../helpers/console");
const _element = require("../../helpers/dom/element");
const _event = require("../../helpers/dom/event");
const _errors = require("../../helpers/errors");
const _contexts = require("../../shortcuts/contexts");
const _a11y = require("../../helpers/a11y");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
const PLUGIN_KEY = 'collapsibleColumns';
const PLUGIN_PRIORITY = 290;
const SETTING_KEYS = [
    'nestedHeaders'
];
const COLLAPSIBLE_ELEMENT_CLASS = 'collapsibleIndicator';
// Name of the hiding map that holds columns hidden by the per-child `visibleWhen` rules (issue
// #10243). Kept separate from the main collapsed-columns map so `getCollapsedColumns()` and the
// collapse hooks never report a column that is merely hidden in the expanded state.
const VISIBLE_WHEN_MAP_NAME = 'collapsibleColumns.visibleWhen';
const SHORTCUTS_GROUP = PLUGIN_KEY;
const actionDictionary = new Map([
    [
        'collapse',
        {
            hideColumn: true,
            beforeHook: 'beforeColumnCollapse',
            afterHook: 'afterColumnCollapse'
        }
    ],
    [
        'expand',
        {
            hideColumn: false,
            beforeHook: 'beforeColumnExpand',
            afterHook: 'afterColumnExpand'
        }
    ]
]);
var /**
   * Map of collapsed columns by the plugin.
   */ _collapsedColumnsMap = /*#__PURE__*/ new WeakMap(), /**
   * Map of columns hidden by the per-child `visibleWhen` rules (issue #10243), kept separate from
   * `#collapsedColumnsMap`.
   */ _visibleWhenMap = /*#__PURE__*/ new WeakMap(), /**
   * Checks whether a collapse or expand action is possible for the given filtered coordinates.
   *
   * @param {Array} filteredCoords Header coordinates filtered to header rows only.
   * @param {string} action Action definition ('collapse' or 'expand').
   * @returns {boolean}
   */ _checkIsActionPossible = /*#__PURE__*/ new WeakSet(), /**
   * Moves the active cell selection off any column a collapse or expand action just hid, so the
   * highlight never lingers on a now-hidden column (for example a `visibleWhen: 'collapsed'` summary
   * column that is hidden again when its group expands).
   *
   * @param {number[]} hiddenColumnsIndexes Visual indexes of columns this action hid.
   */ _adjustSelectionAfterHide = /*#__PURE__*/ new WeakSet(), /**
   * Re-derives the set of columns hidden by the per-child `visibleWhen` rules (issue #10243) from the
   * current header tree (markers + each group's `isCollapsed` state) and writes it into the dedicated
   * `#visibleWhenMap`. Pure recompute - safe to call after any collapse/expand toggle, settings
   * update, or column insert/remove. The hidden set is passed in by the toggle path (which has just
   * computed it) and re-derived for the settings/structure-change paths. The map is rewritten only
   * when the hidden set actually changed, so a legacy collapsible setup - which never produces a
   * `visibleWhen` hidden set - does not pay an index-cache rebuild on every update.
   */ _refreshVisibleWhenColumns = /*#__PURE__*/ new WeakSet(), /**
   * Re-derives the `visibleWhen` hidden set after NestedHeaders rebuilds the header tree on column
   * insertion or removal. The tree (with `isCollapsed` restored) is the source of truth, so a full
   * refresh keeps the hidden set correct without tracking shifted indexes manually.
   */ _onAfterColumnStructureChange = /*#__PURE__*/ new WeakMap(), /**
   * Expands, before a column move runs, any collapsed group the move would split - whether by taking
   * some (but not all) of the group's columns out, or by dropping an unrelated column into the middle
   * of its span. Both leave the group's columns non-adjacent, which drops its collapse indicator while
   * the columns stay hidden, with no control left to expand them. Expanding while the group is still
   * contiguous releases its columns through the normal expand path; hiding does not change visual
   * indexes, so the pending move's coordinates stay valid. A move that keeps a group's columns
   * together (including moving the whole group) leaves it collapsed.
   *
   * @param {number[]} movedColumns Visual indexes of the columns being moved.
   * @param {number} finalIndex The visual index the moved columns will start at after the move.
   * @param {number|undefined} dropIndex The drop visual index (unused).
   * @param {boolean} movePossible Whether the move can be performed.
   */ _onBeforeColumnMove = /*#__PURE__*/ new WeakMap(), /**
   * Projects the visual column order a pending move will produce, expressed in the current visual
   * indexes. Mirrors the move itself: remove the moved columns, then re-insert them at `finalIndex`.
   *
   * @param {number[]} movedColumns Visual indexes of the columns being moved.
   * @param {number} finalIndex The visual index the moved columns will start at after the move.
   * @returns {number[]} The current visual indexes in their post-move order.
   */ _projectColumnOrderAfterMove = /*#__PURE__*/ new WeakSet(), /**
   * Reports whether a group's columns stop being adjacent in the projected post-move order. The group
   * is split when its members no longer occupy one contiguous run of positions.
   *
   * @param {number} columnIndex The group's leftmost visual column index.
   * @param {number} origColspan The group's column span.
   * @param {Map<number, number>} positionByColumn Maps a current visual index to its post-move position.
   * @returns {boolean} `true` when the move would split the group.
   */ _isGroupSplitByOrder = /*#__PURE__*/ new WeakSet(), /**
   * Adds the indicator to the headers.
   *
   * @param {number} column Column index.
   * @param {HTMLElement} TH TH element.
   * @param {number} headerLevel The index of header level counting from the top (positive
   *                             values counting from 0 to N).
   */ _onAfterGetColHeader = /*#__PURE__*/ new WeakMap(), /**
   * Indicator mouse event callback.
   *
   * @param {object} event Mouse event.
   * @param {object} coords Event coordinates.
   */ _onBeforeOnCellMouseDown = /*#__PURE__*/ new WeakMap(), /**
   * Updates the plugin state after HoT initialization.
   */ _onInit = /*#__PURE__*/ new WeakMap(), /**
   * Updates the plugin state after new dataset load.
   *
   * @param {Array[]} sourceData Array of arrays or array of objects containing data.
   * @param {boolean} initialLoad Flag that determines whether the data has been loaded
   *                              during the initialization.
   */ _onAfterLoadData = /*#__PURE__*/ new WeakMap();
class CollapsibleColumns extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns the list of plugin dependencies required before this plugin can be initialized.
   */ static get PLUGIN_DEPS() {
        return [
            'plugin:NestedHeaders'
        ];
    }
    /**
   * Returns the setting keys that trigger a plugin update when changed via `updateSettings`.
   */ static get SETTING_KEYS() {
        return [
            PLUGIN_KEY,
            ...SETTING_KEYS
        ];
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link CollapsibleColumns#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[PLUGIN_KEY];
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        const { nestedHeaders } = this.hot.getSettings();
        if (!nestedHeaders) {
            (0, _console.warn)('You need to configure the Nested Headers plugin in order to use collapsible headers.');
        }
        if (this.pluginName) {
            _class_private_field_set(this, _collapsedColumnsMap, this.hot.columnIndexMapper.createAndRegisterIndexMap(this.pluginName, 'hiding'));
        }
        _class_private_field_set(this, _visibleWhenMap, this.hot.columnIndexMapper.createAndRegisterIndexMap(VISIBLE_WHEN_MAP_NAME, 'hiding'));
        this.nestedHeadersPlugin = this.hot.getPlugin('nestedHeaders');
        this.headerStateManager = this.nestedHeadersPlugin.getStateManager();
        this.addHook('init', _class_private_field_get(this, _onInit));
        this.addHook('afterLoadData', _class_private_field_get(this, _onAfterLoadData));
        this.addHook('afterGetColHeader', _class_private_field_get(this, _onAfterGetColHeader));
        this.addHook('beforeOnCellMouseDown', _class_private_field_get(this, _onBeforeOnCellMouseDown));
        // NestedHeaders (priority 280) rebuilds the header tree on column insert/remove/move before this
        // plugin (priority 290) runs, so refreshing here re-derives the `visibleWhen` hidden set against
        // the freshly rebuilt tree (with `isCollapsed` re-attached by group identity). On a move a group
        // that stayed contiguous keeps its collapse; a split group has its `isCollapsed` dropped, so the
        // re-derived `visibleWhen` set excludes it and these columns are released.
        this.addHook('afterCreateCol', _class_private_field_get(this, _onAfterColumnStructureChange));
        this.addHook('afterRemoveCol', _class_private_field_get(this, _onAfterColumnStructureChange));
        this.addHook('beforeColumnMove', _class_private_field_get(this, _onBeforeColumnMove));
        this.addHook('afterColumnMove', _class_private_field_get(this, _onAfterColumnStructureChange));
        this.registerShortcuts();
        super.enablePlugin();
        // @TODO: Workaround for broken plugin initialization abstraction (#6806).
        this.updatePlugin();
    }
    /**
   * Updates the plugin's state.
   *
   * This method is executed when [`updateSettings()`](@/api/core.md#updatesettings) is invoked with any of the following configuration options:
   *   - [`collapsibleColumns`](@/api/options.md#collapsiblecolumns)
   *   - [`nestedHeaders`](@/api/options.md#nestedheaders)
   */ updatePlugin() {
        // @TODO: Workaround for broken plugin initialization abstraction (#6806).
        if (!this.hot.view) {
            return;
        }
        if (!this.nestedHeadersPlugin?.detectedOverlappedHeaders) {
            const { collapsibleColumns } = this.hot.getSettings();
            if (typeof collapsibleColumns === 'boolean') {
                // Add `collapsible: true` attribute to all headers with colspan higher than 1.
                this.headerStateManager?.mapState((headerSettings)=>{
                    return {
                        collapsible: Number(headerSettings.origColspan) > 1
                    };
                });
            } else if (Array.isArray(collapsibleColumns)) {
                this.headerStateManager?.mapState(()=>{
                    return {
                        collapsible: false
                    };
                });
                this.headerStateManager?.mergeStateWith(collapsibleColumns);
            }
        }
        // Apply the per-child `visibleWhen` rules once the `collapsible` flags are in place - on the
        // initial render this hides every `visibleWhen: 'collapsed'` column (all groups start expanded).
        _class_private_method_get(this, _refreshVisibleWhenColumns, refreshVisibleWhenColumns).call(this);
        super.updatePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        if (this.pluginName) {
            this.hot.columnIndexMapper.unregisterMap(this.pluginName);
        }
        this.hot.columnIndexMapper.unregisterMap(VISIBLE_WHEN_MAP_NAME);
        _class_private_field_set(this, _collapsedColumnsMap, null);
        _class_private_field_set(this, _visibleWhenMap, null);
        this.nestedHeadersPlugin = null;
        this.unregisterShortcuts();
        this.clearButtons();
        super.disablePlugin();
    }
    /**
   * Register shortcuts responsible for toggling collapsible columns.
   *
   * @private
   */ registerShortcuts() {
        this.hot.getShortcutManager().getContext('grid')?.addShortcut({
            keys: [
                [
                    'Enter'
                ]
            ],
            callback: ()=>{
                const activeRange = this.hot.getSelectedRangeActive();
                if (!activeRange) {
                    return;
                }
                const { row, col } = activeRange.highlight;
                if (row === null || col === null) {
                    return;
                }
                const nodeData = this.headerStateManager?.getHeaderTreeNodeData(row, col) ?? {
                    collapsible: false,
                    isCollapsed: false,
                    columnIndex: 0,
                    headerLevel: 0
                };
                const { collapsible, isCollapsed, columnIndex } = nodeData;
                if (!collapsible) {
                    return;
                }
                if (isCollapsed) {
                    this.expandSection({
                        row,
                        col: columnIndex
                    });
                } else {
                    this.collapseSection({
                        row,
                        col: columnIndex
                    });
                }
                // prevent default Enter behavior (move to the next row within a selection range)
                return false;
            },
            runOnlyIf: ()=>!!(this.hot.getSelectedRangeActive()?.isSingle() && this.hot.getSelectedRangeActive()?.highlight.isHeader()),
            group: SHORTCUTS_GROUP,
            relativeToGroup: _contexts.EDITOR_EDIT_GROUP,
            position: 'before'
        });
    }
    /**
   * Unregister shortcuts responsible for toggling collapsible columns.
   *
   * @private
   */ unregisterShortcuts() {
        this.hot.getShortcutManager().getContext('grid')?.removeShortcutsByGroup(SHORTCUTS_GROUP);
    }
    /**
   * Clears the expand/collapse buttons.
   *
   * @private
   */ clearButtons() {
        if (!this.hot.view) {
            return;
        }
        const headerLevels = this.hot.view._wt.getSetting('columnHeaders').length;
        const mainHeaders = this.hot.view._wt.wtTable.THEAD;
        const topHeaders = this.hot.view._wt.wtOverlays.topOverlay?.clone?.wtTable.THEAD ?? null;
        const topLeftCornerHeaders = this.hot.view._wt.wtOverlays.topInlineStartCornerOverlay ? this.hot.view._wt.wtOverlays.topInlineStartCornerOverlay.clone?.wtTable.THEAD ?? null : null;
        const removeButton = function(button) {
            if (button && button.parentNode) {
                button.parentNode.removeChild(button);
            }
        };
        if (!mainHeaders || !topHeaders) {
            return;
        }
        (0, _number.rangeEach)(0, headerLevels - 1, (i)=>{
            const masterLevel = mainHeaders.childNodes[i];
            const topLevel = topHeaders.childNodes[i];
            const topLeftCornerLevel = topLeftCornerHeaders ? topLeftCornerHeaders.childNodes[i] : null;
            (0, _number.rangeEach)(0, masterLevel.childNodes.length - 1, (j)=>{
                let button = masterLevel.childNodes[j].querySelector(`.${COLLAPSIBLE_ELEMENT_CLASS}`);
                removeButton(button);
                if (topLevel && topLevel.childNodes[j]) {
                    button = topLevel.childNodes[j].querySelector(`.${COLLAPSIBLE_ELEMENT_CLASS}`);
                    removeButton(button);
                }
                if (topLeftCornerHeaders && topLeftCornerLevel && topLeftCornerLevel.childNodes[j]) {
                    button = topLeftCornerLevel.childNodes[j].querySelector(`.${COLLAPSIBLE_ELEMENT_CLASS}`);
                    removeButton(button);
                }
            });
        });
    }
    /**
   * Expands section at the provided coords. `coords.col` may be any column the group's header spans,
   * not only its first (anchor) column - it resolves to the owning collapsible group.
   *
   * @param {object} coords Contains coordinates information. (`coords.row`, `coords.col`).
   */ expandSection(coords) {
        this.toggleCollapsibleSection([
            coords
        ], 'expand');
    }
    /**
   * Collapses section at the provided coords. `coords.col` may be any column the group's header spans,
   * not only its first (anchor) column - it resolves to the owning collapsible group.
   *
   * @param {object} coords Contains coordinates information. (`coords.row`, `coords.col`).
   */ collapseSection(coords) {
        this.toggleCollapsibleSection([
            coords
        ], 'collapse');
    }
    /**
   * Collapses or expand all collapsible sections, depending on the action parameter.
   *
   * @param {string} action 'collapse' or 'expand'.
   */ toggleAllCollapsibleSections(action) {
        const coords = this.headerStateManager?.mapNodes((headerSettings)=>{
            const { collapsible, origColspan, headerLevel, columnIndex, isCollapsed } = headerSettings;
            if (collapsible === true && Number(origColspan) > 1 && (isCollapsed && action === 'expand' || !isCollapsed && action === 'collapse')) {
                return {
                    row: this.headerStateManager?.levelToRowCoords(Number(headerLevel)) ?? 0,
                    col: columnIndex
                };
            }
        });
        this.toggleCollapsibleSection(coords, action);
    }
    /**
   * Collapses all collapsible sections.
   */ collapseAll() {
        this.toggleAllCollapsibleSections('collapse');
    }
    /**
   * Expands all collapsible sections.
   */ expandAll() {
        this.toggleAllCollapsibleSections('expand');
    }
    /**
   * Collapses/Expands a section.
   *
   * @param {Array} coords Array of coords - section coordinates.
   * @param {string} [action] Action definition ('collapse' or 'expand').
   * @fires Hooks#beforeColumnCollapse
   * @fires Hooks#beforeColumnExpand
   * @fires Hooks#afterColumnCollapse
   * @fires Hooks#afterColumnExpand
   */ toggleCollapsibleSection(coords, action) {
        if (action === undefined || !actionDictionary.has(action)) {
            (0, _errors.throwWithCause)(`Unsupported action is passed (${action}).`);
        }
        if (!Array.isArray(coords)) {
            return;
        }
        // Ignore coordinates which points to the cells range.
        const filteredCoords = (0, _array.arrayFilter)(coords, ({ row })=>row < 0);
        const isActionPossible = _class_private_method_get(this, _checkIsActionPossible, checkIsActionPossible).call(this, filteredCoords, action);
        const nodeModRollbacks = [];
        const affectedColumnsIndexes = [];
        // Snapshot the declarative `visibleWhen` hidden set (issue #10243) before the nodes are toggled.
        // triggerNodeModification flips `isCollapsed` for declarative groups, so re-deriving afterwards
        // tells us which columns the toggle hid/showed - used for selection adjustment and the
        // action-performed check.
        const visibleWhenHiddenBefore = this.headerStateManager?.getVisibleWhenHiddenColumns() ?? [];
        if (isActionPossible) {
            (0, _array.arrayEach)(filteredCoords, ({ row, col: column })=>{
                const { affectedColumns, rollbackModification } = this.headerStateManager?.triggerNodeModification(action, row, column) ?? {
                    colspanCompensation: 0,
                    affectedColumns: [],
                    rollbackModification: ()=>{}
                };
                // Always keep the rollback - a declarative group toggles `isCollapsed` without reporting
                // affected columns, so its rollback must still run if the before-hook vetoes the action.
                // No-op modifications return an empty rollback, so this stays safe.
                nodeModRollbacks.push(rollbackModification);
                // Gate on whether any columns were affected, not on the colspan delta. A collapse can own
                // columns without changing the colspan - when the columns it claims are already hidden by
                // another source (e.g. HiddenColumns) the colspan is unchanged, but the collapse must still
                // record those columns so the group stays collapsed if that external hide is later removed.
                if (affectedColumns.length > 0) {
                    affectedColumnsIndexes.push(...affectedColumns);
                }
            });
        }
        const currentCollapsedColumns = this.getCollapsedColumns();
        let destinationCollapsedColumns = [];
        // The collapse hooks report the collapsed-columns map only. A declarative `visibleWhen` group
        // hides its columns through the separate `#visibleWhenMap` (so `getCollapsedColumns()` stays a
        // faithful record of legacy collapses), so for such a group `destinationCollapsedColumns` equals
        // `currentCollapsedColumns` even though columns were hidden - the `successfullyCollapsed` flag,
        // not the array delta, tells a consumer whether the toggle did anything.
        if (action === 'collapse') {
            destinationCollapsedColumns = (0, _array.arrayUnique)([
                ...currentCollapsedColumns,
                ...affectedColumnsIndexes
            ]);
        } else if (action === 'expand') {
            destinationCollapsedColumns = (0, _array.arrayFilter)(currentCollapsedColumns, (index)=>!affectedColumnsIndexes.includes(index));
        }
        const actionTranslator = actionDictionary.get(action);
        const isActionAllowed = this.hot.runHooks(actionTranslator.beforeHook, currentCollapsedColumns, destinationCollapsedColumns, isActionPossible);
        if (isActionAllowed === false) {
            // Rollback all header nodes modification (collapse or expand).
            (0, _array.arrayEach)(nodeModRollbacks, (nodeModRollback)=>{
                nodeModRollback();
            });
            return;
        }
        this.hot.batchExecution(()=>{
            (0, _array.arrayEach)(affectedColumnsIndexes, (visualColumn)=>{
                _class_private_field_get(this, _collapsedColumnsMap)?.setValueAtIndex(this.hot.toPhysicalColumn(visualColumn), actionTranslator.hideColumn);
            });
        }, true);
        // The declarative `visibleWhen` hidden set is a pure function of the `isCollapsed` flags that the
        // node modification just toggled, so re-derive it and diff against the snapshot taken before the
        // toggle. `newlyHiddenByVisibleWhen` are the columns this toggle hid through `visibleWhen` - on a
        // collapse the group's own columns, on an expand the `visibleWhen: 'collapsed'` summary columns
        // that are only visible while collapsed. Only refresh when it changed, so a plain legacy collapse
        // does not trigger an extra cache update that would disturb the selection adjustment below.
        const visibleWhenHiddenAfter = this.headerStateManager?.getVisibleWhenHiddenColumns() ?? [];
        const newlyHiddenByVisibleWhen = (0, _array.getDifferenceOfArrays)(visibleWhenHiddenAfter, visibleWhenHiddenBefore);
        const isVisibleWhenChanged = newlyHiddenByVisibleWhen.length > 0 || visibleWhenHiddenAfter.length !== visibleWhenHiddenBefore.length;
        if (isVisibleWhenChanged) {
            // Pass the already-computed set so the refresh does not walk the header tree a third time.
            _class_private_method_get(this, _refreshVisibleWhenColumns, refreshVisibleWhenColumns).call(this, visibleWhenHiddenAfter);
        }
        const isActionPerformed = this.getCollapsedColumns().length !== currentCollapsedColumns.length || isVisibleWhenChanged;
        // Move the selection off any column this toggle hid - a collapse hides the group's columns plus
        // any `visibleWhen` columns, while an expand hides the `visibleWhen: 'collapsed'` columns that are
        // only visible while collapsed.
        const newlyHiddenColumns = action === 'collapse' ? (0, _array.arrayUnique)([
            ...affectedColumnsIndexes,
            ...newlyHiddenByVisibleWhen
        ]) : newlyHiddenByVisibleWhen;
        if (isActionPerformed && newlyHiddenColumns.length > 0) {
            _class_private_method_get(this, _adjustSelectionAfterHide, adjustSelectionAfterHide).call(this, newlyHiddenColumns);
        }
        this.hot.runHooks(actionTranslator.afterHook, currentCollapsedColumns, destinationCollapsedColumns, isActionPossible, isActionPerformed);
        this.hot.view.adjustElementsSize();
        this.hot.render();
    }
    /**
   * Gets an array of physical indexes of collapsed columns.
   *
   * @private
   * @returns {number[]}
   */ getCollapsedColumns() {
        return _class_private_field_get(this, _collapsedColumnsMap)?.getHiddenIndexes() ?? [];
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        _class_private_field_set(this, _collapsedColumnsMap, null);
        _class_private_field_set(this, _visibleWhenMap, null);
        super.destroy();
    }
    constructor(...args){
        super(...args), _class_private_method_init(this, _checkIsActionPossible), _class_private_method_init(this, _adjustSelectionAfterHide), _class_private_method_init(this, _refreshVisibleWhenColumns), _class_private_method_init(this, _projectColumnOrderAfterMove), _class_private_method_init(this, _isGroupSplitByOrder), _class_private_field_init(this, _collapsedColumnsMap, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _visibleWhenMap, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterColumnStructureChange, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeColumnMove, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterGetColHeader, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeOnCellMouseDown, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onInit, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterLoadData, {
            writable: true,
            value: void 0
        }), /**
   * Cached reference to the NestedHeaders plugin.
   *
   * @private
   * @type {NestedHeaders}
   */ this.nestedHeadersPlugin = null, /**
   * The NestedHeaders plugin StateManager instance.
   *
   * @private
   * @type {StateManager}
   */ this.headerStateManager = null, _class_private_field_set(this, _collapsedColumnsMap, null), _class_private_field_set(this, _visibleWhenMap, null), _class_private_field_set(this, _onAfterColumnStructureChange, ()=>{
            _class_private_method_get(this, _refreshVisibleWhenColumns, refreshVisibleWhenColumns).call(this);
        }), _class_private_field_set(this, _onBeforeColumnMove, (movedColumns, finalIndex, dropIndex, movePossible)=>{
            const stateManager = this.headerStateManager;
            if (movePossible === false || !stateManager) {
                return;
            }
            const projectedOrder = _class_private_method_get(this, _projectColumnOrderAfterMove, projectColumnOrderAfterMove).call(this, movedColumns, finalIndex);
            const positionByColumn = new Map(projectedOrder.map((visualColumn, position)=>[
                    visualColumn,
                    position
                ]));
            stateManager.getCollapsedGroups().forEach(({ headerLevel, columnIndex, origColspan })=>{
                if (_class_private_method_get(this, _isGroupSplitByOrder, isGroupSplitByOrder).call(this, columnIndex, origColspan, positionByColumn)) {
                    const row = stateManager.levelToRowCoords(headerLevel);
                    if (row !== null) {
                        this.toggleCollapsibleSection([
                            {
                                row,
                                col: columnIndex
                            }
                        ], 'expand');
                    }
                }
            });
        }), _class_private_field_set(this, _onAfterGetColHeader, (column, TH, headerLevel)=>{
            const headerSettings = this.headerStateManager?.getHeaderSettings(headerLevel, column);
            const { collapsible, origColspan, isCollapsed } = headerSettings ?? {};
            const isNodeCollapsible = collapsible === true && (origColspan ?? 0) > 1 && column >= (this.hot.getSettings().fixedColumnsStart ?? 0);
            const isAriaTagsEnabled = this.hot.getSettings().ariaTags;
            let collapsibleElement = TH.querySelector(`.${COLLAPSIBLE_ELEMENT_CLASS}`);
            (0, _element.removeAttribute)(TH, [
                (0, _a11y.A11Y_EXPANDED)('')[0]
            ]);
            if (isNodeCollapsible) {
                if (!collapsibleElement) {
                    collapsibleElement = this.hot.rootDocument.createElement('div');
                    (0, _element.addClass)(collapsibleElement, COLLAPSIBLE_ELEMENT_CLASS);
                    TH.querySelector('div:first-child')?.appendChild(collapsibleElement);
                }
                const el = collapsibleElement;
                (0, _element.removeClass)(el, [
                    'collapsed',
                    'expanded'
                ]);
                if (isCollapsed) {
                    (0, _element.addClass)(el, 'collapsed');
                    (0, _element.fastInnerText)(el, '+');
                    // Add ARIA tags
                    if (isAriaTagsEnabled) {
                        (0, _element.setAttribute)(TH, ...(0, _a11y.A11Y_EXPANDED)(false));
                    }
                } else {
                    (0, _element.addClass)(el, 'expanded');
                    (0, _element.fastInnerText)(el, '-');
                    // Add ARIA tags
                    if (isAriaTagsEnabled) {
                        (0, _element.setAttribute)(TH, ...(0, _a11y.A11Y_EXPANDED)(true));
                    }
                }
                if (isAriaTagsEnabled) {
                    (0, _element.setAttribute)(el, ...(0, _a11y.A11Y_HIDDEN)());
                }
            } else {
                collapsibleElement?.remove();
            }
        }), _class_private_field_set(this, _onBeforeOnCellMouseDown, (event, coords)=>{
            const target = (0, _element.eventTargetEl)(event);
            if ((0, _element.hasClass)(target, COLLAPSIBLE_ELEMENT_CLASS)) {
                if ((0, _element.hasClass)(target, 'expanded')) {
                    this.eventManager.fireEvent(target, 'mouseup');
                    this.toggleCollapsibleSection([
                        coords
                    ], 'collapse');
                } else if ((0, _element.hasClass)(target, 'collapsed')) {
                    this.eventManager.fireEvent(target, 'mouseup');
                    this.toggleCollapsibleSection([
                        coords
                    ], 'expand');
                }
                (0, _event.stopImmediatePropagation)(event);
            }
        }), _class_private_field_set(this, _onInit, ()=>{
            // @TODO: Workaround for broken plugin initialization abstraction (#6806).
            this.updatePlugin();
        }), _class_private_field_set(this, _onAfterLoadData, (_sourceData, initialLoad)=>{
            if (!initialLoad) {
                this.updatePlugin();
            }
        });
    }
}
function checkIsActionPossible(filteredCoords, action) {
    if (filteredCoords.length === 0) {
        return false;
    }
    let isActionPossible = true;
    (0, _array.arrayEach)(filteredCoords, ({ row, col: column })=>{
        // Read the tree node, not the generated matrix: a declarative group (issue #10243) can hide its
        // own anchor column when collapsed, in which case the matrix cell at the anchor is a hidden
        // placeholder with no collapse state. The tree node always carries the authoritative
        // `collapsible`/`isCollapsed` regardless of which columns are hidden.
        const { collapsible, isCollapsed } = this.headerStateManager?.getHeaderTreeNodeData(row, column) ?? {};
        if (!collapsible || isCollapsed && action === 'collapse' || !isCollapsed && action === 'expand') {
            isActionPossible = false;
            return false;
        }
    });
    return isActionPossible;
}
function adjustSelectionAfterHide(hiddenColumnsIndexes) {
    const selectionRange = this.hot.getSelectedRangeActive();
    if (!selectionRange) {
        return;
    }
    const { row, col } = selectionRange.highlight;
    if (row === null || col === null) {
        return;
    }
    const isHidden = this.hot.rowIndexMapper.isHidden(row) || this.hot.columnIndexMapper.isHidden(col);
    if (isHidden && hiddenColumnsIndexes.includes(col)) {
        const nextRow = row >= 0 ? this.hot.rowIndexMapper.getNearestNotHiddenIndex(row, 1, true) : row;
        const nextColumn = col >= 0 ? this.hot.columnIndexMapper.getNearestNotHiddenIndex(col, 1, true) : col;
        if (nextRow !== null && nextColumn !== null) {
            this.hot.selectCell(nextRow, nextColumn);
        }
    }
}
function refreshVisibleWhenColumns(visualColumnsToHide = this.headerStateManager?.getVisibleWhenHiddenColumns() ?? []) {
    if (!_class_private_field_get(this, _visibleWhenMap)) {
        return;
    }
    const visibleWhenMap = _class_private_field_get(this, _visibleWhenMap);
    const nextHiddenColumns = (0, _array.arrayMap)(visualColumnsToHide, (visualColumn)=>this.hot.toPhysicalColumn(visualColumn));
    const currentHiddenColumns = visibleWhenMap.getHiddenIndexes();
    const isUnchanged = nextHiddenColumns.length === currentHiddenColumns.length && (0, _array.getDifferenceOfArrays)(nextHiddenColumns, currentHiddenColumns).length === 0;
    if (isUnchanged) {
        return;
    }
    this.hot.batchExecution(()=>{
        visibleWhenMap.clear();
        (0, _array.arrayEach)(nextHiddenColumns, (physicalColumn)=>{
            visibleWhenMap.setValueAtIndex(physicalColumn, true);
        });
    }, true);
}
function projectColumnOrderAfterMove(movedColumns, finalIndex) {
    const movedColumnsSet = new Set(movedColumns);
    const remaining = [];
    for(let column = 0, columnsCount = this.hot.countCols(); column < columnsCount; column++){
        if (!movedColumnsSet.has(column)) {
            remaining.push(column);
        }
    }
    return [
        ...remaining.slice(0, finalIndex),
        ...movedColumns,
        ...remaining.slice(finalIndex)
    ];
}
function isGroupSplitByOrder(columnIndex, origColspan, positionByColumn) {
    let minPosition = Infinity;
    let maxPosition = -Infinity;
    let memberCount = 0;
    for(let column = columnIndex; column < columnIndex + origColspan; column++){
        const position = positionByColumn.get(column);
        if (position !== undefined) {
            minPosition = Math.min(minPosition, position);
            maxPosition = Math.max(maxPosition, position);
            memberCount += 1;
        }
    }
    return memberCount > 0 && maxPosition - minPosition !== memberCount - 1;
}
