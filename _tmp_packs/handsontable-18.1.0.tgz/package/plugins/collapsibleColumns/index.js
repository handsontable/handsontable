"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CollapsibleColumns () {
        return _collapsibleColumns.CollapsibleColumns;
    },
    get PLUGIN_KEY () {
        return _collapsibleColumns.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _collapsibleColumns.PLUGIN_PRIORITY;
    }
});
const _collapsibleColumns = require("./collapsibleColumns");
