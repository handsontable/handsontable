"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ManualRowMove () {
        return _manualRowMove.ManualRowMove;
    },
    get PLUGIN_KEY () {
        return _manualRowMove.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _manualRowMove.PLUGIN_PRIORITY;
    }
});
const _manualRowMove = require("./manualRowMove");
