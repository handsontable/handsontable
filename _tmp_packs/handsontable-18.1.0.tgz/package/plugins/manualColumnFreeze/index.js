"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ManualColumnFreeze () {
        return _manualColumnFreeze.ManualColumnFreeze;
    },
    get PLUGIN_KEY () {
        return _manualColumnFreeze.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _manualColumnFreeze.PLUGIN_PRIORITY;
    }
});
const _manualColumnFreeze = require("./manualColumnFreeze");
