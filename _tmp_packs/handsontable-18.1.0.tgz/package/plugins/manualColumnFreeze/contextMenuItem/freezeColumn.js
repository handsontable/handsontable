"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, /**
 * @param {ManualColumnFreeze} manualColumnFreezePlugin The plugin instance.
 * @returns {object}
 */ "default", {
    enumerable: true,
    get: function() {
        return freezeColumnItem;
    }
});
const _constants = /*#__PURE__*/ _interop_require_wildcard(require("../../../i18n/constants"));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
function freezeColumnItem(manualColumnFreezePlugin) {
    return {
        key: 'freeze_column',
        name () {
            const phrase = this.getTranslatedPhrase(_constants.CONTEXTMENU_ITEMS_FREEZE_COLUMN);
            return phrase;
        },
        callback (key, selected) {
            const [{ start: { col: selectedColumn } }] = selected;
            manualColumnFreezePlugin.freezeColumn(selectedColumn);
            this.view.adjustElementsSize();
            this.render();
        },
        hidden () {
            const selection = this.getSelectedRange();
            let hide = false;
            if (selection === undefined) {
                hide = true;
            } else if (selection.length > 1) {
                hide = true;
            } else if (selection[0].from.col !== selection[0].to.col || selection[0].from.col <= (this.getSettings().fixedColumnsStart ?? 0) - 1) {
                hide = true;
            }
            return hide;
        }
    };
}
