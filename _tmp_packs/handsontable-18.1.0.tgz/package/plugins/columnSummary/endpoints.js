"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _array = require("../../helpers/array");
const _console = require("../../helpers/console");
const _utils = require("./utils");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
var /**
   * Destination columns keyed by physical destination row, built once per refresh pass. Used to
   * keep summary results out of other summaries when their row is trimmed and the
   * `columnSummaryResult` class is unreachable.
   */ _summaryDestinations = /*#__PURE__*/ new WeakMap();
/**
 * Class used to make all endpoint-related operations.
 *
 * @private
 * @class Endpoints
 */ class Endpoints {
    /**
   * Initialize the endpoints provided in the settings.
   */ initEndpoints() {
        this.endpoints = this.parseSettings();
        this.refreshAllEndpoints();
    }
    /**
   * Get a single endpoint object.
   *
   * @param {number} index Index of the endpoint.
   * @returns {object}
   */ getEndpoint(index) {
        if (this.settingsType === 'function') {
            return this.fillMissingEndpointData(this.settings)[index];
        }
        return this.endpoints[index];
    }
    /**
   * Returns the number of physical rows the dataset holds, ignoring trimming.
   *
   * Endpoint destination rows and calculation ranges are physical indexes, so they must never be
   * compared against `countRows()` - that counts only the *visible* rows and shrinks whenever a
   * plugin trims rows (NestedRows collapsing a group, TrimRows, the Filters plugin).
   *
   * @returns {number}
   */ countPhysicalRows() {
        return this.hot.rowIndexMapper.getNumberOfIndexes();
    }
    /**
   * Returns the number of rows an endpoint may address, that is the physical row count capped by
   * `maxRows`. Used for the settings defaults that need a row count rather than a bounds check.
   *
   * `maxRows` is normalized the same way `DataMap#getLength` does it: `0` or less means zero rows,
   * anything falsy means no cap.
   *
   * @returns {number}
   */ countAddressableRows() {
        const maxRows = this.hot.getSettings().maxRows;
        let cap;
        if ((maxRows ?? 0) < 0 || maxRows === 0) {
            cap = 0;
        } else {
            cap = maxRows || Infinity;
        }
        return Math.min(this.countPhysicalRows(), cap);
    }
    /**
   * Checks whether an endpoint points outside the table.
   *
   * A *trimmed* destination row is not out of bounds - the row exists, it is only hidden - so it is
   * deliberately not reported here. A row that is visible but sits past `maxRows` is out of bounds,
   * because the grid renders no cell for it.
   *
   * @param {object} endpoint Contains the endpoint information.
   * @param {number} [rowOffset=0] Row offset to apply before the check.
   * @param {number} [colOffset=0] Column offset to apply before the check.
   * @returns {boolean}
   */ isEndpointOutOfBounds(endpoint, rowOffset = 0, colOffset = 0) {
        const destinationRow = endpoint.destinationRow + rowOffset;
        const destinationVisualRow = this.hot.toVisualRow(destinationRow);
        return destinationRow >= this.countPhysicalRows() || endpoint.destinationColumn + colOffset >= this.hot.countCols() || destinationVisualRow !== null && destinationVisualRow >= this.hot.countRows();
    }
    /**
   * Get an array with all the endpoints.
   *
   * @returns {Array}
   */ getAllEndpoints() {
        if (this.settingsType === 'function') {
            return this.fillMissingEndpointData(this.settings);
        }
        return this.endpoints;
    }
    /**
   * Records the destinations of the endpoints a refresh pass is about to calculate.
   *
   * The resolved endpoints are passed in rather than read through `getAllEndpoints()`, which would
   * re-invoke a settings function and could describe a different layout than the pass is working on.
   *
   * @param {object[]} endpoints The endpoints the current pass will calculate.
   */ cacheSummaryDestinations(endpoints) {
        _class_private_field_set(this, _summaryDestinations, new Map());
        (0, _array.arrayEach)(endpoints, (endpoint)=>{
            let columns = _class_private_field_get(this, _summaryDestinations).get(endpoint.destinationRow);
            if (columns === undefined) {
                columns = new Set();
                _class_private_field_get(this, _summaryDestinations).set(endpoint.destinationRow, columns);
            }
            columns.add(endpoint.destinationColumn);
        });
    }
    /**
   * Checks whether a physical cell holds the result of an endpoint.
   *
   * `getCellValue` normally recognizes a result by its `columnSummaryResult` class, but cell meta is
   * addressed by visual coordinates, so a trimmed row has no readable class. Without this check a
   * hidden summary row is summed as if it were plain data and inflates every summary covering it.
   *
   * @param {number} physicalRow Physical row index.
   * @param {number} column Column index.
   * @returns {boolean}
   */ isSummaryDestination(physicalRow, column) {
        if (_class_private_field_get(this, _summaryDestinations) === null) {
            this.cacheSummaryDestinations(this.getAllEndpoints());
        }
        return _class_private_field_get(this, _summaryDestinations).get(physicalRow)?.has(column) === true;
    }
    /**
   * Used to fill the blanks in the endpoint data provided by a settings function.
   *
   * @private
   * @param {Function} func Function provided in the HOT settings.
   * @returns {Array} An array of endpoints.
   */ fillMissingEndpointData(func) {
        return this.parseSettings(func.call(this));
    }
    /**
   * Parse plugin's settings.
   *
   * @param {Array} settings The settings array.
   * @returns {object[]}
   */ parseSettings(settings) {
        const endpointsArray = [];
        let settingsArray = settings;
        if (!settingsArray && typeof this.settings === 'function') {
            this.settingsType = 'function';
            return;
        }
        if (!settingsArray) {
            settingsArray = this.settings;
        }
        (0, _array.arrayEach)(settingsArray, (val)=>{
            const newEndpoint = {};
            this.assignSetting(val, newEndpoint, 'ranges', [
                [
                    0,
                    this.countAddressableRows() - 1
                ]
            ]);
            this.assignSetting(val, newEndpoint, 'reversedRowCoords', false);
            this.assignSetting(val, newEndpoint, 'destinationRow', new Error(`
        You must provide a destination row for the Column Summary plugin in order to work properly!
      `));
            this.assignSetting(val, newEndpoint, 'destinationColumn', new Error(`
        You must provide a destination column for the Column Summary plugin in order to work properly!
      `));
            this.assignSetting(val, newEndpoint, 'sourceColumn', val.destinationColumn);
            this.assignSetting(val, newEndpoint, 'type', 'sum');
            this.assignSetting(val, newEndpoint, 'forceNumeric', false);
            this.assignSetting(val, newEndpoint, 'suppressDataTypeErrors', true);
            this.assignSetting(val, newEndpoint, 'customFunction', null);
            this.assignSetting(val, newEndpoint, 'readOnly', true);
            this.assignSetting(val, newEndpoint, 'roundFloat', false);
            endpointsArray.push(newEndpoint);
        });
        return endpointsArray;
    }
    /**
   * Setter for the internal setting objects.
   *
   * @param {object} settings Object with the settings.
   * @param {object} endpoint Contains information about the endpoint for the the calculation.
   * @param {string} name Settings name.
   * @param {object} defaultValue Default value for the settings.
   */ assignSetting(settings, endpoint, name, defaultValue) {
        if (name === 'ranges' && settings[name] === undefined) {
            endpoint[name] = defaultValue;
            return;
        } else if (name === 'ranges' && settings[name].length === 0) {
            return;
        }
        if (settings[name] === undefined) {
            if (defaultValue instanceof Error) {
                throw defaultValue;
            }
            endpoint[name] = defaultValue;
        } else {
            /* eslint-disable no-lonely-if */ if (name === 'destinationRow' && endpoint.reversedRowCoords) {
                endpoint[name] = this.countAddressableRows() - settings[name] - 1;
            } else {
                endpoint[name] = settings[name];
            }
        }
    }
    /**
   * Resets the endpoint setup before the structure alteration (like inserting or removing rows/columns). Used for settings provided as a function.
   *
   * @private
   * @param {string} action Type of the action performed.
   * @param {number} index Row/column index.
   * @param {number} number Number of rows/columns added/removed.
   */ resetSetupBeforeStructureAlteration(action, index, number) {
        if (this.settingsType !== 'function') {
            return;
        }
        const type = action.indexOf('row') > -1 ? 'row' : 'col';
        const endpoints = this.getAllEndpoints();
        (0, _array.arrayEach)(endpoints, (val)=>{
            if (type === 'row' && val.destinationRow >= index) {
                if (action === 'insert_row') {
                    val.alterRowOffset = number;
                } else if (action === 'remove_row') {
                    val.alterRowOffset = -1 * number;
                }
            }
            if (type === 'col' && val.destinationColumn >= index) {
                if (action === 'insert_col') {
                    val.alterColumnOffset = number;
                } else if (action === 'remove_col') {
                    val.alterColumnOffset = -1 * number;
                }
            }
        });
        this.resetAllEndpoints(endpoints, false);
    }
    /**
   * AfterCreateRow/afterCreateRow/afterRemoveRow/afterRemoveCol hook callback. Reset and reenables the summary functionality
   * after changing the table structure.
   *
   * @private
   * @param {string} action Type of the action performed.
   * @param {number} index Row/column index.
   * @param {number} number Number of rows/columns added/removed.
   * @param {Array} [logicRows] Array of the logical indexes.
   * @param {string} [source] Source of change.
   * @param {boolean} [forceRefresh] `true` of the endpoints should refresh after completing the function.
   */ resetSetupAfterStructureAlteration(action, index, number, logicRows, source, forceRefresh = true) {
        // Automatic row/column creation (`minSpareRows`/`minSpareCols`) should not trigger the endpoint recalculation.
        if (source === 'auto') {
            return;
        }
        if (this.settingsType === 'function') {
            // We need to run it on a next avaiable hook, because the TrimRows' `afterCreateRow` hook triggers after this one,
            // and it needs to be run to properly calculate the endpoint value.
            const beforeViewRenderCallback = ()=>{
                this.hot.removeHook('beforeViewRender', beforeViewRenderCallback);
                return this.refreshAllEndpoints();
            };
            this.hot.addHookOnce('beforeViewRender', beforeViewRenderCallback);
            return;
        }
        const type = action.indexOf('row') > -1 ? 'row' : 'col';
        const multiplier = action.indexOf('remove') > -1 ? -1 : 1;
        const endpoints = this.getAllEndpoints();
        const rowMoving = action.indexOf('move_row') === 0;
        const placeOfAlteration = index;
        (0, _array.arrayEach)(endpoints, (val)=>{
            if (type === 'row' && val.destinationRow >= placeOfAlteration) {
                val.alterRowOffset = multiplier * number;
            }
            if (type === 'col' && val.destinationColumn >= placeOfAlteration) {
                val.alterColumnOffset = multiplier * number;
            }
        });
        this.resetAllEndpoints(endpoints, !rowMoving);
        if (rowMoving) {
            (0, _array.arrayEach)(endpoints, (endpoint)=>{
                this.extendEndpointRanges(endpoint, placeOfAlteration, logicRows?.[0] ?? 0, logicRows?.length ?? 0);
                this.recreatePhysicalRanges(endpoint);
                this.clearOffsetInformation(endpoint);
            });
        } else {
            (0, _array.arrayEach)(endpoints, (endpoint)=>{
                this.shiftEndpointCoordinates(endpoint, placeOfAlteration);
            });
        }
        if (forceRefresh) {
            this.refreshAllEndpoints();
        }
    }
    /**
   * Clear the offset information from the endpoint object.
   *
   * @private
   * @param {object} endpoint And endpoint object.
   */ clearOffsetInformation(endpoint) {
        endpoint.alterRowOffset = undefined;
        endpoint.alterColumnOffset = undefined;
    }
    /**
   * Extend the row ranges for the provided endpoint.
   *
   * @private
   * @param {object} endpoint The endpoint object.
   * @param {number} placeOfAlteration Index of the row where the alteration takes place.
   * @param {number} previousPosition Previous endpoint result position.
   * @param {number} offset Offset generated by the alteration.
   */ extendEndpointRanges(endpoint, placeOfAlteration, previousPosition, offset) {
        (0, _array.arrayEach)(endpoint.ranges, (range)=>{
            // is a range, not a single row
            if (range[1]) {
                if (placeOfAlteration >= range[0] && placeOfAlteration <= range[1]) {
                    if (previousPosition > range[1]) {
                        range[1] += offset;
                    } else if (previousPosition < range[0]) {
                        range[0] -= offset;
                    }
                } else if (previousPosition >= range[0] && previousPosition <= range[1]) {
                    range[1] -= offset;
                    if (placeOfAlteration <= range[0]) {
                        range[0] += 1;
                        range[1] += 1;
                    }
                }
            }
        });
    }
    /**
   * Recreate the physical ranges for the provided endpoint. Used (for example) when a row gets moved and extends an existing range.
   *
   * @private
   * @param {object} endpoint An endpoint object.
   */ recreatePhysicalRanges(endpoint) {
        const ranges = endpoint.ranges;
        const newRanges = [];
        const allIndexes = [];
        (0, _array.arrayEach)(ranges, (range)=>{
            const newRange = [];
            if (range[1]) {
                for(let i = range[0]; i <= range[1]; i++){
                    newRange.push(this.hot.toPhysicalRow(i));
                }
            } else {
                newRange.push(this.hot.toPhysicalRow(range[0]));
            }
            allIndexes.push(newRange);
        });
        (0, _array.arrayEach)(allIndexes, (range)=>{
            let newRange = [];
            (0, _array.arrayEach)(range, (coord, index)=>{
                if (index === 0) {
                    newRange.push(coord);
                } else if (range[index] !== range[index - 1] + 1) {
                    newRange.push(range[index - 1]);
                    newRanges.push(newRange);
                    newRange = [];
                    newRange.push(coord);
                }
                if (index === range.length - 1) {
                    newRange.push(coord);
                    newRanges.push(newRange);
                }
            });
        });
        endpoint.ranges = newRanges;
    }
    /**
   * Shifts the endpoint coordinates by the defined offset.
   *
   * @private
   * @param {object} endpoint Endpoint object.
   * @param {number} offsetStartIndex Index of the performed change (if the change is located after the endpoint, nothing about the endpoint has to be changed.
   */ shiftEndpointCoordinates(endpoint, offsetStartIndex) {
        if (endpoint.alterRowOffset && endpoint.alterRowOffset !== 0) {
            endpoint.destinationRow += endpoint.alterRowOffset || 0;
            (0, _array.arrayEach)(endpoint.ranges, (element)=>{
                (0, _array.arrayEach)(element, (subElement, j)=>{
                    if (subElement >= offsetStartIndex) {
                        element[j] += endpoint.alterRowOffset || 0;
                    }
                });
            });
        } else if (endpoint.alterColumnOffset && endpoint.alterColumnOffset !== 0) {
            endpoint.destinationColumn += endpoint.alterColumnOffset || 0;
            endpoint.sourceColumn += endpoint.alterColumnOffset || 0;
        }
    }
    /**
   * Resets (removes) the endpoints from the table.
   *
   * @param {Array} [endpoints] Array containing the endpoints.
   * @param {boolean} [useOffset=true] Use the cell offset value.
   */ resetAllEndpoints(endpoints = this.getAllEndpoints(), useOffset = true) {
        const anyEndpointOutOfRange = endpoints.some((endpoint)=>{
            return this.isEndpointOutOfBounds(endpoint, endpoint.alterRowOffset || 0, endpoint.alterColumnOffset || 0);
        });
        if (anyEndpointOutOfRange) {
            return;
        }
        this.cellsToSetCache = [];
        (0, _array.arrayEach)(endpoints, (endpoint)=>{
            this.resetEndpointValue(endpoint, useOffset);
        });
        if (this.cellsToSetCache.length) {
            this.hot.setDataAtCell(this.cellsToSetCache, null, undefined, 'ColumnSummary.reset');
        }
        this.cellsToSetCache = [];
    }
    /**
   * Calculate and refresh all defined endpoints.
   */ refreshAllEndpoints() {
        const endpoints = this.getAllEndpoints();
        this.cellsToSetCache = [];
        this.cacheSummaryDestinations(endpoints);
        (0, _array.arrayEach)(endpoints, (value)=>{
            this.currentEndpoint = value;
            this.plugin.calculate(value);
            this.setEndpointValue(value, 'init');
        });
        this.currentEndpoint = null;
        if (this.cellsToSetCache.length) {
            this.hot.setDataAtCell(this.cellsToSetCache, null, undefined, 'ColumnSummary.reset');
        }
        this.cellsToSetCache = [];
    }
    /**
   * Calculate and refresh endpoints only in the changed columns.
   *
   * @param {Array} changes Array of changes from the `afterChange` hook.
   */ refreshChangedEndpoints(changes) {
        const endpoints = this.getAllEndpoints();
        const needToRefresh = [];
        this.cellsToSetCache = [];
        this.cacheSummaryDestinations(endpoints);
        (0, _array.arrayEach)(changes, (value, key, changesObj)=>{
            const change = value;
            if (`${change[2] || ''}` === `${change[3]}`) {
                return;
            }
            (0, _array.arrayEach)(endpoints, (endpoint, j)=>{
                if (this.hot.propToCol(changesObj[key][1]) === endpoint.sourceColumn && needToRefresh.indexOf(j) === -1) {
                    needToRefresh.push(j);
                }
            });
        });
        (0, _array.arrayEach)(needToRefresh, (value)=>{
            this.refreshEndpoint(endpoints[value]);
        });
        if (this.cellsToSetCache.length) {
            this.hot.setDataAtCell(this.cellsToSetCache, null, undefined, 'ColumnSummary.reset');
        }
        this.cellsToSetCache = [];
    }
    /**
   * Calculate and refresh endpoints whose `sourceColumn` (visual) matches any of the provided columns.
   *
   * @param {Set<number>|number[]} visualColumns Visual column indexes to match against.
   */ refreshEndpointsBySourceColumns(visualColumns) {
        const columnsSet = visualColumns instanceof Set ? visualColumns : new Set(visualColumns);
        const endpoints = this.getAllEndpoints();
        const matched = endpoints.filter((endpoint)=>columnsSet.has(endpoint.sourceColumn));
        if (matched.length === 0) {
            return;
        }
        this.cellsToSetCache = [];
        // Every endpoint is cached, not just the matched ones - a summary result must stay excluded from
        // the ranges of the endpoints being refreshed, whatever their own source column is.
        this.cacheSummaryDestinations(endpoints);
        (0, _array.arrayEach)(matched, (endpoint)=>{
            this.refreshEndpoint(endpoint);
        });
        if (this.cellsToSetCache.length) {
            this.hot.setDataAtCell(this.cellsToSetCache, null, undefined, 'ColumnSummary.reset');
        }
        this.cellsToSetCache = [];
    }
    /**
   * Refreshes the cell meta information for the all endpoints after the `updateSettings` method call which in some
   * cases (call with `columns` option) can reset the cell metas to the initial state.
   */ refreshCellMetas() {
        // Declarative writes: kept on the cell meta (so they survive the viewport meta eviction) but not
        // recorded as user-defined, so an `updateSettings` cache reset clears them and they are re-applied
        // for the current endpoints. `_setCellMetaDeclarative` does not fire `beforeSetCellMeta`/
        // `afterSetCellMeta` and cannot be vetoed - matching the previous direct-write behavior.
        this.endpoints.forEach((endpoint)=>{
            const destinationVisualRow = this.hot.toVisualRow(endpoint.destinationRow);
            const destinationColumn = endpoint.destinationColumn;
            if (destinationVisualRow !== null) {
                this.hot._setCellMetaDeclarative(destinationVisualRow, destinationColumn, 'readOnly', endpoint.readOnly);
                this.hot._setCellMetaDeclarative(destinationVisualRow, destinationColumn, 'className', 'columnSummaryResult');
            }
        });
    }
    /**
   * Calculate and refresh a single endpoint.
   *
   * @param {object} endpoint Contains the endpoint information.
   */ refreshEndpoint(endpoint) {
        this.currentEndpoint = endpoint;
        this.plugin.calculate(endpoint);
        this.setEndpointValue(endpoint, undefined);
        this.currentEndpoint = null;
    }
    /**
   * Reset the endpoint value.
   *
   * @param {object} endpoint Contains the endpoint information.
   * @param {boolean} [useOffset=true] Use the cell offset value.
   */ resetEndpointValue(endpoint, useOffset = true) {
        const alterRowOffset = endpoint.alterRowOffset || 0;
        const alterColOffset = endpoint.alterColumnOffset || 0;
        const destinationVisualRow = this.hot.toVisualRow(endpoint.destinationRow + (useOffset ? alterRowOffset : 0));
        // The destination row is trimmed (for example it sits inside a collapsed NestedRows group), so
        // there is no cell to clear.
        if (destinationVisualRow === null) {
            return;
        }
        this.cellsToSetCache.push([
            destinationVisualRow,
            this.hot.toVisualColumn(endpoint.destinationColumn + (useOffset ? alterColOffset : 0)),
            ''
        ]);
    }
    /**
   * Set the endpoint value.
   *
   * @param {object} endpoint Contains the endpoint information.
   * @param {string} [source] Source of the call information.
   * @param {boolean} [render=false] `true` if it needs to render the table afterwards.
   */ setEndpointValue(endpoint, source, render = false) {
        if (this.isEndpointOutOfBounds(endpoint)) {
            this.throwOutOfBoundsWarning();
            return;
        }
        const destinationVisualRow = this.hot.toVisualRow(endpoint.destinationRow);
        if (destinationVisualRow !== null) {
            const destinationColumn = endpoint.destinationColumn;
            const cellMeta = this.hot.getCellMetaTransient(destinationVisualRow, destinationColumn);
            if (source === 'init' || cellMeta.readOnly !== endpoint.readOnly) {
                // Declarative writes (see `refreshCellMetas`) so the styling survives viewport meta eviction
                // without firing the public `setCellMeta` hooks or being vetoable.
                this.hot._setCellMetaDeclarative(destinationVisualRow, destinationColumn, 'readOnly', endpoint.readOnly);
                this.hot._setCellMetaDeclarative(destinationVisualRow, destinationColumn, 'className', 'columnSummaryResult');
            }
        }
        endpoint.result = (0, _utils.roundFloat)(endpoint.result, endpoint.roundFloat);
        // A trimmed destination row has no cell to write to - writing one throws in `DataMap.set`. The
        // result stays on the endpoint; the cell keeps its previous value until the next recalculation
        // that runs while the row is visible. Nothing re-runs the endpoints on untrim, so a destination
        // hidden at the moment of a change shows a stale value until then.
        if (destinationVisualRow !== null) {
            if (render) {
                this.hot.setDataAtCell(destinationVisualRow, endpoint.destinationColumn, endpoint.result, 'ColumnSummary.set');
            } else {
                this.cellsToSetCache.push([
                    destinationVisualRow,
                    endpoint.destinationColumn,
                    endpoint.result
                ]);
            }
        }
        endpoint.alterRowOffset = undefined;
        endpoint.alterColumnOffset = undefined;
    }
    /**
   * Throw an error for the calculation range being out of boundaries.
   *
   * @private
   */ throwOutOfBoundsWarning() {
        (0, _console.warn)('One of the Column Summary plugins\' destination points you provided is beyond the table boundaries!');
    }
    /**
   * Initializes the endpoints manager with a reference to the ColumnSummary plugin and the summary endpoint configuration.
   */ constructor(plugin, settings){
        _class_private_field_init(this, _summaryDestinations, {
            writable: true,
            value: void 0
        });
        /**
   * Array of declared plugin endpoints (calculation destination points).
   *
   * @type {Array}
   * @default {Array} Empty array.
   */ this.endpoints = [];
        /**
   * Settings type. Can be either 'array' or 'function'.
   *
   * @type {string}
   * @default {'array'}
   */ this.settingsType = 'array';
        /**
   * The current endpoint (calculation destination point) in question.
   *
   * @type {object}
   * @default null
   */ this.currentEndpoint = null;
        /**
   * Array containing a list of changes to be applied.
   *
   * @private
   * @type {Array}
   * @default {[]}
   */ this.cellsToSetCache = [];
        _class_private_field_set(this, _summaryDestinations, null);
        this.plugin = plugin;
        // `_setCellMetaDeclarative` is defined on the Core runtime object but kept off the public
        // `HotInstance` type; this internal plugin reaches it through the `HotInstanceInternal` view.
        this.hot = this.plugin.hot;
        this.settings = settings;
    }
}
const _default = Endpoints;
