"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ColumnSummary () {
        return _columnSummary.ColumnSummary;
    },
    get PLUGIN_KEY () {
        return _columnSummary.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _columnSummary.PLUGIN_PRIORITY;
    }
});
const _columnSummary = require("./columnSummary");
