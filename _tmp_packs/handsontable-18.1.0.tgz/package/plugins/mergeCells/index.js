"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get MergeCells () {
        return _mergeCells.MergeCells;
    },
    get PLUGIN_KEY () {
        return _mergeCells.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _mergeCells.PLUGIN_PRIORITY;
    }
});
const _mergeCells = require("./mergeCells");
