"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "FocusOrder", {
    enumerable: true,
    get: function() {
        return FocusOrder;
    }
});
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var /**
   * Geometry snapshots of the selected ranges, one per selection layer. Recreated every time the
   * selection is changed.
   */ _layers = /*#__PURE__*/ new WeakMap(), /**
   * The currently highlighted node within the horizontal focus order.
   */ _currentHorizontalNode = /*#__PURE__*/ new WeakMap(), /**
   * The currently highlighted node within the vertical focus order.
   */ _currentVerticalNode = /*#__PURE__*/ new WeakMap(), /**
   * The merged cells getter function.
   */ _mergedCellsGetter = /*#__PURE__*/ new WeakMap(), /**
   * The row index mapper.
   */ _rowIndexMapper = /*#__PURE__*/ new WeakMap(), /**
   * The column index mapper.
   */ _columnIndexMapper = /*#__PURE__*/ new WeakMap(), /**
   * Gets the focus node that contains the provided cell within the provided selection layer, or
   * `null` when the cell produces no focus stop (outside the layer, hidden, or covered by a merged
   * cell that sticks out of the layer).
   *
   * @param {number} selectionLayer The selection layer index.
   * @param {number} row The visual row index.
   * @param {number} column The visual column index.
   * @returns {FocusNodeData | null}
   */ _getNodeAt = /*#__PURE__*/ new WeakSet(), /**
   * Creates a focus node for the provided merged cell, or `null` when the merged cell produces no
   * focus stop — it sticks out of the layer's bounds or has no visible cell to anchor at.
   *
   * @param {number} selectionLayer The selection layer index.
   * @param {MergedCellCoords} mergeParent The merged cell to create the node for.
   * @returns {FocusNodeData | null}
   */ _createMergeNode = /*#__PURE__*/ new WeakSet(), /**
   * Finds the anchor — the first visible cell in scan order — of the provided rectangle. Returns
   * `null` when the rectangle has no visible row or column.
   *
   * @param {number} rowStart The first visual row index of the rectangle.
   * @param {number} rowEnd The last visual row index of the rectangle.
   * @param {number} colStart The first visual column index of the rectangle.
   * @param {number} colEnd The last visual column index of the rectangle.
   * @returns {ScanPosition | null}
   */ _findAnchor = /*#__PURE__*/ new WeakSet(), /**
   * Gets the position the lazy scan resumes from for the provided node — the node's anchor, or its
   * top-start corner when the anchor cannot be resolved anymore (e.g. hidden in the meantime).
   *
   * @param {FocusNodeData} node The node to resolve the scan position for.
   * @returns {ScanPosition}
   */ _nodeScanPosition = /*#__PURE__*/ new WeakSet(), /**
   * Computes the neighboring node data of the provided node, or `undefined` when there is no node.
   *
   * @param {FocusNodeData | null} node The node to start from.
   * @param {FocusOrderDirection} order The traversal order.
   * @param {number} direction The traversal direction. `1` for next, `-1` for previous.
   * @returns {FocusNodeData | undefined}
   */ _neighborNode = /*#__PURE__*/ new WeakSet(), /**
   * Finds the neighboring node of the provided node, walking the selection layers circularly —
   * exactly like the previously materialized circular linked list did. When the provided node is
   * the only focus stop, the node itself is returned.
   *
   * @param {FocusNodeData} node The node to start from.
   * @param {FocusOrderDirection} order The traversal order.
   * @param {number} direction The traversal direction. `1` for next, `-1` for previous.
   * @returns {FocusNodeData | null}
   */ _findNeighborNode = /*#__PURE__*/ new WeakSet(), /**
   * Finds the first node of the whole focus order, or `undefined` when the selection produces no
   * focus stops.
   *
   * @param {FocusOrderDirection} order The traversal order.
   * @returns {FocusNodeData | undefined}
   */ _findFirstNode = /*#__PURE__*/ new WeakSet(), /**
   * Finds the first focus node of the provided layer at or after the provided scan position
   * (exclusive). Passing `null` as the position scans the layer from its edge (inclusive).
   *
   * @param {number} selectionLayer The selection layer index.
   * @param {ScanPosition | null} fromPosition The position to start the scan from, or `null` to
   * scan from the layer's edge.
   * @param {FocusOrderDirection} order The traversal order.
   * @param {number} direction The traversal direction. `1` for forward, `-1` for backward.
   * @returns {FocusNodeData | null}
   */ _findNodeInLayer = /*#__PURE__*/ new WeakSet(), /**
   * Checks whether the merged cell's node is emitted at the provided scan position. Scanning
   * forward, a merged cell is emitted exactly at its anchor. Scanning backward, it is emitted as
   * soon as the scan enters the anchor's row (horizontal order) or column (vertical order) — every
   * cell between that position and the anchor belongs to the same merged cell.
   *
   * @param {FocusNodeData} mergeNode The merged cell's node.
   * @param {ScanPosition} position The current scan position (a cell of the merged cell).
   * @param {FocusOrderDirection} order The traversal order.
   * @param {number} direction The traversal direction. `1` for forward, `-1` for backward.
   * @returns {boolean}
   */ _emitsMergeNodeAt = /*#__PURE__*/ new WeakSet(), /**
   * Advances the scan position past the provided merged cell along the traversal order's inner
   * axis, so the scan cost stays relative to the merged cells walked past — not to their area.
   *
   * @param {LayerGeometry} layer The layer geometry.
   * @param {ScanPosition} position The current scan position (a cell of the merged cell).
   * @param {MergedCellCoords} mergeParent The merged cell to skip.
   * @param {FocusOrderDirection} order The traversal order.
   * @param {number} direction The traversal direction. `1` for forward, `-1` for backward.
   * @returns {ScanPosition | null}
   */ _skipMerge = /*#__PURE__*/ new WeakSet(), /**
   * Gets the first (forward) or last (backward) visible cell position of the provided layer, or
   * `null` when the layer has no visible cell.
   *
   * @param {LayerGeometry} layer The layer geometry.
   * @param {number} direction The traversal direction. `1` for forward, `-1` for backward.
   * @returns {ScanPosition | null}
   */ _layerEdgePosition = /*#__PURE__*/ new WeakSet(), /**
   * Advances the scan position to the next (or previous) visible cell of the layer in the provided
   * traversal order, or `null` when the layer's end is reached.
   *
   * @param {LayerGeometry} layer The layer geometry.
   * @param {ScanPosition} position The current scan position.
   * @param {FocusOrderDirection} order The traversal order.
   * @param {number} direction The traversal direction. `1` for forward, `-1` for backward.
   * @returns {ScanPosition | null}
   */ _advance = /*#__PURE__*/ new WeakSet();
class FocusOrder {
    /**
   * Gets the currently selected node data from the vertical focus order.
   *
   * @returns {FocusNodeData | undefined}
   */ getCurrentVerticalNode() {
        return _class_private_field_get(this, _currentVerticalNode) ?? undefined;
    }
    /**
   * Gets the first node data from the vertical focus order.
   *
   * @returns {FocusNodeData | undefined}
   */ getFirstVerticalNode() {
        return _class_private_method_get(this, _findFirstNode, findFirstNode).call(this, 'vertical');
    }
    /**
   * Gets the next selected node data from the vertical focus order.
   *
   * @returns {FocusNodeData}
   */ getNextVerticalNode() {
        // The cast mirrors the previous linked-list implementation: with no current node the method
        // returns `undefined` at runtime and the callers rely on that behavior.
        return _class_private_method_get(this, _neighborNode, neighborNode).call(this, _class_private_field_get(this, _currentVerticalNode), 'vertical', 1);
    }
    /**
   * Gets the previous selected node data from the vertical focus order.
   *
   * @returns {FocusNodeData}
   */ getPrevVerticalNode() {
        // See `getNextVerticalNode` for why the cast is kept.
        return _class_private_method_get(this, _neighborNode, neighborNode).call(this, _class_private_field_get(this, _currentVerticalNode), 'vertical', -1);
    }
    /**
   * Gets the currently selected node data from the horizontal focus order.
   *
   * @returns {FocusNodeData | undefined}
   */ getCurrentHorizontalNode() {
        return _class_private_field_get(this, _currentHorizontalNode) ?? undefined;
    }
    /**
   * Gets the first node data from the horizontal focus order.
   *
   * @returns {FocusNodeData | undefined}
   */ getFirstHorizontalNode() {
        return _class_private_method_get(this, _findFirstNode, findFirstNode).call(this, 'horizontal');
    }
    /**
   * Gets the next selected node data from the horizontal focus order.
   *
   * @returns {FocusNodeData}
   */ getNextHorizontalNode() {
        // See `getNextVerticalNode` for why the cast is kept.
        return _class_private_method_get(this, _neighborNode, neighborNode).call(this, _class_private_field_get(this, _currentHorizontalNode), 'horizontal', 1);
    }
    /**
   * Gets the previous selected node data from the horizontal focus order.
   *
   * @returns {FocusNodeData}
   */ getPrevHorizontalNode() {
        // See `getNextVerticalNode` for why the cast is kept.
        return _class_private_method_get(this, _neighborNode, neighborNode).call(this, _class_private_field_get(this, _currentHorizontalNode), 'horizontal', -1);
    }
    /**
   * Sets the previous node in both focus orders as active.
   */ setPrevNodeAsActive() {
        if (_class_private_field_get(this, _currentVerticalNode)) {
            _class_private_field_set(this, _currentVerticalNode, _class_private_method_get(this, _findNeighborNode, findNeighborNode).call(this, _class_private_field_get(this, _currentVerticalNode), 'vertical', -1));
        }
        if (_class_private_field_get(this, _currentHorizontalNode)) {
            _class_private_field_set(this, _currentHorizontalNode, _class_private_method_get(this, _findNeighborNode, findNeighborNode).call(this, _class_private_field_get(this, _currentHorizontalNode), 'horizontal', -1));
        }
    }
    /**
   * Sets the next node in both focus orders as active.
   */ setNextNodeAsActive() {
        if (_class_private_field_get(this, _currentVerticalNode)) {
            _class_private_field_set(this, _currentVerticalNode, _class_private_method_get(this, _findNeighborNode, findNeighborNode).call(this, _class_private_field_get(this, _currentVerticalNode), 'vertical', 1));
        }
        if (_class_private_field_get(this, _currentHorizontalNode)) {
            _class_private_field_set(this, _currentHorizontalNode, _class_private_method_get(this, _findNeighborNode, findNeighborNode).call(this, _class_private_field_get(this, _currentHorizontalNode), 'horizontal', 1));
        }
    }
    /**
   * Rebuilds the focus order based on the provided selection. Only the layers' geometry is
   * captured — the focus stops themselves are computed lazily during navigation.
   *
   * @param {CellRange[]} selectedRanges The selected ranges to build the focus order for.
   */ buildFocusOrder(selectedRanges) {
        _class_private_field_set(this, _layers, selectedRanges.map((range)=>{
            const topStart = range.getTopStartCorner();
            const bottomEnd = range.getBottomEndCorner();
            const highlight = range.highlight.clone().normalize();
            return {
                rowFrom: topStart.row ?? 0,
                rowTo: bottomEnd.row ?? 0,
                colFrom: topStart.col ?? 0,
                colTo: bottomEnd.col ?? 0,
                highlightRow: highlight.row ?? 0,
                highlightCol: highlight.col ?? 0
            };
        }));
        let highlightNode = null;
        for(let selectionLayer = 0; selectionLayer < _class_private_field_get(this, _layers).length; selectionLayer++){
            const { highlightRow, highlightCol } = _class_private_field_get(this, _layers)[selectionLayer];
            const node = _class_private_method_get(this, _getNodeAt, getNodeAt).call(this, selectionLayer, highlightRow, highlightCol);
            if (node) {
                highlightNode = node;
            }
        }
        _class_private_field_set(this, _currentHorizontalNode, highlightNode);
        _class_private_field_set(this, _currentVerticalNode, highlightNode);
    }
    /**
   * Sets the active node based on the provided row and column.
   *
   * @param {number} row The visual row index.
   * @param {number} column The visual column index.
   * @param {number} selectionLayerIndex The index of the selection layer to which the focus should be marked as active.
   * @returns {FocusOrder}
   */ setActiveNode(row, column, selectionLayerIndex) {
        // Without a layer index no node can match — kept for compatibility with the previous
        // implementation, which compared each node's layer against `undefined`.
        if (selectionLayerIndex === undefined) {
            return this;
        }
        const node = _class_private_method_get(this, _getNodeAt, getNodeAt).call(this, selectionLayerIndex, row, column);
        if (node) {
            _class_private_field_set(this, _currentHorizontalNode, node);
            _class_private_field_set(this, _currentVerticalNode, node);
        }
        return this;
    }
    /**
   * Initializes the focus order manager with the merged cell getter and row and column index mappers used to navigate focus through merged regions.
   */ constructor({ mergedCellsGetter, rowIndexMapper, columnIndexMapper }){
        _class_private_method_init(this, _getNodeAt);
        _class_private_method_init(this, _createMergeNode);
        _class_private_method_init(this, _findAnchor);
        _class_private_method_init(this, _nodeScanPosition);
        _class_private_method_init(this, _neighborNode);
        _class_private_method_init(this, _findNeighborNode);
        _class_private_method_init(this, _findFirstNode);
        _class_private_method_init(this, _findNodeInLayer);
        _class_private_method_init(this, _emitsMergeNodeAt);
        _class_private_method_init(this, _skipMerge);
        _class_private_method_init(this, _layerEdgePosition);
        _class_private_method_init(this, _advance);
        _class_private_field_init(this, _layers, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _currentHorizontalNode, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _currentVerticalNode, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _mergedCellsGetter, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _rowIndexMapper, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _columnIndexMapper, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _layers, []);
        _class_private_field_set(this, _currentHorizontalNode, null);
        _class_private_field_set(this, _currentVerticalNode, null);
        _class_private_field_set(this, _mergedCellsGetter, mergedCellsGetter);
        _class_private_field_set(this, _rowIndexMapper, rowIndexMapper);
        _class_private_field_set(this, _columnIndexMapper, columnIndexMapper);
    }
}
function getNodeAt(selectionLayer, row, column) {
    const layer = _class_private_field_get(this, _layers)[selectionLayer];
    if (!layer) {
        return null;
    }
    const mergeParent = _class_private_field_get(this, _mergedCellsGetter).call(this, row, column);
    if (mergeParent) {
        return _class_private_method_get(this, _createMergeNode, createMergeNode).call(this, selectionLayer, mergeParent);
    }
    if (row < layer.rowFrom || row > layer.rowTo || column < layer.colFrom || column > layer.colTo || _class_private_field_get(this, _rowIndexMapper).isHidden(row) || _class_private_field_get(this, _columnIndexMapper).isHidden(column)) {
        return null;
    }
    return {
        selectionLayer,
        rowStart: row,
        rowEnd: row,
        colStart: column,
        colEnd: column
    };
}
function createMergeNode(selectionLayer, mergeParent) {
    const layer = _class_private_field_get(this, _layers)[selectionLayer];
    const rowStart = mergeParent.row;
    const rowEnd = mergeParent.row + mergeParent.rowspan - 1;
    const colStart = mergeParent.col;
    const colEnd = mergeParent.col + mergeParent.colspan - 1;
    if (rowStart < layer.rowFrom || rowEnd > layer.rowTo || colStart < layer.colFrom || colEnd > layer.colTo || _class_private_method_get(this, _findAnchor, findAnchor).call(this, rowStart, rowEnd, colStart, colEnd) === null) {
        return null;
    }
    return {
        selectionLayer,
        rowStart,
        rowEnd,
        colStart,
        colEnd
    };
}
function findAnchor(rowStart, rowEnd, colStart, colEnd) {
    const row = _class_private_field_get(this, _rowIndexMapper).getNearestNotHiddenIndex(rowStart, 1);
    const column = _class_private_field_get(this, _columnIndexMapper).getNearestNotHiddenIndex(colStart, 1);
    if (row === null || row > rowEnd || column === null || column > colEnd) {
        return null;
    }
    return {
        row,
        column
    };
}
function nodeScanPosition(node) {
    return _class_private_method_get(this, _findAnchor, findAnchor).call(this, node.rowStart, node.rowEnd, node.colStart, node.colEnd) ?? {
        row: node.rowStart,
        column: node.colStart
    };
}
function neighborNode(node, order, direction) {
    if (!node) {
        return undefined;
    }
    return _class_private_method_get(this, _findNeighborNode, findNeighborNode).call(this, node, order, direction) ?? undefined;
}
function findNeighborNode(node, order, direction) {
    const totalLayers = _class_private_field_get(this, _layers).length;
    if (totalLayers === 0) {
        return null;
    }
    const startLayer = _class_private_field_get(this, _layers)[node.selectionLayer] ? node.selectionLayer : 0;
    let foundNode = _class_private_method_get(this, _findNodeInLayer, findNodeInLayer).call(this, startLayer, _class_private_method_get(this, _nodeScanPosition, nodeScanPosition).call(this, node), order, direction);
    for(let step = 1; foundNode === null && step <= totalLayers; step++){
        const rawLayer = (startLayer + step * direction) % totalLayers;
        const layer = (rawLayer + totalLayers) % totalLayers;
        foundNode = _class_private_method_get(this, _findNodeInLayer, findNodeInLayer).call(this, layer, null, order, direction);
    }
    return foundNode;
}
function findFirstNode(order) {
    for(let selectionLayer = 0; selectionLayer < _class_private_field_get(this, _layers).length; selectionLayer++){
        const node = _class_private_method_get(this, _findNodeInLayer, findNodeInLayer).call(this, selectionLayer, null, order, 1);
        if (node) {
            return node;
        }
    }
    return undefined;
}
function findNodeInLayer(selectionLayer, fromPosition, order, direction) {
    const layer = _class_private_field_get(this, _layers)[selectionLayer];
    if (!layer) {
        return null;
    }
    let position = fromPosition === null ? _class_private_method_get(this, _layerEdgePosition, layerEdgePosition).call(this, layer, direction) : _class_private_method_get(this, _advance, advance).call(this, layer, fromPosition, order, direction);
    while(position !== null){
        const mergeParent = _class_private_field_get(this, _mergedCellsGetter).call(this, position.row, position.column);
        if (!mergeParent) {
            return {
                selectionLayer,
                rowStart: position.row,
                rowEnd: position.row,
                colStart: position.column,
                colEnd: position.column
            };
        }
        const mergeNode = _class_private_method_get(this, _createMergeNode, createMergeNode).call(this, selectionLayer, mergeParent);
        if (mergeNode && _class_private_method_get(this, _emitsMergeNodeAt, emitsMergeNodeAt).call(this, mergeNode, position, order, direction)) {
            return mergeNode;
        }
        position = _class_private_method_get(this, _skipMerge, skipMerge).call(this, layer, position, mergeParent, order, direction);
    }
    return null;
}
function emitsMergeNodeAt(mergeNode, position, order, direction) {
    const anchor = _class_private_method_get(this, _findAnchor, findAnchor).call(this, mergeNode.rowStart, mergeNode.rowEnd, mergeNode.colStart, mergeNode.colEnd);
    if (anchor === null) {
        return false;
    }
    if (direction === 1) {
        return anchor.row === position.row && anchor.column === position.column;
    }
    return order === 'horizontal' ? anchor.row === position.row : anchor.column === position.column;
}
function skipMerge(layer, position, mergeParent, order, direction) {
    if (order === 'horizontal') {
        const column = direction === 1 ? Math.min(mergeParent.col + mergeParent.colspan - 1, layer.colTo) : Math.max(mergeParent.col, layer.colFrom);
        return _class_private_method_get(this, _advance, advance).call(this, layer, {
            row: position.row,
            column
        }, order, direction);
    }
    const row = direction === 1 ? Math.min(mergeParent.row + mergeParent.rowspan - 1, layer.rowTo) : Math.max(mergeParent.row, layer.rowFrom);
    return _class_private_method_get(this, _advance, advance).call(this, layer, {
        row,
        column: position.column
    }, order, direction);
}
function layerEdgePosition(layer, direction) {
    const row = direction === 1 ? _class_private_field_get(this, _rowIndexMapper).getNearestNotHiddenIndex(layer.rowFrom, 1) : _class_private_field_get(this, _rowIndexMapper).getNearestNotHiddenIndex(layer.rowTo, -1);
    const column = direction === 1 ? _class_private_field_get(this, _columnIndexMapper).getNearestNotHiddenIndex(layer.colFrom, 1) : _class_private_field_get(this, _columnIndexMapper).getNearestNotHiddenIndex(layer.colTo, -1);
    if (row === null || row < layer.rowFrom || row > layer.rowTo || column === null || column < layer.colFrom || column > layer.colTo) {
        return null;
    }
    return {
        row,
        column
    };
}
function advance(layer, position, order, direction) {
    if (order === 'horizontal') {
        const column = _class_private_field_get(this, _columnIndexMapper).getNearestNotHiddenIndex(position.column + direction, direction);
        if (column !== null && column >= layer.colFrom && column <= layer.colTo) {
            return {
                row: position.row,
                column
            };
        }
        const row = _class_private_field_get(this, _rowIndexMapper).getNearestNotHiddenIndex(position.row + direction, direction);
        const edgeColumn = direction === 1 ? _class_private_field_get(this, _columnIndexMapper).getNearestNotHiddenIndex(layer.colFrom, 1) : _class_private_field_get(this, _columnIndexMapper).getNearestNotHiddenIndex(layer.colTo, -1);
        if (row === null || row < layer.rowFrom || row > layer.rowTo || edgeColumn === null || edgeColumn < layer.colFrom || edgeColumn > layer.colTo) {
            return null;
        }
        return {
            row,
            column: edgeColumn
        };
    }
    const row = _class_private_field_get(this, _rowIndexMapper).getNearestNotHiddenIndex(position.row + direction, direction);
    if (row !== null && row >= layer.rowFrom && row <= layer.rowTo) {
        return {
            row,
            column: position.column
        };
    }
    const column = _class_private_field_get(this, _columnIndexMapper).getNearestNotHiddenIndex(position.column + direction, direction);
    const edgeRow = direction === 1 ? _class_private_field_get(this, _rowIndexMapper).getNearestNotHiddenIndex(layer.rowFrom, 1) : _class_private_field_get(this, _rowIndexMapper).getNearestNotHiddenIndex(layer.rowTo, -1);
    if (column === null || column < layer.colFrom || column > layer.colTo || edgeRow === null || edgeRow < layer.rowFrom || edgeRow > layer.rowTo) {
        return null;
    }
    return {
        row: edgeRow,
        column
    };
}
