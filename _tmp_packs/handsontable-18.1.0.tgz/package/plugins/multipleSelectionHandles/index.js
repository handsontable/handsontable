"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get MultipleSelectionHandles () {
        return _multipleSelectionHandles.MultipleSelectionHandles;
    },
    get PLUGIN_KEY () {
        return _multipleSelectionHandles.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _multipleSelectionHandles.PLUGIN_PRIORITY;
    }
});
const _multipleSelectionHandles = require("./multipleSelectionHandles");
