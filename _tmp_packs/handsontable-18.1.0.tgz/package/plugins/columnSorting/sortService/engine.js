"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DO_NOT_SWAP () {
        return DO_NOT_SWAP;
    },
    get FIRST_AFTER_SECOND () {
        return FIRST_AFTER_SECOND;
    },
    get FIRST_BEFORE_SECOND () {
        return FIRST_BEFORE_SECOND;
    },
    get sort () {
        return sort;
    }
});
const _registry = require("./registry");
const DO_NOT_SWAP = 0;
const FIRST_BEFORE_SECOND = -1;
const FIRST_AFTER_SECOND = 1;
function sort(indexesWithData, rootComparatorId, ...argsForRootComparator) {
    const rootComparator = (0, _registry.getRootComparator)(rootComparatorId);
    indexesWithData.sort(rootComparator(...argsForRootComparator));
}
