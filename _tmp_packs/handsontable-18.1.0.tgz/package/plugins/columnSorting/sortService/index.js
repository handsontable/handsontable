"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DO_NOT_SWAP () {
        return _engine.DO_NOT_SWAP;
    },
    get FIRST_AFTER_SECOND () {
        return _engine.FIRST_AFTER_SECOND;
    },
    get FIRST_BEFORE_SECOND () {
        return _engine.FIRST_BEFORE_SECOND;
    },
    get getCompareFunctionFactory () {
        return _registry.getCompareFunctionFactory;
    },
    get getRootComparator () {
        return _registry.getRootComparator;
    },
    get registerRootComparator () {
        return _registry.registerRootComparator;
    },
    get sort () {
        return _engine.sort;
    }
});
const _registry = require("./registry");
const _engine = require("./engine");
