"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get COLUMN_DATA_TYPE () {
        return COLUMN_DATA_TYPE;
    },
    get compareFunctionFactory () {
        return compareFunctionFactory;
    }
});
const _utils = require("../utils");
function compareFunctionFactory(sortOrder, _columnMeta, columnPluginSettings) {
    return (0, _utils.createDateTimeCompareFunction)(sortOrder, columnPluginSettings);
}
const COLUMN_DATA_TYPE = 'intl-datetime';
