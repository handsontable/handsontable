"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get COLUMN_DATA_TYPE () {
        return COLUMN_DATA_TYPE;
    },
    get compareFunctionFactory () {
        return compareFunctionFactory;
    }
});
const _sortService = require("../sortService");
const _default = require("../sortFunction/default");
const _mixed = require("../../../helpers/mixed");
/**
 * Resolves the sort order result for two checkbox values that are both from the template.
 *
 * @param {unknown} unifiedValue The first unified value.
 * @param {unknown} unifiedNextValue The second unified value.
 * @param {unknown} checkedTemplate The checked template value.
 * @param {unknown} uncheckedTemplate The unchecked template value.
 * @param {string} sortOrder Sort order (`asc` for ascending, `desc` for descending).
 * @returns {number} The comparison result.
 */ function compareTemplateValues(unifiedValue, unifiedNextValue, checkedTemplate, uncheckedTemplate, sortOrder) {
    if (unifiedValue === uncheckedTemplate && unifiedNextValue === checkedTemplate) {
        return sortOrder === 'asc' ? _sortService.FIRST_BEFORE_SECOND : _sortService.FIRST_AFTER_SECOND;
    }
    if (unifiedValue === checkedTemplate && unifiedNextValue === uncheckedTemplate) {
        return sortOrder === 'asc' ? _sortService.FIRST_AFTER_SECOND : _sortService.FIRST_BEFORE_SECOND;
    }
    return _sortService.DO_NOT_SWAP;
}
/**
 * Resolves the sort order result when at least one value is not from the checkbox template.
 *
 * @param {boolean} isValueFromTemplate Whether the first value is from the template.
 * @param {boolean} isNextValueFromTemplate Whether the second value is from the template.
 * @param {string} sortOrder Sort order (`asc` for ascending, `desc` for descending).
 * @param {Function} compareDefaultValues Compare function used for two non-template values.
 * @param {unknown} value The first value.
 * @param {unknown} nextValue The second value.
 * @returns {number | null} The comparison result or null if both values are from template.
 */ function compareBadValues(isValueFromTemplate, isNextValueFromTemplate, sortOrder, compareDefaultValues, value, nextValue) {
    // 1st value === #BAD_VALUE#
    if (isValueFromTemplate === false && isNextValueFromTemplate) {
        return sortOrder === 'asc' ? _sortService.FIRST_BEFORE_SECOND : _sortService.FIRST_AFTER_SECOND;
    }
    // 2nd value === #BAD_VALUE#
    if (isValueFromTemplate && isNextValueFromTemplate === false) {
        return sortOrder === 'asc' ? _sortService.FIRST_AFTER_SECOND : _sortService.FIRST_BEFORE_SECOND;
    }
    // 1st value === #BAD_VALUE# && 2nd value === #BAD_VALUE#
    if (isValueFromTemplate === false && isNextValueFromTemplate === false) {
        // Sorting by values (not just by visual representation).
        return compareDefaultValues(value, nextValue);
    }
    return null;
}
function compareFunctionFactory(sortOrder, columnMeta, columnPluginSettings) {
    const checkedTemplate = columnMeta.checkedTemplate;
    const uncheckedTemplate = columnMeta.uncheckedTemplate;
    const { sortEmptyCells } = columnPluginSettings;
    // Created once per sort run so the default comparator's per-run caches stay effective when
    // non-template ("bad") values fall back to value-based sorting.
    const compareDefaultValues = (0, _default.compareFunctionFactory)(sortOrder, columnMeta, columnPluginSettings);
    return function(value, nextValue) {
        const isEmptyValue = (0, _mixed.isEmpty)(value);
        const isEmptyNextValue = (0, _mixed.isEmpty)(nextValue);
        const unifiedValue = isEmptyValue ? uncheckedTemplate : value;
        const unifiedNextValue = isEmptyNextValue ? uncheckedTemplate : nextValue;
        const isValueFromTemplate = unifiedValue === uncheckedTemplate || unifiedValue === checkedTemplate;
        const isNextValueFromTemplate = unifiedNextValue === uncheckedTemplate || unifiedNextValue === checkedTemplate;
        // As an empty cell we recognize cells with undefined, null and '' values.
        if (sortEmptyCells === false) {
            if (isEmptyValue && isEmptyNextValue === false) {
                return _sortService.FIRST_AFTER_SECOND;
            }
            if (isEmptyValue === false && isEmptyNextValue) {
                return _sortService.FIRST_BEFORE_SECOND;
            }
        }
        const badValueResult = compareBadValues(isValueFromTemplate, isNextValueFromTemplate, sortOrder, compareDefaultValues, value, nextValue);
        if (badValueResult !== null) {
            return badValueResult;
        }
        return compareTemplateValues(unifiedValue, unifiedNextValue, checkedTemplate, uncheckedTemplate, sortOrder);
    };
}
const COLUMN_DATA_TYPE = 'checkbox';
