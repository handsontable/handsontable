"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get COLUMN_DATA_TYPE () {
        return COLUMN_DATA_TYPE;
    },
    get compareFunctionFactory () {
        return compareFunctionFactory;
    }
});
const _mixed = require("../../../helpers/mixed");
const _sortService = require("../sortService");
const _string = require("../../../helpers/string");
/**
 * Normalizes a cell value for comparison by converting booleans to numbers and strings to lowercase.
 *
 * Lowercased strings are memoized in the provided cache. The compare function is created once per
 * sort run, so each distinct string pays the locale-aware lowercasing once instead of on every
 * comparison (~2*log(n) times per row in a sort).
 *
 * @param {unknown} value The value to normalize.
 * @param {string | undefined} locale The locale to use for string lowercasing.
 * @param {Map} lowerCaseCache Per-sort-run cache mapping original strings to lowercased ones.
 * @returns {unknown} The normalized value.
 */ function normalizeValue(value, locale, lowerCaseCache) {
    if (typeof value === 'boolean') {
        return Number(value);
    }
    if (typeof value === 'string') {
        let lowerCasedValue = lowerCaseCache.get(value);
        if (lowerCasedValue === undefined) {
            lowerCasedValue = (0, _string.localeLowerCase)(value, locale);
            lowerCaseCache.set(value, lowerCasedValue);
        }
        return lowerCasedValue;
    }
    return value;
}
/**
 * Compares two non-empty values, handling NaN and numeric coercion.
 *
 * @param {unknown} value The first value.
 * @param {unknown} nextValue The second value.
 * @param {string} sortOrder The sort order (`asc` or `desc`).
 * @returns {number} The comparison result.
 */ function compareNonEmptyValues(value, nextValue, sortOrder) {
    const valueIsNaN = isNaN(value);
    const nextValueIsNaN = isNaN(nextValue);
    if (valueIsNaN && !nextValueIsNaN) {
        return sortOrder === 'asc' ? _sortService.FIRST_AFTER_SECOND : _sortService.FIRST_BEFORE_SECOND;
    }
    if (!valueIsNaN && nextValueIsNaN) {
        return sortOrder === 'asc' ? _sortService.FIRST_BEFORE_SECOND : _sortService.FIRST_AFTER_SECOND;
    }
    let comparableValue = value;
    let comparableNextValue = nextValue;
    if (!valueIsNaN && !nextValueIsNaN) {
        comparableValue = parseFloat(String(value));
        comparableNextValue = parseFloat(String(nextValue));
    }
    const a = comparableValue;
    const b = comparableNextValue;
    if (a < b) {
        return sortOrder === 'asc' ? _sortService.FIRST_BEFORE_SECOND : _sortService.FIRST_AFTER_SECOND;
    }
    if (a > b) {
        return sortOrder === 'asc' ? _sortService.FIRST_AFTER_SECOND : _sortService.FIRST_BEFORE_SECOND;
    }
    return _sortService.DO_NOT_SWAP;
}
function compareFunctionFactory(sortOrder, columnMeta, columnPluginSettings) {
    const locale = columnMeta.locale;
    const lowerCaseCache = new Map();
    return function(value, nextValue) {
        const { sortEmptyCells } = columnPluginSettings;
        const normalizedValue = normalizeValue(value, locale, lowerCaseCache);
        const normalizedNextValue = normalizeValue(nextValue, locale, lowerCaseCache);
        if (normalizedValue === normalizedNextValue) {
            return _sortService.DO_NOT_SWAP;
        }
        if ((0, _mixed.isEmpty)(normalizedValue)) {
            if ((0, _mixed.isEmpty)(normalizedNextValue)) {
                return _sortService.DO_NOT_SWAP;
            }
            // Just fist value is empty and `sortEmptyCells` option was set
            if (sortEmptyCells) {
                return sortOrder === 'asc' ? _sortService.FIRST_BEFORE_SECOND : _sortService.FIRST_AFTER_SECOND;
            }
            return _sortService.FIRST_AFTER_SECOND;
        }
        if ((0, _mixed.isEmpty)(normalizedNextValue)) {
            // Just second value is empty and `sortEmptyCells` option was set
            if (sortEmptyCells) {
                return sortOrder === 'asc' ? _sortService.FIRST_AFTER_SECOND : _sortService.FIRST_BEFORE_SECOND;
            }
            return _sortService.FIRST_BEFORE_SECOND;
        }
        return compareNonEmptyValues(normalizedValue, normalizedNextValue, sortOrder);
    };
}
const COLUMN_DATA_TYPE = 'default';
