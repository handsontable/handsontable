"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get HEADER_ACTION_CLASS () {
        return HEADER_ACTION_CLASS;
    },
    get HEADER_CLASS_ASC_SORT () {
        return HEADER_CLASS_ASC_SORT;
    },
    get HEADER_CLASS_DESC_SORT () {
        return HEADER_CLASS_DESC_SORT;
    },
    get getClassesToAdd () {
        return getClassesToAdd;
    },
    get getClassesToRemove () {
        return getClassesToRemove;
    }
});
const _utils = require("./utils");
const HEADER_CLASS_ASC_SORT = 'ascending';
const HEADER_CLASS_DESC_SORT = 'descending';
const HEADER_CLASS_INDICATOR_DISABLED = 'indicatorDisabled';
const HEADER_SORT_CLASS = 'columnSorting';
const HEADER_ACTION_CLASS = 'sortAction';
const orderToCssClass = new Map([
    [
        _utils.ASC_SORT_STATE,
        HEADER_CLASS_ASC_SORT
    ],
    [
        _utils.DESC_SORT_STATE,
        HEADER_CLASS_DESC_SORT
    ]
]);
function getClassesToAdd(columnStatesManager, column, showSortIndicator, headerAction) {
    const cssClasses = [
        HEADER_SORT_CLASS
    ];
    if (headerAction) {
        cssClasses.push(HEADER_ACTION_CLASS);
    }
    if (showSortIndicator === false) {
        cssClasses.push(HEADER_CLASS_INDICATOR_DISABLED);
        return cssClasses;
    }
    const columnOrder = columnStatesManager.getSortOrderOfColumn(column);
    if (columnOrder !== undefined) {
        const cssClass = orderToCssClass.get(columnOrder);
        if (cssClass !== undefined) {
            cssClasses.push(cssClass);
        }
    }
    return cssClasses;
}
function getClassesToRemove(_headerSpanElement) {
    return Array.from(orderToCssClass.values()).concat(HEADER_ACTION_CLASS, HEADER_CLASS_INDICATOR_DISABLED, HEADER_SORT_CLASS);
}
