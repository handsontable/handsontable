"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get APPEND_COLUMN_CONFIG_STRATEGY () {
        return _columnSorting.APPEND_COLUMN_CONFIG_STRATEGY;
    },
    get ColumnSorting () {
        return _columnSorting.ColumnSorting;
    },
    get PLUGIN_KEY () {
        return _columnSorting.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _columnSorting.PLUGIN_PRIORITY;
    },
    get REPLACE_COLUMN_CONFIG_STRATEGY () {
        return _columnSorting.REPLACE_COLUMN_CONFIG_STRATEGY;
    }
});
const _columnSorting = require("./columnSorting");
