"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get APPEND_COLUMN_CONFIG_STRATEGY () {
        return APPEND_COLUMN_CONFIG_STRATEGY;
    },
    get ColumnSorting () {
        return ColumnSorting;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    },
    get REPLACE_COLUMN_CONFIG_STRATEGY () {
        return REPLACE_COLUMN_CONFIG_STRATEGY;
    }
});
const _element = require("../../helpers/dom/element");
const _mixed = require("../../helpers/mixed");
const _object = require("../../helpers/object");
const _function = require("../../helpers/function");
const _array = require("../../helpers/array");
const _base = require("../base");
const _hooks = require("../../core/hooks");
const _columnStatesManager = require("./columnStatesManager");
const _contexts = require("../../shortcuts/contexts");
const _utils = require("./utils");
const _domHelpers = require("./domHelpers");
const _rootComparator = require("./rootComparator");
const _sortService = require("./sortService");
const _a11y = require("../../helpers/a11y");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
const PLUGIN_KEY = 'columnSorting';
const PLUGIN_PRIORITY = 50;
const APPEND_COLUMN_CONFIG_STRATEGY = 'append';
const REPLACE_COLUMN_CONFIG_STRATEGY = 'replace';
const SHORTCUTS_GROUP = PLUGIN_KEY;
/**
 * Marks the header container of a column that is showing a sort indicator. The indicator is
 * positioned against that container, so the room it needs is reserved there rather than as padding
 * on the label - padding on the label would enlarge the area that sorts on click, which is exactly
 * what it must not do. A class rather than a `:has()` selector, which is banned in this package.
 */ const CONTAINER_WITH_INDICATOR_CLASS = 'has-sort-indicator';
(0, _sortService.registerRootComparator)(PLUGIN_KEY, _rootComparator.rootComparator);
_hooks.Hooks.getSingleton().register('beforeColumnSort');
_hooks.Hooks.getSingleton().register('afterColumnSort');
/**
 * Tracks the conflicts between `columnSorting` and `multiColumnSorting` options.
 * Only one plugin can be enabled for Handsontable instance. Once one of them is enabled,
 * the other should remain disabled even if it's set to `true`.
 */ const pluginConflictsState = new WeakMap();
var /**
   * Sort queued by a header press, applied on mouse up unless the press became a column drag.
   */ _pendingHeaderSort = /*#__PURE__*/ new WeakMap(), /**
   * Sort by predefined plugin configuration.
   */ _loadOrSortBySettings = /*#__PURE__*/ new WeakMap(), /**
   * Callback for the `onAfterGetColHeader` hook. Adds column sorting CSS classes.
   *
   * @param {number} column Visual column index.
   * @param {Element} TH TH HTML element.
   */ _onAfterGetColHeader = /*#__PURE__*/ new WeakMap(), /**
   * Reserves room for the sort indicator on the header container, matching the state the label
   * was just given.
   *
   * Called from the header render paths, not from `updateHeaderClasses`, so it runs after any
   * subclass override has finished adding its classes. `TableView` rebuilds the container's class
   * list on every render, so this has to run per render.
   *
   * @param {HTMLElement} headerSpanElement The header label element.
   */ _syncIndicatorReserve = /*#__PURE__*/ new WeakSet(), /**
   * Callback for the `afterLoadData` hook.
   *
   * @param {boolean} initialLoad Flag that determines whether the data has been loaded during the initialization.
   */ _onAfterLoadData = /*#__PURE__*/ new WeakMap(), _onAfterDataProviderFetch = /*#__PURE__*/ new WeakMap(), /**
   * Changes the behavior of selection / dragging.
   *
   * @param {MouseEvent} event The `mousedown` event.
   * @param {CellCoords} coords Visual coordinates.
   * @param {HTMLElement} TD The cell element.
   * @param {object} controller An object with properties `row`, `column` and `cell`. Each property contains
   *                            a boolean value that allows or disallows changing the selection for that particular area.
   */ _onBeforeOnCellMouseDown = /*#__PURE__*/ new WeakMap(), /**
   * Resolves a header press on release: sorts, unless ManualColumnMove turned the press into a
   * drag.
   *
   * Safe to call more than once for the same gesture - the queued press is taken first, so
   * whichever release signal arrives first wins and the rest are no-ops.
   */ _resolvePendingSort = /*#__PURE__*/ new WeakMap(), /**
   * Marks a queued press as spent once ManualColumnMove has moved the column.
   */ _onAfterColumnMove = /*#__PURE__*/ new WeakMap(), /**
   * Whether ManualColumnMove is mid-drag. False when that plugin is absent or disabled.
   */ _isColumnBeingDragged = /*#__PURE__*/ new WeakSet();
class ColumnSorting extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Checks if the plugin is enabled in the Handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link ColumnSorting#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[this.pluginKey];
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (pluginConflictsState.has(this.hot) && pluginConflictsState.get(this.hot) !== this.pluginKey) {
            this.hot.updateSettings({
                [this.pluginKey]: false
            });
            (0, _utils.warnAboutPluginsConflict)(pluginConflictsState.get(this.hot), this.pluginKey);
            return;
        }
        if (this.enabled) {
            return;
        }
        pluginConflictsState.set(this.hot, this.pluginKey);
        this.columnStatesManager = new _columnStatesManager.ColumnStatesManager(this.hot, `${this.pluginKey}.sortingStates`);
        this.columnMetaCache = this.hot.columnIndexMapper.createAndRegisterIndexMap(`${this.pluginKey}.columnMeta`, 'physicalIndexToValue', (physicalIndex)=>{
            let visualIndex = this.hot.toVisualColumn(physicalIndex);
            if (visualIndex === null) {
                visualIndex = physicalIndex;
            }
            return this.getMergedPluginSettings(visualIndex);
        });
        this.addHook('afterGetColHeader', _class_private_field_get(this, _onAfterGetColHeader));
        this.addHook('beforeOnCellMouseDown', _class_private_field_get(this, _onBeforeOnCellMouseDown));
        this.addHook('afterOnCellMouseDown', (event, target)=>this.onAfterOnCellMouseDown(event, target));
        // Primary release signal. On touch devices Walkontable calls its `onMouseUp` directly from
        // `touchend` instead of dispatching a DOM `mouseup`, so a document listener alone would never
        // fire and tapping a header would stop sorting.
        this.addHook('afterOnCellMouseUp', _class_private_field_get(this, _resolvePendingSort));
        // Fallback for a release that lands outside any cell - that is the drag case, and the queued
        // sort still has to be cleared rather than left pending for the next release.
        this.eventManager.addEventListener(this.hot.rootDocument.documentElement, 'mouseup', ()=>_class_private_field_get(this, _resolvePendingSort).call(this));
        this.addHook('afterColumnMove', _class_private_field_get(this, _onAfterColumnMove));
        this.addHook('afterInit', _class_private_field_get(this, _loadOrSortBySettings));
        this.addHook('afterLoadData', _class_private_field_get(this, _onAfterLoadData));
        this.addHook('afterDataProviderFetch', _class_private_field_get(this, _onAfterDataProviderFetch), -1);
        // TODO: Workaround? It should be refactored / described.
        if (this.hot.view) {
            _class_private_field_get(this, _loadOrSortBySettings).call(this);
        }
        this.registerShortcuts();
        super.enablePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        const clearColHeader = (column, TH)=>{
            const headerSpanElement = (0, _utils.getHeaderSpanElement)(TH);
            if ((0, _utils.isFirstLevelColumnHeader)(column, TH) === false || headerSpanElement === null) {
                return;
            }
            this.updateHeaderClasses(headerSpanElement);
            _class_private_method_get(this, _syncIndicatorReserve, syncIndicatorReserve).call(this, headerSpanElement);
        };
        pluginConflictsState.delete(this.hot);
        // Changing header width and removing indicator.
        this.hot.addHook('afterGetColHeader', clearColHeader);
        this.hot.addHookOnce('afterViewRender', ()=>{
            this.hot.removeHook('afterGetColHeader', clearColHeader);
        });
        this.hot.batchExecution(()=>{
            if (this.indexesSequenceCache !== null) {
                this.hot.rowIndexMapper.setIndexesSequence(this.indexesSequenceCache.getValues());
                this.hot.rowIndexMapper.unregisterMap(this.pluginKey);
                this.indexesSequenceCache = null;
            }
        }, true);
        this.hot.columnIndexMapper.unregisterMap(`${this.pluginKey}.columnMeta`);
        this.columnStatesManager?.destroy();
        this.columnMetaCache = null;
        this.columnStatesManager = null;
        _class_private_field_set(this, _pendingHeaderSort, null);
        this.unregisterShortcuts();
        super.disablePlugin();
    }
    /**
   * Register shortcuts responsible for toggling column sorting functionality.
   *
   * @private
   */ registerShortcuts() {
        this.hot.getShortcutManager().getContext('grid')?.addShortcut({
            keys: [
                [
                    'Enter'
                ]
            ],
            callback: ()=>{
                const activeRange = this.hot.getSelectedRangeActive();
                if (!activeRange) {
                    return false;
                }
                const { highlight } = activeRange;
                this.sort(this.getColumnNextConfig(highlight.col ?? 0));
                // prevent default Enter behavior (move to the next row within a selection range)
                return false;
            },
            runOnlyIf: ()=>{
                const highlight = this.hot.getSelectedRangeActive()?.highlight;
                const highlightedHeaderElement = highlight && highlight.row !== null && highlight.col !== null ? this.hot.getCell(highlight.row, highlight.col, true) : null;
                return !!(highlight && this.hot.getSelectedRangeActive()?.isSingle() && this.hot.selection.isCellVisible(highlight) && highlight.row !== null && highlight.row < 0 && highlight.col !== null && highlight.col >= 0 && highlightedHeaderElement && (0, _element.isBottomMostColumnHeader)(highlightedHeaderElement));
            },
            relativeToGroup: _contexts.EDITOR_EDIT_GROUP,
            position: 'before',
            group: SHORTCUTS_GROUP
        });
    }
    /**
   * Unregister shortcuts responsible for toggling column sorting functionality.
   *
   * @private
   */ unregisterShortcuts() {
        this.hot.getShortcutManager().getContext('grid')?.removeShortcutsByGroup(SHORTCUTS_GROUP);
    }
    // DIFF - MultiColumnSorting & ColumnSorting: changed function documentation.
    /**
   * Sorts the table by chosen columns and orders.
   *
   * @param {undefined|object} sortConfig Single column sort configuration. The configuration object contains `column` and `sortOrder` properties.
   * First of them contains visual column index, the second one contains sort order (`asc` for ascending, `desc` for descending).
   *
   * **Note**: Please keep in mind that every call of `sort` function set an entirely new sort order. Previous sort configs aren't preserved.
   *
   * @example
   * ```js
   * // sort ascending first visual column
   * hot.getPlugin('columnSorting').sort({ column: 0, sortOrder: 'asc' });
   * ```
   *
   * @fires Hooks#beforeColumnSort
   * @fires Hooks#afterColumnSort
   */ sort(sortConfig) {
        const currentSortConfig = this.columnStatesManager.getSortStates();
        // We always pass configs defined as an array to `beforeColumnSort` and `afterColumnSort` hooks.
        const destinationSortConfigs = this.getNormalizedSortConfigs(sortConfig);
        const sortPossible = this.areValidSortConfigs(destinationSortConfigs);
        const allowSort = this.hot.runHooks('beforeColumnSort', currentSortConfig, destinationSortConfigs, sortPossible);
        if (allowSort === false) {
            return;
        }
        if (currentSortConfig.length === 0 && this.indexesSequenceCache === null) {
            this.indexesSequenceCache = this.hot.rowIndexMapper.createAndRegisterIndexMap(this.pluginKey, 'indexesSequence');
            this.indexesSequenceCache.setValues(this.hot.rowIndexMapper.getIndexesSequence());
        }
        if (sortPossible) {
            this.columnStatesManager?.setSortStates(destinationSortConfigs);
            this.sortByPresetSortStates(destinationSortConfigs);
        }
        this.hot.runHooks('afterColumnSort', currentSortConfig, sortPossible ? destinationSortConfigs : currentSortConfig, sortPossible);
        if (sortPossible) {
            this.hot.render();
        }
    }
    /**
   * Clear the sort performed on the table.
   */ clearSort() {
        this.sort([]);
    }
    /**
   * Checks if the table is sorted (any column have to be sorted).
   *
   * @returns {boolean}
   */ isSorted() {
        return this.enabled && !this.columnStatesManager?.isListOfSortedColumnsEmpty();
    }
    /**
   * Get sort configuration for particular column or for all sorted columns. Objects contain `column` and `sortOrder` properties.
   *
   * **Note**: Please keep in mind that returned objects expose **visual** column index under the `column` key. They are handled by the `sort` function.
   *
   * @param {number} [column] Visual column index.
   * @returns {undefined|object|Array}
   */ getSortConfig(column) {
        if (column !== undefined) {
            return this.columnStatesManager?.getColumnSortState(column);
        }
        return this.columnStatesManager?.getSortStates();
    }
    /**
   * @description
   * Warn: Useful mainly for providing server side sort implementation (see in the example below). It doesn't sort the data set. It just sets sort configuration for all sorted columns.
   * Note: Please keep in mind that this method doesn't re-render the table.
   *
   * @example
   * ```js
   * beforeColumnSort: function(currentSortConfig, destinationSortConfigs) {
   *   const columnSortPlugin = this.getPlugin('columnSorting');
   *
   *   columnSortPlugin.setSortConfig(destinationSortConfigs);
   *
   *   // const newData = ... // Calculated data set, ie. from an AJAX call.
   *
   *   this.updateData(newData); // Update data set and re-render the table.
   *
   *   return false; // The blockade for the default sort action.
   * }
   * ```
   *
   * @param {undefined|object|Array} sortConfig Single column sort configuration or full sort configuration (for all sorted columns).
   * The configuration object contains `column` and `sortOrder` properties. First of them contains visual column index, the second one contains
   * sort order (`asc` for ascending, `desc` for descending).
   */ setSortConfig(sortConfig) {
        // We always set configs defined as an array.
        const destinationSortConfigs = this.getNormalizedSortConfigs(sortConfig);
        if (this.areValidSortConfigs(destinationSortConfigs)) {
            this.columnStatesManager?.setSortStates(destinationSortConfigs);
        }
    }
    /**
   * Get normalized sort configs.
   *
   * @private
   * @param {object|Array} [sortConfig=[]] Single column sort configuration or full sort configuration (for all sorted columns).
   * The configuration object contains `column` and `sortOrder` properties. First of them contains visual column index, the second one contains
   * sort order (`asc` for ascending, `desc` for descending).
   * @returns {Array}
   */ getNormalizedSortConfigs(sortConfig = []) {
        if (Array.isArray(sortConfig)) {
            return sortConfig.slice(0, 1);
        }
        return [
            sortConfig
        ];
    }
    /**
   * Get if sort configs are valid.
   *
   * @private
   * @param {Array} sortConfigs Sort configuration for all sorted columns. Objects contain `column` and `sortOrder` properties.
   * @returns {boolean}
   */ areValidSortConfigs(sortConfigs) {
        const numberOfColumns = this.hot.countCols();
        // We don't translate visual indexes to physical indexes.
        return (0, _utils.areValidSortStates)(sortConfigs) && sortConfigs.every(({ column })=>column <= numberOfColumns && column >= 0);
    }
    /**
   * Get next sort configuration for particular column. Object contain `column` and `sortOrder` properties.
   *
   * **Note**: Please keep in mind that returned object expose **visual** column index under the `column` key.
   *
   * @private
   * @param {number} column Visual column index.
   * @returns {undefined|object}
   */ getColumnNextConfig(column) {
        const sortOrder = this.columnStatesManager?.getSortOrderOfColumn(column);
        if ((0, _mixed.isDefined)(sortOrder)) {
            const nextSortOrder = (0, _utils.getNextSortOrder)(sortOrder);
            if (nextSortOrder !== undefined) {
                return {
                    column,
                    sortOrder: nextSortOrder
                };
            }
            return;
        }
        const nrOfColumns = this.hot.countCols();
        if (Number.isInteger(column) && column >= 0 && column < nrOfColumns) {
            return {
                column,
                sortOrder: (0, _utils.getNextSortOrder)() ?? 'asc'
            };
        }
    }
    /**
   * Get sort configuration with "next order" for particular column.
   *
   * @private
   * @param {number} columnToChange Visual column index of column which order will be changed.
   * @param {string} strategyId ID of strategy. Possible values: 'append' and 'replace'. The first one
   * change order of particular column and change it's position in the sort queue to the last one. The second one
   * just change order of particular column.
   *
   * **Note**: Please keep in mind that returned objects expose **visual** column index under the `column` key.
   *
   * @returns {Array}
   */ getNextSortConfig(columnToChange, strategyId = APPEND_COLUMN_CONFIG_STRATEGY) {
        const indexOfColumnToChange = this.columnStatesManager.getIndexOfColumnInSortQueue(columnToChange);
        const isColumnSorted = indexOfColumnToChange !== -1;
        const currentSortConfig = this.columnStatesManager.getSortStates();
        const nextColumnConfig = this.getColumnNextConfig(columnToChange);
        if (isColumnSorted) {
            if ((0, _mixed.isUndefined)(nextColumnConfig)) {
                return [
                    ...currentSortConfig.slice(0, indexOfColumnToChange),
                    ...currentSortConfig.slice(indexOfColumnToChange + 1)
                ];
            }
            if (strategyId === APPEND_COLUMN_CONFIG_STRATEGY) {
                return [
                    ...currentSortConfig.slice(0, indexOfColumnToChange),
                    ...currentSortConfig.slice(indexOfColumnToChange + 1),
                    nextColumnConfig
                ];
            } else if (strategyId === REPLACE_COLUMN_CONFIG_STRATEGY) {
                return [
                    ...currentSortConfig.slice(0, indexOfColumnToChange),
                    nextColumnConfig,
                    ...currentSortConfig.slice(indexOfColumnToChange + 1)
                ];
            }
        }
        if (nextColumnConfig !== undefined) {
            return currentSortConfig.concat(nextColumnConfig);
        }
        return currentSortConfig;
    }
    /**
   * Get plugin's column config for the specified column index.
   *
   * @private
   * @param {object} columnConfig Configuration inside `columns` property for the specified column index.
   * @returns {object}
   */ getPluginColumnConfig(columnConfig) {
        if ((0, _object.isObject)(columnConfig)) {
            const pluginColumnConfig = columnConfig[this.pluginKey];
            if ((0, _object.isObject)(pluginColumnConfig)) {
                return pluginColumnConfig;
            }
        }
        return {};
    }
    /**
   * Get plugin settings related properties, properly merged from cascade settings.
   *
   * @private
   * @param {number} column Visual column index.
   * @returns {object}
   */ getMergedPluginSettings(column) {
        const pluginMainSettings = this.hot.getSettings()[this.pluginKey];
        const storedColumnProperties = this.columnStatesManager?.getAllColumnsProperties() ?? {};
        const cellMeta = this.hot.getCellMetaTransient(0, column);
        const columnMeta = Object.getPrototypeOf(cellMeta);
        if (Array.isArray(columnMeta.columns)) {
            return Object.assign(storedColumnProperties, pluginMainSettings, this.getPluginColumnConfig(columnMeta.columns[column]));
        } else if ((0, _function.isFunction)(columnMeta.columns)) {
            const columnConfig = columnMeta.columns(column);
            return Object.assign(storedColumnProperties, pluginMainSettings, this.getPluginColumnConfig(columnConfig));
        }
        return Object.assign(storedColumnProperties, pluginMainSettings);
    }
    /**
   * Get copy of settings for first cell in the column.
   *
   * @private
   * @param {number} column Visual column index.
   * @returns {object}
   */ // TODO: Workaround. Inheriting of non-primitive cell meta values doesn't work. Instead of getting properties from column meta we call this function.
    // TODO: Remove test named: "should not break the dataset when inserted new row" (#5431).
    getFirstCellSettings(column) {
        const cellMeta = this.hot.getCellMetaTransient(0, column);
        const cellMetaCopy = Object.create(cellMeta);
        cellMetaCopy[this.pluginKey] = this.columnMetaCache?.getValueAtIndex(this.hot.toPhysicalColumn(column));
        return cellMetaCopy;
    }
    /**
   * Get number of rows which should be sorted.
   *
   * @private
   * @param {number} numberOfRows Total number of displayed rows.
   * @returns {number}
   */ getNumberOfRowsToSort(numberOfRows) {
        const settings = this.hot.getSettings();
        const fixedRowsBottom = settings.fixedRowsBottom || 0;
        // `maxRows` option doesn't take into account `minSpareRows` option in this case.
        // `fixedRowsBottom` is excluded from the sort range so footer rows (e.g. SUM formulas)
        // stay pinned and keep their absolute-address references intact.
        if ((settings.maxRows ?? Infinity) <= numberOfRows) {
            return Math.max(0, (settings.maxRows ?? 0) - fixedRowsBottom);
        }
        return Math.max(0, numberOfRows - (settings.minSpareRows ?? 0) - fixedRowsBottom);
    }
    /**
   * Performs the sorting using a stable sort function basing on internal state of sorting.
   *
   * @param {Array} sortConfigs Sort configuration for all sorted columns. Objects contain `column` and `sortOrder` properties.
   * @private
   */ sortByPresetSortStates(sortConfigs) {
        this.hot.rowIndexMapper.setIndexesSequence(this.indexesSequenceCache.getValues());
        if (sortConfigs.length === 0) {
            return;
        }
        const indexesWithData = [];
        const numberOfRows = this.hot.countRows();
        const settings = this.hot.getSettings();
        const fixedRowsTop = settings.fixedRowsTop || 0;
        const upperBound = this.getNumberOfRowsToSort(numberOfRows);
        const getDataForSortedColumns = (visualRowIndex)=>(0, _array.arrayMap)(sortConfigs, (sortConfig)=>this.hot.getDataAtCell(visualRowIndex, sortConfig.column));
        for(let visualRowIndex = fixedRowsTop; visualRowIndex < upperBound; visualRowIndex += 1){
            indexesWithData.push([
                this.hot.toPhysicalRow(visualRowIndex),
                ...getDataForSortedColumns(visualRowIndex)
            ]);
        }
        const indexesBefore = (0, _array.arrayMap)(indexesWithData, (indexWithData)=>indexWithData[0]);
        (0, _sortService.sort)(indexesWithData, this.pluginKey, (0, _array.arrayMap)(sortConfigs, (sortConfig)=>sortConfig.sortOrder), (0, _array.arrayMap)(sortConfigs, (sortConfig)=>this.getFirstCellSettings(sortConfig.column)));
        // Append fixedRowsBottom + spareRows (everything between upperBound and numberOfRows)
        for(let visualRowIndex = upperBound; visualRowIndex < numberOfRows; visualRowIndex += 1){
            indexesWithData.push([
                visualRowIndex,
                ...getDataForSortedColumns(visualRowIndex)
            ]);
        }
        const indexesAfter = (0, _array.arrayMap)(indexesWithData, (indexWithData)=>indexWithData[0]);
        const indexMapping = new Map((0, _array.arrayMap)(indexesBefore, (indexBefore, indexInsideArray)=>[
                indexBefore,
                indexesAfter[indexInsideArray]
            ]));
        const newIndexesSequence = (0, _array.arrayMap)(this.hot.rowIndexMapper.getIndexesSequence(), (physicalIndex)=>{
            return indexMapping.get(physicalIndex) ?? physicalIndex;
        });
        this.hot.rowIndexMapper.setIndexesSequence(newIndexesSequence);
    }
    /**
   * Sort the table by provided configuration.
   *
   * @private
   * @param {object} allSortSettings All sort config settings. Object may contain `initialConfig`, `indicator`,
   * `sortEmptyCells`, `headerAction` and `compareFunctionFactory` properties.
   */ sortBySettings(allSortSettings) {
        if ((0, _object.isPlainObject)(allSortSettings)) {
            this.columnStatesManager.updateAllColumnsProperties(allSortSettings);
            const { initialConfig } = allSortSettings;
            if (Array.isArray(initialConfig) || (0, _object.isPlainObject)(initialConfig)) {
                this.sort(initialConfig);
            }
        } else {
            // Extra render for headers. Their width may change.
            this.hot.render();
        }
    }
    /**
   * Update header classes.
   *
   * @private
   * @param {HTMLElement} headerSpanElement Header span element.
   * @param {...*} args Extra arguments for helpers.
   */ updateHeaderClasses(headerSpanElement, columnStatesManager, column, showSortIndicator, headerActionEnabled) {
        (0, _element.removeClass)(headerSpanElement, (0, _domHelpers.getClassesToRemove)(headerSpanElement));
        if (this.enabled !== false && columnStatesManager !== undefined && column !== undefined) {
            (0, _element.addClass)(headerSpanElement, (0, _domHelpers.getClassesToAdd)(columnStatesManager, column, showSortIndicator ?? false, headerActionEnabled ?? false));
        }
    }
    /**
   * Overwriting base plugin's `onUpdateSettings` method. Please keep in mind that `onAfterUpdateSettings` isn't called
   * for `updateSettings` in specific situations.
   *
   * @private
   * @param {object} newSettings New settings object.
   */ onUpdateSettings(newSettings) {
        super.onUpdateSettings(newSettings);
        if (this.columnMetaCache !== null) {
            // Column meta cache base on settings, thus we should re-init the map.
            this.columnMetaCache.init(this.hot.columnIndexMapper.getNumberOfIndexes());
        }
        const pluginSettings = newSettings[this.pluginKey];
        if ((0, _mixed.isDefined)(pluginSettings)) {
            this.sortBySettings(pluginSettings);
        }
    }
    /**
   * Indicates if clickable header was clicked.
   *
   * @private
   * @param {MouseEvent} event The `mousedown` event.
   * @param {number} column Visual column index.
   * @returns {boolean}
   */ wasClickableHeaderClicked(event, column) {
        const columnSettings = this.getFirstCellSettings(column);
        const pluginSettingsForColumn = columnSettings[this.pluginKey];
        const headerActionEnabled = pluginSettingsForColumn.headerAction;
        return headerActionEnabled && (0, _element.hasClass)((0, _element.eventTargetEl)(event), _utils.HEADER_SPAN_CLASS);
    }
    /**
   * Callback for the `onAfterOnCellMouseDown` hook.
   *
   * Queues the sort rather than running it. The header is also the surface ManualColumnMove
   * drags a column by, so which action the user meant is only known once the button is
   * released: a press that stays put is a click to sort, a press that travels is a drag.
   * Selection changes stay here so the header still reacts the moment it is pressed.
   *
   * @private
   * @param {Event} event Event which are provided by hook.
   * @param {CellCoords} coords Visual coords of the selected cell.
   */ onAfterOnCellMouseDown(event, coords) {
        if ((0, _utils.wasHeaderClickedProperly)(coords.row, coords.col, event) === false) {
            return;
        }
        if (this.wasClickableHeaderClicked(event, coords.col) === false) {
            return;
        }
        const isCtrlPressed = this.hot.getShortcutManager().isCtrlPressed();
        if (isCtrlPressed) {
            this.hot.deselectCell();
            this.hot.selectColumns(coords.col);
        }
        const activeEditor = this.hot.getActiveEditor();
        const awaitsValidation = !!(activeEditor?.isOpened() && this.hot.getCellValidator(activeEditor.row, activeEditor.col));
        _class_private_field_set(this, _pendingHeaderSort, {
            column: coords.col,
            isCtrlPressed,
            // Subscribed on press, not on release: selecting the column closes the editor and its
            // validation runs in a microtask, so it is already over before mouse up. Reading
            // `awaitsValidation` on release is wrong too - by then the new selection has opened an
            // editor on the highlighted cell.
            validation: awaitsValidation ? new Promise((resolve)=>{
                this.hot.addHookOnce('postAfterValidate', ()=>resolve());
            }) : null,
            consumedByMove: false
        });
    }
    /**
   * Applies the sort queued by a header press.
   *
   * Kept separate from the press handler so `MultiColumnSorting` can choose a different sort
   * configuration for the same gesture without repeating the click-versus-drag handling.
   *
   * @private
   * @param {object} press The press that queued this sort.
   */ applyHeaderClickSort(press) {
        this.sort(this.getColumnNextConfig(press.column));
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        // `BasePlugin.destroy` nulls enumerable own properties, which cannot reach a `#private`
        // field, so drop the queued press here.
        _class_private_field_set(this, _pendingHeaderSort, null);
        // TODO: Probably not supported yet by ESLint: https://github.com/eslint/eslint/issues/11045
        // eslint-disable-next-line no-unused-expressions
        this.columnStatesManager?.destroy();
        super.destroy();
    }
    constructor(...args){
        super(...args), _class_private_method_init(this, _syncIndicatorReserve), _class_private_method_init(this, _isColumnBeingDragged), _class_private_field_init(this, _pendingHeaderSort, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _loadOrSortBySettings, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterGetColHeader, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterLoadData, {
            writable: true,
            value: void 0
        }), /**
   * Callback for the `afterDataProviderFetch` hook.
   * Keeps header sort state in sync with query `sort` after server-backed `loadData` (same timing as Pagination).
   *
   * @param {object} result [[Hooks#afterDataProviderFetch]] payload; reads `columnSortConfig` only.
   */ _class_private_field_init(this, _onAfterDataProviderFetch, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onBeforeOnCellMouseDown, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _resolvePendingSort, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterColumnMove, {
            writable: true,
            value: void 0
        }), /**
   * Instance of column state manager.
   *
   * @private
   * @type {null|ColumnStatesManager}
   */ this.columnStatesManager = null, /**
   * Cached column properties from plugin like i.e. `indicator`, `headerAction`.
   *
   * @private
   * @type {null|PhysicalIndexToValueMap}
   */ this.columnMetaCache = null, _class_private_field_set(this, _pendingHeaderSort, null), /**
   * Main settings key designed for the plugin.
   *
   * @private
   * @type {string}
   */ this.pluginKey = PLUGIN_KEY, /**
   * Plugin indexes cache.
   *
   * @private
   * @type {null|IndexesSequence}
   */ this.indexesSequenceCache = null, _class_private_field_set(this, _loadOrSortBySettings, ()=>{
            const allSortSettings = this.hot.getSettings()[this.pluginKey];
            this.sortBySettings(allSortSettings);
        }), _class_private_field_set(this, _onAfterGetColHeader, (column, TH)=>{
            const headerSpanElement = (0, _utils.getHeaderSpanElement)(TH);
            if ((0, _utils.isFirstLevelColumnHeader)(column, TH) === false || headerSpanElement === null) {
                return;
            }
            const columnSettings = this.getFirstCellSettings(column);
            const pluginSettingsForColumn = columnSettings[this.pluginKey];
            const showSortIndicator = pluginSettingsForColumn.indicator;
            const headerActionEnabled = pluginSettingsForColumn.headerAction;
            this.updateHeaderClasses(headerSpanElement, this.columnStatesManager ?? undefined, column, showSortIndicator, headerActionEnabled);
            _class_private_method_get(this, _syncIndicatorReserve, syncIndicatorReserve).call(this, headerSpanElement);
            if (this.hot.getSettings().ariaTags) {
                const currentSortState = this.columnStatesManager?.getSortOrderOfColumn(column);
                (0, _element.setAttribute)(TH, ...(0, _a11y.A11Y_SORT)(currentSortState ? `${currentSortState}ending` : 'none'));
            }
        }), _class_private_field_set(this, _onAfterLoadData, (initialLoad)=>{
            if (initialLoad === true) {
                // TODO: Workaround? It should be refactored / described.
                if (this.hot.view) {
                    _class_private_field_get(this, _loadOrSortBySettings).call(this);
                }
            }
        }), _class_private_field_set(this, _onAfterDataProviderFetch, (result)=>{
            this.setSortConfig(result?.columnSortConfig ?? []);
        }), _class_private_field_set(this, _onBeforeOnCellMouseDown, (event, coords, TD, controller)=>{
            // Drop any press whose release never arrived - e.g. the window lost focus while the button
            // was held. Without this a stale press would resolve on the next unrelated release and sort
            // a column out of nowhere.
            _class_private_field_set(this, _pendingHeaderSort, null);
            if ((0, _utils.wasHeaderClickedProperly)(coords.row, coords.col, event) === false) {
                return;
            }
            if (this.wasClickableHeaderClicked(event, coords.col) && this.hot.getShortcutManager().isCtrlPressed()) {
                controller.column = true;
            }
        }), _class_private_field_set(this, _resolvePendingSort, ()=>{
            const pending = _class_private_field_get(this, _pendingHeaderSort);
            if (pending === null) {
                return;
            }
            _class_private_field_set(this, _pendingHeaderSort, null);
            // Two signals, because both plugins handle the same `mouseup` and the listener order is not
            // fixed - re-enabling `columnSorting` after `manualColumnMove` appends this plugin's listener
            // last. Running first, the drag is still in progress; running second, the move has already
            // fired. Either one cancels the sort.
            if (pending.consumedByMove || _class_private_method_get(this, _isColumnBeingDragged, isColumnBeingDragged).call(this)) {
                return;
            }
            // A cell that was mid-edit must finish validating before the rows move under it. Waited on
            // here, not in `applyHeaderClickSort`, so subclasses that override that seam still get it.
            if (pending.validation === null) {
                this.applyHeaderClickSort(pending);
                return;
            }
            void pending.validation.then(()=>this.applyHeaderClickSort(pending));
        }), _class_private_field_set(this, _onAfterColumnMove, ()=>{
            if (_class_private_field_get(this, _pendingHeaderSort) !== null) {
                _class_private_field_get(this, _pendingHeaderSort).consumedByMove = true;
            }
        });
    }
}
function syncIndicatorReserve(headerSpanElement) {
    const container = headerSpanElement.parentElement;
    if (container === null) {
        return;
    }
    // `sortAction` is required: the CSS that pulls the indicator out of the flex row is keyed on
    // it. With `headerAction: false` the label shows an indicator but keeps its full width, so
    // reserving would just push it inwards.
    const showsIndicator = (0, _element.hasClass)(headerSpanElement, _domHelpers.HEADER_ACTION_CLASS) && ((0, _element.hasClass)(headerSpanElement, _domHelpers.HEADER_CLASS_ASC_SORT) || (0, _element.hasClass)(headerSpanElement, _domHelpers.HEADER_CLASS_DESC_SORT));
    if (showsIndicator) {
        (0, _element.addClass)(container, CONTAINER_WITH_INDICATOR_CLASS);
    } else {
        (0, _element.removeClass)(container, CONTAINER_WITH_INDICATOR_CLASS);
    }
}
function isColumnBeingDragged() {
    const manualColumnMove = this.hot.getPlugin('manualColumnMove');
    return manualColumnMove?.isDragging() === true;
}
