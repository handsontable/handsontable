"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get PLUGIN_KEY () {
        return _touchScroll.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _touchScroll.PLUGIN_PRIORITY;
    },
    get TouchScroll () {
        return _touchScroll.TouchScroll;
    }
});
const _touchScroll = require("./touchScroll");
