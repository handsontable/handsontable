"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AutoColumnSize () {
        return _autoColumnSize.AutoColumnSize;
    },
    get AutoRowSize () {
        return _autoRowSize.AutoRowSize;
    },
    get Autofill () {
        return _autofill.Autofill;
    },
    get BasePlugin () {
        return _base.BasePlugin;
    },
    get BindRowsWithHeaders () {
        return _bindRowsWithHeaders.BindRowsWithHeaders;
    },
    get CollapsibleColumns () {
        return _collapsibleColumns.CollapsibleColumns;
    },
    get ColumnSorting () {
        return _columnSorting.ColumnSorting;
    },
    get ColumnSummary () {
        return _columnSummary.ColumnSummary;
    },
    get Comments () {
        return _comments.Comments;
    },
    get ContextMenu () {
        return _contextMenu.ContextMenu;
    },
    get CopyPaste () {
        return _copyPaste.CopyPaste;
    },
    get CustomBorders () {
        return _customBorders.CustomBorders;
    },
    get DataProvider () {
        return _dataProvider.DataProvider;
    },
    get Dialog () {
        return _dialog.Dialog;
    },
    get DragToScroll () {
        return _dragToScroll.DragToScroll;
    },
    get DropdownMenu () {
        return _dropdownMenu.DropdownMenu;
    },
    get EmptyDataState () {
        return _emptyDataState.EmptyDataState;
    },
    get ExportFile () {
        return _exportFile.ExportFile;
    },
    get Filters () {
        return _filters.Filters;
    },
    get Formulas () {
        return _formulas.Formulas;
    },
    get HiddenColumns () {
        return _hiddenColumns.HiddenColumns;
    },
    get HiddenRows () {
        return _hiddenRows.HiddenRows;
    },
    get Loading () {
        return _loading.Loading;
    },
    get ManualColumnFreeze () {
        return _manualColumnFreeze.ManualColumnFreeze;
    },
    get ManualColumnMove () {
        return _manualColumnMove.ManualColumnMove;
    },
    get ManualColumnResize () {
        return _manualColumnResize.ManualColumnResize;
    },
    get ManualRowMove () {
        return _manualRowMove.ManualRowMove;
    },
    get ManualRowResize () {
        return _manualRowResize.ManualRowResize;
    },
    get MergeCells () {
        return _mergeCells.MergeCells;
    },
    get MoveCells () {
        return _moveCells.MoveCells;
    },
    get MultiColumnSorting () {
        return _multiColumnSorting.MultiColumnSorting;
    },
    get MultipleSelectionHandles () {
        return _multipleSelectionHandles.MultipleSelectionHandles;
    },
    get NestedHeaders () {
        return _nestedHeaders.NestedHeaders;
    },
    get NestedRows () {
        return _nestedRows.NestedRows;
    },
    get Notification () {
        return _notification.Notification;
    },
    get Pagination () {
        return _pagination.Pagination;
    },
    get Search () {
        return _search.Search;
    },
    get SelectionHandles () {
        return _selectionHandles.SelectionHandles;
    },
    get StretchColumns () {
        return _stretchColumns.StretchColumns;
    },
    get TouchScroll () {
        return _touchScroll.TouchScroll;
    },
    get TrimRows () {
        return _trimRows.TrimRows;
    },
    get UndoRedo () {
        return _undoRedo.UndoRedo;
    },
    get getPlugin () {
        return _registry.getPlugin;
    },
    get getPluginsNames () {
        return _registry.getPluginsNames;
    },
    get registerAllPlugins () {
        return registerAllPlugins;
    },
    get registerPlugin () {
        return _registry.registerPlugin;
    }
});
const _autoColumnSize = require("./autoColumnSize");
const _autofill = require("./autofill");
const _autoRowSize = require("./autoRowSize");
const _base = require("./base");
const _bindRowsWithHeaders = require("./bindRowsWithHeaders");
const _collapsibleColumns = require("./collapsibleColumns");
const _columnSorting = require("./columnSorting");
const _columnSummary = require("./columnSummary");
const _comments = require("./comments");
const _contextMenu = require("./contextMenu");
const _copyPaste = require("./copyPaste");
const _customBorders = require("./customBorders");
const _dataProvider = require("./dataProvider");
const _dragToScroll = require("./dragToScroll");
const _dropdownMenu = require("./dropdownMenu");
const _exportFile = require("./exportFile");
const _filters = require("./filters");
const _formulas = require("./formulas");
const _hiddenColumns = require("./hiddenColumns");
const _hiddenRows = require("./hiddenRows");
const _manualColumnFreeze = require("./manualColumnFreeze");
const _manualColumnMove = require("./manualColumnMove");
const _manualColumnResize = require("./manualColumnResize");
const _manualRowMove = require("./manualRowMove");
const _manualRowResize = require("./manualRowResize");
const _mergeCells = require("./mergeCells");
const _moveCells = require("./moveCells");
const _multiColumnSorting = require("./multiColumnSorting");
const _multipleSelectionHandles = require("./multipleSelectionHandles");
const _nestedHeaders = require("./nestedHeaders");
const _nestedRows = require("./nestedRows");
const _pagination = require("./pagination");
const _search = require("./search");
const _selectionHandles = require("./selectionHandles");
const _stretchColumns = require("./stretchColumns");
const _touchScroll = require("./touchScroll");
const _trimRows = require("./trimRows");
const _undoRedo = require("./undoRedo");
const _dialog = require("./dialog");
const _loading = require("./loading");
const _notification = require("./notification");
const _emptyDataState = require("./emptyDataState");
const _registry = require("./registry");
function registerAllPlugins() {
    (0, _registry.registerPlugin)(_autoColumnSize.AutoColumnSize);
    (0, _registry.registerPlugin)(_autofill.Autofill);
    (0, _registry.registerPlugin)(_autoRowSize.AutoRowSize);
    (0, _registry.registerPlugin)(_bindRowsWithHeaders.BindRowsWithHeaders);
    (0, _registry.registerPlugin)(_collapsibleColumns.CollapsibleColumns);
    (0, _registry.registerPlugin)(_columnSorting.ColumnSorting);
    (0, _registry.registerPlugin)(_columnSummary.ColumnSummary);
    (0, _registry.registerPlugin)(_comments.Comments);
    (0, _registry.registerPlugin)(_contextMenu.ContextMenu);
    (0, _registry.registerPlugin)(_copyPaste.CopyPaste);
    (0, _registry.registerPlugin)(_customBorders.CustomBorders);
    (0, _registry.registerPlugin)(_dataProvider.DataProvider);
    (0, _registry.registerPlugin)(_dragToScroll.DragToScroll);
    (0, _registry.registerPlugin)(_dropdownMenu.DropdownMenu);
    (0, _registry.registerPlugin)(_exportFile.ExportFile);
    (0, _registry.registerPlugin)(_filters.Filters);
    (0, _registry.registerPlugin)(_formulas.Formulas);
    (0, _registry.registerPlugin)(_hiddenColumns.HiddenColumns);
    (0, _registry.registerPlugin)(_hiddenRows.HiddenRows);
    (0, _registry.registerPlugin)(_manualColumnFreeze.ManualColumnFreeze);
    (0, _registry.registerPlugin)(_manualColumnMove.ManualColumnMove);
    (0, _registry.registerPlugin)(_manualColumnResize.ManualColumnResize);
    (0, _registry.registerPlugin)(_manualRowMove.ManualRowMove);
    (0, _registry.registerPlugin)(_manualRowResize.ManualRowResize);
    (0, _registry.registerPlugin)(_mergeCells.MergeCells);
    (0, _registry.registerPlugin)(_moveCells.MoveCells);
    (0, _registry.registerPlugin)(_multiColumnSorting.MultiColumnSorting);
    (0, _registry.registerPlugin)(_multipleSelectionHandles.MultipleSelectionHandles);
    (0, _registry.registerPlugin)(_nestedHeaders.NestedHeaders);
    (0, _registry.registerPlugin)(_nestedRows.NestedRows);
    (0, _registry.registerPlugin)(_pagination.Pagination);
    (0, _registry.registerPlugin)(_search.Search);
    (0, _registry.registerPlugin)(_selectionHandles.SelectionHandles);
    (0, _registry.registerPlugin)(_stretchColumns.StretchColumns);
    (0, _registry.registerPlugin)(_touchScroll.TouchScroll);
    (0, _registry.registerPlugin)(_trimRows.TrimRows);
    (0, _registry.registerPlugin)(_undoRedo.UndoRedo);
    (0, _registry.registerPlugin)(_dialog.Dialog);
    (0, _registry.registerPlugin)(_loading.Loading);
    (0, _registry.registerPlugin)(_notification.Notification);
    (0, _registry.registerPlugin)(_emptyDataState.EmptyDataState);
}
