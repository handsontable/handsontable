"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get HiddenColumns () {
        return HiddenColumns;
    },
    get PLUGIN_KEY () {
        return PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return PLUGIN_PRIORITY;
    }
});
const _base = require("../base");
const _element = require("../../helpers/dom/element");
const _number = require("../../helpers/number");
const _array = require("../../helpers/array");
const _predefinedItems = require("../contextMenu/predefinedItems");
const _hooks = require("../../core/hooks");
const _hideColumn = /*#__PURE__*/ _interop_require_default(require("./contextMenuItem/hideColumn"));
const _showColumn = /*#__PURE__*/ _interop_require_default(require("./contextMenuItem/showColumn"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
_hooks.Hooks.getSingleton().register('beforeHideColumns');
_hooks.Hooks.getSingleton().register('afterHideColumns');
_hooks.Hooks.getSingleton().register('beforeUnhideColumns');
_hooks.Hooks.getSingleton().register('afterUnhideColumns');
const PLUGIN_KEY = 'hiddenColumns';
const PLUGIN_PRIORITY = 310;
const SKIP_COLUMN_ON_PASTE_BY_PLUGIN = Symbol('skipColumnOnPasteByHiddenColumns');
var /**
   * Map of hidden columns by the plugin.
   *
   * @private
   * @type {null|HidingMap}
   */ _hiddenColumnsMap = /*#__PURE__*/ new WeakMap(), /**
   * Adds the additional column width for the hidden column indicators.
   *
   * @param {number|undefined} width Column width.
   * @param {number} column Visual column index.
   * @returns {number}
   */ _onModifyColWidth = /*#__PURE__*/ new WeakMap(), /**
   * Sets the copy-related cell meta.
   *
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {object} cellProperties Object containing the cell properties.
   */ _onAfterGetCellMeta = /*#__PURE__*/ new WeakMap(), /**
   * Modifies the copyable range, accordingly to the provided config.
   *
   * @param {Array} ranges An array of objects defining copyable cells.
   * @returns {Array}
   */ _onModifyCopyableRange = /*#__PURE__*/ new WeakMap(), /**
   * Adds the needed classes to the headers.
   *
   * @param {number} column Visual column index.
   * @param {HTMLElement} TH Header's TH element.
   */ _onAfterGetColHeader = /*#__PURE__*/ new WeakMap(), /**
   * Add Show-hide columns to context menu.
   *
   * @param {object} options An array of objects containing information about the pre-defined Context Menu items.
   */ _onAfterContextMenuDefaultOptions = /*#__PURE__*/ new WeakMap(), /**
   * On map initialized hook callback.
   */ _onMapInit = /*#__PURE__*/ new WeakSet();
class HiddenColumns extends _base.BasePlugin {
    /**
   * Returns the plugin key used to identify this plugin in Handsontable settings.
   */ static get PLUGIN_KEY() {
        return PLUGIN_KEY;
    }
    /**
   * Returns the priority order used to determine the order in which plugins are initialized.
   */ static get PLUGIN_PRIORITY() {
        return PLUGIN_PRIORITY;
    }
    /**
   * Returns the default settings applied when the plugin is enabled without explicit configuration.
   */ static get DEFAULT_SETTINGS() {
        return {
            copyPasteEnabled: true,
            indicators: false,
            columns: []
        };
    }
    /**
   * Checks if the plugin is enabled in the handsontable settings. This method is executed in {@link Hooks#beforeInit}
   * hook and if it returns `true` then the {@link HiddenColumns#enablePlugin} method is called.
   *
   * @returns {boolean}
   */ isEnabled() {
        return !!this.hot.getSettings()[PLUGIN_KEY];
    }
    /**
   * Enables the plugin functionality for this Handsontable instance.
   */ enablePlugin() {
        if (this.enabled) {
            return;
        }
        _class_private_field_set(this, _hiddenColumnsMap, this.hot.columnIndexMapper.createAndRegisterIndexMap(this.pluginName ?? '', 'hiding'));
        _class_private_field_get(this, _hiddenColumnsMap).addLocalHook('init', ()=>_class_private_method_get(this, _onMapInit, onMapInit).call(this));
        // `createAndRegisterIndexMap` initializes the map synchronously when the dataset is already
        // loaded (a plugin re-enable), before the hook above could attach - replay the init handler.
        if (this.hot.columnIndexMapper.getNumberOfIndexes() > 0) {
            _class_private_method_get(this, _onMapInit, onMapInit).call(this);
        }
        this.addHook('afterContextMenuDefaultOptions', _class_private_field_get(this, _onAfterContextMenuDefaultOptions));
        this.addHook('afterGetCellMeta', _class_private_field_get(this, _onAfterGetCellMeta));
        this.addHook('modifyColWidth', _class_private_field_get(this, _onModifyColWidth), 2);
        this.addHook('afterGetColHeader', _class_private_field_get(this, _onAfterGetColHeader));
        this.addHook('modifyCopyableRange', _class_private_field_get(this, _onModifyCopyableRange));
        super.enablePlugin();
    }
    /**
   * Updates the plugin's state.
   *
   * This method is executed when [`updateSettings()`](@/api/core.md#updatesettings) is invoked with any of the following configuration options:
   *  - [`hiddenColumns`](@/api/options.md#hiddencolumns)
   */ updatePlugin() {
        this.disablePlugin();
        this.enablePlugin();
        super.updatePlugin();
    }
    /**
   * Disables the plugin functionality for this Handsontable instance.
   */ disablePlugin() {
        super.disablePlugin();
        this.hot.columnIndexMapper.unregisterMap(this.pluginName ?? '');
        this.resetCellsMeta();
    }
    /**
   * Shows the provided columns.
   *
   * @param {number[]} columns Array of visual column indexes.
   */ showColumns(columns) {
        const currentHideConfig = this.getHiddenColumns();
        const isValidConfig = this.isValidConfig(columns);
        let destinationHideConfig = currentHideConfig;
        const hidingMapValues = _class_private_field_get(this, _hiddenColumnsMap).getValues().slice();
        const isAnyColumnShowed = columns.length > 0;
        if (isValidConfig && isAnyColumnShowed) {
            const physicalColumns = columns.map((visualColumn)=>this.hot.toPhysicalColumn(visualColumn));
            // Preparing new values for hiding map.
            (0, _array.arrayEach)(physicalColumns, (physicalColumn)=>{
                hidingMapValues[physicalColumn] = false;
            });
            // Preparing new hiding config.
            destinationHideConfig = (0, _array.arrayReduce)(hidingMapValues, (hiddenIndexes, isHidden, physicalIndex)=>{
                if (isHidden) {
                    hiddenIndexes.push(this.hot.toVisualColumn(physicalIndex));
                }
                return hiddenIndexes;
            }, []);
        }
        const continueHiding = this.hot.runHooks('beforeUnhideColumns', currentHideConfig, destinationHideConfig, isValidConfig && isAnyColumnShowed);
        if (continueHiding === false) {
            return;
        }
        if (isValidConfig && isAnyColumnShowed) {
            _class_private_field_get(this, _hiddenColumnsMap).setValues(hidingMapValues);
        }
        // @TODO Should call once per render cycle, currently fired separately in different plugins
        this.hot.view.adjustElementsSize();
        this.hot.runHooks('afterUnhideColumns', currentHideConfig, destinationHideConfig, isValidConfig && isAnyColumnShowed, isValidConfig && destinationHideConfig.length < currentHideConfig.length);
    }
    /**
   * Shows a single column.
   *
   * @param {...number} column Visual column index.
   */ showColumn(...column) {
        this.showColumns(column);
    }
    /**
   * Hides the columns provided in the array.
   *
   * @param {number[]} columns Array of visual column indexes.
   */ hideColumns(columns) {
        const currentHideConfig = this.getHiddenColumns();
        const isConfigValid = this.isValidConfig(columns);
        let destinationHideConfig = currentHideConfig;
        if (isConfigValid) {
            destinationHideConfig = Array.from(new Set(currentHideConfig.concat(columns)));
        }
        const continueHiding = this.hot.runHooks('beforeHideColumns', currentHideConfig, destinationHideConfig, isConfigValid);
        if (continueHiding === false) {
            return;
        }
        if (isConfigValid) {
            this.hot.batchExecution(()=>{
                (0, _array.arrayEach)(columns, (visualColumn)=>{
                    _class_private_field_get(this, _hiddenColumnsMap).setValueAtIndex(this.hot.toPhysicalColumn(visualColumn), true);
                });
            }, true);
        }
        this.hot.runHooks('afterHideColumns', currentHideConfig, destinationHideConfig, isConfigValid, isConfigValid && destinationHideConfig.length > currentHideConfig.length);
    }
    /**
   * Hides a single column.
   *
   * @param {...number} column Visual column index.
   */ hideColumn(...column) {
        this.hideColumns(column);
    }
    /**
   * Returns an array of visual indexes of hidden columns.
   *
   * @returns {number[]}
   */ getHiddenColumns() {
        return (0, _array.arrayMap)(_class_private_field_get(this, _hiddenColumnsMap).getHiddenIndexes(), (physicalColumnIndex)=>{
            return this.hot.toVisualColumn(physicalColumnIndex);
        });
    }
    /**
   * Checks if the provided column is hidden.
   *
   * @param {number} column Visual column index.
   * @returns {boolean}
   */ isHidden(column) {
        return _class_private_field_get(this, _hiddenColumnsMap).getValueAtIndex(this.hot.toPhysicalColumn(column)) || false;
    }
    /**
   * Get if trim config is valid. Check whether all of the provided column indexes are within the bounds of the table.
   *
   * @param {Array} hiddenColumns List of hidden column indexes.
   * @returns {boolean}
   */ isValidConfig(hiddenColumns) {
        const nrOfColumns = this.hot.countCols();
        if (Array.isArray(hiddenColumns) && hiddenColumns.length > 0) {
            return hiddenColumns.every((visualColumn)=>Number.isInteger(visualColumn) && visualColumn >= 0 && visualColumn < nrOfColumns);
        }
        return false;
    }
    /**
   * Reset all rendered cells meta.
   *
   * @private
   */ resetCellsMeta() {
        (0, _array.arrayEach)(this.hot.getCellsMeta(), (meta)=>{
            const cellMeta = meta;
            if (cellMeta[SKIP_COLUMN_ON_PASTE_BY_PLUGIN]) {
                delete cellMeta.skipColumnOnPaste;
                delete cellMeta[SKIP_COLUMN_ON_PASTE_BY_PLUGIN];
            }
        });
    }
    /**
   * Destroys the plugin instance.
   */ destroy() {
        _class_private_field_set(this, _hiddenColumnsMap, null);
        super.destroy();
    }
    constructor(...args){
        super(...args), _class_private_method_init(this, _onMapInit), _class_private_field_init(this, _hiddenColumnsMap, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onModifyColWidth, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterGetCellMeta, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onModifyCopyableRange, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterGetColHeader, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _onAfterContextMenuDefaultOptions, {
            writable: true,
            value: void 0
        }), _class_private_field_set(this, _hiddenColumnsMap, null), _class_private_field_set(this, _onModifyColWidth, (width, column)=>{
            // Hook is triggered internally only for the visible columns. Conditional will be handled for the API
            // calls of the `getColWidth` function on not visible indexes.
            if (this.isHidden(column)) {
                return 0;
            }
            if (this.getSetting('indicators') && (this.isHidden(column + 1) || this.isHidden(column - 1))) {
                // Add additional space for hidden column indicator.
                if (typeof width === 'number' && this.hot.hasColHeaders()) {
                    return width + 15;
                }
            }
        }), _class_private_field_set(this, _onAfterGetCellMeta, (row, column, cellProperties)=>{
            if (this.getSetting('copyPasteEnabled') === false) {
                // Cell property handled by the `Autofill` and the `CopyPaste` plugins. The plugin only sets
                // and marks cells whose `skipColumnOnPaste` it actually flips to `true`. Cells that already
                // had `true` from user configuration (`columns`, `cells`, or `cell`) are left untouched,
                // so that unhiding the column does not erase the user-defined value.
                const cellPropsWithMarker = cellProperties;
                if (this.isHidden(column)) {
                    if (cellProperties.skipColumnOnPaste !== true) {
                        cellProperties.skipColumnOnPaste = true;
                        cellPropsWithMarker[SKIP_COLUMN_ON_PASTE_BY_PLUGIN] = true;
                    }
                } else if (cellPropsWithMarker[SKIP_COLUMN_ON_PASTE_BY_PLUGIN]) {
                    delete cellProperties.skipColumnOnPaste;
                    delete cellPropsWithMarker[SKIP_COLUMN_ON_PASTE_BY_PLUGIN];
                }
            }
            if (this.isHidden(column - 1)) {
                cellProperties.className = cellProperties.className || '';
                if (cellProperties.className.indexOf('afterHiddenColumn') === -1) {
                    cellProperties.className += ' afterHiddenColumn';
                }
            } else if (cellProperties.className) {
                const classArr = cellProperties.className.split(' ');
                if (classArr.length > 0) {
                    const containAfterHiddenColumn = classArr.indexOf('afterHiddenColumn');
                    if (containAfterHiddenColumn > -1) {
                        classArr.splice(containAfterHiddenColumn, 1);
                    }
                    cellProperties.className = classArr.join(' ');
                }
            }
        }), _class_private_field_set(this, _onModifyCopyableRange, (ranges)=>{
            // Ranges shouldn't be modified when `copyPasteEnabled` option is set to `true` (by default).
            if (this.getSetting('copyPasteEnabled')) {
                return ranges;
            }
            const newRanges = [];
            const pushRange = (startRow, endRow, startCol, endCol)=>{
                newRanges.push({
                    startRow,
                    endRow,
                    startCol,
                    endCol
                });
            };
            (0, _array.arrayEach)(ranges, (rangeItem)=>{
                const range = rangeItem;
                let isHidden = true;
                let rangeStart = 0;
                (0, _number.rangeEach)(range.startCol, range.endCol, (visualColumn)=>{
                    if (this.isHidden(visualColumn)) {
                        if (!isHidden) {
                            pushRange(range.startRow, range.endRow, rangeStart, visualColumn - 1);
                        }
                        isHidden = true;
                    } else {
                        if (isHidden) {
                            rangeStart = visualColumn;
                        }
                        if (visualColumn === range.endCol) {
                            pushRange(range.startRow, range.endRow, rangeStart, visualColumn);
                        }
                        isHidden = false;
                    }
                });
            });
            return newRanges;
        }), _class_private_field_set(this, _onAfterGetColHeader, (column, TH)=>{
            if (!this.getSetting('indicators') || column < 0) {
                return;
            }
            const classList = [];
            if (column >= 1 && this.isHidden(column - 1)) {
                classList.push('afterHiddenColumn');
            }
            if (column < this.hot.countCols() - 1 && this.isHidden(column + 1)) {
                classList.push('beforeHiddenColumn');
            }
            (0, _element.addClass)(TH, classList);
        }), _class_private_field_set(this, _onAfterContextMenuDefaultOptions, (options)=>{
            options.items.push({
                name: _predefinedItems.SEPARATOR
            }, (0, _hideColumn.default)(this), (0, _showColumn.default)(this));
        });
    }
}
function onMapInit() {
    const columns = this.getSetting('columns');
    if (Array.isArray(columns)) {
        this.hideColumns(columns);
    }
}
