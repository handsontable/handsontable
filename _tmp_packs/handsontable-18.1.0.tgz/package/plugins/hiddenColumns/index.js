"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get HiddenColumns () {
        return _hiddenColumns.HiddenColumns;
    },
    get PLUGIN_KEY () {
        return _hiddenColumns.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _hiddenColumns.PLUGIN_PRIORITY;
    }
});
const _hiddenColumns = require("./hiddenColumns");
