"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ManualColumnMove () {
        return _manualColumnMove.ManualColumnMove;
    },
    get PLUGIN_KEY () {
        return _manualColumnMove.PLUGIN_KEY;
    },
    get PLUGIN_PRIORITY () {
        return _manualColumnMove.PLUGIN_PRIORITY;
    }
});
const _manualColumnMove = require("./manualColumnMove");
