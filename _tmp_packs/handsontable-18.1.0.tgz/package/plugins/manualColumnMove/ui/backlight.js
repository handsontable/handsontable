"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _base = /*#__PURE__*/ _interop_require_default(require("./_base"));
const _element = require("../../../helpers/dom/element");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const CSS_CLASSNAME = 'ht__manualColumnMove--backlight';
/**
 * @class BacklightUI
 * @util
 */ class BacklightUI extends _base.default {
    /**
   * Custom className on build process.
   */ build() {
        super.build();
        (0, _element.addClass)(this._element, CSS_CLASSNAME);
    }
}
const _default = BacklightUI;
