"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DefaultColumnSizeSource () {
        return DefaultColumnSizeSource;
    },
    get DefaultRowSizeSource () {
        return DefaultRowSizeSource;
    }
});
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
var /**
   * The Walkontable settings.
   *
   * @type {Settings}
   */ _wtSettings = /*#__PURE__*/ new WeakMap();
class DefaultRowSizeSource {
    /**
   * @param {number} sourceIndex The source index of the row.
   * @returns {number | undefined}
   */ getSize(sourceIndex) {
        return _class_private_field_get(this, _wtSettings).getSetting('rowHeight', sourceIndex);
    }
    /**
   * @param {number} sourceIndex The source index of the row.
   * @param {string} overlayName The overlay name.
   * @returns {number | undefined}
   */ getSizeForOverlay(sourceIndex, overlayName) {
        return _class_private_field_get(this, _wtSettings).getSetting('rowHeightByOverlayName', sourceIndex, overlayName);
    }
    /**
   * @returns {number}
   */ getDefaultSize() {
        return _class_private_field_get(this, _wtSettings).getSetting('stylesHandler').getDefaultRowHeight();
    }
    /**
   * @returns {boolean}
   */ isUniform() {
        return _class_private_field_get(this, _wtSettings).getSetting('rowHeightsUniform');
    }
    /**
   * @param {Settings} wtSettings The Walkontable settings.
   */ constructor(wtSettings){
        _class_private_field_init(this, _wtSettings, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _wtSettings, wtSettings);
    }
}
var /**
   * The Walkontable settings.
   *
   * @type {Settings}
   */ _wtSettings1 = /*#__PURE__*/ new WeakMap();
class DefaultColumnSizeSource {
    /**
   * @param {number} sourceIndex The source index of the column.
   * @returns {number | undefined}
   */ getSize(sourceIndex) {
        return _class_private_field_get(this, _wtSettings1).getSetting('columnWidth', sourceIndex);
    }
    /**
   * @returns {number}
   */ getDefaultSize() {
        return _class_private_field_get(this, _wtSettings1).getSetting('defaultColumnWidth');
    }
    /**
   * @returns {boolean}
   */ isUniform() {
        return _class_private_field_get(this, _wtSettings1).getSetting('columnWidthsUniform');
    }
    /**
   * @param {Settings} wtSettings The Walkontable settings.
   */ constructor(wtSettings){
        _class_private_field_init(this, _wtSettings1, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _wtSettings1, wtSettings);
    }
}
