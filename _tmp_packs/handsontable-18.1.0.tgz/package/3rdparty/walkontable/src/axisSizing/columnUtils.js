"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return ColumnUtils;
    }
});
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
var /**
   * The table module dependencies.
   *
   * @type {TableDeps}
   */ _deps = /*#__PURE__*/ new WeakMap(), /**
   * The column-width source — supplies the provided width and the default width.
   *
   * @type {ColumnSizeSource}
   */ _columnSizeSource = /*#__PURE__*/ new WeakMap();
class ColumnUtils {
    /**
   * Read-only access to the dependencies, for the renderer, which reads `columnUtils.deps`
   * externally and so cannot reach the private `#deps`.
   *
   * @returns {TableDeps}
   */ get deps() {
        return _class_private_field_get(this, _deps);
    }
    /**
   * Returns column width based on passed source index.
   *
   * @param {number} sourceIndex Column source index.
   * @returns {number}
   */ getWidth(sourceIndex) {
        // Preserve the `||` (not `??`) fallback: a provided width of `0` intentionally falls through to
        // the default.
        return _class_private_field_get(this, _columnSizeSource).getSize(sourceIndex) || _class_private_field_get(this, _columnSizeSource).getDefaultSize();
    }
    /**
   * Returns column header height based on passed header level.
   *
   * @param {number} level Column header level.
   * @returns {number}
   */ getHeaderHeight(level) {
        const height = this.wtSettings.getSetting('stylesHandler').getDefaultRowHeight();
        // The provided header height arrives through the `columnHeaderHeight` setting funnel: the
        // `columnHeaderHeight` option, the `modifyColumnHeaderHeight` hook (AutoRowSize feeds it), and -
        // for content-driven headers with no plugin - the render-size probe, all merged per level by the
        // Handsontable-side callback. Content taller than this is not measured here; the header cell is
        // min-height, so it expands on its own and the probe records the result for the next draw.
        const setting = this.wtSettings.getSetting('columnHeaderHeight');
        const providedHeight = Array.isArray(setting) ? setting[level] : setting;
        if (providedHeight !== undefined && providedHeight !== null) {
            return height ? Math.max(height, providedHeight) : providedHeight;
        }
        return height;
    }
    /**
   * Returns column header width based on passed source index.
   *
   * @param {number} sourceIndex Column source index.
   * @returns {number}
   */ getHeaderWidth(sourceIndex) {
        const { columnFilter } = _class_private_field_get(this, _deps).getWtTable();
        if (!columnFilter) {
            return undefined;
        }
        return this.headerWidths.get(columnFilter.sourceToRendered(sourceIndex));
    }
    /**
   * Calculates column header widths that can be retrieved from the cache.
   */ calculateWidths() {
        const { wtSettings } = this;
        let rowHeaderWidthSetting = wtSettings.getSetting('rowHeaderWidth');
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        rowHeaderWidthSetting = wtSettings.getSetting('onModifyRowHeaderWidth', rowHeaderWidthSetting);
        if (rowHeaderWidthSetting !== null && rowHeaderWidthSetting !== undefined) {
            const rowHeadersCount = wtSettings.getSetting('rowHeaders').length;
            const defaultColumnWidth = wtSettings.getSetting('defaultColumnWidth');
            for(let visibleColumnIndex = 0; visibleColumnIndex < rowHeadersCount; visibleColumnIndex++){
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                let width = Array.isArray(rowHeaderWidthSetting) ? rowHeaderWidthSetting[visibleColumnIndex] : rowHeaderWidthSetting;
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                width = width === null || width === undefined ? defaultColumnWidth : width;
                this.headerWidths.set(visibleColumnIndex, width);
            }
        }
    }
    /**
   * @param {TableDeps} deps The table module dependencies.
   */ constructor(deps){
        _class_private_field_init(this, _deps, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _columnSizeSource, {
            writable: true,
            value: void 0
        });
        /**
   * @type {Map<number, number>}
   */ this.headerWidths = new Map();
        _class_private_field_set(this, _deps, deps);
        _class_private_field_set(this, _columnSizeSource, deps.columnSizeSource);
        this.wtSettings = deps.wtSettings;
    }
}
