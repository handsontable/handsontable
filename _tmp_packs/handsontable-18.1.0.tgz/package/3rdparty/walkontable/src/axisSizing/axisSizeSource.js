/**
 * The sizing ports. These interfaces are the seam between the rendering engine and whoever supplies
 * the row heights and column widths — the settings/defaults inside Walkontable, or (through the
 * settings callbacks) the Handsontable size funnel and its `AutoRowSize`/`AutoColumnSize` plugins.
 *
 * A source answers only the "provided size" half of a measurement. The oversized-content merge
 * (`Math.max(provided, measured)`) still lives in `RowUtils`/`ColumnUtils` for now; it moves behind
 * the port in a later stage. Indexes are source indexes — the space the engine renders in, passed
 * through unchanged.
 */ /**
 * A per-axis size source. Supplies the provided size of one item plus the axis defaults.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
