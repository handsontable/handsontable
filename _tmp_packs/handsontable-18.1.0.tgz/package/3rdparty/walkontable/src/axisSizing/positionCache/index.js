"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "PositionCache", {
    enumerable: true,
    get: function() {
        return PositionCache;
    }
});
const _strategy = require("./strategy");
const _uniformStrategy = require("./uniformStrategy");
const _sparseStrategy = require("./sparseStrategy");
const _prefixSumStrategy = require("./prefixSumStrategy");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
var /**
   * The lookup strategy built from the sizes read at build time; `null` until the first build and
   * after invalidation.
   *
   * @type {PositionStrategy|null}
   */ _strategy1 = /*#__PURE__*/ new WeakMap(), _totalItemsFn = /*#__PURE__*/ new WeakMap(), _sizeFn = /*#__PURE__*/ new WeakMap(), _defaultSizeFn = /*#__PURE__*/ new WeakMap(), _isUniformFn = /*#__PURE__*/ new WeakMap(), _sparseExceptionsFn = /*#__PURE__*/ new WeakMap(), _onBuildFn = /*#__PURE__*/ new WeakMap();
class PositionCache {
    /**
   * The prefix sum array when the current strategy holds one (prefix-sum mode); `null` in the
   * uniform and sparse modes and while the cache is not built. Kept for the `isBuilt()` type
   * guard and its consumers.
   *
   * @type {Float64Array|null}
   */ get prefixSum() {
        return _class_private_field_get(this, _strategy1)?.prefixSum ?? null;
    }
    /**
   * Builds the lookup strategy by reading the current total items, size function, and default
   * size from the configured providers: uniform when the uniform predicate holds, sparse when
   * the exceptions provider returns overrides, and the full prefix-sum walk otherwise.
   */ build() {
        var _this, _this1, _ref, _this2, _this3, _ref1, _this4, _this5, _ref2;
        const totalItems = _class_private_field_get(this, _totalItemsFn).call(this);
        const sizeFn = _class_private_field_get(this, _sizeFn);
        const defaultSize = _class_private_field_get(this, _defaultSizeFn).call(this);
        this.totalItems = totalItems;
        this.buildSeq += 1;
        (_this = _class_private_field_get(_ref = _this1 = this, _onBuildFn)) === null || _this === void 0 ? void 0 : _this.call(_this1);
        if ((_this2 = _class_private_field_get(_ref1 = _this3 = this, _isUniformFn)) === null || _this2 === void 0 ? void 0 : _this2.call(_this3)) {
            const size = (0, _strategy.sampleBaseSize)(totalItems - 1, sizeFn, defaultSize);
            _class_private_field_set(this, _strategy1, new _uniformStrategy.UniformPositionStrategy(size, totalItems));
            return;
        }
        const exceptions = (_this4 = _class_private_field_get(_ref2 = _this5 = this, _sparseExceptionsFn)) === null || _this4 === void 0 ? void 0 : _this4.call(_this5);
        if (exceptions) {
            _class_private_field_set(this, _strategy1, new _sparseStrategy.SparsePositionStrategy(exceptions, totalItems, sizeFn, defaultSize));
            return;
        }
        _class_private_field_set(this, _strategy1, new _prefixSumStrategy.PrefixSumPositionStrategy(totalItems, sizeFn, defaultSize));
    }
    /**
   * Returns the cumulative size at an index (sum of items 0..index-1).
   *
   * @param {number} index The item index.
   * @returns {number} The cumulative size before this index, or `0` when the cache is not built.
   */ getOffset(index) {
        return _class_private_field_get(this, _strategy1)?.getOffset(index) ?? 0;
    }
    /**
   * Finds the item index at a given pixel offset.
   *
   * @param {number} offset The pixel offset.
   * @returns {number} The index whose cumulative start position is at or just before the offset.
   *   Returns `0` when there are no items or the cache is not built.
   */ findIndexAtOffset(offset) {
        return _class_private_field_get(this, _strategy1)?.findIndexAtOffset(offset) ?? 0;
    }
    /**
   * Returns the size of a single item at the given index.
   *
   * @param {number} index The item index.
   * @returns {number} The size of the item, or `0` outside the item range or when not built.
   */ getSizeAt(index) {
        return _class_private_field_get(this, _strategy1)?.getSizeAt(index) ?? 0;
    }
    /**
   * Returns the total size of all items.
   *
   * @returns {number}
   */ getTotalSize() {
        return _class_private_field_get(this, _strategy1)?.getTotalSize() ?? 0;
    }
    /**
   * Builds the lookup strategy only when the cache is not yet built or the item count has
   * changed.
   */ ensureBuilt() {
        if (!this.isCurrent()) {
            this.build();
        }
    }
    /**
   * Invalidates the cache so it will be rebuilt on the next
   * {@link PositionCache#ensureBuilt} call.
   */ invalidate() {
        _class_private_field_set(this, _strategy1, null);
        this.totalItems = 0;
    }
    /**
   * Returns whether the cache holds a prefix-sum array (heterogeneous mode). The uniform and
   * sparse strategies keep `prefixSum` as `null`, so this is `false` there; use it only as the
   * prefix-sum type guard.
   *
   * @returns {boolean}
   */ isBuilt() {
        return this.prefixSum !== null;
    }
    /**
   * Returns whether the cache currently holds valid built data for the current item count, in any
   * mode. Unlike {@link PositionCache#isBuilt} (a prefix-sum-mode type guard that is always `false`
   * in the uniform and sparse modes), this reflects the real build/invalidate state:
   * {@link PositionCache#build} sets it regardless of mode, {@link PositionCache#invalidate} clears
   * it, and a changed item count makes it stale (mirroring {@link PositionCache#ensureBuilt}). It is
   * the signal for "the sizes the pre-render calculators read are still current" — e.g.
   * `markOversizedRows` invalidates the row cache here when it finds a genuinely oversized row.
   *
   * @returns {boolean}
   */ isCurrent() {
        return _class_private_field_get(this, _strategy1) !== null && this.totalItems === _class_private_field_get(this, _totalItemsFn).call(this);
    }
    /**
   * @param {object} config The configuration object.
   * @param {Function} config.totalItemsFn A function that returns the total number of items (rows or columns).
   * @param {Function} config.sizeFn A function that returns the size for a given index.
   * @param {Function} config.defaultSizeFn A function that returns the default size for items
   *   that return NaN/undefined.
   * @param {Function} [config.isUniformFn] Optional predicate; when `true`, all items share one size.
   * @param {Function} [config.sparseExceptionsFn] Optional provider of per-index size overrides
   *   on top of a uniform base.
   * @param {Function} [config.onBuildFn] Optional callback invoked on every (re)build.
   */ constructor({ totalItemsFn, sizeFn, defaultSizeFn, isUniformFn, sparseExceptionsFn, onBuildFn }){
        _class_private_field_init(this, _strategy1, {
            writable: true,
            value: void 0
        });
        /**
   * A function that returns the total number of items (rows or columns).
   *
   * @type {Function}
   */ _class_private_field_init(this, _totalItemsFn, {
            writable: true,
            value: void 0
        });
        /**
   * A function that returns the size for a given index.
   *
   * @type {Function}
   */ _class_private_field_init(this, _sizeFn, {
            writable: true,
            value: void 0
        });
        /**
   * A function that returns the default size for items that return NaN/undefined.
   *
   * @type {Function}
   */ _class_private_field_init(this, _defaultSizeFn, {
            writable: true,
            value: void 0
        });
        /**
   * Optional predicate. When it returns `true`, every item is guaranteed to have the same size,
   * so the uniform strategy is used. The predicate must be conservative: return `false` whenever
   * any per-item size override may exist.
   *
   * @type {Function|undefined}
   */ _class_private_field_init(this, _isUniformFn, {
            writable: true,
            value: void 0
        });
        /**
   * Optional provider of "sparse exceptions": a record of per-index size overrides on top of an
   * otherwise uniform base size (e.g. `wtViewport.oversizedRows` when the size source itself is
   * uniform). When it returns a record, the sparse strategy is used. Return `null` whenever the
   * base sizes are not uniform (per-item size settings or hooks exist).
   *
   * @type {Function|undefined}
   */ _class_private_field_init(this, _sparseExceptionsFn, {
            writable: true,
            value: void 0
        });
        /**
   * Optional callback invoked whenever the cache is (re)built, in any mode. Lets the owner record
   * the context the sizes were read in (e.g. which row carried the first-rendered-row border
   * compensation at build time).
   *
   * @type {Function|undefined}
   */ _class_private_field_init(this, _onBuildFn, {
            writable: true,
            value: void 0
        });
        /**
   * The total number of items (rows or columns) read at build time.
   *
   * @type {number}
   */ this.totalItems = 0;
        _class_private_field_set(this, _strategy1, null);
        /**
   * Increments on every {@link PositionCache#build}, in any mode.
   *
   * A caller that must not be served a build taken while its own inputs were incomplete can
   * snapshot this and compare afterwards. `isCurrent()` cannot answer that: an invalidate followed
   * by a rebuild leaves it `true` both before and after.
   *
   * @type {number}
   */ this.buildSeq = 0;
        _class_private_field_set(this, _totalItemsFn, totalItemsFn);
        _class_private_field_set(this, _sizeFn, sizeFn);
        _class_private_field_set(this, _defaultSizeFn, defaultSizeFn);
        _class_private_field_set(this, _isUniformFn, isUniformFn);
        _class_private_field_set(this, _sparseExceptionsFn, sparseExceptionsFn);
        _class_private_field_set(this, _onBuildFn, onBuildFn);
    }
}
