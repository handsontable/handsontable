"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DEFAULT_COLUMN_WIDTH", {
    enumerable: true,
    get: function() {
        return DEFAULT_COLUMN_WIDTH;
    }
});
const DEFAULT_COLUMN_WIDTH = 50;
