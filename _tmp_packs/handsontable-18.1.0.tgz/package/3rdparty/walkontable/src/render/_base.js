"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BaseRenderer", {
    enumerable: true,
    get: function() {
        return BaseRenderer;
    }
});
const _nodesPool = require("../utils/nodesPool");
class BaseRenderer {
    /**
   * Sets the table renderer instance to the current renderer.
   *
   * @param {TableRenderer} table The TableRenderer instance.
   */ setTable(table) {
        if (this.nodesPool) {
            this.nodesPool.setRootDocument(table.rootDocument);
        }
        this.table = table;
    }
    /**
   * Renders the contents to the elements.
   */ render() {}
    /**
   * Creates a new BaseRenderer instance.
   *
   * @param {string | null} nodeType - The node type which the renderer will manage while building the table (eg. 'TD', 'TR', 'TH'), or null.
   * @param {HTMLElement} rootNode - The root node to which newly created elements will be inserted.
   */ constructor(nodeType, rootNode){
        /**
   * Factory for newly created DOM elements.
   *
   * @type {NodesPool|null}
   */ this.nodesPool = null;
        /**
   * Counter of nodes already added.
   *
   * @type {number}
   */ this.renderedNodes = 0;
        this.nodesPool = typeof nodeType === 'string' ? new _nodesPool.NodesPool(nodeType) : null;
        this.nodeType = nodeType;
        if (rootNode !== undefined) {
            this.rootNode = rootNode;
        }
    }
}
