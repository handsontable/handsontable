"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ColGroupRenderer", {
    enumerable: true,
    get: function() {
        return ColGroupRenderer;
    }
});
const _base = require("./_base");
const _console = require("../../../../helpers/console");
const _templateLiteralTag = require("../../../../helpers/templateLiteralTag");
const _element = require("../../../../helpers/dom/element");
const _orderView = require("../utils/orderView");
let performanceWarningAppeared = false;
class ColGroupRenderer extends _base.BaseRenderer {
    /**
   * Renders the col group elements.
   */ render() {
        const { columnsToRender, rowHeadersCount } = this.table;
        const allColumnsToRender = columnsToRender + rowHeadersCount;
        if (!performanceWarningAppeared && columnsToRender > 1000) {
            performanceWarningAppeared = true;
            (0, _console.warn)((0, _templateLiteralTag.toSingleLine)`Performance tip: Handsontable rendered more than 1000 visible columns.\x20
        Consider limiting the number of rendered columns by specifying the table width and/or\x20
        turning off the "renderAllColumns" option.`);
        }
        this.orderView.setSize(allColumnsToRender).setOffset(0).start();
        for(let visibleColumnIndex = 0; visibleColumnIndex < allColumnsToRender; visibleColumnIndex++){
            this.orderView.render();
            const COL = this.orderView.getCurrentNode();
            if (!COL) {
                continue; // eslint-disable-line no-continue
            }
            if (visibleColumnIndex < rowHeadersCount) {
                const sourceColumnIndex = this.table.renderedColumnToSource(visibleColumnIndex);
                COL.style.width = `${this.table.columnUtils.getHeaderWidth(sourceColumnIndex)}px`;
            } else {
                const sourceColumnIndex = this.table.renderedColumnToSource(visibleColumnIndex - rowHeadersCount);
                COL.style.width = `${this.table.columnUtils.getWidth(sourceColumnIndex)}px`;
            }
        }
        this.orderView.end();
        const firstChild = this.rootNode.firstChild;
        if (firstChild) {
            (0, _element.addClass)(firstChild, 'rowHeader');
        }
    }
    /**
   * Creates a new ColGroupRenderer instance.
   *
   * @param {HTMLElement} rootNode - The root HTML element (colgroup) for rendering COL elements.
   */ constructor(rootNode){
        super('COL', rootNode);
        this.orderView = new _orderView.OrderView(rootNode, ()=>this.nodesPool.obtain(), this.nodeType);
    }
}
