"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ColumnHeaderRowsRenderer", {
    enumerable: true,
    get: function() {
        return ColumnHeaderRowsRenderer;
    }
});
const _base = require("./_base");
const _orderView = require("../utils/orderView");
const _element = require("../../../../helpers/dom/element");
const _a11y = require("../../../../helpers/a11y");
class ColumnHeaderRowsRenderer extends _base.BaseRenderer {
    /**
   * Returns currently rendered node.
   *
   * @param {number} visualIndex Visual index of the rendered node (it always goes from 0 to N).
   * @returns {HTMLTableRowElement}
   */ getRenderedNode(visualIndex) {
        return this.orderView.getNode(visualIndex);
    }
    /**
   * Renders the TR elements.
   */ render() {
        const { columnHeadersCount } = this.table;
        if (this.table.isAriaEnabled()) {
            (0, _element.setAttribute)(this.rootNode, [
                (0, _a11y.A11Y_ROWGROUP)()
            ]);
        }
        this.orderView.setSize(columnHeadersCount).setOffset(0).start();
        for(let visibleRowIndex = 0; visibleRowIndex < columnHeadersCount; visibleRowIndex++){
            this.orderView.render();
            const TR = this.orderView.getCurrentNode();
            if (TR && this.table.isAriaEnabled()) {
                (0, _element.setAttribute)(TR, [
                    (0, _a11y.A11Y_ROW)(),
                    (0, _a11y.A11Y_ROWINDEX)(visibleRowIndex + 1)
                ]);
            }
        }
        this.orderView.end();
    }
    /**
   * Creates a new ColumnHeaderRowsRenderer instance.
   *
   * @param {HTMLElement} rootNode - The root HTML element (THEAD) to manage TR elements within.
   */ constructor(rootNode){
        super('TR', rootNode);
        this.orderView = new _orderView.OrderView(rootNode, ()=>this.nodesPool.obtain(), this.nodeType);
    }
}
