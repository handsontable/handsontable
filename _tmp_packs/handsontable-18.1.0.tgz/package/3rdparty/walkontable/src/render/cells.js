"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "CellsRenderer", {
    enumerable: true,
    get: function() {
        return CellsRenderer;
    }
});
const _element = require("../../../../helpers/dom/element");
const _orderView = require("../utils/orderView");
const _base = require("./_base");
const _a11y = require("../../../../helpers/a11y");
class CellsRenderer extends _base.BaseRenderer {
    /**
   * Obtains the instance of the SharedOrderView class which is responsible for rendering the nodes to the root node.
   *
   * @param {HTMLTableRowElement} rootNode The TR element, which is root element for cells (TD).
   * @returns {SharedOrderView}
   */ obtainOrderView(rootNode) {
        if (!this.orderViews.has(rootNode)) {
            this.orderViews.set(rootNode, new _orderView.SharedOrderView(rootNode, ()=>this.nodesPool.obtain(), this.nodeType));
        }
        return this.orderViews.get(rootNode);
    }
    /**
   * Renders the cells.
   */ render() {
        const { rowsToRender, columnsToRender, rows, rowHeaders } = this.table;
        for(let visibleRowIndex = 0; visibleRowIndex < rowsToRender; visibleRowIndex++){
            const sourceRowIndex = this.table.renderedRowToSource(visibleRowIndex);
            const TR = rows.getRenderedNode(visibleRowIndex);
            if (!TR) {
                continue; // eslint-disable-line no-continue
            }
            const orderView = this.obtainOrderView(TR);
            const rowHeadersView = rowHeaders.obtainOrderView(TR);
            orderView.prependView(rowHeadersView).setSize(columnsToRender).setOffset(0).start();
            for(let visibleColumnIndex = 0; visibleColumnIndex < columnsToRender; visibleColumnIndex++){
                orderView.render();
                const sourceColumnIndex = this.table.renderedColumnToSource(visibleColumnIndex);
                const TD = orderView.getCurrentNode();
                if (!TD) {
                    continue; // eslint-disable-line no-continue
                }
                if (!(0, _element.hasClass)(TD, 'hide')) {
                    TD.className = '';
                }
                TD.removeAttribute('style');
                TD.removeAttribute('dir');
                // Remove all accessibility-related attributes for the cell to start fresh.
                (0, _element.removeAttribute)(TD, [
                    /aria-(.*)/,
                    /role/
                ]);
                this.table.cellRenderer(sourceRowIndex, sourceColumnIndex, TD);
                if (this.table.isAriaEnabled()) {
                    (0, _element.setAttribute)(TD, [
                        ...TD.hasAttribute('role') ? [] : [
                            (0, _a11y.A11Y_GRIDCELL)()
                        ],
                        (0, _a11y.A11Y_TABINDEX)(-1),
                        // `aria-colindex` is incremented by both tbody and thead rows.
                        (0, _a11y.A11Y_COLINDEX)(sourceColumnIndex + (this.table.rowUtils?.deps?.getRowHeaders()?.length ?? 0) + 1)
                    ]);
                }
            }
            orderView.end();
        }
    }
    /**
   * Creates a new CellsRenderer instance.
   */ constructor(){
        super('TD'), /**
   * Cache for OrderView classes connected to specified node.
   *
   * @type {WeakMap}
   */ this.orderViews = new WeakMap();
    }
}
