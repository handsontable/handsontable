"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ColumnHeadersRenderer", {
    enumerable: true,
    get: function() {
        return ColumnHeadersRenderer;
    }
});
const _element = require("../../../../helpers/dom/element");
const _base = require("./_base");
const _orderView = require("../utils/orderView");
const _a11y = require("../../../../helpers/a11y");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var /**
   * Stamps the `htLastVisibleHeader` class on the last TH of the header row that does not carry
   * the `hiddenHeader` class (nested headers hide their colspan-continuation THs with it), and
   * clears the class from every other TH. The theme CSS rounds the trailing header corner with
   * this class. It replaces the former `th:not(.hiddenHeader):not(:has(~ th:not(.hiddenHeader)))`
   * theme selector: any `:has()` rule in a stylesheet makes Chrome re-run host-page-scaled style
   * invalidation on DOM mutations, so the state is stamped here, after the row's headers (and the
   * header renderers that toggle `hiddenHeader`) have been rendered.
   *
   * @param {HTMLElement} TR The header row (TR element) to process.
   */ _markLastVisibleHeader = /*#__PURE__*/ new WeakSet();
class ColumnHeadersRenderer extends _base.BaseRenderer {
    /**
   * Obtains the instance of the OrderView class which is responsible for rendering the nodes to the root node.
   *
   * @param {HTMLTableRowElement} rootNode The TR element, which is root element for column headers (TH).
   * @returns {OrderView}
   */ obtainOrderView(rootNode) {
        if (!this.orderViews.has(rootNode)) {
            this.orderViews.set(rootNode, new _orderView.OrderView(rootNode, ()=>this.nodesPool.obtain(), this.nodeType));
        }
        return this.orderViews.get(rootNode);
    }
    /**
   * Renders the TH elements.
   */ render() {
        const { columnHeadersCount, columnHeaderFunctions, columnsToRender, rowHeadersCount, columnHeaderRows } = this.table;
        const allColumnsToRender = columnsToRender + rowHeadersCount;
        for(let visibleRowIndex = 0; visibleRowIndex < columnHeadersCount; visibleRowIndex++){
            const TR = columnHeaderRows.getRenderedNode(visibleRowIndex);
            if (!TR) {
                continue; // eslint-disable-line no-continue
            }
            const orderView = this.obtainOrderView(TR);
            orderView.setSize(allColumnsToRender).setOffset(0).start();
            for(let visibleColumnIndex = 0; visibleColumnIndex < allColumnsToRender; visibleColumnIndex++){
                orderView.render();
                const renderedColumnIndex = visibleColumnIndex - rowHeadersCount;
                const sourceColumnIndex = this.table.renderedColumnToSource(renderedColumnIndex);
                const TH = orderView.getCurrentNode();
                if (!TH) {
                    continue; // eslint-disable-line no-continue
                }
                TH.className = '';
                TH.removeAttribute('style');
                // Remove all accessibility-related attributes for the header to start fresh.
                (0, _element.removeAttribute)(TH, [
                    /aria-(.*)/,
                    /role/
                ]);
                if (this.table.isAriaEnabled()) {
                    (0, _element.setAttribute)(TH, [
                        (0, _a11y.A11Y_COLINDEX)(visibleColumnIndex + 1),
                        (0, _a11y.A11Y_TABINDEX)(-1),
                        (0, _a11y.A11Y_COLUMNHEADER)(),
                        ...renderedColumnIndex >= 0 ? [
                            (0, _a11y.A11Y_SCOPE_COL)()
                        ] : [
                            // Adding `role=row` to the corner headers to prevent
                            // https://github.com/handsontable/dev-handsontable/issues/1574
                            (0, _a11y.A11Y_GRIDCELL_BUTTON)(),
                            (0, _a11y.A11Y_LABEL)('Select whole grid')
                        ]
                    ]);
                }
                columnHeaderFunctions[visibleRowIndex](sourceColumnIndex, TH, visibleRowIndex);
            }
            orderView.end();
            _class_private_method_get(this, _markLastVisibleHeader, markLastVisibleHeader).call(this, TR);
        }
    }
    /**
   * Creates a new ColumnHeadersRenderer instance.
   */ constructor(){
        super('TH'), _class_private_method_init(this, _markLastVisibleHeader), /**
   * Cache for OrderView classes connected to specified node.
   *
   * @type {WeakMap}
   */ this.orderViews = new WeakMap();
    }
}
function markLastVisibleHeader(TR) {
    const { children } = TR;
    let lastVisibleTH = null;
    for(let index = children.length - 1; index >= 0; index--){
        const TH = children[index];
        if (lastVisibleTH === null && !(0, _element.hasClass)(TH, 'hiddenHeader')) {
            lastVisibleTH = TH;
            if (!(0, _element.hasClass)(TH, 'htLastVisibleHeader')) {
                (0, _element.addClass)(TH, 'htLastVisibleHeader');
            }
        } else if ((0, _element.hasClass)(TH, 'htLastVisibleHeader')) {
            (0, _element.removeClass)(TH, 'htLastVisibleHeader');
        }
    }
}
