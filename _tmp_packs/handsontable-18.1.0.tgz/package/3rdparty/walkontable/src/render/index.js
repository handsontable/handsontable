"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CellsRenderer () {
        return _cells.CellsRenderer;
    },
    get ColGroupRenderer () {
        return _colGroup.ColGroupRenderer;
    },
    get ColumnHeaderRowsRenderer () {
        return _columnHeaderRows.ColumnHeaderRowsRenderer;
    },
    get ColumnHeadersRenderer () {
        return _columnHeaders.ColumnHeadersRenderer;
    },
    get Renderer () {
        return Renderer;
    },
    get RowHeadersRenderer () {
        return _rowHeaders.RowHeadersRenderer;
    },
    get RowsRenderer () {
        return _rows.RowsRenderer;
    },
    get TableRenderer () {
        return _tableRenderer.TableRenderer;
    }
});
const _rowHeaders = require("./rowHeaders");
const _columnHeaderRows = require("./columnHeaderRows");
const _columnHeaders = require("./columnHeaders");
const _colGroup = require("./colGroup");
const _rows = require("./rows");
const _cells = require("./cells");
const _tableRenderer = require("./tableRenderer");
/**
 * Content renderer.
 *
 * @class Renderer
 */ class Renderer {
    /**
   * Sets the overlay that is currently rendered. If `null` is provided, the master overlay is set.
   *
   * @param {'inline_start'|'top'|'top_inline_start_corner'|'bottom'|'bottom_inline_start_corner'|'master'} overlayName The overlay name.
   * @returns {Renderer}
   */ setActiveOverlayName(overlayName) {
        this.renderer.setActiveOverlayName(overlayName);
        return this;
    }
    /**
   * Sets filter calculators for newly calculated row and column position. The filters are used to transform visual
   * indexes (0 to N) to source indexes provided by Handsontable.
   *
   * @param {RowFilter} rowFilter The row filter instance.
   * @param {ColumnFilter} columnFilter The column filter instance.
   * @returns {Renderer}
   */ setFilters(rowFilter, columnFilter) {
        this.renderer.setFilters(rowFilter, columnFilter);
        return this;
    }
    /**
   * Sets the viewport size of the rendered table.
   *
   * @param {number} rowsCount An amount of rows to render.
   * @param {number} columnsCount An amount of columns to render.
   * @returns {Renderer}
   */ setViewportSize(rowsCount, columnsCount) {
        this.renderer.setViewportSize(rowsCount, columnsCount);
        return this;
    }
    /**
   * Sets row and column header functions.
   *
   * @param {Function[]} rowHeaders Row header functions. Factories for creating content for row headers.
   * @param {Function[]} columnHeaders Column header functions. Factories for creating content for column headers.
   * @returns {Renderer}
   */ setHeaderContentRenderers(rowHeaders, columnHeaders) {
        this.renderer.setHeaderContentRenderers(rowHeaders, columnHeaders);
        return this;
    }
    /**
   * Marks this draw as one where the column-header (THEAD) pass may be skipped when the column render
   * window is unchanged (a pure vertical scroll).
   *
   * @param {boolean} skippable Whether the column-header pass may be skipped for this draw.
   * @returns {Renderer}
   */ setColumnHeadersRenderSkippable(skippable) {
        this.renderer.setColumnHeadersRenderSkippable(skippable);
        return this;
    }
    /**
   * Renders the table.
   */ render() {
        this.renderer.render();
    }
    /**
   * Creates a new Renderer instance.
   *
   * @param {RendererOptions} options The renderer configuration options.
   */ constructor({ TABLE, THEAD, COLGROUP, TBODY, rowUtils, columnUtils, cellRenderer, stylesHandler } = {}){
        /**
     * General renderer class used to render Walkontable content on screen.
     *
     * @type {TableRenderer}
     */ this.renderer = new _tableRenderer.TableRenderer(TABLE, {
            cellRenderer,
            stylesHandler
        });
        this.renderer.setRenderers({
            rowHeaders: new _rowHeaders.RowHeadersRenderer(),
            columnHeaderRows: new _columnHeaderRows.ColumnHeaderRowsRenderer(THEAD),
            columnHeaders: new _columnHeaders.ColumnHeadersRenderer(),
            colGroup: new _colGroup.ColGroupRenderer(COLGROUP),
            rows: new _rows.RowsRenderer(TBODY),
            cells: new _cells.CellsRenderer()
        });
        this.renderer.setAxisUtils(rowUtils, columnUtils);
    }
}
