"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return Walkontable;
    }
});
const _event = /*#__PURE__*/ _interop_require_wildcard(require("../event"));
const _overlays = /*#__PURE__*/ _interop_require_wildcard(require("../overlay/overlays"));
const _overlay = require("../overlay");
const _settings = /*#__PURE__*/ _interop_require_default(require("../settings"));
const _masterTable = /*#__PURE__*/ _interop_require_default(require("../table/regions/masterTable"));
const _baseTable = require("../table/baseTable");
const _viewport = /*#__PURE__*/ _interop_require_wildcard(require("../viewport/viewport"));
const _base = /*#__PURE__*/ _interop_require_default(require("./_base"));
const _manager = require("../selection/manager");
const _object = require("../../../../helpers/object");
const _element = require("../../../../helpers/dom/element");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
class Walkontable extends _base.default {
    /**
   * Export settings as class names added to the parent element of the table.
   */ exportSettingsAsClassNames() {
        const toExport = {
            rowHeaders: 'htRowHeaders',
            columnHeaders: 'htColumnHeaders'
        };
        const allClassNames = [];
        const newClassNames = [];
        (0, _object.objectEach)(toExport, (className, key)=>{
            if (this.wtSettings.getSetting(key).length) {
                newClassNames.push(className);
            }
            allClassNames.push(className);
        });
        (0, _element.removeClass)(this.wtTable.wtRootElement.parentNode, allClassNames);
        (0, _element.addClass)(this.wtTable.wtRootElement.parentNode, newClassNames);
    }
    /**
   * Destroy instance.
   */ destroy() {
        this.wtTable.destroy();
        super.destroy();
    }
    /**
   * Gets the overlay instance by its name.
   *
   * @param {'inline_start'|'top'|'top_inline_start_corner'|'bottom'|'bottom_inline_start_corner'} overlayName The overlay name.
   * @returns {Overlay | null}
   */ getOverlayByName(overlayName) {
        if (!_overlay.CLONE_TYPES.includes(overlayName)) {
            return null;
        }
        const camelCaseOverlay = overlayName.replace(/_([a-z])/g, (_match, letter)=>letter.toUpperCase());
        return this.wtOverlays[`${camelCaseOverlay}Overlay`] ?? null;
    }
    /**
   * @param {HTMLTableElement} table Main table.
   * @param {SettingsPure} settings The Walkontable settings.
   */ constructor(table, settings){
        super(table, new _settings.default(settings));
        this.wtTable = new _masterTable.default((0, _baseTable.createTableDeps)(this.engineContext));
        // Built after the master table exists (the deps resolve `getWtTable()` concretely); the overlays
        // are still late-bound and come through as thunks in the deps.
        this.wtViewport = new _viewport.default((0, _viewport.createViewportDeps)(this.engineContext));
        this.selectionManager = new _manager.SelectionManager(this.wtSettings.getSetting('selections'));
        this.wtEvent = new _event.default((0, _event.createEventDeps)(this.engineContext));
        this.wtOverlays = new _overlays.default((0, _overlays.createOverlaysDeps)(this.engineContext));
        this.exportSettingsAsClassNames();
        this.findOriginalHeaders();
    }
}
