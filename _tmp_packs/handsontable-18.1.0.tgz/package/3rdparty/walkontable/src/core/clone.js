"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return Clone;
    }
});
const _event = /*#__PURE__*/ _interop_require_wildcard(require("../event"));
const _baseTable = require("../table/baseTable");
const _base = /*#__PURE__*/ _interop_require_default(require("./_base"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
class Clone extends _base.default {
    /**
   * @param {HTMLTableElement} table Main table.
   * @param {SettingsPure|Settings} settings The Walkontable settings.
   * @param {WalkontableCloneOptions} clone Clone data.
   */ constructor(table, settings, clone){
        // Share the master's geometry reader instead of creating a new one, so a single reader serves
        // the master and all overlay clones.
        super(table, settings, clone.geometryReader);
        this.cloneSource = clone.source;
        this.cloneOverlay = clone.overlay;
        this.wtTable = this.cloneOverlay.createTable((0, _baseTable.createTableDeps)(this.engineContext));
        this.wtViewport = clone.viewport;
        this.selectionManager = clone.selectionManager;
        // Event deps resolve `getWtTable()`/`getSelectionManager()` off this clone's context, so they
        // read the clone's own table and selection manager (set just above). The parent Event is the
        // per-instance link back to the master, kept as a separate argument.
        this.wtEvent = new _event.default((0, _event.createEventDeps)(this.engineContext), clone.event);
        this.findOriginalHeaders();
    }
}
