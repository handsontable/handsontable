"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return CoreAbstract;
    }
});
const _element = require("../../../../helpers/dom/element");
const _string = require("../../../../helpers/string");
const _eventManager = /*#__PURE__*/ _interop_require_default(require("../../../../eventManager"));
const _scroll = /*#__PURE__*/ _interop_require_wildcard(require("../scroll/scroll"));
const _coords = /*#__PURE__*/ _interop_require_default(require("../cell/coords"));
const _range = /*#__PURE__*/ _interop_require_default(require("../cell/range"));
const _liveGeometryReader = require("../domMeasure/liveGeometryReader");
const _wire = require("../wire");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
class CoreAbstract {
    /**
   * Gets or creates the event manager instance.
   *
   * @returns {EventManager} The event manager instance.
   */ get eventManager() {
        return new _eventManager.default(this);
    }
    /**
   * Gets the root document from dom bindings.
   *
   * @returns {Document} The root document.
   */ get rootDocument() {
        return this.domBindings.rootDocument;
    }
    /**
   * Gets the root window from dom bindings.
   *
   * @returns {Window} The root window.
   */ get rootWindow() {
        return this.domBindings.rootWindow;
    }
    /**
   * Delegates to wtSettings.getSetting.
   *
   * @param {string} key The settings key.
   * @param {...unknown} args Additional arguments.
   * @returns {unknown}
   */ getSetting(key, ...args) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return this.wtSettings.getSetting(key, ...args);
    }
    /**
   * Delegates to wtSettings.update.
   *
   * @param {string} key The settings key.
   * @param {unknown} value The value to set.
   */ update(key, value) {
        this.wtSettings.update(key, value);
    }
    /**
   * Finds and stores original table headers, setting up column header rendering callbacks if not already configured.
   */ findOriginalHeaders() {
        const originalHeaders = [];
        // find original headers
        if (this.wtTable.THEAD && this.wtTable.THEAD.childNodes.length && this.wtTable.THEAD.childNodes[0].childNodes.length) {
            for(let c = 0, clen = this.wtTable.THEAD.childNodes[0].childNodes.length; c < clen; c++){
                originalHeaders.push(this.wtTable.THEAD.childNodes[0].childNodes[c].innerHTML);
            }
            if (!this.wtSettings.getSetting('columnHeaders').length) {
                this.wtSettings.update('columnHeaders', [
                    function(column, TH) {
                        (0, _element.fastInnerText)(TH, originalHeaders[column]);
                    }
                ]);
            }
        }
    }
    /**
   * Creates and returns the CellCoords object.
   *
   * @param {*} row The row index.
   * @param {*} column The column index.
   * @returns {CellCoords}
   */ createCellCoords(row, column) {
        return new _coords.default(row, column, this.wtSettings.getSetting('rtlMode'));
    }
    /**
   * Creates and returns the CellRange object.
   *
   * @param {CellCoords} highlight The highlight coordinates.
   * @param {CellCoords} from The from coordinates.
   * @param {CellCoords} to The to coordinates.
   * @returns {CellRange}
   */ createCellRange(highlight, from, to) {
        return new _range.default(highlight, from, to, this.wtSettings.getSetting('rtlMode'));
    }
    /**
   * Force rerender of Walkontable.
   *
   * @param {boolean} [fastDraw=false] When `true`, try to refresh only the positions of borders without rerendering
   *                                   the data. It will only work if Table.draw() does not force
   *                                   rendering anyway.
   * @returns {Walkontable}
   */ draw(fastDraw = false) {
        this.drawInterrupted = false;
        if (!this.wtTable.isVisible() || (0, _element.hasZeroHeight)(this.wtTable.wtRootElement.parentNode)) {
            // draw interrupted because TABLE is not visible or has the height set to 0
            this.drawInterrupted = true;
        } else {
            this.wtTable.draw(fastDraw);
        }
        return this;
    }
    /**
   * Returns the TD at coords. If topmost is set to true, returns TD from the topmost overlay layer,
   * if not set or set to false, returns TD from the master table.
   *
   * @param {CellCoords} coords The cell coordinates.
   * @param {boolean} [topmost=false] If set to `true`, it returns the TD element from the topmost overlay. For example,
   *                                  if the wanted cell is in the range of fixed rows, it will return a TD element
   *                                  from the top overlay.
   * @returns {HTMLElement}
   */ getCell(coords, topmost = false) {
        if (coords.row === null || coords.col === null) {
            return undefined;
        }
        if (!topmost) {
            return this.wtTable.getCell(coords);
        }
        const totalRows = this.wtSettings.getSetting('totalRows');
        const fixedRowsTop = this.wtSettings.getSetting('fixedRowsTop');
        const fixedRowsBottom = this.wtSettings.getSetting('fixedRowsBottom');
        const fixedColumnsStart = this.wtSettings.getSetting('fixedColumnsStart');
        if (coords.row < fixedRowsTop && coords.col < fixedColumnsStart) {
            return this.wtOverlays.topInlineStartCornerOverlay.clone?.wtTable.getCell(coords);
        } else if (coords.row < fixedRowsTop) {
            return this.wtOverlays.topOverlay.clone?.wtTable.getCell(coords);
        } else if (coords.col < fixedColumnsStart && coords.row >= totalRows - fixedRowsBottom) {
            return this.wtOverlays.bottomInlineStartCornerOverlay?.clone?.wtTable.getCell(coords);
        } else if (coords.col < fixedColumnsStart) {
            return this.wtOverlays.inlineStartOverlay.clone?.wtTable.getCell(coords);
        } else if (coords.row < totalRows && coords.row >= totalRows - fixedRowsBottom) {
            return this.wtOverlays.bottomOverlay?.clone?.wtTable.getCell(coords);
        }
        return this.wtTable.getCell(coords);
    }
    /**
   * Scrolls the viewport to a cell (rerenders if needed).
   *
   * @param {CellCoords} coords The cell coordinates to scroll to.
   * @param {'auto' | 'start' | 'end'} [horizontalSnap='auto'] If `'start'`, viewport is scrolled to show
   * the cell on the left of the table. If `'end'`, viewport is scrolled to show the cell on the right of
   * the table. When `'auto'`, the viewport is scrolled only when the column is outside of the viewport.
   * @param {'auto' | 'top' | 'bottom'} [verticalSnap='auto'] If `'top'`, viewport is scrolled to show
   * the cell on the top of the table. If `'bottom'`, viewport is scrolled to show the cell on the bottom of
   * the table. When `'auto'`, the viewport is scrolled only when the row is outside of the viewport.
   * @returns {boolean}
   */ scrollViewport(coords, horizontalSnap, verticalSnap) {
        if (coords.row === null || coords.col === null) {
            return false;
        }
        return this.wtScroll.scrollViewport(coords, horizontalSnap, verticalSnap);
    }
    /**
   * Scrolls the viewport to a column (rerenders if needed).
   *
   * @param {number} column Visual column index.
   * @param {'auto' | 'start' | 'end'} [snapping='auto'] If `'start'`, viewport is scrolled to show
   * the cell on the left of the table. If `'end'`, viewport is scrolled to show the cell on the right of
   * the table. When `'auto'`, the viewport is scrolled only when the column is outside of the viewport.
   * @returns {boolean}
   */ scrollViewportHorizontally(column, snapping) {
        return this.wtScroll.scrollViewportHorizontally(column, snapping);
    }
    /**
   * Scrolls the viewport to a row (rerenders if needed).
   *
   * @param {number} row Visual row index.
   * @param {'auto' | 'top' | 'bottom'} [snapping='auto'] If `'top'`, viewport is scrolled to show
   * the cell on the top of the table. If `'bottom'`, viewport is scrolled to show the cell on
   * the bottom of the table. When `'auto'`, the viewport is scrolled only when the row is outside of
   * the viewport.
   * @returns {boolean}
   */ scrollViewportVertically(row, snapping) {
        return this.wtScroll.scrollViewportVertically(row, snapping);
    }
    /**
   * @returns {Array}
   */ getViewport() {
        return [
            this.wtTable.getFirstVisibleRow(),
            this.wtTable.getFirstVisibleColumn(),
            this.wtTable.getLastVisibleRow(),
            this.wtTable.getLastVisibleColumn()
        ];
    }
    /**
   * Gets the overlay instance by its name. Returns null in the base implementation.
   *
   * @param {string} _overlayName The overlay name.
   * @returns {object | null}
   */ getOverlayByName(_overlayName) {
        return null;
    }
    /**
   * Exports settings as CSS class names. No-op in the base implementation.
   */ exportSettingsAsClassNames() {
    // no-op; overridden in Walkontable (master table)
    }
    /**
   * Destroy instance.
   */ destroy() {
        this.wtOverlays.destroy();
        this.wtEvent.destroy();
    }
    /**
   * @param {HTMLTableElement} table Main table.
   * @param {Settings} settings The Walkontable settings.
   * @param {GeometryReader} [geometryReader] The shared geometry reader. The master creates one live
   *   reader and passes it to every clone (see `Clone`), so a single reader serves the master and all
   *   overlay clones — the one place a `CachingGeometryReader` gets swapped in later. When omitted (the
   *   master), a `LiveGeometryReader` is created.
   */ constructor(table, settings, geometryReader){
        /**
   * The walkontable instance id.
   *
   * @public
   * @type {Readonly<string>}
   */ this.guid = `wt_${(0, _string.randomString)()}`;
        /**
   * Flag indicating whether the current drawing operation was interrupted.
   *
   * @type {boolean}
   */ this.drawInterrupted = false;
        /**
   * Flag indicating whether the table has been drawn.
   *
   * @type {boolean}
   */ this.drawn = false;
        /**
   * The name of the overlay that currently renders the table.
   *
   * @public
   * @type {string}
   */ this.activeOverlayName = 'master';
        this.domBindings = {
            rootTable: table,
            rootDocument: table.ownerDocument,
            rootWindow: table.ownerDocument.defaultView,
            geometryReader: geometryReader ?? new _liveGeometryReader.LiveGeometryReader(table.ownerDocument.defaultView)
        };
        this.wtSettings = settings;
        // The engine context is the single composition surface: it holds the stable references and
        // defines every late-bound/cyclic thunk ONCE. Built here because settings and DOM bindings now
        // exist; the thunks resolve the table/viewport/overlays lazily, at call time, exactly as before.
        this.engineContext = (0, _wire.buildContext)(this);
        // `Scroll` is created before the table/viewport/overlays exist, so its dependency set is assembled
        // from the context (the late-bound engine objects come through as thunks resolved at call time).
        this.wtScroll = new _scroll.default((0, _scroll.createScrollDeps)(this.engineContext));
    }
}
