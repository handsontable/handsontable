"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get createEventDeps () {
        return createEventDeps;
    },
    get default () {
        return _default;
    }
});
const _element = require("../../../helpers/dom/element");
const _pointerToCoords = require("./utils/pointerToCoords");
const _feature = require("../../../helpers/feature");
const _browser = require("../../../helpers/browser");
const _inputOrigin = require("../../../helpers/dom/inputOrigin");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
const LONG_PRESS_DELAY = 500;
const LONG_PRESS_MOVE_THRESHOLD = 10;
/**
 * How long (ms) after a mousedown the double-click detector keeps waiting for the matching
 * second click. Mirrors the OS double-click tolerance with margin.
 */ const DBLCLICK_MOUSEDOWN_TIMEOUT = 1000;
/**
 * How long (ms) after a mouseup the double-click detector keeps the first click "armed"
 * for a mouse-driven double-click.
 */ const DBLCLICK_MOUSEUP_TIMEOUT = 500;
/**
 * How long (ms) after a touch tap a second tap on the same cell counts as a double-tap. Touch
 * taps are paired by `#handleTouchTap()`, independently of the mouse double-click slots, so a
 * real mouse click after a tap never pairs with it. iOS drops taps under ~250 ms and humans
 * double-tap at 300–600 ms (DEV-2687).
 */ const TOUCH_DBLTAP_TIMEOUT = 1000;
function createEventDeps(ctx) {
    return {
        facadeGetter: ctx.getFacade(),
        rootDocument: ctx.rootDocument,
        rootWindow: ctx.rootWindow,
        geometryReader: ctx.geometryReader,
        wtSettings: ctx.wtSettings,
        eventManager: ctx.makeEventManager(),
        wtTable: ctx.getWtTable(),
        selectionManager: ctx.getSelectionManager()
    };
}
var /**
   * The Event module dependencies (same `#deps` pattern as the other Walkontable modules).
   *
   * @type {EventDeps}
   */ _deps = /*#__PURE__*/ new WeakMap(), /**
   * Parent Event instance, or null for the root instance.
   *
   * @type {Event | null}
   */ _parent = /*#__PURE__*/ new WeakMap(), /**
   * @type {boolean}
   */ _selectedCellBeforeTouchEnd = /*#__PURE__*/ new WeakMap(), /**
   * @type {number[]}
   */ _dblClickTimeout = /*#__PURE__*/ new WeakMap(), /**
   * @type {number[]}
   */ _dblClickOrigin = /*#__PURE__*/ new WeakMap(), /**
   * Coordinates of the most recent touch tap, kept for double-tap detection. Coordinates, not the
   * resolved TD: Walkontable recycles TD elements across scrolls and re-renders, so element
   * identity can pair two taps that landed on different cells (DEV-2687 review). Touch taps never
   * arm the mouse double-click slots, so a mouse click after a tap cannot pair with a tap.
   *
   * @type {CellCoords|null}
   */ _lastTapCoords = /*#__PURE__*/ new WeakMap(), /**
   * Timestamp (ms) of the most recent touch tap.
   *
   * @type {number}
   */ _lastTapAt = /*#__PURE__*/ new WeakMap(), /**
   * Timer ID for the long-press gesture detection.
   *
   * @type {number|null}
   */ _longPressTimeout = /*#__PURE__*/ new WeakMap(), /**
   * Marks that the long-press contextmenu gesture has been triggered for the current touch.
   *
   * @type {boolean}
   */ _longPressFired = /*#__PURE__*/ new WeakMap(), /**
   * Starting coordinates of a touch gesture (used to detect movement that cancels long-press
   * and to distinguish a tap from a scroll).
   *
   * @type {{ x: number, y: number }|null}
   */ _touchStartCoords = /*#__PURE__*/ new WeakMap(), /**
   * Marks that the current touch gesture has moved beyond the threshold and should be treated
   * as a scroll rather than a tap.
   *
   * @type {boolean}
   */ _touchWasMoved = /*#__PURE__*/ new WeakMap(), /**
   * The original `touchstart` event captured so the synthesized mousedown can be deferred to
   * `touchend` and only fired when the gesture is a tap (not a scroll).
   *
   * @type {TouchEvent|null}
   */ _deferredTouchStartEvent = /*#__PURE__*/ new WeakMap(), /**
   * Timestamp (ms) of the most recent `onMouseUp` call that originated from a touch gesture.
   * On devices that register both touch and mouse listeners (iPad with a desktop UA, Windows
   * touchscreens) the browser synthesizes a `mousedown`/`mouseup`/`click` sequence after
   * `touchend`. The whole sequence must be ignored – dropping only one half fires
   * `onCellMouseDown` a second time per tap, and the leaked pair would act as a phantom mouse
   * click (DEV-2687).
   * Used as the fallback for engines that do not expose `sourceCapabilities`
   * (see `#isTouchSynthesizedMouseEvent`).
   *
   * @type {number}
   */ _lastTouchMouseUpAt = /*#__PURE__*/ new WeakMap(), /**
   * `true` between a touch-driven `onMouseUp` and the browser-synthesized `mouseup` that follows it.
   * Only that first pair is dropped; once it is consumed, real mouse events pass even inside the
   * `TOUCH_SYNTHESIZED_MOUSE_WINDOW` ceiling, so a fill-handle drag or a drag-selection started with
   * a mouse right after a tap works on engines that do not report the input origin (DEV-2687). The
   * flag is re-armed by every touch-driven `onMouseUp` and cleared when a scroll-classified gesture
   * ends, so a tap that synthesized nothing cannot swallow that gesture's own compatibility pair.
   *
   * @type {boolean}
   */ _synthesizedPairPending = /*#__PURE__*/ new WeakMap(), /**
   * @type {boolean}
   */ _mouseDown = /*#__PURE__*/ new WeakMap(), /**
   * The last renderable coords seen in `onMouseMove` while the mouse was outside the viewport.
   * Used to skip the `onCellMouseOverOutside` listener call (and therefore `setRangeEnd`) when
   * repeated mousemove events land on the same edge cell.
   *
   * @type {{ row: number, col: number } | null}
   */ _mouseOverOutsideLastCoords = /*#__PURE__*/ new WeakMap(), /**
   * Decides whether a mouse event caught by the mouse listeners is one half of the browser-synthesized
   * `mousedown`/`mouseup` pair that follows a touch tap, and must therefore be dropped. Order of the
   * checks: an engine that reports the input origin and says "not touch" wins (Blink, a real mouse or
   * pen is never dropped); otherwise the event is synthesized only if a touch-driven `onMouseUp` just
   * armed the pair (`#synthesizedPairPending`) and the ceiling has not passed. The `mouseup` half
   * consumes the pair, so any later mouse event inside the ceiling is treated as real. Dropping both
   * halves keeps `onCellMouseDown` at one call per tap and context-menu commands at one execution
   * (#12803); a tap that left no stamp (a gesture treated as a scroll) has its pair processed.
   *
   * @param {MouseEvent} event The mouse event object.
   * @returns {boolean}
   */ _isTouchSynthesizedMouseEvent = /*#__PURE__*/ new WeakSet(), /**
   * Returns the cell coordinates for the given mouse position and whether the mouse is
   * outside the visible viewport. When the mouse is outside, the nearest edge cell is returned.
   *
   * @private
   * @param {number} mouseX Client X coordinate of the mouse.
   * @param {number} mouseY Client Y coordinate of the mouse.
   * @returns {{ coords: CellCoords, isOutside: boolean }}
   */ _getCellCoordsFromMousePosition = /*#__PURE__*/ new WeakSet(), /**
   * Pairs touch taps into double-taps. Called from `onMouseUp` while `touchApplied` is `true`,
   * i.e. for the `onMouseUp` that `onTouchEnd` drives. Two taps on the same coordinates within
   * `TOUCH_DBLTAP_TIMEOUT` fire the double-click callbacks; a long-press, a tap outside the cells,
   * or a tap on different coordinates resets the detector.
   *
   * @param {MouseEvent|TouchEvent} event The event that ended the tap.
   * @param {ParentCell} cell The tapped cell, as returned by `parentCell()`.
   */ _handleTouchTap = /*#__PURE__*/ new WeakSet(), /**
   * Fires the corner or the cell double-click callback for the given cell.
   *
   * @param {MouseEvent|TouchEvent} event The event that completed the double-click.
   * @param {ParentCell} cell The double-clicked cell.
   */ _fireDblClick = /*#__PURE__*/ new WeakSet(), /**
   * Starts the long-press timer. When the timer fires, a synthetic `contextmenu` event is
   * dispatched on the original touch target so that the existing contextmenu hook chain
   * (and ContextMenu plugin) work without changes.
   *
   * @private
   * @param {TouchEvent} event The original `touchstart` event.
   */ _startLongPressTimer = /*#__PURE__*/ new WeakSet(), /**
   * Cancels the pending long-press timer.
   *
   * @private
   */ _cancelLongPressTimer = /*#__PURE__*/ new WeakSet();
/**
 * @class Event
 */ class Event {
    /**
   * Adds listeners for mouse and touch events.
   *
   * @private
   */ registerEvents() {
        _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.holder, 'contextmenu', (event)=>this.onContextMenu(event));
        _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.TABLE, 'mouseover', (event)=>this.onMouseOver(event));
        _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.TABLE, 'mouseout', (event)=>this.onMouseOut(event));
        if (_class_private_field_get(this, _deps).wtTable.isMaster) {
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).rootDocument, 'mousemove', (event)=>this.onMouseMove(event));
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).rootDocument, 'mouseup', ()=>{
                _class_private_field_set(this, _mouseDown, false);
                _class_private_field_set(this, _mouseOverOutsideLastCoords, null);
            });
        }
        const initTouchEvents = ()=>{
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.holder, 'touchstart', (event)=>this.onTouchStart(event));
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.holder, 'touchend', (event)=>this.onTouchEnd(event));
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.holder, 'touchmove', (event)=>this.onTouchMove(event));
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.holder, 'touchcancel', ()=>this.onTouchCancel());
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.holder, 'scroll', ()=>this.onHolderScroll());
        };
        const initMouseEvents = ()=>{
            // On devices that register both touch and mouse listeners (e.g. iPad Safari with a
            // desktop UA), `touchend` already drove `onMouseDown`/`onMouseUp`. The browser then
            // synthesizes a `mousedown`/`mouseup` pair ~0-50 ms later; drop BOTH halves when the
            // touch path handled the tap, so `onCellMouseDown` fires once per tap (DEV-2687) and
            // context-menu commands do not execute twice (#12803).
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.holder, 'mouseup', (event)=>{
                if (_class_private_method_get(this, _isTouchSynthesizedMouseEvent, isTouchSynthesizedMouseEvent).call(this, event)) {
                    return;
                }
                this.onMouseUp(event);
            });
            _class_private_field_get(this, _deps).eventManager.addEventListener(_class_private_field_get(this, _deps).wtTable.holder, 'mousedown', (event)=>{
                if (_class_private_method_get(this, _isTouchSynthesizedMouseEvent, isTouchSynthesizedMouseEvent).call(this, event)) {
                    return;
                }
                this.onMouseDown(event);
            });
        };
        if ((0, _browser.isMobileBrowser)()) {
            initTouchEvents();
        } else {
            // PC like devices which support both methods (touchscreen and ability to plug-in mouse).
            if ((0, _feature.isTouchSupported)()) {
                initTouchEvents();
            }
            initMouseEvents();
        }
    }
    /**
   * Checks if an element is already selected.
   *
   * @private
   * @param {Element} touchTarget An element to check.
   * @returns {boolean}
   */ selectedCellWasTouched(touchTarget) {
        const cellUnderFinger = this.parentCell(touchTarget);
        const coordsOfCellUnderFinger = cellUnderFinger.coords;
        if (_class_private_field_get(this, _selectedCellBeforeTouchEnd) && coordsOfCellUnderFinger) {
            const [rowTouched, rowSelected] = [
                coordsOfCellUnderFinger.row,
                _class_private_field_get(this, _selectedCellBeforeTouchEnd).from.row
            ];
            const [colTouched, colSelected] = [
                coordsOfCellUnderFinger.col,
                _class_private_field_get(this, _selectedCellBeforeTouchEnd).from.col
            ];
            return rowTouched === rowSelected && colTouched === colSelected;
        }
        return false;
    }
    /**
   * Gets closest TD or TH element.
   *
   * @private
   * @param {Element} elem An element from the traversing starts.
   * @returns {object} Contains coordinates and reference to TD or TH if it exists. Otherwise it's empty object.
   */ parentCell(elem) {
        const cell = {
            coords: null,
            TD: null
        };
        const TABLE = _class_private_field_get(this, _deps).wtTable.TABLE;
        const TD = (0, _element.closestDown)(elem, [
            'TD',
            'TH'
        ], TABLE);
        const elemEl = elem;
        if (TD) {
            cell.coords = _class_private_field_get(this, _deps).wtTable.getCoords(TD);
            cell.TD = TD;
        } else if ((0, _element.hasClass)(elemEl, 'wtBorder') && (0, _element.hasClass)(elemEl, 'current')) {
            const focusCellRange = _class_private_field_get(this, _deps).selectionManager.getFocusSelection()?.cellRange;
            if (focusCellRange) {
                cell.coords = focusCellRange.highlight;
                cell.TD = _class_private_field_get(this, _deps).wtTable.getCell(cell.coords);
            }
        } else if ((0, _element.hasClass)(elemEl, 'wtBorder') && (0, _element.hasClass)(elemEl, 'area')) {
            const areaCellRange = _class_private_field_get(this, _deps).selectionManager.getAreaSelection()?.cellRange;
            if (areaCellRange) {
                cell.coords = areaCellRange.to;
                cell.TD = _class_private_field_get(this, _deps).wtTable.getCell(cell.coords);
            }
        }
        return cell;
    }
    /**
   * OnMouseDown callback.
   *
   * @private
   * @param {MouseEvent} event The mouse event object.
   */ onMouseDown(event) {
        const activeElement = (0, _element.getDeepActiveElement)(_class_private_field_get(this, _deps).rootDocument);
        const targetEl = (0, _element.eventTargetEl)(event);
        const getParentNode = (level)=>(0, _element.getParent)(targetEl, level);
        const realTarget = (0, _element.eventTargetEl)(event);
        // ignore non-TD focusable elements from mouse down processing
        // (https://github.com/handsontable/handsontable/issues/3555)
        if (activeElement && ![
            'TD',
            'TH'
        ].includes(activeElement.nodeName) && (realTarget === activeElement || getParentNode(0) === activeElement || getParentNode(1) === activeElement)) {
            return;
        }
        const cell = this.parentCell(realTarget);
        if ((0, _element.hasClass)(realTarget, 'corner')) {
            _class_private_field_get(this, _deps).wtSettings.getSetting('onCellCornerMouseDown', event, realTarget);
        } else if (cell.TD) {
            _class_private_field_set(this, _mouseDown, true);
            _class_private_field_set(this, _mouseOverOutsideLastCoords, null);
            if (_class_private_field_get(this, _deps).wtSettings.has('onCellMouseDown')) {
                this.callListener('onCellMouseDown', event, cell.coords, cell.TD);
            }
        }
        // The mouse double-click slots are armed by mouse clicks only; touch taps are paired by
        // #handleTouchTap() in onMouseUp (DEV-2687).
        if (!this.touchApplied && event.button === 0 && cell.TD) {
            _class_private_field_get(this, _dblClickOrigin)[0] = cell.TD;
            if (_class_private_field_get(this, _dblClickTimeout)[0] !== null) {
                clearTimeout(_class_private_field_get(this, _dblClickTimeout)[0]);
            }
            _class_private_field_get(this, _dblClickTimeout)[0] = setTimeout(()=>{
                _class_private_field_get(this, _dblClickOrigin)[0] = null;
            }, DBLCLICK_MOUSEDOWN_TIMEOUT);
        }
    }
    /**
   * OnContextMenu callback.
   *
   * @private
   * @param {MouseEvent} event The mouse event object.
   */ onContextMenu(event) {
        _class_private_method_get(this, _cancelLongPressTimer, cancelLongPressTimer).call(this);
        if (_class_private_field_get(this, _deps).wtSettings.has('onCellContextMenu')) {
            const cell = this.parentCell((0, _element.eventTargetEl)(event));
            if (cell.TD) {
                this.callListener('onCellContextMenu', event, cell.coords, cell.TD);
            }
        }
    }
    /**
   * OnMouseOver callback.
   *
   * @private
   * @param {MouseEvent} event The mouse event object.
   */ onMouseOver(event) {
        if (!_class_private_field_get(this, _deps).wtSettings.has('onCellMouseOver')) {
            return;
        }
        const table = _class_private_field_get(this, _deps).wtTable.TABLE;
        const td = (0, _element.closestDown)((0, _element.eventTargetEl)(event), [
            'TD',
            'TH'
        ], table);
        const parent = _class_private_field_get(this, _parent) || this;
        if (td && td !== parent.lastMouseOver && (0, _element.isChildOf)(td, table)) {
            parent.lastMouseOver = td;
            const tdCoords = _class_private_field_get(this, _deps).wtTable.getCoords(td);
            if (tdCoords) {
                this.callListener('onCellMouseOver', event, tdCoords, td);
            }
        }
    }
    /**
   * OnMouseMove callback.
   *
   * @private
   * @param {MouseEvent} event The mouse event object.
   */ onMouseMove(event) {
        if (!_class_private_field_get(this, _mouseDown)) {
            return;
        }
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        const { coords, isOutside } = _class_private_method_get(this, _getCellCoordsFromMousePosition, getCellCoordsFromMousePosition).call(this, event.clientX, event.clientY);
        if (isOutside) {
            const lastCoords = _class_private_field_get(this, _mouseOverOutsideLastCoords);
            if (!lastCoords || lastCoords.row !== coords.row || lastCoords.col !== coords.col) {
                const TD = _class_private_field_get(this, _deps).wtTable.getCell(coords);
                if (TD instanceof HTMLElement) {
                    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
                    _class_private_field_set(this, _mouseOverOutsideLastCoords, {
                        row: coords.row,
                        col: coords.col
                    });
                    this.callListener('onCellMouseOverOutside', event, coords, TD);
                }
            }
        } else {
            _class_private_field_set(this, _mouseOverOutsideLastCoords, null);
        }
    }
    /**
   * OnMouseOut callback.
   *
   * @private
   * @param {MouseEvent} event The mouse event object.
   */ onMouseOut(event) {
        if (!_class_private_field_get(this, _deps).wtSettings.has('onCellMouseOut')) {
            return;
        }
        const table = _class_private_field_get(this, _deps).wtTable.TABLE;
        const lastTD = (0, _element.closestDown)((0, _element.eventTargetEl)(event), [
            'TD',
            'TH'
        ], table);
        const nextTD = (0, _element.closestDown)(event.relatedTarget, [
            'TD',
            'TH'
        ], table);
        const parent = _class_private_field_get(this, _parent) || this;
        if (lastTD && lastTD !== nextTD && (0, _element.isChildOf)(lastTD, table)) {
            const lastTDCoords = _class_private_field_get(this, _deps).wtTable.getCoords(lastTD);
            if (lastTDCoords) {
                this.callListener('onCellMouseOut', event, lastTDCoords, lastTD);
            }
            if (nextTD === null) {
                parent.lastMouseOver = null;
            }
        }
    }
    /**
   * OnMouseUp callback.
   *
   * @private
   * @param {MouseEvent} event The mouse event object.
   */ onMouseUp(event) {
        _class_private_field_set(this, _mouseDown, false);
        _class_private_field_set(this, _mouseOverOutsideLastCoords, null);
        const cell = this.parentCell((0, _element.eventTargetEl)(event));
        if (cell.TD && _class_private_field_get(this, _deps).wtSettings.has('onCellMouseUp')) {
            this.callListener('onCellMouseUp', event, cell.coords, cell.TD);
        }
        if (this.touchApplied) {
            _class_private_method_get(this, _handleTouchTap, handleTouchTap).call(this, event, cell);
            return;
        }
        // ignore non-left mouse buttons
        if (event.button !== 0) {
            return;
        }
        if (cell.TD && cell.TD === _class_private_field_get(this, _dblClickOrigin)[0] && cell.TD === _class_private_field_get(this, _dblClickOrigin)[1]) {
            _class_private_method_get(this, _fireDblClick, fireDblClick).call(this, event, cell);
            _class_private_field_get(this, _dblClickOrigin)[0] = null;
            _class_private_field_get(this, _dblClickOrigin)[1] = null;
        } else if (cell.TD && cell.TD === _class_private_field_get(this, _dblClickOrigin)[0]) {
            _class_private_field_get(this, _dblClickOrigin)[1] = cell.TD;
            if (_class_private_field_get(this, _dblClickTimeout)[1] !== null) {
                clearTimeout(_class_private_field_get(this, _dblClickTimeout)[1]);
            }
            _class_private_field_get(this, _dblClickTimeout)[1] = setTimeout(()=>{
                _class_private_field_get(this, _dblClickOrigin)[1] = null;
            }, DBLCLICK_MOUSEUP_TIMEOUT);
        }
    }
    /**
   * OnTouchStart callback. Captures the gesture start so the synthesized mousedown can be
   * deferred to `touchend`; this lets a touch-drag gesture scroll the grid without
   * re-triggering the cell selection (see issue #11659).
   *
   * @private
   * @param {TouchEvent} event The touch event object.
   */ onTouchStart(event) {
        _class_private_field_set(this, _selectedCellBeforeTouchEnd, _class_private_field_get(this, _deps).selectionManager.getFocusSelection()?.cellRange ?? null);
        this.touchApplied = true;
        _class_private_field_set(this, _touchWasMoved, false);
        _class_private_field_set(this, _longPressFired, false);
        _class_private_field_set(this, _deferredTouchStartEvent, event);
        _class_private_method_get(this, _startLongPressTimer, startLongPressTimer).call(this, event);
    }
    /**
   * OnTouchEnd callback. Fires the deferred mousedown only when the gesture is a tap
   * (no movement past the threshold and no long-press); for a scroll gesture the
   * selection stays untouched (see issue #11659).
   *
   * @private
   * @param {TouchEvent} event The touch event object.
   */ onTouchEnd(event) {
        const wasScrolled = _class_private_field_get(this, _touchWasMoved);
        const isTap = !wasScrolled && !_class_private_field_get(this, _longPressFired) && _class_private_field_get(this, _deferredTouchStartEvent) !== null;
        const deferredTouchStartEvent = _class_private_field_get(this, _deferredTouchStartEvent);
        _class_private_method_get(this, _cancelLongPressTimer, cancelLongPressTimer).call(this);
        _class_private_field_set(this, _deferredTouchStartEvent, null);
        if (isTap && deferredTouchStartEvent !== null) {
            this.onMouseDown(deferredTouchStartEvent);
        }
        const target = (0, _element.eventTargetEl)(event);
        const parentCellCoords = this.parentCell(target)?.coords;
        const isCellsRange = parentCellCoords !== null && parentCellCoords !== undefined && (parentCellCoords.row ?? -1) >= 0 && (parentCellCoords.col ?? -1) >= 0;
        const isEventCancelable = event.cancelable && isCellsRange && _class_private_field_get(this, _deps).wtSettings.getSetting('isDataViewInstance');
        // To prevent accidental redirects or other actions that the interactive elements (e.q "A" link) do
        // while the cell is highlighted, all touch events that are triggered on different cells are
        // "preventDefault"'ed. The user can interact with the element (e.q. click on the link that opens
        // a new page) only when the same cell was previously selected (see related PR #7980).
        if (isEventCancelable) {
            const interactiveElements = [
                'A',
                'BUTTON',
                'INPUT'
            ];
            // For browsers that use the WebKit as an engine (excluding Safari), there is a bug. The prevent
            // default has to be called all the time. Otherwise, the second tap won't be triggered (probably
            // caused by the native ~300ms delay - https://webkit.org/blog/5610/more-responsive-tapping-on-ios/).
            // To make the interactive elements work, the event target element has to be check. If the element
            // matches the allow-list, the event is not prevented.
            if ((0, _browser.isIOS)() && ((0, _browser.isChromeWebKit)() || (0, _browser.isFirefoxWebKit)()) && this.selectedCellWasTouched(target) && !interactiveElements.includes(target.tagName)) {
                event.preventDefault();
            } else if (!this.selectedCellWasTouched(target) && !(target.tagName === 'INPUT' && target.type === 'checkbox')) {
                // For other browsers, prevent default is fired only for the first tap and only when the previous
                // highlighted cell was different. Checkbox inputs are excluded so that checkboxes with
                // disableVisualSelection can still be toggled via touch (the focus cellRange is never populated
                // when visual selection is disabled, so selectedCellWasTouched always returns false for them).
                event.preventDefault();
            }
        }
        // Fire mouseUp whenever the gesture also produced a mouseDown - either a tap
        // (deferred mousedown above) or a long-press (mousedown fired from the timer
        // callback). Skipping it for a long-press that ended in a scroll would leave
        // an unpaired mousedown and break plugins listening to onCellMouseUp /
        // before/after hooks (e.g. nestedHeaders, ContextMenu close logic).
        // Suppress only for pure scroll gestures, where onMouseDown was never fired.
        if (!wasScrolled || _class_private_field_get(this, _longPressFired)) {
            // The stamp is taken AFTER the tap is handled, so the selection/render work onMouseUp does
            // is not charged against the TOUCH_SYNTHESIZED_MOUSE_WINDOW ceiling. Everything onMouseUp
            // triggers is synchronous; the browser only dispatches the synthesized mousedown/mouseup
            // sequence after this touchend handler returns.
            this.onMouseUp(event);
            _class_private_field_set(this, _lastTouchMouseUpAt, Date.now());
            _class_private_field_set(this, _synthesizedPairPending, true);
        } else {
            // A pure scroll gesture calls neither onMouseDown nor onMouseUp, so #handleTouchTap never
            // runs to reset the tap detector. Reset it here so a scroll between two taps can't pair them.
            _class_private_field_set(this, _lastTapCoords, null);
            // This gesture armed nothing, so a still-pending flag belongs to an earlier gesture whose
            // pair never came; clear it so THIS gesture's compatibility pair is processed.
            _class_private_field_set(this, _synthesizedPairPending, false);
        }
        this.touchApplied = false;
        _class_private_field_set(this, _touchWasMoved, false);
        _class_private_field_set(this, _longPressFired, false);
    }
    /**
   * OnTouchCancel callback. Browsers cancel a gesture instead of ending it whenever the system
   * claims the touch (an edge-swipe, a dialog, a context callout) — `touchend` then never fires.
   * Without this reset `touchApplied` stays `true` and every REAL mouse `mouseup` is routed into
   * the touch tap detector, which has no button filter, so two right-clicks or two drag-selections
   * ending on the same cell within the double-tap window would fire a phantom double-click.
   * It also releases the mouse-down flag: a long-press fires `onMouseDown` from its timer, and
   * after a cancel no `mouseup` ever follows, which would leave mouse-move selection dragging
   * armed until the next click. The pending synthesized-pair flag is cleared for the same reason
   * the scroll branch of `onTouchEnd` clears it: a cancelled gesture armed nothing, so a
   * still-pending flag belongs to an earlier gesture whose pair never came, and left in place it
   * would drop the next real mouse pair inside the ceiling on engines that do not report the
   * input origin.
   *
   * @private
   */ onTouchCancel() {
        _class_private_method_get(this, _cancelLongPressTimer, cancelLongPressTimer).call(this);
        this.touchApplied = false;
        _class_private_field_set(this, _mouseDown, false);
        _class_private_field_set(this, _touchWasMoved, false);
        _class_private_field_set(this, _longPressFired, false);
        _class_private_field_set(this, _deferredTouchStartEvent, null);
        _class_private_field_set(this, _lastTapCoords, null);
        _class_private_field_set(this, _synthesizedPairPending, false);
    }
    /**
   * Holder `scroll` callback. Cancels the long-press timer and runs the momentum-scroll
   * bookkeeping. When called during an active touch sequence it also marks the gesture
   * as a scroll so the deferred mousedown is not fired on `touchend` - native scrolling
   * can start at ~8px, before the 10px LONG_PRESS_MOVE_THRESHOLD that `onTouchMove`
   * watches (issue #11659).
   *
   * @private
   */ onHolderScroll() {
        if (!this.momentumScrolling) {
            this.momentumScrolling = {};
        }
        if (this.touchApplied) {
            _class_private_field_set(this, _touchWasMoved, true);
        }
        _class_private_method_get(this, _cancelLongPressTimer, cancelLongPressTimer).call(this);
        clearTimeout(this.momentumScrolling._timeout);
        if (!this.momentumScrolling.ongoing) {
            _class_private_field_get(this, _deps).wtSettings.getSetting('onBeforeTouchScroll');
        }
        this.momentumScrolling.ongoing = true;
        this.momentumScrolling._timeout = setTimeout(()=>{
            if (!this.touchApplied) {
                this.momentumScrolling.ongoing = false;
                _class_private_field_get(this, _deps).wtSettings.getSetting('onAfterMomentumScroll');
            }
        }, 200);
    }
    /**
   * OnTouchMove callback. Once the finger moves beyond the threshold, marks the gesture as a
   * scroll so `touchend` skips firing the deferred mousedown, and cancels the long-press timer.
   *
   * @private
   * @param {TouchEvent} event The touch event object.
   */ onTouchMove(event) {
        if (_class_private_field_get(this, _touchStartCoords) === null) {
            return;
        }
        const touch = event.touches[0];
        if (!touch) {
            _class_private_field_set(this, _touchWasMoved, true);
            _class_private_method_get(this, _cancelLongPressTimer, cancelLongPressTimer).call(this);
            return;
        }
        const dx = Math.abs(touch.clientX - _class_private_field_get(this, _touchStartCoords).x);
        const dy = Math.abs(touch.clientY - _class_private_field_get(this, _touchStartCoords).y);
        if (dx > LONG_PRESS_MOVE_THRESHOLD || dy > LONG_PRESS_MOVE_THRESHOLD) {
            _class_private_field_set(this, _touchWasMoved, true);
            _class_private_method_get(this, _cancelLongPressTimer, cancelLongPressTimer).call(this);
        }
    }
    /**
   * Call listener with backward compatibility.
   *
   * @private
   * @param {string} name Name of listener.
   * @param {MouseEvent} event The event object.
   * @param {CellCoords} coords Coordinates.
   * @param {HTMLElement} target Event target.
   */ callListener(name, event, coords, target) {
        const listener = _class_private_field_get(this, _deps).wtSettings.getSettingPure(name);
        if (listener) {
            listener(event, coords, target, _class_private_field_get(this, _deps).facadeGetter());
        }
    }
    /**
   * Clears double-click timeouts and destroys the internal eventManager instance.
   */ destroy() {
        if (_class_private_field_get(this, _dblClickTimeout)[0] !== null) {
            clearTimeout(_class_private_field_get(this, _dblClickTimeout)[0]);
        }
        if (_class_private_field_get(this, _dblClickTimeout)[1] !== null) {
            clearTimeout(_class_private_field_get(this, _dblClickTimeout)[1]);
        }
        _class_private_method_get(this, _cancelLongPressTimer, cancelLongPressTimer).call(this);
        if (this.momentumScrolling) {
            clearTimeout(this.momentumScrolling._timeout);
        }
        _class_private_field_get(this, _deps).eventManager.destroy();
    }
    /**
   * @param {EventDeps} deps The Event module dependencies.
   * @param {Event} [parent=null] The main Event instance.
   */ constructor(deps, parent = null){
        _class_private_method_init(this, _isTouchSynthesizedMouseEvent);
        _class_private_method_init(this, _getCellCoordsFromMousePosition);
        _class_private_method_init(this, _handleTouchTap);
        _class_private_method_init(this, _fireDblClick);
        _class_private_method_init(this, _startLongPressTimer);
        _class_private_method_init(this, _cancelLongPressTimer);
        _class_private_field_init(this, _deps, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _parent, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _selectedCellBeforeTouchEnd, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _dblClickTimeout, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _dblClickOrigin, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _lastTapCoords, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _lastTapAt, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _longPressTimeout, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _longPressFired, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _touchStartCoords, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _touchWasMoved, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _deferredTouchStartEvent, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _lastTouchMouseUpAt, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _synthesizedPairPending, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _mouseDown, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _mouseOverOutsideLastCoords, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _selectedCellBeforeTouchEnd, null);
        _class_private_field_set(this, _dblClickTimeout, [
            null,
            null
        ]);
        _class_private_field_set(this, _dblClickOrigin, [
            null,
            null
        ]);
        _class_private_field_set(this, _lastTapCoords, null);
        _class_private_field_set(this, _lastTapAt, 0);
        _class_private_field_set(this, _longPressTimeout, null);
        _class_private_field_set(this, _longPressFired, false);
        _class_private_field_set(this, _touchStartCoords, null);
        _class_private_field_set(this, _touchWasMoved, false);
        _class_private_field_set(this, _deferredTouchStartEvent, null);
        _class_private_field_set(this, _lastTouchMouseUpAt, 0);
        _class_private_field_set(this, _synthesizedPairPending, false);
        _class_private_field_set(this, _mouseDown, false);
        _class_private_field_set(this, _mouseOverOutsideLastCoords, null);
        _class_private_field_set(this, _deps, deps);
        _class_private_field_set(this, _parent, parent);
        this.registerEvents();
    }
}
function isTouchSynthesizedMouseEvent(event) {
    if ((0, _inputOrigin.getMouseEventTouchOrigin)(event) === false) {
        return false;
    }
    const withinCeiling = Date.now() - _class_private_field_get(this, _lastTouchMouseUpAt) < _inputOrigin.TOUCH_SYNTHESIZED_MOUSE_WINDOW;
    if (!_class_private_field_get(this, _synthesizedPairPending) || !withinCeiling) {
        _class_private_field_set(this, _synthesizedPairPending, false);
        return false;
    }
    if (event.type === 'mouseup') {
        _class_private_field_set(this, _synthesizedPairPending, false);
    }
    return true;
}
function getCellCoordsFromMousePosition(mouseX, mouseY) {
    return (0, _pointerToCoords.getCellCoordsFromMousePosition)(_class_private_field_get(this, _deps), mouseX, mouseY);
}
function handleTouchTap(event, cell) {
    if (_class_private_field_get(this, _longPressFired) || !cell.TD || !cell.coords) {
        _class_private_field_set(this, _lastTapCoords, null);
        return;
    }
    const now = Date.now();
    const isSameCell = _class_private_field_get(this, _lastTapCoords) !== null && _class_private_field_get(this, _lastTapCoords).row === cell.coords.row && _class_private_field_get(this, _lastTapCoords).col === cell.coords.col;
    if (isSameCell && now - _class_private_field_get(this, _lastTapAt) < TOUCH_DBLTAP_TIMEOUT) {
        _class_private_method_get(this, _fireDblClick, fireDblClick).call(this, event, cell);
        _class_private_field_set(this, _lastTapCoords, null);
        return;
    }
    // Clone: parentCell()'s border branches return references into the live selection CellRange,
    // which normalize() mutates in place — a stored alias could silently shift within the
    // double-tap window.
    _class_private_field_set(this, _lastTapCoords, cell.coords.clone());
    _class_private_field_set(this, _lastTapAt, now);
}
function fireDblClick(event, cell) {
    if ((0, _element.hasClass)((0, _element.eventTargetEl)(event), 'corner')) {
        this.callListener('onCellCornerDblClick', event, cell.coords, cell.TD);
    } else {
        this.callListener('onCellDblClick', event, cell.coords, cell.TD);
    }
}
function startLongPressTimer(event) {
    _class_private_method_get(this, _cancelLongPressTimer, cancelLongPressTimer).call(this);
    const touch = event.touches[0];
    if (!touch) {
        return;
    }
    _class_private_field_set(this, _touchStartCoords, {
        x: touch.clientX,
        y: touch.clientY
    });
    _class_private_field_set(this, _longPressTimeout, setTimeout(()=>{
        _class_private_field_set(this, _longPressTimeout, null);
        _class_private_field_set(this, _longPressFired, true);
        _class_private_field_set(this, _touchStartCoords, null);
        // Select the long-pressed cell so context-menu commands (e.g. "Insert row above")
        // operate on it. With the deferred-mousedown flow, touchend skips onMouseDown
        // when #longPressFired is true, so we fire it here before opening the menu.
        this.onMouseDown(event);
        _class_private_field_get(this, _dblClickOrigin)[0] = null;
        _class_private_field_get(this, _dblClickOrigin)[1] = null;
        _class_private_field_set(this, _lastTapCoords, null);
        if (_class_private_field_get(this, _dblClickTimeout)[0] !== null) {
            clearTimeout(_class_private_field_get(this, _dblClickTimeout)[0]);
        }
        if (_class_private_field_get(this, _dblClickTimeout)[1] !== null) {
            clearTimeout(_class_private_field_get(this, _dblClickTimeout)[1]);
        }
        const target = event.target;
        if (!target) {
            return;
        }
        const contextMenuEvent = new MouseEvent('contextmenu', {
            bubbles: true,
            cancelable: true,
            clientX: touch.clientX,
            clientY: touch.clientY,
            screenX: touch.screenX,
            screenY: touch.screenY
        });
        target.dispatchEvent(contextMenuEvent);
    }, LONG_PRESS_DELAY));
}
function cancelLongPressTimer() {
    if (_class_private_field_get(this, _longPressTimeout) !== null) {
        clearTimeout(_class_private_field_get(this, _longPressTimeout));
        _class_private_field_set(this, _longPressTimeout, null);
    }
    _class_private_field_set(this, _touchStartCoords, null);
}
const _default = Event;
