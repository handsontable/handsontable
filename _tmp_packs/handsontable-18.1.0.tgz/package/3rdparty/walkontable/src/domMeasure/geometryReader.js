/**
 * Reads geometric measurements from the DOM.
 *
 * Every layout-forcing DOM read in the rendering engine goes through this port instead of reading
 * element properties (`clientHeight`, `offsetWidth`, …) directly. Centralizing the reads here is the
 * seam a caching layer can later slot into: a future adapter can memoize measurements per draw
 * without changing any call site.
 *
 * The only adapter today is `LiveGeometryReader` — a stateless pass-through that reads straight from
 * the DOM and holds no cache, so it introduces no behavior change.
 *
 * The contract currently covers the reads used by the viewport calculations. It grows as more
 * modules are routed through the port; only methods matched to a real call site are declared.
 *
 * @interface GeometryReader
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
