"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _baseTable = /*#__PURE__*/ _interop_require_default(require("../baseTable"));
const _stickyRowsBottom = /*#__PURE__*/ _interop_require_default(require("../rangeQuery/stickyRowsBottom"));
const _stickyColumnsStart = /*#__PURE__*/ _interop_require_default(require("../rangeQuery/stickyColumnsStart"));
const _object = require("../../../../../helpers/object");
const _overlay = require("../../overlay");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * Subclass of `Table` that provides the helper methods relevant to bottomInlineStartCornerOverlay
 * (in RTL mode the overlay sits on the right of the screen), implemented through mixins.
 *
 * @mixes stickyRowsBottom
 * @mixes stickyColumnsStart
 */ class BottomInlineStartCornerOverlayTable extends _baseTable.default {
    /**
   * @param {TableDeps} deps The table module dependencies.
   */ constructor(deps){
        super(deps, _overlay.CLONE_BOTTOM_INLINE_START_CORNER);
    }
}
(0, _object.mixin)(BottomInlineStartCornerOverlayTable, _stickyRowsBottom.default);
(0, _object.mixin)(BottomInlineStartCornerOverlayTable, _stickyColumnsStart.default);
const _default = BottomInlineStartCornerOverlayTable;
