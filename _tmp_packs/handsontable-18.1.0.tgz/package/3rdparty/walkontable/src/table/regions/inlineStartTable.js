"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _baseTable = /*#__PURE__*/ _interop_require_default(require("../baseTable"));
const _virtualRange = require("../rangeQuery/virtualRange");
const _stickyColumnsStart = /*#__PURE__*/ _interop_require_default(require("../rangeQuery/stickyColumnsStart"));
const _object = require("../../../../../helpers/object");
const _overlay = require("../../overlay");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * Subclass of `Table` that provides the helper methods relevant to InlineStartOverlayTable, implemented through mixins.
 */ class InlineStartOverlayTable extends _baseTable.default {
    /**
   * @param {TableDeps} deps The table module dependencies.
   */ constructor(deps){
        super(deps, _overlay.CLONE_INLINE_START);
    }
}
(0, _object.mixin)(InlineStartOverlayTable, _virtualRange.rowRangeQuery);
(0, _object.mixin)(InlineStartOverlayTable, _stickyColumnsStart.default);
const _default = InlineStartOverlayTable;
