"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _baseTable = /*#__PURE__*/ _interop_require_default(require("../baseTable"));
const _stickyRowsBottom = /*#__PURE__*/ _interop_require_default(require("../rangeQuery/stickyRowsBottom"));
const _virtualRange = require("../rangeQuery/virtualRange");
const _object = require("../../../../../helpers/object");
const _overlay = require("../../overlay");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * Subclass of `Table` that provides the helper methods relevant to BottomOverlay, implemented through mixins.
 *
 * @mixes stickyRowsBottom
 * @mixes calculatedColumns
 */ class BottomOverlayTable extends _baseTable.default {
    /**
   * @param {TableDeps} deps The table module dependencies.
   */ constructor(deps){
        super(deps, _overlay.CLONE_BOTTOM);
    }
}
(0, _object.mixin)(BottomOverlayTable, _stickyRowsBottom.default);
(0, _object.mixin)(BottomOverlayTable, _virtualRange.columnRangeQuery);
const _default = BottomOverlayTable;
