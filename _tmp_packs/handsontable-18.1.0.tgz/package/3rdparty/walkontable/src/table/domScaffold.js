/**
 * Construction-time DOM scaffolding for `Table` and every subclass.
 *
 * These methods build the wrapper DOM the engine renders into — the `wtSpreader` / `wtHider` /
 * `wtHolder` wrapper chain around the `<table>`, and the `thead`/`tbody`/`colgroup` sections. They run
 * once from the `Table` constructor. They are universal (every table type needs them), so the mixin is
 * applied once to the base `Table` (`mixin(Table, domScaffold)` in `table.ts`) and inherited by all
 * subclasses. The methods run on the `Table` instance (`this`), assigning its public fields
 * (`TABLE`/`THEAD`/`TBODY`/`COLGROUP`) and reading the settings. They reach the injected deps through
 * the read-only `this.deps` getter, since a mixin cannot see the class's `#deps` private field.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "domScaffold", {
    enumerable: true,
    get: function() {
        return domScaffold;
    }
});
const _element = require("../../../../helpers/dom/element");
const _a11y = require("../../../../helpers/a11y");
const _object = require("../../../../helpers/object");
const domScaffold = {
    /**
   * Ensures the table has `tbody`, `thead`, and `colgroup` sections, creating any that are missing.
   *
   * @this Table
   */ fixTableDomTree () {
        const rootDocument = this.deps.rootDocument;
        this.TBODY = this.TABLE.querySelector('tbody');
        if (!this.TBODY) {
            this.TBODY = rootDocument.createElement('tbody');
            this.TABLE.appendChild(this.TBODY);
        }
        this.THEAD = this.TABLE.querySelector('thead');
        if (!this.THEAD) {
            this.THEAD = rootDocument.createElement('thead');
            this.TABLE.insertBefore(this.THEAD, this.TBODY);
        }
        this.COLGROUP = this.TABLE.querySelector('colgroup');
        if (!this.COLGROUP) {
            this.COLGROUP = rootDocument.createElement('colgroup');
            this.TABLE.insertBefore(this.COLGROUP, this.THEAD);
        }
    },
    /**
   * @param {HTMLTableElement} table An element to process.
   * @returns {HTMLElement}
   * @this Table
   */ createSpreader (table) {
        const parent = table.parentNode;
        let spreader;
        if (!parent || parent.nodeType !== Node.ELEMENT_NODE || !(0, _element.isHTMLElement)(parent) || !(0, _element.hasClass)(parent, 'wtHolder')) {
            spreader = this.deps.rootDocument.createElement('div');
            spreader.className = 'wtSpreader';
            if (parent) {
                // if TABLE is detached (e.g. in Jasmine test), it has no parentNode so we cannot attach holder to it
                table.before(spreader);
            }
            spreader.appendChild(table);
        }
        if (spreader) {
            spreader.style.position = 'relative';
            if (this.wtSettings.getSetting('ariaTags')) {
                (0, _element.setAttribute)(spreader, [
                    (0, _a11y.A11Y_PRESENTATION)()
                ]);
            }
        }
        return spreader;
    },
    /**
   * @param {HTMLElement} spreader An element to the hider element is injected.
   * @returns {HTMLElement}
   * @this Table
   */ createHider (spreader) {
        const parent = spreader.parentNode;
        let hider;
        if (!parent || parent.nodeType !== Node.ELEMENT_NODE || !(0, _element.isHTMLElement)(parent) || !(0, _element.hasClass)(parent, 'wtHolder')) {
            hider = this.deps.rootDocument.createElement('div');
            hider.className = 'wtHider';
            if (parent) {
                // if TABLE is detached (e.g. in Jasmine test), it has no parentNode so we cannot attach holder to it
                spreader.before(hider);
            }
            hider.appendChild(spreader);
        }
        if (hider && this.wtSettings.getSetting('ariaTags')) {
            (0, _element.setAttribute)(hider, [
                (0, _a11y.A11Y_PRESENTATION)()
            ]);
        }
        return hider;
    },
    /**
   * @param {HTMLElement} hider An element to the holder element is injected.
   * @returns {HTMLElement}
   * @this Table
   */ createHolder (hider) {
        const parent = hider.parentNode;
        let holder;
        if (!parent || parent.nodeType !== Node.ELEMENT_NODE || !(0, _element.isHTMLElement)(parent) || !(0, _element.hasClass)(parent, 'wtHolder')) {
            holder = this.deps.rootDocument.createElement('div');
            holder.style.position = 'relative';
            holder.className = 'wtHolder';
            if (this.isMaster) {
                (0, _element.setAttribute)(holder, [
                    (0, _a11y.A11Y_TABINDEX)(-1)
                ]);
            }
            if (parent) {
                // if TABLE is detached (e.g. in Jasmine test), it has no parentNode so we cannot attach holder to it
                hider.before(holder);
            }
            if (this.isMaster) {
                const holderParent = holder.parentNode;
                // holderParent is null when TABLE is detached (e.g. in Jasmine tests); skip class assignment in that case.
                // isHTMLElement() is used instead of `instanceof HTMLElement` because the latter fails in
                // cross-frame contexts (e.g. when HoT is mounted inside an <iframe> via React portals):
                // the iframe's HTMLElement constructor !== the parent frame's HTMLElement.
                if ((0, _element.isHTMLElement)(holderParent)) {
                    holderParent.className += 'ht_master handsontable';
                    holderParent.setAttribute('dir', this.wtSettings.getSettingPure('rtlMode') ? 'rtl' : 'ltr');
                    if (this.wtSettings.getSetting('ariaTags')) {
                        (0, _element.setAttribute)(holderParent, [
                            (0, _a11y.A11Y_PRESENTATION)()
                        ]);
                    }
                }
            }
            holder.appendChild(hider);
        }
        if (holder && this.wtSettings.getSetting('ariaTags')) {
            (0, _element.setAttribute)(holder, [
                (0, _a11y.A11Y_PRESENTATION)()
            ]);
        }
        return holder;
    }
};
(0, _object.defineGetter)(domScaffold, 'MIXIN_NAME', 'domScaffold', {
    writable: false,
    enumerable: false
});
