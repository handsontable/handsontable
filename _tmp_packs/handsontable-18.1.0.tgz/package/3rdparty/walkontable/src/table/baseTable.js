"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get createTableDeps () {
        return createTableDeps;
    },
    get default () {
        return _default;
    }
});
const _cellAccess = require("./cellAccess");
const _domScaffold = require("./domScaffold");
const _sizeGetters = /*#__PURE__*/ _interop_require_default(require("../axisSizing/sizeGetters"));
const _viewportPredicates = /*#__PURE__*/ _interop_require_default(require("./rangeQuery/viewportPredicates"));
const _element = require("../../../../helpers/dom/element");
const _object = require("../../../../helpers/object");
const _render = require("../render");
const _columnUtils = /*#__PURE__*/ _interop_require_default(require("../axisSizing/columnUtils"));
const _rowUtils = /*#__PURE__*/ _interop_require_default(require("../axisSizing/rowUtils"));
const _drawCycle = require("./drawCycle");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function createTableDeps(ctx) {
    return {
        wot: ctx.wot,
        facadeGetter: ctx.getFacade(),
        wtSettings: ctx.wtSettings,
        rootDocument: ctx.rootDocument,
        rootTable: ctx.rootTable,
        geometryReader: ctx.geometryReader,
        rowSizeSource: ctx.rowSizeSource,
        columnSizeSource: ctx.columnSizeSource,
        getWtTable: ctx.getWtTable,
        getWtViewport: ctx.getWtViewport,
        getWtOverlays: ctx.getWtOverlays,
        getSelectionManager: ctx.getSelectionManager,
        getCloneSource: ctx.getCloneSource,
        getParentTableOffset: ctx.getParentTableOffset,
        getColumnHeaders: ctx.getColumnHeaders,
        getRowHeaders: ctx.getRowHeaders,
        isDrawn: ctx.isDrawn,
        setDrawn: ctx.setDrawn
    };
}
var /**
   * The table module dependencies.
   *
   * @type {TableDeps}
   */ _deps = /*#__PURE__*/ new WeakMap();
/**
 * @todo These mixes are never added to the class Table, however their members are used here.
 * @todo Continue: Potentially it works only, because some of these mixes are added to every inherited class.
 * @todo Refactoring, move code from `if(this.isMaster)` into MasterTable, and others like that.
 * @mixes stickyColumnsStart
 * @mixes stickyRowsBottom
 * @mixes stickyRowsTop
 * @mixes calculatedRows
 * @mixes calculatedColumns
 * @abstract
 */ class Table {
    /**
   * Read-only access to the dependencies, for the range-query mixins (`calculatedRows`/
   * `calculatedColumns`/`stickyRows*`/`stickyColumns*`) and `RowUtils`/`ColumnUtils`, which are
   * defined outside this class and so cannot reach the private `#deps`.
   *
   * @returns {TableDeps}
   */ get deps() {
        return _class_private_field_get(this, _deps);
    }
    // The row/column range-query methods (getFirstRenderedRow, getFirstRenderedColumn, the visible /
    // partially-visible variants, the counts, and the header counts) are attached to the appropriate
    // subclasses by the `withRowRangeQuery` / `withColumnRangeQuery` factories in `renderedRange.ts`.
    // They are exposed on the `Table` type through the `interface Table` merge near the bottom of this
    // file, so `Table`-typed callers can use them; each concrete subclass supplies the runtime
    // implementation for the groups it composes (sticky-overlay methods are still added at runtime by
    // the `mixin()` helper).
    // Methods defined in subclass MasterTable but called from Table via `this.isMaster` guards.
    /**
   * Aligns overlays with the trimming container.
   *
   * @returns {void}
   */ alignOverlaysWithTrimmingContainer() {}
    /**
   * Returns a boolean that is true if this Table represents a specific overlay, identified by the overlay name.
   * For MasterTable, it returns false.
   *
   * @param {string} overlayTypeName The overlay type.
   * @returns {boolean}
   */ is(overlayTypeName) {
        return this.name === overlayTypeName;
    }
    /**
   * Redraws the table.
   *
   * @param {boolean} [fastDraw=false] If TRUE, will try to avoid full redraw and only update the border positions.
   *                                   If FALSE or UNDEFINED, will perform a full redraw.
   * @returns {Table}
   */ draw(fastDraw = false) {
        (0, _drawCycle.runDrawCycle)(this, fastDraw);
        return this;
    }
    /**
   * Modify row header widths provided by user in class contructor.
   *
   * @private
   * @param {Function | number | null} rowHeaderWidthFactory The function which can provide default width values for rows..
   * @returns {number}
   */ _modifyRowHeaderWidth(rowHeaderWidthFactory) {
        const rawWidths = typeof rowHeaderWidthFactory === 'function' ? rowHeaderWidthFactory() : rowHeaderWidthFactory;
        let widths = rawWidths;
        if (Array.isArray(widths)) {
            widths = [
                ...widths
            ];
            widths[widths.length - 1] = this._correctRowHeaderWidth(widths[widths.length - 1]);
        } else {
            widths = this._correctRowHeaderWidth(widths);
        }
        return widths;
    }
    /**
   * Correct row header width if necessary.
   *
   * @private
   * @param {number | null} width The width to process.
   * @returns {number}
   */ _correctRowHeaderWidth(width) {
        let rowHeaderWidth = typeof width === 'number' ? width : this.wtSettings.getSetting('defaultColumnWidth');
        if (this.correctHeaderWidth) {
            rowHeaderWidth += 1;
        }
        return rowHeaderWidth;
    }
    /**
   * Destroys the table instance. Overridden by MasterTable to release DOM resources.
   */ destroy() {
    // Intentionally empty
    }
    /**
   *
   * @abstract
   * @param {TableDeps} deps The table module dependencies.
   * @param {'master'|CLONE_TYPES_ENUM} name Overlay name.
   */ constructor(deps, name){
        _class_private_field_init(this, _deps, {
            writable: true,
            value: void 0
        });
        /**
   * The table body element (TBODY).
   *
   * @type {HTMLTableSectionElement | null}
   */ this.TBODY = null;
        /**
   * The table head element (THEAD).
   *
   * @type {HTMLTableSectionElement | null}
   */ this.THEAD = null;
        /**
   * The column group element (COLGROUP).
   *
   * @type {HTMLTableColElement | null}
   */ this.COLGROUP = null;
        /**
   * Indicates if the table has height bigger than 0px.
   *
   * @type {boolean}
   */ this.hasTableHeight = true;
        /**
   * Indicates if the table has width bigger than 0px.
   *
   * @type {boolean}
   */ this.hasTableWidth = true;
        /**
   * Indicates if the table is visible. By visible, it means that the holder
   * element has CSS 'display' property different than 'none'.
   *
   * @type {boolean}
   */ this.isTableVisible = false;
        /**
   * The offset of the table element.
   *
   * @type {number | { top: number; left: number }}
   */ this.tableOffset = 0;
        /**
   * The offset of the holder element.
   *
   * @type {number | { top: number; left: number }}
   */ this.holderOffset = 0;
        /**
     * Indicates if this instance is of type `MasterTable` (i.e. It is NOT an overlay).
     *
     * @type {boolean}
     */ this.isMaster = name === 'master';
        this.name = name;
        _class_private_field_set(this, _deps, deps);
        this.facadeGetter = deps.facadeGetter;
        this.wtSettings = deps.wtSettings;
        // legacy support
        this.wot = _class_private_field_get(this, _deps).wot;
        this.TABLE = deps.rootTable;
        (0, _element.removeTextNodes)(this.TABLE);
        // TODO refactoring, to recognize the legitimacy of moving them into domBidings
        this.spreader = this.createSpreader(this.TABLE);
        this.hider = this.createHider(this.spreader);
        this.holder = this.createHolder(this.hider);
        // parentNode is always an HTMLElement in production; null only when TABLE is detached (e.g. Jasmine tests).
        this.wtRootElement = this.holder.parentNode;
        if (this.isMaster) {
            this.alignOverlaysWithTrimmingContainer(); // todo wow, It calls method from child class (MasterTable).
        }
        this.fixTableDomTree();
        this.rowFilter = null; // TODO refactoring, eliminate all (re)creations of this object, then updates state when needed.
        this.columnFilter = null; // TODO refactoring, eliminate all (re)creations of this object, then updates state when needed.
        this.correctHeaderWidth = false;
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        const origRowHeaderWidth = this.wtSettings.getSettingPure('rowHeaderWidth');
        // Fix for jumping row headers (https://github.com/handsontable/handsontable/issues/3850)
        this.wtSettings.update('rowHeaderWidth', ()=>this._modifyRowHeaderWidth(origRowHeaderWidth));
        this.rowUtils = new _rowUtils.default(_class_private_field_get(this, _deps));
        this.columnUtils = new _columnUtils.default(_class_private_field_get(this, _deps));
        this.tableRenderer = new _render.Renderer({
            TABLE: this.TABLE,
            THEAD: this.THEAD ?? undefined,
            COLGROUP: this.COLGROUP ?? undefined,
            TBODY: this.TBODY ?? undefined,
            rowUtils: this.rowUtils,
            columnUtils: this.columnUtils,
            cellRenderer: this.wtSettings.getSettingPure('cellRenderer'),
            stylesHandler: this.wtSettings.getSetting('stylesHandler')
        });
    }
}
// Declaration merge: exposes the row/column range-query methods on the `Table` type for
// `Table`-typed callers. The runtime implementations are composed per subclass by the
// `withRowRangeQuery` / `withColumnRangeQuery` factories (see `renderedRange.ts`); subclasses that do
// not compose a group inherit only the type here, matching the previous runtime-mixin behavior where
// calling an absent group threw.
// eslint-disable-next-line no-use-before-define, no-redeclare
(0, _object.mixin)(Table, _cellAccess.cellAccess);
(0, _object.mixin)(Table, _domScaffold.domScaffold);
(0, _object.mixin)(Table, _sizeGetters.default);
(0, _object.mixin)(Table, _viewportPredicates.default);
const _default = Table;
