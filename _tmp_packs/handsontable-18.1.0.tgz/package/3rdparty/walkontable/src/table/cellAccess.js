/**
 * Cell / header DOM-access queries for `Table` and every subclass.
 *
 * These methods translate between source coordinates and the rendered DOM (finding a `TD`/`TH`, a row,
 * a header, or the coords for a given element). They are universal — every table type (master and each
 * overlay clone) needs them — so the mixin is applied once to the base `Table` (`mixin(Table,
 * cellAccess)` in `table.ts`) and inherited by all subclasses, unlike the axis-selective range-query /
 * sticky mixins that are applied per subclass. The methods run on the `Table` instance (`this`),
 * reading its public fields (`THEAD`/`TBODY`/`rowFilter`/`columnFilter`/`wtSettings`/`wot`/
 * `wtRootElement`). They use no `#`-private state, so no `deps` getter is needed here.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "cellAccess", {
    enumerable: true,
    get: function() {
        return cellAccess;
    }
});
const _element = require("../../../../helpers/dom/element");
const _object = require("../../../../helpers/object");
const _errors = require("../../../../helpers/errors");
const _overlay = require("../overlay");
const cellAccess = {
    /**
   * Returns the TD element for the provided coordinates (from the rendered DOM) if it is rendered on
   * the screen, or the exit code otherwise (a negative number when the coordinates are out of the
   * rendered viewport). The exit codes are checked in the order the arguments are given. Thus, if both
   * the row and the column coords are out of the rendered bounds, the method returns the error code for
   * the row.
   *
   * @param {CellCoords} coords The cell coordinates.
   * @returns {HTMLElement|number} HTMLElement on success or Number one of the exit codes on error:
   *  -1 row before viewport
   *  -2 row after viewport
   *  -3 column before viewport
   *  -4 column after viewport.
   * @this Table
   */ getCell (coords) {
        if (coords.row === null || coords.col === null) {
            return -5;
        }
        let row = coords.row;
        let column = coords.col;
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        const hookResult = this.wtSettings.getSetting('onModifyGetCellCoords', row, column, !this.isMaster, 'render');
        if (hookResult && Array.isArray(hookResult)) {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            [row, column] = hookResult;
        }
        if (this.isRowBeforeRenderedRows(row)) {
            // row before rendered rows
            return -1;
        } else if (this.isRowAfterRenderedRows(row)) {
            // row after rendered rows
            return -2;
        } else if (this.isColumnBeforeRenderedColumns(column)) {
            // column before rendered columns
            return -3;
        } else if (this.isColumnAfterRenderedColumns(column)) {
            // column after rendered columns
            return -4;
        }
        const TR = this.getRow(row);
        if (!TR && row >= 0) {
            (0, _errors.throwWithCause)('TR was expected to be rendered but is not');
        }
        const trElement = TR !== false ? TR : null;
        const TD = trElement?.childNodes[this.columnFilter.sourceColumnToVisibleRowHeadedColumn(column)];
        if (!TD && column >= 0) {
            (0, _errors.throwWithCause)('TD or TH was expected to be rendered but is not');
        }
        // TD is a TD/TH HTMLElement guaranteed by DOM structure. TypeScript cannot narrow ChildNode
        // to HTMLElement without instanceof, but adding a throw here would change the existing contract
        // for negative column (header) lookups where TD may be undefined.
        return TD;
    },
    /**
   * Get the DOM element of the row with the provided index.
   *
   * @param {number} rowIndex Row index.
   * @returns {HTMLTableRowElement|boolean} Return the row's DOM element or `false` if the row with the
   * provided index doesn't exist.
   * @this Table
   */ getRow (rowIndex) {
        let renderedRowIndex = null;
        let parentElement = null;
        if (rowIndex < 0) {
            renderedRowIndex = this.rowFilter?.sourceRowToVisibleColHeadedRow(rowIndex);
            parentElement = this.THEAD;
        } else {
            renderedRowIndex = this.rowFilter?.sourceToRendered(rowIndex);
            parentElement = this.TBODY;
        }
        if (renderedRowIndex !== undefined && renderedRowIndex !== null && parentElement !== null) {
            if (parentElement.childNodes.length < renderedRowIndex + 1) {
                return false;
            } else {
                return parentElement.childNodes[renderedRowIndex];
            }
        }
        return false;
    },
    /**
   * GetColumnHeader.
   *
   * @param {number} col Column index.
   * @param {number} [level=0] Header level (0 = most distant to the table).
   * @returns {object} HTMLElement on success or undefined on error.
   * @this Table
   */ getColumnHeader (col, level = 0) {
        const TR = this.THEAD.childNodes[level];
        const TH = TR?.childNodes[this.columnFilter.sourceColumnToVisibleRowHeadedColumn(col)];
        return (0, _element.isHTMLElement)(TH) ? TH : undefined;
    },
    /**
   * Gets all columns headers (TH elements) from the table.
   *
   * @param {number} column A source column index.
   * @returns {HTMLTableCellElement[]}
   * @this Table
   */ getColumnHeaders (column) {
        const THs = [];
        const visibleColumn = this.columnFilter.sourceColumnToVisibleRowHeadedColumn(column);
        this.THEAD.childNodes.forEach((TR)=>{
            const TH = TR.childNodes[visibleColumn];
            if ((0, _element.isHTMLTableCellElement)(TH)) {
                THs.push(TH);
            }
        });
        return THs;
    },
    /**
   * GetRowHeader.
   *
   * @param {number} row Row index.
   * @param {number} [level=0] Header level (0 = most distant to the table).
   * @returns {HTMLElement} HTMLElement on success or Number one of the exit codes on error: `null table
   *   doesn't have row headers`.
   * @this Table
   */ getRowHeader (row, level = 0) {
        const rowHeadersCount = this.wtSettings.getSetting('rowHeaders').length;
        if (level >= rowHeadersCount) {
            return undefined;
        }
        const renderedRow = this.rowFilter.sourceToRendered(row);
        const visibleRow = renderedRow < 0 ? this.rowFilter.sourceRowToVisibleColHeadedRow(row) : renderedRow;
        const parentElement = renderedRow < 0 ? this.THEAD : this.TBODY;
        const TR = parentElement?.childNodes[visibleRow];
        const TH = TR?.childNodes[level];
        return (0, _element.isHTMLElement)(TH) ? TH : undefined;
    },
    /**
   * Gets all rows headers (TH elements) from the table.
   *
   * @param {number} row A source row index.
   * @returns {HTMLTableCellElement[]}
   * @this Table
   */ getRowHeaders (row) {
        const THs = [];
        const rowHeadersCount = this.wtSettings.getSetting('rowHeaders').length;
        for(let renderedRowIndex = 0; renderedRowIndex < rowHeadersCount; renderedRowIndex++){
            const TR = this.TBODY.childNodes[this.rowFilter.sourceToRendered(row)];
            const TH = TR?.childNodes[renderedRowIndex];
            if (TH) {
                THs.push(TH);
            }
        }
        return THs;
    },
    /**
   * Returns cell coords object for a given TD (or a child element of a TD element).
   *
   * @param {HTMLTableCellElement} TD A cell DOM element (or a child of one).
   * @returns {CellCoords|null} The coordinates of the provided TD element (or the closest TD element) or
   *   null, if the provided element is not applicable.
   * @this Table
   */ getCoords (TD) {
        let cellElement = TD;
        if (cellElement.nodeName !== 'TD' && cellElement.nodeName !== 'TH') {
            cellElement = (0, _element.closest)(cellElement, [
                'TD',
                'TH'
            ]);
        }
        if (cellElement === null) {
            return null;
        }
        const TR = cellElement.parentNode;
        if (!TR) {
            return null;
        }
        const CONTAINER = TR.parentNode;
        if (!CONTAINER) {
            return null;
        }
        let row = (0, _element.isHTMLElement)(TR) ? (0, _element.index)(TR) : 0;
        let col = (0, _element.isHTMLTableCellElement)(cellElement) ? cellElement.cellIndex : 0;
        if ((0, _element.overlayContainsElement)(_overlay.CLONE_TOP_INLINE_START_CORNER, cellElement, this.wtRootElement) || (0, _element.overlayContainsElement)(_overlay.CLONE_TOP, cellElement, this.wtRootElement)) {
            if (CONTAINER.nodeName === 'THEAD') {
                row -= CONTAINER.childNodes.length;
            }
        } else if ((0, _element.overlayContainsElement)(_overlay.CLONE_BOTTOM_INLINE_START_CORNER, cellElement, this.wtRootElement) || (0, _element.overlayContainsElement)(_overlay.CLONE_BOTTOM, cellElement, this.wtRootElement)) {
            const totalRows = this.wtSettings.getSetting('totalRows');
            row = totalRows - CONTAINER.childNodes.length + row;
        } else if (CONTAINER === this.THEAD) {
            row = this.rowFilter.visibleColHeadedRowToSourceRow(row);
        } else if (this.rowFilter) {
            row = this.rowFilter.renderedToSource(row);
        }
        if ((0, _element.overlayContainsElement)(_overlay.CLONE_TOP_INLINE_START_CORNER, cellElement, this.wtRootElement) || (0, _element.overlayContainsElement)(_overlay.CLONE_INLINE_START, cellElement, this.wtRootElement) || (0, _element.overlayContainsElement)(_overlay.CLONE_BOTTOM_INLINE_START_CORNER, cellElement, this.wtRootElement)) {
            col = this.columnFilter.offsettedTH(col);
        } else if (this.columnFilter) {
            col = this.columnFilter.visibleRowHeadedColumnToSourceColumn(col);
        }
        // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
        const hookResult = this.wtSettings.getSetting('onModifyGetCoordsElement', row, col);
        if (hookResult && Array.isArray(hookResult)) {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            [row, col] = hookResult;
        }
        return this.wot.createCellCoords(row, col);
    },
    /**
   * Returns the TR element for the provided visual row index.
   *
   * @param {number} row The visual row index.
   * @returns {HTMLTableRowElement}
   * @this Table
   */ getTrForRow (row) {
        return this.TBODY.childNodes[this.rowFilter.sourceToRendered(row)];
    }
};
(0, _object.defineGetter)(cellAccess, 'MIXIN_NAME', 'cellAccess', {
    writable: false,
    enumerable: false
});
