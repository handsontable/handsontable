"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BottomInlineStartCornerOverlay () {
        return _bottomInlineStartCornerOverlay.BottomInlineStartCornerOverlay;
    },
    get BottomOverlay () {
        return _bottomOverlay.BottomOverlay;
    },
    get InlineStartOverlay () {
        return _inlineStartOverlay.InlineStartOverlay;
    },
    get Overlay () {
        return _base.Overlay;
    },
    get TopInlineStartCornerOverlay () {
        return _topInlineStartCornerOverlay.TopInlineStartCornerOverlay;
    },
    get TopOverlay () {
        return _topOverlay.TopOverlay;
    }
});
const _bottomInlineStartCornerOverlay = require("./regions/bottomInlineStartCornerOverlay");
const _bottomOverlay = require("./regions/bottomOverlay");
const _inlineStartOverlay = require("./regions/inlineStartOverlay");
const _base = require("./regions/_base");
const _topInlineStartCornerOverlay = require("./regions/topInlineStartCornerOverlay");
const _topOverlay = require("./regions/topOverlay");
_export_star(require("./constants"), exports);
function _export_star(from, to) {
    Object.keys(from).forEach(function(k) {
        if (k !== "default" && !Object.prototype.hasOwnProperty.call(to, k)) {
            Object.defineProperty(to, k, {
                enumerable: true,
                get: function() {
                    return from[k];
                }
            });
        }
    });
    return from;
}
