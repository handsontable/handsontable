/**
 * @typedef {'top'|'bottom'|'inline_start'|'top_inline_start_corner'|'bottom_inline_start_corner'} CLONE_TYPES_ENUM
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CLONE_BOTTOM () {
        return CLONE_BOTTOM;
    },
    get CLONE_BOTTOM_INLINE_START_CORNER () {
        return CLONE_BOTTOM_INLINE_START_CORNER;
    },
    get CLONE_CLASS_NAMES () {
        return CLONE_CLASS_NAMES;
    },
    get CLONE_INLINE_START () {
        return CLONE_INLINE_START;
    },
    get CLONE_TOP () {
        return CLONE_TOP;
    },
    get CLONE_TOP_INLINE_START_CORNER () {
        return CLONE_TOP_INLINE_START_CORNER;
    },
    get CLONE_TYPES () {
        return CLONE_TYPES;
    }
});
const CLONE_TOP = 'top';
const CLONE_BOTTOM = 'bottom';
const CLONE_INLINE_START = 'inline_start';
const CLONE_TOP_INLINE_START_CORNER = 'top_inline_start_corner';
const CLONE_BOTTOM_INLINE_START_CORNER = 'bottom_inline_start_corner';
const CLONE_TYPES = [
    CLONE_TOP,
    CLONE_BOTTOM,
    CLONE_INLINE_START,
    CLONE_TOP_INLINE_START_CORNER,
    CLONE_BOTTOM_INLINE_START_CORNER
];
const CLONE_CLASS_NAMES = new Map([
    [
        CLONE_TOP,
        `ht_clone_${CLONE_TOP}`
    ],
    [
        CLONE_BOTTOM,
        `ht_clone_${CLONE_BOTTOM}`
    ],
    [
        CLONE_INLINE_START,
        `ht_clone_${CLONE_INLINE_START} ht_clone_left`
    ],
    [
        CLONE_TOP_INLINE_START_CORNER,
        `ht_clone_${CLONE_TOP_INLINE_START_CORNER} ht_clone_top_left_corner`
    ],
    [
        CLONE_BOTTOM_INLINE_START_CORNER,
        `ht_clone_${CLONE_BOTTOM_INLINE_START_CORNER} ht_clone_bottom_left_corner`
    ]
]);
