"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get Overlay () {
        return Overlay;
    },
    get createCloneDeps () {
        return createCloneDeps;
    },
    get createOverlayDeps () {
        return createOverlayDeps;
    }
});
const _element = require("../../../../../helpers/dom/element");
const _object = require("../../../../../helpers/object");
const _console = require("../../../../../helpers/console");
const _constants = require("../constants");
const _clone = /*#__PURE__*/ _interop_require_default(require("../../core/clone"));
const _a11y = require("../../../../../helpers/a11y");
const _errors = require("../../../../../helpers/errors");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function createOverlayDeps(ctx) {
    return {
        wot: ctx.wot,
        facadeGetter: ctx.getFacade(),
        wtSettings: ctx.wtSettings,
        rootDocument: ctx.rootDocument,
        rootWindow: ctx.rootWindow,
        geometryReader: ctx.geometryReader,
        // The master table (its DOM elements are mirrored onto the overlay at construction).
        getWtTable: ctx.getWtTable,
        // Resolved when the overlay builds its clone (see `createCloneDeps`). The clone shares the
        // master's viewport and selection manager, and takes the master's event as its Event parent.
        getWtViewport: ctx.getWtViewport,
        getWtOverlays: ctx.getWtOverlays,
        getWtEvent: ctx.getWtEvent,
        getSelectionManager: ctx.getSelectionManager
    };
}
function createCloneDeps(deps, overlay) {
    return {
        source: deps.wot,
        overlay,
        viewport: deps.getWtViewport(),
        event: deps.getWtEvent(),
        selectionManager: deps.getSelectionManager(),
        // The master's geometry reader, shared into the clone so one reader serves the master and every
        // overlay clone (see `CoreAbstract` constructor).
        geometryReader: deps.geometryReader
    };
}
var /**
   * The overlay module dependencies (holds the DOM roots and the master instance handle).
   *
   * @type {OverlayDeps}
   */ _deps = /*#__PURE__*/ new WeakMap();
class Overlay {
    /**
   * Read-only access to the dependencies, for the overlay subclasses (top/bottom/inline-start and
   * the corner overlays), which are defined outside this class and so cannot reach the private
   * `#deps`.
   *
   * @returns {OverlayDeps}
   */ get deps() {
        return _class_private_field_get(this, _deps);
    }
    /**
   * Pre-applies the overlay's header-border class before the cell render (single-pass gated
   * path). Overridden by the top, bottom, and inline-start overlays, which own an `innerBorder*`
   * toggle; a no-op on overlays that have none (e.g. the corner overlays).
   */ prepareHeaderBorders() {}
    /**
   * Checks if the overlay rendering state has changed.
   *
   * @returns {boolean}
   */ hasRenderingStateChanged() {
        return this.needFullRender !== this.shouldBeRendered();
    }
    /**
   * Updates internal state with an information about the need of full rendering of the overlay in the next draw cycles.
   *
   * If the state is changed to render the overlay, the `needFullRender` property is set to `true` which means that
   * the overlay will be fully rendered in the current draw cycle. If the state is changed to not render the overlay,
   * the `needFullRender` property is set to `false` which means that the overlay will be fully rendered in the
   * current draw cycle but it will not be rendered in the next draw cycles.
   *
   * @param {'before' | 'after'} drawPhase The phase of the rendering process.
   */ updateStateOfRendering(drawPhase) {
        if (drawPhase === 'before' && this.shouldBeRendered()) {
            this.needFullRender = true;
        } else if (drawPhase === 'after' && !this.shouldBeRendered()) {
            this.needFullRender = false;
        }
    }
    /**
   * Checks if overlay should be fully rendered.
   *
   * @returns {boolean}
   */ shouldBeRendered() {
        return true;
    }
    /**
   * Update the trimming container.
   */ updateTrimmingContainer() {
        this.trimmingContainer = (0, _element.getTrimmingContainer)(this.hider.parentNode?.parentNode ?? this.hider);
    }
    /**
   * Update the main scrollable element.
   */ updateMainScrollableElement() {
        const wtTable = _class_private_field_get(this, _deps).getWtTable();
        const { rootWindow } = _class_private_field_get(this, _deps);
        const computedOverflow = _class_private_field_get(this, _deps).geometryReader.getComputedStyle(wtTable.wtRootElement.parentNode).getPropertyValue('overflow');
        const preventOverflow = this.wtSettings.getSetting('preventOverflow');
        if (computedOverflow === 'hidden' || computedOverflow === 'clip') {
            this.mainTableScrollableElement = _class_private_field_get(this, _deps).getWtTable().holder;
        } else if (preventOverflow === 'horizontal' && this.type === _constants.CLONE_TOP || preventOverflow === 'vertical' && this.type === _constants.CLONE_INLINE_START) {
            this.mainTableScrollableElement = rootWindow;
        } else {
            this.mainTableScrollableElement = (0, _element.getScrollableElement)(wtTable.TABLE);
        }
    }
    /**
   * Calculates coordinates of the provided element, relative to the root Handsontable element.
   * NOTE: The element needs to be a child of the overlay in order for the method to work correctly.
   *
   * @param {HTMLElement} element The cell element to calculate the position for.
   * @param {number} rowIndex Visual row index.
   * @param {number} columnIndex Visual column index.
   * @returns {{top: number, start: number}|undefined}
   */ getRelativeCellPosition(element, rowIndex, columnIndex) {
        if (!this.clone || this.clone.wtTable.holder.contains(element) === false) {
            (0, _console.warn)(`The provided element is not a child of the ${this.type} overlay`);
            return;
        }
        const windowScroll = this.mainTableScrollableElement === _class_private_field_get(this, _deps).rootWindow;
        const fixedColumnStart = columnIndex < this.wtSettings.getSetting('fixedColumnsStart');
        const fixedRowTop = rowIndex < this.wtSettings.getSetting('fixedRowsTop');
        const fixedRowBottom = rowIndex >= this.wtSettings.getSetting('totalRows') - this.wtSettings.getSetting('fixedRowsBottom');
        const spreader = this.clone.wtTable.spreader;
        const { geometryReader } = _class_private_field_get(this, _deps);
        const spreaderOffset = {
            start: this.getRelativeStartPosition(spreader),
            top: geometryReader.offsetTop(spreader)
        };
        const elementOffset = {
            start: this.getRelativeStartPosition(element),
            top: geometryReader.offsetTop(element)
        };
        let offsetObject = null;
        if (windowScroll) {
            offsetObject = this.getRelativeCellPositionWithinWindow(fixedRowTop, fixedColumnStart, elementOffset, spreaderOffset);
        } else {
            offsetObject = this.getRelativeCellPositionWithinHolder(fixedRowTop, fixedRowBottom, fixedColumnStart, elementOffset, spreaderOffset);
        }
        return offsetObject;
    }
    /**
   * Get inline start value depending of direction.
   *
   * @param {HTMLElement} el Element.
   * @returns {number}
   */ getRelativeStartPosition(el) {
        const { geometryReader } = _class_private_field_get(this, _deps);
        if (!this.isRtl()) {
            return geometryReader.offsetLeft(el);
        }
        const offsetParentWidth = geometryReader.offsetWidth(geometryReader.offsetParent(el));
        return offsetParentWidth - geometryReader.offsetLeft(el) - geometryReader.offsetWidth(el);
    }
    /**
   * Calculates coordinates of the provided element, relative to the root Handsontable element within a table with window
   * as a scrollable element.
   *
   * @private
   * @param {boolean} onFixedRowTop `true` if the coordinates point to a place within the top fixed rows.
   * @param {boolean} onFixedColumn `true` if the coordinates point to a place within the fixed columns.
   * @param {number} elementOffset Offset position of the cell element.
   * @param {number} spreaderOffset Offset position of the spreader element.
   * @returns {{top: number, left: number}}
   */ getRelativeCellPositionWithinWindow(onFixedRowTop, onFixedColumn, elementOffset, spreaderOffset) {
        const { geometryReader } = _class_private_field_get(this, _deps);
        const absoluteRootElementPosition = geometryReader.getBoundingClientRect(_class_private_field_get(this, _deps).getWtTable().wtRootElement);
        // `preventOverflow` can force this overlay onto the window (see `makeClone()`) while the
        // master still scrolls its holder. `wtRootElement` does not move with that scroll, so
        // subtract the master scroll from spreader-based offsets to align with the visible cell (#10403).
        const masterScrollsHolder = _class_private_field_get(this, _deps).getWtOverlays().scrollableElement !== _class_private_field_get(this, _deps).rootWindow;
        const tableScrollPosition = {
            horizontal: masterScrollsHolder ? _class_private_field_get(this, _deps).getWtOverlays().inlineStartOverlay.getScrollPosition() : 0,
            vertical: masterScrollsHolder ? _class_private_field_get(this, _deps).getWtOverlays().topOverlay.getScrollPosition() : 0
        };
        let horizontalOffset = 0;
        let verticalOffset = 0;
        if (!onFixedColumn) {
            horizontalOffset = spreaderOffset.start - tableScrollPosition.horizontal;
        } else {
            let absoluteRootElementStartPosition = absoluteRootElementPosition.left;
            if (this.isRtl()) {
                absoluteRootElementStartPosition = _class_private_field_get(this, _deps).rootWindow.innerWidth - (absoluteRootElementPosition.left + absoluteRootElementPosition.width + geometryReader.getScrollbarWidth());
            }
            horizontalOffset = absoluteRootElementStartPosition <= 0 ? -1 * absoluteRootElementStartPosition : 0;
        }
        if (onFixedRowTop && this.clone) {
            const absoluteOverlayPosition = geometryReader.getBoundingClientRect(this.clone.wtTable.TABLE);
            verticalOffset = absoluteOverlayPosition.top - absoluteRootElementPosition.top;
        } else {
            verticalOffset = spreaderOffset.top - tableScrollPosition.vertical;
        }
        return {
            start: elementOffset.start + horizontalOffset,
            top: elementOffset.top + verticalOffset
        };
    }
    /**
   * Calculates coordinates of the provided element, relative to the root Handsontable element within a table with window
   * as a scrollable element.
   *
   * @private
   * @param {boolean} onFixedRowTop `true` if the coordinates point to a place within the top fixed rows.
   * @param {boolean} onFixedRowBottom `true` if the coordinates point to a place within the bottom fixed rows.
   * @param {boolean} onFixedColumn `true` if the coordinates point to a place within the fixed columns.
   * @param {number} elementOffset Offset position of the cell element.
   * @param {number} spreaderOffset Offset position of the spreader element.
   * @returns {{top: number, left: number}}
   */ getRelativeCellPositionWithinHolder(onFixedRowTop, onFixedRowBottom, onFixedColumn, elementOffset, spreaderOffset) {
        const tableScrollPosition = {
            horizontal: _class_private_field_get(this, _deps).getWtOverlays().inlineStartOverlay.getScrollPosition(),
            vertical: _class_private_field_get(this, _deps).getWtOverlays().topOverlay.getScrollPosition()
        };
        let horizontalOffset = 0;
        let verticalOffset = 0;
        if (!onFixedColumn) {
            horizontalOffset = tableScrollPosition.horizontal - spreaderOffset.start;
        }
        if (onFixedRowBottom && this.clone) {
            const { geometryReader } = _class_private_field_get(this, _deps);
            const absoluteRootElementPosition = geometryReader.getBoundingClientRect(_class_private_field_get(this, _deps).getWtTable().wtRootElement);
            const absoluteOverlayPosition = geometryReader.getBoundingClientRect(this.clone.wtTable.TABLE); // todo refactoring: DEMETER
            verticalOffset = absoluteOverlayPosition.top * -1 + absoluteRootElementPosition.top;
        } else if (!onFixedRowTop) {
            verticalOffset = tableScrollPosition.vertical - spreaderOffset.top;
        }
        return {
            start: elementOffset.start - horizontalOffset,
            top: elementOffset.top - verticalOffset
        };
    }
    /**
   * Make a clone of table for overlay.
   *
   * @returns {Clone}
   */ makeClone() {
        if (_constants.CLONE_TYPES.indexOf(this.type) === -1) {
            (0, _errors.throwWithCause)(`Clone type "${this.type}" is not supported.`);
        }
        const wtTable = _class_private_field_get(this, _deps).getWtTable();
        const { wtSettings } = this;
        const { rootDocument, rootWindow } = _class_private_field_get(this, _deps);
        const clone = rootDocument.createElement('div');
        const clonedTable = rootDocument.createElement('table');
        const tableParent = wtTable.wtRootElement.parentNode;
        if (!tableParent) {
            (0, _errors.throwWithCause)('The Walkontable root element has no parent node.');
        }
        clone.className = `${_constants.CLONE_CLASS_NAMES.get(this.type)} handsontable`;
        clone.setAttribute('dir', this.isRtl() ? 'rtl' : 'ltr');
        clone.style.position = 'absolute';
        clone.style.top = '0';
        clone.style.overflow = 'visible';
        if (this.isRtl()) {
            clone.style.right = '0';
        } else {
            clone.style.left = '0';
        }
        if (wtSettings.getSetting('ariaTags')) {
            (0, _element.setAttribute)(clone, [
                (0, _a11y.A11Y_PRESENTATION)()
            ]);
        }
        clonedTable.className = wtTable.TABLE.className;
        // Clone the main table's `role` attribute to the cloned table.
        const mainTableRole = wtTable.TABLE.getAttribute('role');
        if (mainTableRole) {
            clonedTable.setAttribute('role', mainTableRole);
        }
        clone.appendChild(clonedTable);
        tableParent.appendChild(clone);
        const preventOverflow = this.wtSettings.getSetting('preventOverflow');
        const computedOverflow = _class_private_field_get(this, _deps).geometryReader.getComputedStyle(tableParent).getPropertyValue('overflow');
        if (computedOverflow === 'hidden' || computedOverflow === 'clip') {
            this.mainTableScrollableElement = wtTable.holder;
        } else if (preventOverflow === 'horizontal' && this.type === _constants.CLONE_TOP || preventOverflow === 'vertical' && this.type === _constants.CLONE_INLINE_START) {
            this.mainTableScrollableElement = rootWindow;
        } else {
            this.mainTableScrollableElement = (0, _element.getScrollableElement)(wtTable.TABLE);
        }
        // Create a new instance of the Walkontable class
        return new _clone.default(clonedTable, this.wtSettings, createCloneDeps(_class_private_field_get(this, _deps), this));
    }
    /**
   * Refresh/Redraw overlay.
   *
   * @param {boolean} [fastDraw=false] When `true`, try to refresh only the positions of borders without rerendering
   *                                   the data. It will only work if Table.draw() does not force
   *                                   rendering anyway.
   */ refresh(fastDraw = false) {
        if (this.needFullRender && this.clone) {
            const cloneSource = this.clone.cloneSource;
            cloneSource.activeOverlayName = this.clone.wtTable.name;
            this.clone.draw(fastDraw);
            cloneSource.activeOverlayName = 'master';
        }
    }
    /**
   * Reset overlay styles to initial values.
   */ reset() {
        if (!this.clone) {
            return;
        }
        const holder = this.clone.wtTable.holder; // todo refactoring: DEMETER
        const hider = this.clone.wtTable.hider; // todo refactoring: DEMETER
        const holderStyle = holder.style;
        const hiderStyle = hider.style;
        const rootStyle = holder.parentNode.style;
        [
            holderStyle,
            hiderStyle,
            rootStyle
        ].forEach((style)=>{
            style.width = '';
            style.height = '';
        });
    }
    /**
   * Determine if Walkontable is running in RTL mode.
   *
   * @returns {boolean}
   */ isRtl() {
        return this.wtSettings.getSetting('rtlMode');
    }
    /**
   * Destroy overlay instance.
   */ destroy() {
        // Every clone owns its own `Event` instance, and only the master's is reached by
        // `CoreAbstract#destroy()`. Destroying it here clears the timers the clone armed - the 200 ms
        // momentum-scroll timer (registered on touch devices), plus the double-click and long-press
        // ones. Left pending, the momentum timer fires after `Core#destroy()` and calls
        // `runHooks('afterMomentumScroll')` on a destroyed instance, which throws (issue #13120).
        if (this.clone instanceof _clone.default) {
            this.clone.wtEvent.destroy();
        }
        this.clone?.eventManager.destroy(); // todo check if it is good place for that operation
    }
    /**
   * @param {OverlayDeps} deps The overlay module dependencies.
   * @param {CLONE_TYPES_ENUM} type The overlay type name (clone name).
   */ constructor(deps, type){
        _class_private_field_init(this, _deps, {
            writable: true,
            value: void 0
        });
        (0, _object.defineGetter)(this, 'wot', deps.wot, {
            writable: false
        });
        _class_private_field_set(this, _deps, deps);
        this.facadeGetter = deps.facadeGetter;
        this.wtSettings = deps.wtSettings;
        const { TABLE, hider, spreader, holder, wtRootElement } = deps.getWtTable();
        this.type = type;
        this.TABLE = TABLE;
        this.hider = hider;
        this.spreader = spreader;
        this.holder = holder;
        this.wtRootElement = wtRootElement;
        this.trimmingContainer = (0, _element.getTrimmingContainer)(this.hider.parentNode?.parentNode ?? this.hider);
        this.needFullRender = this.shouldBeRendered();
        this.clone = this.makeClone();
    }
}
