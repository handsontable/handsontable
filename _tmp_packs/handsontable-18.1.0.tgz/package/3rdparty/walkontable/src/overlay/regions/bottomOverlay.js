"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BottomOverlay", {
    enumerable: true,
    get: function() {
        return BottomOverlay;
    }
});
const _element = require("../../../../../helpers/dom/element");
const _bottomTable = /*#__PURE__*/ _interop_require_default(require("../../table/regions/bottomTable"));
const _base = require("./_base");
const _constants = require("../constants");
const _errors = require("../../../../../helpers/errors");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * Computes the bottom overlay's header-border state without mutating the DOM. Pure: reads settings
   * and the current class state only. Splitting the decision from the write lets the single-pass draw
   * resolve the `innerBorderBottom` toggle before rendering, instead of after.
   *
   * @param {number} position Header Y position if trimming container is window or scroll top if not.
   * @returns {{ innerBorderBottom: string, positionChanged: boolean }}
   */ _computeHeaderBordersState = /*#__PURE__*/ new WeakSet();
class BottomOverlay extends _base.Overlay {
    /**
   * Factory method to create a subclass of `Table` that is relevant to this overlay.
   *
   * @see Table#constructor
   * @param {...*} args Parameters that will be forwarded to the `Table` constructor.
   * @returns {BottomOverlayTable}
   */ createTable(deps) {
        return new _bottomTable.default(deps);
    }
    /**
   * Checks if overlay should be fully rendered.
   *
   * @returns {boolean}
   */ shouldBeRendered() {
        return this.wtSettings.getSetting('shouldRenderBottomOverlay');
    }
    /**
   * Updates the top overlay position.
   *
   * @returns {boolean}
   */ resetFixedPosition() {
        if (!this.needFullRender || !this.shouldBeRendered() || !this.deps.getWtTable().holder.parentNode || !this.clone) {
            // removed from DOM
            return false;
        }
        const { rootWindow } = this.deps;
        const overlayRoot = this.clone.wtTable.holder.parentNode;
        overlayRoot.style.top = '';
        let overlayPosition = 0;
        const preventOverflow = this.wtSettings.getSetting('preventOverflow');
        if (this.trimmingContainer === rootWindow && (!preventOverflow || preventOverflow !== 'vertical')) {
            overlayPosition = this.getOverlayOffset();
            // At non-integer zoom levels (e.g. 90%) the browser physically rounds each row's
            // border to the nearest physical pixel, causing the rendered TABLE to extend a
            // fractional CSS pixel past the holder's integer CSS height. Subtract this overflow
            // so the overlay sits flush against the actual table content instead of the
            // CSS-integer hider boundary.
            const { geometryReader } = this.deps;
            const masterTableRect = geometryReader.getBoundingClientRect(this.deps.getWtTable().TABLE);
            const masterHolderRect = geometryReader.getBoundingClientRect(this.deps.getWtTable().holder);
            const masterTableOverflow = Math.max(0, masterTableRect.bottom - masterHolderRect.bottom);
            overlayRoot.style.bottom = `${overlayPosition - masterTableOverflow}px`;
        } else {
            overlayPosition = this.getScrollPosition();
            this.repositionOverlay();
        }
        const positionChanged = this.adjustHeaderBordersPosition(overlayPosition);
        this.adjustElementsSize();
        return positionChanged;
    }
    /**
   * Updates the bottom overlay position.
   */ repositionOverlay() {
        if (!this.clone) {
            return;
        }
        const wtTable = this.deps.getWtTable();
        const wtViewport = this.deps.getWtViewport();
        const { rootDocument } = this.deps;
        const cloneRoot = this.clone.wtTable.holder.parentNode;
        let bottomOffset = 0;
        if (!wtViewport.hasVerticalScroll()) {
            bottomOffset += wtViewport.getWorkspaceHeight() - wtTable.getTotalHeight();
        }
        if (wtViewport.hasVerticalScroll() && wtViewport.hasHorizontalScroll()) {
            bottomOffset += this.deps.geometryReader.getScrollbarWidth(rootDocument);
        }
        cloneRoot.style.bottom = `${bottomOffset}px`;
    }
    /**
   * Sets the main overlay's vertical scroll position.
   *
   * @param {number} pos The scroll position.
   * @returns {boolean}
   */ setScrollPosition(pos) {
        const { rootWindow } = this.deps;
        const scrollableElement = this.mainTableScrollableElement;
        const scrollEl = scrollableElement;
        const getScrollPosition = ()=>{
            return scrollableElement === rootWindow ? rootWindow.scrollY : scrollEl.scrollTop;
        };
        const setScrollPosition = (newPosition)=>{
            if (scrollableElement === rootWindow) {
                rootWindow.scrollTo(rootWindow.scrollX, newPosition);
            } else {
                scrollEl.scrollTop = newPosition;
            }
        };
        const oldScrollPosition = getScrollPosition();
        let result = false;
        if (pos !== oldScrollPosition) {
            setScrollPosition(pos);
            result = oldScrollPosition !== getScrollPosition();
        }
        return result;
    }
    /**
   * Triggers onScroll hook callback.
   */ onScroll() {
        this.wtSettings.getSetting('onScrollHorizontally');
    }
    /**
   * Calculates total sum cells height. Delegates to the viewport's row-height prefix-sum cache
   * (`Viewport#sumRowHeights`), so a call costs O(1) instead of walking every row in the
   * `[from, to)` range — `scrollTo` passes ranges that start at row 0, which made keyboard
   * navigation near the bottom of a large grid re-sum the whole dataset on every keypress.
   *
   * @param {number} from Row index which calculates started from.
   * @param {number} to Row index where calculation is finished.
   * @returns {number} Height sum.
   */ sumCellSizes(from, to) {
        return this.deps.getWtViewport().sumRowHeights(from, to);
    }
    /**
   * Adjust overlay root element, children and master table element sizes (width, height).
   */ adjustElementsSize() {
        this.updateTrimmingContainer();
        if (this.needFullRender) {
            this.adjustRootElementSize();
            this.adjustRootChildrenSize();
        }
    }
    /**
   * Adjust overlay root element size (width and height).
   */ adjustRootElementSize() {
        if (!this.clone) {
            return;
        }
        const wtTable = this.deps.getWtTable();
        const wtViewport = this.deps.getWtViewport();
        const { rootDocument, rootWindow } = this.deps;
        const overlayRoot = this.clone.wtTable.holder.parentNode;
        const overlayRootStyle = overlayRoot.style;
        const preventOverflow = this.wtSettings.getSetting('preventOverflow');
        if (this.trimmingContainer !== rootWindow || preventOverflow === 'horizontal') {
            let width = wtViewport.getWorkspaceWidth();
            if (wtViewport.hasVerticalScroll()) {
                width -= this.deps.geometryReader.getScrollbarWidth(rootDocument);
            }
            width = Math.min(width, this.deps.geometryReader.scrollWidth(wtTable.wtRootElement));
            overlayRootStyle.width = `${width}px`;
        } else {
            overlayRootStyle.width = '';
        }
        this.clone.wtTable.holder.style.width = overlayRootStyle.width;
        let tableHeight = this.deps.geometryReader.outerHeight(this.clone.wtTable.TABLE);
        if (!wtTable.hasDefinedSize()) {
            tableHeight = 0;
        }
        overlayRootStyle.height = `${tableHeight}px`;
    }
    /**
   * Adjust overlay root childs size.
   */ adjustRootChildrenSize() {
        if (!this.clone) {
            return;
        }
        const { holder } = this.clone.wtTable;
        this.clone.wtTable.hider.style.width = this.hider.style.width;
        const holderParent = holder.parentNode;
        holder.style.width = holderParent.style.width;
        holder.style.height = holderParent.style.height;
    }
    /**
   * Adjust the overlay dimensions and position.
   */ applyToDOM() {
        const total = this.wtSettings.getSetting('totalRows');
        const rowsRenderCalculator = this.deps.getWtViewport().rowsRenderCalculator;
        if (typeof rowsRenderCalculator?.startPosition === 'number') {
            this.spreader.style.top = `${rowsRenderCalculator.startPosition}px`;
        } else if (total === 0 || rowsRenderCalculator === null) {
            // 0 rows, or nothing rendered yet — a `null` calculator is the drawn-but-never-rendered state
            // a skipped first draw leaves behind (see `restoreRenderedStateIfSafe` in `table/drawCycle.ts`).
            this.spreader.style.top = '0';
        } else {
            (0, _errors.throwWithCause)('Incorrect value of the rowsRenderCalculator');
        }
        this.spreader.style.bottom = '';
        if (this.needFullRender) {
            this.syncOverlayOffset();
        }
    }
    /**
   * Synchronize calculated left position to an element.
   */ syncOverlayOffset() {
        if (!this.clone) {
            return;
        }
        const styleProperty = this.isRtl() ? 'right' : 'left';
        const { spreader } = this.clone.wtTable;
        const columnsRenderCalculator = this.deps.getWtViewport().columnsRenderCalculator;
        if (typeof columnsRenderCalculator?.startPosition === 'number') {
            spreader.style[styleProperty] = `${columnsRenderCalculator.startPosition}px`;
        } else {
            spreader.style[styleProperty] = '';
        }
    }
    /**
   * Scrolls vertically to a row.
   *
   * @param {number} sourceRow Row index which you want to scroll to.
   * @param {boolean} [bottomEdge=false] If `true`, scrolls according to the bottom edge (top edge is by default).
   */ scrollTo(sourceRow, bottomEdge) {
        let newY = this.getTableParentOffset();
        const { geometryReader } = this.deps;
        const sourceInstance = this.wot.cloneSource ? this.wot.cloneSource : this.wot;
        const mainHolder = sourceInstance.wtTable.holder;
        let scrollbarCompensation = 0;
        if (bottomEdge && geometryReader.offsetHeight(mainHolder) !== geometryReader.clientHeight(mainHolder)) {
            scrollbarCompensation = geometryReader.getScrollbarWidth(this.deps.rootDocument);
        }
        if (bottomEdge) {
            newY += this.sumCellSizes(0, sourceRow + 1);
            newY -= this.deps.getWtViewport().getViewportHeight();
            // Fix 1 pixel offset when cell is selected
            newY += 1;
        } else {
            newY += this.sumCellSizes(this.wtSettings.getSetting('fixedRowsBottom'), sourceRow);
        }
        newY += scrollbarCompensation;
        return this.setScrollPosition(newY);
    }
    /**
   * Gets table parent top position.
   *
   * @returns {number}
   */ getTableParentOffset() {
        if (this.mainTableScrollableElement === this.deps.rootWindow) {
            return this.deps.getWtTable().holderOffset.top;
        }
        return 0;
    }
    /**
   * Gets the main overlay's vertical scroll position.
   *
   * @returns {number} Main table's vertical scroll position.
   */ getScrollPosition() {
        return (0, _element.getScrollTop)(this.mainTableScrollableElement, this.deps.rootWindow);
    }
    /**
   * Gets the main overlay's vertical overlay offset.
   *
   * @returns {number} Main table's vertical overlay offset.
   */ getOverlayOffset() {
        const { rootWindow } = this.deps;
        const preventOverflow = this.wtSettings.getSetting('preventOverflow');
        let overlayOffset = 0;
        if (this.trimmingContainer === rootWindow && (!preventOverflow || preventOverflow !== 'vertical') && this.clone) {
            const rootHeight = this.deps.getWtTable().getTotalHeight();
            const overlayRootHeight = this.clone.wtTable.getTotalHeight();
            const maxOffset = rootHeight - overlayRootHeight;
            const docClientHeight = this.deps.geometryReader.clientHeight(this.deps.rootDocument.documentElement);
            overlayOffset = Math.max(this.getTableParentOffset() - this.getScrollPosition() - docClientHeight + rootHeight, 0);
            if (overlayOffset > maxOffset) {
                overlayOffset = 0;
            }
        }
        return overlayOffset;
    }
    /**
   * Pre-applies the header-border class before the cell render (single-pass gated path), so the
   * post-render `resetFixedPosition` toggle is a no-op and the nested re-draw is skipped. Element mode
   * only — see `TopOverlay#prepareHeaderBorders`.
   */ prepareHeaderBorders() {
        if (!this.needFullRender || !this.shouldBeRendered() || !this.deps.getWtTable().holder.parentNode || !this.clone || this.trimmingContainer === this.deps.rootWindow) {
            return;
        }
        this.adjustHeaderBordersPosition(this.getScrollPosition());
    }
    /**
   * Adds css classes to hide the header border's header (cell-selection border hiding issue).
   *
   * @param {number} position Header Y position if trimming container is window or scroll top if not.
   * @returns {boolean}
   */ adjustHeaderBordersPosition(position) {
        const masterParent = this.deps.getWtTable().holder.parentNode;
        const state = _class_private_method_get(this, _computeHeaderBordersState, computeHeaderBordersState).call(this, position);
        if (state.innerBorderBottom === 'add') {
            (0, _element.addClass)(masterParent, 'innerBorderBottom');
        } else if (state.innerBorderBottom === 'remove') {
            (0, _element.removeClass)(masterParent, 'innerBorderBottom');
        }
        if (state.innerBorderBottom !== 'keep') {
            this.cachedFixedRowsBottom = this.wtSettings.getSetting('fixedRowsBottom');
        }
        return state.positionChanged;
    }
    /**
   */ constructor(deps){
        super(deps, _constants.CLONE_BOTTOM), _class_private_method_init(this, _computeHeaderBordersState), /**
   * Cached value which holds the previous value of the `fixedRowsBottom` option.
   * It is used as a comparison value that can be used to detect changes in that value.
   *
   * @type {number}
   */ this.cachedFixedRowsBottom = -1;
        this.cachedFixedRowsBottom = this.wtSettings.getSetting('fixedRowsBottom');
    }
}
function computeHeaderBordersState(position) {
    const { wtSettings } = this;
    const masterParent = this.deps.getWtTable().holder.parentNode;
    const fixedRowsBottom = wtSettings.getSetting('fixedRowsBottom');
    const areFixedRowsBottomChanged = this.cachedFixedRowsBottom !== fixedRowsBottom;
    const columnHeaders = wtSettings.getSetting('columnHeaders');
    let innerBorderBottom = 'keep';
    let positionChanged = false;
    if ((areFixedRowsBottomChanged || fixedRowsBottom === 0) && columnHeaders.length > 0) {
        const previousState = (0, _element.hasClass)(masterParent, 'innerBorderBottom');
        if (position || wtSettings.getSetting('totalRows') === 0) {
            innerBorderBottom = 'add';
            positionChanged = !previousState;
        } else {
            innerBorderBottom = 'remove';
            positionChanged = previousState;
        }
    }
    return {
        innerBorderBottom,
        positionChanged
    };
}
