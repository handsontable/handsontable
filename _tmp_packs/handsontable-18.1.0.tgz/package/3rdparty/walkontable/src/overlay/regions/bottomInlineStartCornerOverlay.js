"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BottomInlineStartCornerOverlay", {
    enumerable: true,
    get: function() {
        return BottomInlineStartCornerOverlay;
    }
});
const _element = require("../../../../../helpers/dom/element");
const _bottomInlineStartCornerTable = /*#__PURE__*/ _interop_require_default(require("../../table/regions/bottomInlineStartCornerTable"));
const _base = require("./_base");
const _constants = require("../constants");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
class BottomInlineStartCornerOverlay extends _base.Overlay {
    /**
   * Factory method to create a subclass of `Table` that is relevant to this overlay.
   *
   * @see Table#constructor
   * @param {...*} args Parameters that will be forwarded to the `Table` constructor.
   * @returns {BottomInlineStartCornerOverlayTable}
   */ createTable(deps) {
        return new _bottomInlineStartCornerTable.default(deps);
    }
    /**
   * Checks if overlay should be fully rendered.
   *
   * @returns {boolean}
   */ shouldBeRendered() {
        return this.wtSettings.getSetting('shouldRenderBottomOverlay') && this.wtSettings.getSetting('shouldRenderInlineStartOverlay');
    }
    /**
   * Updates the corner overlay position.
   *
   * @returns {boolean}
   */ resetFixedPosition() {
        const { wot } = this;
        this.updateTrimmingContainer();
        const { clone } = this;
        if (!wot.wtTable.holder.parentNode || !clone) {
            // removed from DOM
            return false;
        }
        const overlayRoot = clone.wtTable.holder.parentNode;
        overlayRoot.style.top = '';
        if (this.trimmingContainer === this.deps.rootWindow) {
            const inlineStartOffset = this.inlineStartOverlay.getOverlayOffset();
            const { geometryReader } = this.deps;
            const masterTableRect = geometryReader.getBoundingClientRect(this.deps.getWtTable().TABLE);
            const masterHolderRect = geometryReader.getBoundingClientRect(this.deps.getWtTable().holder);
            const masterTableOverflow = Math.max(0, masterTableRect.bottom - masterHolderRect.bottom);
            const bottom = this.bottomOverlay.getOverlayOffset() - masterTableOverflow;
            overlayRoot.style[this.isRtl() ? 'right' : 'left'] = `${inlineStartOffset}px`;
            overlayRoot.style.bottom = `${bottom}px`;
        } else {
            (0, _element.resetCssTransform)(overlayRoot);
            this.repositionOverlay();
        }
        let tableHeight = this.deps.geometryReader.outerHeight(clone.wtTable.TABLE);
        const tableWidth = this.deps.geometryReader.outerWidth(clone.wtTable.TABLE);
        if (!this.deps.getWtTable().hasDefinedSize()) {
            tableHeight = 0;
        }
        overlayRoot.style.height = `${tableHeight}px`;
        overlayRoot.style.width = `${tableWidth}px`;
        return true;
    }
    /**
   * Sets the scroll position (no-op for corner overlay).
   * @param {number} _pos The scroll position (unused).
   * @returns {boolean} Always returns false.
   */ setScrollPosition(_pos) {
        return false;
    }
    /**
   * Gets the scroll position (no-op for corner overlay).
   * @returns {number} Always returns 0.
   */ getScrollPosition() {
        return 0;
    }
    /**
   * Gets the table parent offset (no-op for corner overlay).
   * @returns {number} Always returns 0.
   */ getTableParentOffset() {
        return 0;
    }
    /**
   * Gets the overlay offset (no-op for corner overlay).
   * @returns {number} Always returns 0.
   */ getOverlayOffset() {
        return 0;
    }
    /**
   * Handles scroll events (no-op for corner overlay).
   */ onScroll() {}
    /**
   * Sums the size of cells between two indexes (no-op for corner overlay).
   * @param {number} _from The starting cell index (unused).
   * @param {number} _to The ending cell index (unused).
   * @returns {number} Always returns 0.
   */ sumCellSizes(_from, _to) {
        return 0;
    }
    /**
   * Adjusts the size of overlay elements (intentionally empty).
   */ adjustElementsSize() {}
    /**
   * Applies changes to the DOM (intentionally empty).
   */ applyToDOM() {}
    /**
   * Scrolls to a specified cell index (no-op for corner overlay).
   * @param {number} _sourceIndex The source row or column index (unused).
   * @param {boolean} _snapToEdge Whether to snap to the edge (unused).
   * @returns {boolean} Always returns false.
   */ scrollTo(_sourceIndex, _snapToEdge) {
        return false;
    }
    /**
   * Reposition the overlay.
   */ repositionOverlay() {
        if (!this.clone) {
            return;
        }
        const wtTable = this.deps.getWtTable();
        const wtViewport = this.deps.getWtViewport();
        const { rootDocument } = this.deps;
        const cloneRoot = this.clone.wtTable.holder.parentNode;
        let bottomOffset = 0;
        if (!wtViewport.hasVerticalScroll()) {
            bottomOffset += wtViewport.getWorkspaceHeight() - wtTable.getTotalHeight();
        }
        if (wtViewport.hasVerticalScroll() && wtViewport.hasHorizontalScroll()) {
            bottomOffset += this.deps.geometryReader.getScrollbarWidth(rootDocument);
        }
        cloneRoot.style.bottom = `${bottomOffset}px`;
    }
    /**
   * @param {BottomOverlay} bottomOverlay The instance of the Top overlay.
   * @param {InlineStartOverlay} inlineStartOverlay The instance of the InlineStart overlay.
   */ constructor(deps, bottomOverlay, inlineStartOverlay){
        super(deps, _constants.CLONE_BOTTOM_INLINE_START_CORNER);
        this.bottomOverlay = bottomOverlay;
        this.inlineStartOverlay = inlineStartOverlay;
    }
}
