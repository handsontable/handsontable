"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
/**
 * @class ColumnFilter
 */ class ColumnFilter {
    /**
   * @param {number} index The visual column index.
   * @returns {number}
   */ offsetted(index) {
        return index + this.offset;
    }
    /**
   * @param {number} index The visual column index.
   * @returns {number}
   */ unOffsetted(index) {
        return index - this.offset;
    }
    /**
   * @param {number} index The visual column index.
   * @returns {number}
   */ renderedToSource(index) {
        return this.offsetted(index);
    }
    /**
   * @param {number} index The visual column index.
   * @returns {number}
   */ sourceToRendered(index) {
        return this.unOffsetted(index);
    }
    /**
   * @param {number} index The visual column index.
   * @returns {number}
   */ offsettedTH(index) {
        return index - this.countTH;
    }
    /**
   * @param {number} index The visual column index.
   * @returns {number}
   */ unOffsettedTH(index) {
        return index + this.countTH;
    }
    /**
   * @param {number} index The visual column index.
   * @returns {number}
   */ visibleRowHeadedColumnToSourceColumn(index) {
        return this.renderedToSource(this.offsettedTH(index));
    }
    /**
   * @param {number} index The visual column index.
   * @returns {number}
   */ sourceColumnToVisibleRowHeadedColumn(index) {
        return this.unOffsettedTH(this.sourceToRendered(index));
    }
    /**
   * @param {number} offset The scroll horizontal offset.
   * @param {number} total The total width of the table.
   * @param {number} countTH The number of rendered row headers.
   */ constructor(offset, total, countTH){
        this.offset = offset;
        this.total = total;
        this.countTH = countTH;
    }
}
const _default = ColumnFilter;
