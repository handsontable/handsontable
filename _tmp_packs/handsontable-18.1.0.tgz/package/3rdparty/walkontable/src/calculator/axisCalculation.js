"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "calculateAxis", {
    enumerable: true,
    get: function() {
        return calculateAxis;
    }
});
function calculateAxis(context, { totalCount, zeroBasedScrollOffset, scrollEnd, positionCache, setSizeField, setTotalCalculated, getTotalCalculated }) {
    context._initialize(context);
    let startIndex = 0;
    if (zeroBasedScrollOffset > 0 && totalCount > 0) {
        const cachedIndex = positionCache.findIndexAtOffset(zeroBasedScrollOffset);
        startIndex = cachedIndex;
        setTotalCalculated(context, positionCache.getOffset(startIndex));
    }
    let lastProcessedIndex = -1;
    for(let i = startIndex; i < totalCount; i++){
        const size = positionCache.getSizeAt(i);
        setSizeField(context, size);
        context._process(i, context);
        lastProcessedIndex = i;
        setTotalCalculated(context, getTotalCalculated(context) + size);
        if (getTotalCalculated(context) >= scrollEnd) {
            context.needReverse = false;
            break;
        }
    }
    context.lastProcessedIndex = lastProcessedIndex;
    context._finalize(context);
}
