"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "FullyVisibleRowsCalculationType", {
    enumerable: true,
    get: function() {
        return FullyVisibleRowsCalculationType;
    }
});
class FullyVisibleRowsCalculationType {
    /**
   * Initializes the calculation.
   */ initialize() {}
    /**
   * Processes the row.
   *
   * @param {number} row The row index.
   * @param {ViewportRowsCalculator} viewportCalculator The viewport calculator object.
   */ process(row, viewportCalculator) {
        const { totalCalculatedHeight, zeroBasedScrollOffset, innerViewportHeight, rowHeight } = viewportCalculator;
        if (totalCalculatedHeight >= zeroBasedScrollOffset && totalCalculatedHeight + rowHeight <= innerViewportHeight) {
            if (this.startRow === null) {
                this.startRow = row;
            }
            this.endRow = row;
        }
    }
    /**
   * Finalizes the calculation.
   *
   * @param {ViewportRowsCalculator} viewportCalculator The viewport calculator object.
   */ finalize(viewportCalculator) {
        const { scrollOffset, viewportHeight, horizontalScrollbarHeight, totalRows, needReverse, positionCache, rowHeight } = viewportCalculator;
        if (!positionCache) {
            return;
        }
        // If the estimation has reached the last row and there is still some space available in the viewport,
        // we need to render in reverse in order to fill the whole viewport with rows
        if (this.endRow === totalRows - 1 && needReverse) {
            this.startRow = this.endRow;
            while(this.startRow > 0){
                const calculatedViewportHeight = positionCache.getOffset(this.endRow) + rowHeight - positionCache.getOffset(this.startRow - 1);
                if (calculatedViewportHeight <= viewportHeight - horizontalScrollbarHeight) {
                    this.startRow -= 1;
                }
                if (calculatedViewportHeight >= viewportHeight - horizontalScrollbarHeight) {
                    break;
                }
            }
        }
        this.startPosition = this.startRow !== null ? positionCache.getOffset(this.startRow) : null;
        const mostBottomScrollOffset = scrollOffset + viewportHeight - horizontalScrollbarHeight;
        const topRowOffset = this.startRow === null ? 0 : viewportCalculator.getRowHeight(this.startRow);
        if (mostBottomScrollOffset < topRowOffset || scrollOffset > positionCache.getOffset(viewportCalculator.lastProcessedIndex)) {
            this.isVisibleInTrimmingContainer = false;
        } else {
            this.isVisibleInTrimmingContainer = true;
        }
        if (this.endRow !== null && totalRows < this.endRow) {
            this.endRow = totalRows - 1;
        }
        if (this.startRow !== null && this.endRow !== null) {
            this.count = this.endRow - this.startRow + 1;
        }
    }
    constructor(){
        /**
   * Total number of fully visible rows in the viewport.
   *
   * @type {number}
   */ this.count = 0;
        /**
   * The row index of the first fully visible row in the viewport.
   *
   * @type {number|null}
   */ this.startRow = null;
        /**
   * The row index of the last fully visible row in the viewport.
   *
   * @type {number|null}
   */ this.endRow = null;
        /**
   * Position of the first fully visible row (in px).
   *
   * @type {number|null}
   */ this.startPosition = null;
        /**
   * Determines if the viewport is visible in the trimming container.
   *
   * @type {boolean}
   */ this.isVisibleInTrimmingContainer = false;
    }
}
