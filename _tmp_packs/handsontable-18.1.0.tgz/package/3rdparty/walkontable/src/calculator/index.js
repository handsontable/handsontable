"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get FullyVisibleColumnsCalculationType () {
        return _fullyVisibleColumns.FullyVisibleColumnsCalculationType;
    },
    get FullyVisibleRowsCalculationType () {
        return _fullyVisibleRows.FullyVisibleRowsCalculationType;
    },
    get PartiallyVisibleColumnsCalculationType () {
        return _partiallyVisibleColumns.PartiallyVisibleColumnsCalculationType;
    },
    get PartiallyVisibleRowsCalculationType () {
        return _partiallyVisibleRows.PartiallyVisibleRowsCalculationType;
    },
    get RenderedAllColumnsCalculationType () {
        return _renderedAllColumns.RenderedAllColumnsCalculationType;
    },
    get RenderedAllRowsCalculationType () {
        return _renderedAllRows.RenderedAllRowsCalculationType;
    },
    get RenderedColumnsCalculationType () {
        return _renderedColumns.RenderedColumnsCalculationType;
    },
    get RenderedRowsCalculationType () {
        return _renderedRows.RenderedRowsCalculationType;
    },
    get ViewportColumnsCalculator () {
        return _viewportColumns.ViewportColumnsCalculator;
    },
    get ViewportRowsCalculator () {
        return _viewportRows.ViewportRowsCalculator;
    }
});
const _fullyVisibleColumns = require("./calculationType/fullyVisibleColumns");
const _fullyVisibleRows = require("./calculationType/fullyVisibleRows");
const _partiallyVisibleColumns = require("./calculationType/partiallyVisibleColumns");
const _partiallyVisibleRows = require("./calculationType/partiallyVisibleRows");
const _renderedAllColumns = require("./calculationType/renderedAllColumns");
const _renderedAllRows = require("./calculationType/renderedAllRows");
const _renderedColumns = require("./calculationType/renderedColumns");
const _renderedRows = require("./calculationType/renderedRows");
const _viewportColumns = require("./viewportColumns");
const _viewportRows = require("./viewportRows");
