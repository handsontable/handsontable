"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get OrderView () {
        return _view.OrderView;
    },
    get SharedOrderView () {
        return _sharedView.SharedOrderView;
    }
});
const _view = require("./view");
const _sharedView = require("./sharedView");
