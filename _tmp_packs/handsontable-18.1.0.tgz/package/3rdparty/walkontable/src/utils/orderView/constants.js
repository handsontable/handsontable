/**
 * Describes that ViewSizeSet instance doesn't share sizes with another
 * instance (root node can contain only one type of children nodes).
 *
 * @type {number}
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get WORKING_SPACE_ALL () {
        return WORKING_SPACE_ALL;
    },
    get WORKING_SPACE_BOTTOM () {
        return WORKING_SPACE_BOTTOM;
    },
    get WORKING_SPACE_TOP () {
        return WORKING_SPACE_TOP;
    }
});
const WORKING_SPACE_ALL = 0;
const WORKING_SPACE_TOP = 1;
const WORKING_SPACE_BOTTOM = 2;
