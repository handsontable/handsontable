"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "getDefaults", {
    enumerable: true,
    get: function() {
        return getDefaults;
    }
});
const _element = require("../../../../helpers/dom/element");
function getDefaults(settings) {
    return {
        facade: undefined,
        table: undefined,
        // Determines whether the Walkontable instance is used as dataset viewer. When its instance is used as
        // a context menu, autocomplete list, etc, the returned value is `false`.
        isDataViewInstance: true,
        // presentation mode
        externalRowCalculator: false,
        // Escape hatch for the single-pass (predicted) layout. When `false`, the viewport's
        // scrollbar/size queries measure the rendered DOM (the legacy, multi-pass path) instead of
        // reading the predicted layout snapshot. Plugins whose rendering is incompatible with a
        // predicted single pass (e.g. `mergeCells`, whose virtualized merged-cell height depends on the
        // viewport it is trying to compute) opt out through this flag, wired in `TableView`.
        singlePassLayout: true,
        currentRowClassName: null,
        currentColumnClassName: null,
        preventOverflow () {
            return false;
        },
        preventWheel: false,
        // data source
        data: undefined,
        // Number of renderable columns for the left overlay.
        fixedColumnsStart: 0,
        // Number of renderable rows for the top overlay.
        fixedRowsTop: 0,
        // Number of renderable rows for the bottom overlay.
        fixedRowsBottom: 0,
        // Enable the inline start overlay when conditions are met (left for LTR and right for RTL document mode).
        shouldRenderInlineStartOverlay: ()=>{
            return settings.getSetting('fixedColumnsStart') > 0 || settings.getSetting('rowHeaders').length > 0;
        },
        // Enable the top overlay when conditions are met.
        shouldRenderTopOverlay: ()=>{
            return settings.getSetting('fixedRowsTop') > 0 || settings.getSetting('columnHeaders').length > 0;
        },
        // Enable the bottom overlay when conditions are met.
        shouldRenderBottomOverlay: ()=>{
            return settings.getSetting('fixedRowsBottom') > 0;
        },
        minSpareRows: 0,
        // this must be array of functions: [function (row, TH) {}]
        rowHeaders () {
            return [];
        },
        // this must be array of functions: [function (column, TH) {}]
        columnHeaders () {
            return [];
        },
        totalRows: undefined,
        totalColumns: undefined,
        cellRenderer: (row, column, TD)=>{
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            const cellData = settings.getSetting('data', row, column);
            (0, _element.fastInnerText)(TD, cellData === undefined || cellData === null ? '' : cellData);
        },
        // columnWidth: 50,
        columnWidth () {
        // return undefined means use default size for the rendered cell content
        },
        rowHeight () {
        // return undefined means use default size for the rendered cell content
        },
        rowHeightByOverlayName () {
        // return undefined means use default size for the rendered cell content
        },
        rowHeightsUniform () {
            // return true only when every row is guaranteed the default height (enables the
            // PositionCache arithmetic fast path). Conservative default: false.
            return false;
        },
        columnWidthsUniform () {
            // return true only when every column is guaranteed the default width.
            return false;
        },
        defaultColumnWidth: 50,
        selections: null,
        hideBorderOnMouseDownOver: false,
        viewportRowCalculatorOverride: null,
        viewportColumnCalculatorOverride: null,
        viewportRowRenderingThreshold: null,
        viewportColumnRenderingThreshold: null,
        // Whether the corresponding `viewport*RenderingOffset` grid option is in its 'auto' (dynamic
        // overscan) mode. An explicit numeric offset is an exact user choice — the directional
        // scroll-overscan then stays off (see `viewport/calculatorFactory.ts`). Engine-level default is
        // `true`: a raw Walkontable consumer with no offset override gets the overscan.
        viewportRowRenderingOffsetIsAuto: true,
        viewportColumnRenderingOffsetIsAuto: true,
        // callbacks
        onCellMouseDown: null,
        onCellContextMenu: null,
        onCellMouseOver: null,
        onCellMouseOverOutside: null,
        onCellMouseOut: null,
        onCellMouseUp: null,
        // onCellMouseOut: null,
        onCellDblClick: null,
        onCellCornerMouseDown: null,
        onCellCornerDblClick: null,
        onSelectionHandleMouseDown: null,
        onSelectionEdgeMouseDown: null,
        beforeDraw: null,
        onDraw: null,
        onBeforeRemoveCellClassNames: null,
        onAfterDrawSelection: null,
        onBeforeDrawBorders: null,
        // viewport scroll hooks
        onBeforeViewportScrollHorizontally: (column)=>column,
        onBeforeViewportScrollVertically: (row)=>row,
        // native scroll hooks
        onScrollHorizontally: null,
        onScrollVertically: null,
        //
        onBeforeTouchScroll: null,
        onAfterMomentumScroll: null,
        onModifyRowHeaderWidth: null,
        onModifyGetCellCoords: null,
        onModifyGetCoordsElement: null,
        onModifyGetCoords: null,
        onBeforeHighlightingRowHeader: (sourceRow)=>sourceRow,
        onBeforeHighlightingColumnHeader: (sourceCol)=>sourceCol,
        onWindowResize: null,
        onContainerElementResize: null,
        renderAllColumns: false,
        renderAllRows: false,
        groups: false,
        rowHeaderWidth: null,
        columnHeaderHeight: null,
        headerClassName: null,
        rtlMode: false,
        ariaTags: true,
        stylesHandler: null
    };
}
