/**
 * Barrel for the settings slice. Keeps every `'./settings'` / `'../settings'` import resolving to the
 * `Settings` class after the file was split into the accessor engine (`accessor.ts`) and the defaults
 * data (`defaults.ts`).
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _accessor.default;
    }
});
const _accessor = /*#__PURE__*/ _interop_require_default(require("./accessor"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
