"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return Settings;
    }
});
const _object = require("../../../../helpers/object");
const _errors = require("../../../../helpers/errors");
const _defaults = require("./defaults");
class Settings {
    /**
   * Update settings.
   *
   * @param {object|string} settings The singular settings to update or if passed as object to merge with.
   * @param {*} value The value to set if the first argument is passed as string.
   * @returns {Settings}
   */ update(settings, value) {
        if (value === undefined) {
            (0, _object.objectEach)(settings, (settingValue, key)=>{
                this.settings[key] = settingValue;
            });
        } else {
            this.settings[settings] = value;
        }
        return this;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    getSetting(key, param1, param2, param3, param4) {
        if (typeof this.settings[key] === 'function') {
            return this.settings[key](param1, param2, param3, param4);
        } else if (param1 !== undefined && Array.isArray(this.settings[key])) {
            return this.settings[key][param1];
        }
        return this.settings[key];
    }
    // eslint-disable-next-line jsdoc/require-jsdoc -- TypeScript overload implementation; documented in the overload signature above
    getSettingPure(key) {
        return this.settings[key];
    }
    /**
   * Checks if setting exists.
   *
   * @param {boolean} key The settings key to check.
   * @returns {boolean}
   */ has(key) {
        return !!this.settings[key];
    }
    /**
   * @param {object} settings The user defined settings.
   */ constructor(settings){
        /**
   * Reference to settings.
   *
   * @protected
   * @type {object}
   */ this.settings = {};
        /**
   * The defaults values of settings.
   * Void 0 means it is required, null means it can be empty.
   *
   * @public
   * @type {Readonly<object>}
   */ this.defaults = Object.freeze((0, _defaults.getDefaults)(this));
        (0, _object.objectEach)(this.defaults, (value, key)=>{
            if (settings[key] !== undefined) {
                this.settings[key] = settings[key];
            } else if (value === undefined) {
                (0, _errors.throwWithCause)(`A required setting "${key}" was not provided`);
            } else {
                this.settings[key] = value;
            }
        });
    }
}
