/**
 * Selection type that is visible only if the row or column header is clicked. If that happened
 * all row or column header layers are highlighted.
 *
 * @type {string}
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get ACTIVE_HEADER_TYPE () {
        return ACTIVE_HEADER_TYPE;
    },
    get AREA_TYPE () {
        return AREA_TYPE;
    },
    get COLUMN_TYPE () {
        return COLUMN_TYPE;
    },
    get CUSTOM_SELECTION_TYPE () {
        return CUSTOM_SELECTION_TYPE;
    },
    get FILL_TYPE () {
        return FILL_TYPE;
    },
    get FOCUS_TYPE () {
        return FOCUS_TYPE;
    },
    get HEADER_TYPE () {
        return HEADER_TYPE;
    },
    get ROW_TYPE () {
        return ROW_TYPE;
    }
});
const ACTIVE_HEADER_TYPE = 'active-header';
const HEADER_TYPE = 'header';
const AREA_TYPE = 'area';
const FOCUS_TYPE = 'focus';
const FILL_TYPE = 'fill';
const ROW_TYPE = 'row';
const COLUMN_TYPE = 'column';
const CUSTOM_SELECTION_TYPE = 'custom-selection';
