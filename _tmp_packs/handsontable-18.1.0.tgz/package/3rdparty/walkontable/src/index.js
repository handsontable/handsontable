"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CellCoords () {
        return _coords.default;
    },
    get CellRange () {
        return _range.default;
    },
    get Core () {
        return _core.default;
    },
    get DEFAULT_COLUMN_WIDTH () {
        return _constants.DEFAULT_COLUMN_WIDTH;
    },
    get HIGHLIGHT_ACTIVE_HEADER_TYPE () {
        return _selection.ACTIVE_HEADER_TYPE;
    },
    get HIGHLIGHT_AREA_TYPE () {
        return _selection.AREA_TYPE;
    },
    get HIGHLIGHT_COLUMN_TYPE () {
        return _selection.COLUMN_TYPE;
    },
    get HIGHLIGHT_CUSTOM_SELECTION_TYPE () {
        return _selection.CUSTOM_SELECTION_TYPE;
    },
    get HIGHLIGHT_FILL_TYPE () {
        return _selection.FILL_TYPE;
    },
    get HIGHLIGHT_FOCUS_TYPE () {
        return _selection.FOCUS_TYPE;
    },
    get HIGHLIGHT_HEADER_TYPE () {
        return _selection.HEADER_TYPE;
    },
    get HIGHLIGHT_ROW_TYPE () {
        return _selection.ROW_TYPE;
    },
    get NodesPool () {
        return _nodesPool.NodesPool;
    },
    get OrderView () {
        return _orderView.OrderView;
    },
    get Renderer () {
        return _render;
    },
    get Selection () {
        return _selection.Selection;
    },
    get SharedOrderView () {
        return _orderView.SharedOrderView;
    },
    get ViewportColumnsCalculator () {
        return _calculator.ViewportColumnsCalculator;
    },
    get ViewportRowsCalculator () {
        return _calculator.ViewportRowsCalculator;
    },
    get default () {
        return _core.default;
    },
    get getListenersCounter () {
        return _eventManager.getListenersCounter;
    }
});
const _calculator = require("./calculator");
const _constants = require("./constants");
const _coords = /*#__PURE__*/ _interop_require_default(require("./cell/coords"));
const _range = /*#__PURE__*/ _interop_require_default(require("./cell/range"));
const _core = /*#__PURE__*/ _interop_require_default(require("./facade/core"));
const _selection = require("./selection");
const _render = /*#__PURE__*/ _interop_require_wildcard(require("./render"));
const _nodesPool = require("./utils/nodesPool");
const _orderView = require("./utils/orderView");
const _eventManager = require("../../../eventManager");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
