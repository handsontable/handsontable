"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get parse () {
        return _SheetClip.parse;
    },
    get stringify () {
        return _SheetClip.stringify;
    }
});
const _SheetClip = require("./SheetClip");
