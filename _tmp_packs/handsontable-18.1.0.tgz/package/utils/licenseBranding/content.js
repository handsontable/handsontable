"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get LICENSE_KEY_DOCS_URL () {
        return LICENSE_KEY_DOCS_URL;
    },
    get LOCK_CONTENT () {
        return LOCK_CONTENT;
    },
    get POPOVER_CONTENT () {
        return POPOVER_CONTENT;
    },
    get SALES_MAILTO () {
        return SALES_MAILTO;
    },
    get SUPPORT_MAILTO () {
        return SUPPORT_MAILTO;
    }
});
const _mixed = require("../../helpers/mixed");
const SALES_MAILTO = 'mailto:sales@handsontable.com';
const SUPPORT_MAILTO = 'mailto:support@handsontable.com';
const LICENSE_KEY_DOCS_URL = 'https://handsontable.com/docs/tutorial-license-key.html';
const POPOVER_CONTENT = {
    trial_valid: {
        title: 'Handsontable Trial',
        body: ({ daysRemaining })=>`Your Handsontable license key ${(0, _mixed._formatExpiryClause)(daysRemaining)}. ${_mixed._PURCHASE_LICENSE_TEXT}`,
        linkText: 'Contact Sales',
        linkHref: SALES_MAILTO,
        dismissible: false
    },
    trial_notice: {
        title: 'Handsontable Trial',
        body: ({ daysRemaining })=>`Your Handsontable license key ${(0, _mixed._formatExpiryClause)(daysRemaining)}. ${_mixed._PURCHASE_LICENSE_TEXT}`,
        linkText: 'Contact Sales',
        linkHref: SALES_MAILTO,
        dismissible: false
    },
    trial_soft_stop: {
        title: 'Handsontable Trial Expired',
        body: ()=>`${_mixed._LICENSE_EXPIRED_TITLE} ${_mixed._PURCHASE_LICENSE_TEXT}`,
        linkText: 'Contact Sales',
        linkHref: SALES_MAILTO,
        dismissible: true
    }
};
const LOCK_CONTENT = {
    trial_hard_stop: ({ licensedUntil })=>({
            title: `Your Handsontable trial license key expired on ${licensedUntil}.`,
            description: 'You may no longer use Handsontable under the trial license. To continue using ' + 'the software, contact sales@handsontable.com to purchase a valid license.',
            action: {
                text: 'Contact Sales',
                href: SALES_MAILTO
            }
        }),
    // A key that cannot be read and no key at all both block the grid, with the sentences their
    // bottom bar used to carry. Both are installation faults, so both point at support rather than
    // sales, and both keep the documentation link the bar had.
    invalid: ()=>({
            title: 'The license key for Handsontable is invalid.',
            description: '',
            action: {
                text: 'Contact Support',
                href: SUPPORT_MAILTO
            },
            docsLink: {
                text: 'Read more',
                href: LICENSE_KEY_DOCS_URL,
                trailingText: ' on how to install it properly, or contact us at support@handsontable.com.'
            }
        }),
    missing: ()=>({
            title: 'The license key for Handsontable is missing.',
            description: 'Use your purchased key to activate the product. Alternatively, you can activate ' + 'Handsontable to use for non-commercial purposes by passing the key: ' + '\'non-commercial-and-evaluation\'. ',
            action: {
                text: 'Contact Support',
                href: SUPPORT_MAILTO
            },
            docsLink: {
                text: 'Read more',
                href: LICENSE_KEY_DOCS_URL,
                trailingText: ' about it in the documentation, or contact us at support@handsontable.com.'
            }
        })
};
