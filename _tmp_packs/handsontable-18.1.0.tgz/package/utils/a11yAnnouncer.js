"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get announce () {
        return announce;
    },
    get install () {
        return install;
    },
    get uninstall () {
        return uninstall;
    }
});
/**
 * The module provides functionality to announce custom messages to assistive technologies.
 */ let announcerElement = null;
let installCounter = 0;
function install(rootPortalElement) {
    const document = rootPortalElement.ownerDocument;
    if (!announcerElement) {
        announcerElement = document.createElement('div');
        announcerElement.setAttribute('role', 'status');
        announcerElement.setAttribute('aria-live', 'assertive');
        announcerElement.setAttribute('aria-atomic', 'true');
        const style = announcerElement.style;
        style.position = 'absolute';
        style.width = '1px';
        style.height = '1px';
        style.margin = '-1px';
        style.overflow = 'hidden';
        style.clipPath = 'rect(0 0 0 0)';
        style.whiteSpace = 'nowrap';
        rootPortalElement.appendChild(announcerElement);
    }
    installCounter += 1;
}
function uninstall() {
    if (installCounter === 0) {
        return;
    }
    if (installCounter === 1) {
        announcerElement.remove();
        announcerElement = null;
    }
    installCounter -= 1;
}
function announce(message) {
    if (!announcerElement) {
        return;
    }
    // The value needs to be cleared first to ensure that screen readers announce the new message.
    announcerElement.textContent = '';
    setTimeout(()=>{
        if (announcerElement) {
            announcerElement.textContent = message;
        }
    }, 100);
}
