/**
 * The length of the checksum (SHA-512 as hex) that closes the machine-readable
 * block of every entitlement license key.
 *
 * @type {number}
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CHECKSUM_LENGTH () {
        return CHECKSUM_LENGTH;
    },
    get DATE_FIELDS () {
        return DATE_FIELDS;
    },
    get HANDSONTABLE_PRODUCT () {
        return HANDSONTABLE_PRODUCT;
    },
    get KNOWN_CAPABILITIES () {
        return KNOWN_CAPABILITIES;
    },
    get MILLISECONDS_PER_DAY () {
        return MILLISECONDS_PER_DAY;
    },
    get NO_CONSOLE_WARNS_FLAG () {
        return NO_CONSOLE_WARNS_FLAG;
    },
    get NO_UI_WARNS_FLAG () {
        return NO_UI_WARNS_FLAG;
    },
    get TRIAL_FLAG () {
        return TRIAL_FLAG;
    }
});
const CHECKSUM_LENGTH = 128;
const DATE_FIELDS = [
    'usage_until',
    'release_until'
];
const HANDSONTABLE_PRODUCT = 'handsontable';
const KNOWN_CAPABILITIES = [
    'core'
];
const TRIAL_FLAG = 'trial';
const NO_CONSOLE_WARNS_FLAG = 'no-console-warns';
const NO_UI_WARNS_FLAG = 'no-ui-warns';
const MILLISECONDS_PER_DAY = 86400000;
