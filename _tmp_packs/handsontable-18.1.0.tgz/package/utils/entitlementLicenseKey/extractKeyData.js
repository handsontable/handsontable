"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get defineOwn () {
        return defineOwn;
    },
    get extractEntitlementKeyData () {
        return extractEntitlementKeyData;
    },
    get getProductEntitlement () {
        return getProductEntitlement;
    }
});
const _constants = require("./constants");
const _sha512 = require("./sha512");
const _encoding = require("./encoding");
/**
 * The alphabet of the encoded payload - URL-safe base64 without padding. The
 * checksum (lowercase hex) is a subset of it, which is what lets the two be
 * split by a fixed length from the right.
 *
 * @type {RegExp}
 */ const ENCODED_PAYLOAD = /^[A-Za-z0-9\-_]+$/;
const CHECKSUM = /^[0-9a-f]+$/;
/**
 * Reports own-property presence without trusting a payload's inherited or
 * overridden `hasOwnProperty`.
 *
 * @param {object} object The object to inspect.
 * @param {string} key The property name to look up.
 * @returns {boolean}
 */ function hasOwn(object, key) {
    return Object.prototype.hasOwnProperty.call(object, key);
}
/**
 * Narrows an unknown value to a plain (non-null, non-array) object.
 *
 * @param {*} value The value to check.
 * @returns {boolean}
 */ function isPlainObject(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
/**
 * Returns `true` when the value is a non-negative integer. `Number.isFinite`
 * also rejects `Infinity` (JSON `1e999` parses to it), which would otherwise
 * turn a window size into a non-finite date downstream.
 *
 * @param {*} value The value to check.
 * @returns {boolean}
 */ function isNonNegativeInteger(value) {
    return typeof value === 'number' && Number.isFinite(value) && Math.floor(value) === value && value >= 0;
}
/**
 * Returns `true` when the value is an array of strings.
 *
 * @param {*} value The value to check.
 * @returns {boolean}
 */ function isStringArray(value) {
    return Array.isArray(value) && value.every((item)=>typeof item === 'string');
}
function defineOwn(target, key, value) {
    Object.defineProperty(target, key, {
        value,
        enumerable: true,
        writable: true,
        configurable: true
    });
}
/**
 * Verifies and normalizes one product entry.
 *
 * Strict about SHAPE: exactly one of the two dates, a real calendar date, and
 * the two window sizes. A key that gets this wrong is malformed, not merely
 * unknown, and reading it would mean guessing what was licensed.
 *
 * Lenient about VOCABULARY: an unrecognized capability token, an unrecognized
 * flag and an unrecognized extra field are all kept and ignored. Without that
 * leniency every token added on the issuing side would break every build
 * already deployed in the field.
 *
 * Returns `null` when the entry is malformed.
 *
 * @param {*} entry The product entry of the payload.
 * @returns {ProductEntitlement|null}
 */ function normalizeProductEntry(entry) {
    if (!isPlainObject(entry)) {
        return null;
    }
    if (!isStringArray(entry.capabilities)) {
        return null;
    }
    const presentDateFields = _constants.DATE_FIELDS.filter((field)=>entry[field] !== undefined);
    // Exactly one date per product. "Both" and "neither" are each a different
    // commercial shape that the format cannot express, so neither may be silently
    // resolved by whichever field the reader happens to look at first.
    if (presentDateFields.length !== 1) {
        return null;
    }
    if ((0, _encoding.parseIsoDateToTimestamp)(`${entry[presentDateFields[0]]}`) === null) {
        return null;
    }
    if (!isNonNegativeInteger(entry.notice) || !isNonNegativeInteger(entry.grace)) {
        return null;
    }
    if (entry.flags !== undefined && !isStringArray(entry.flags)) {
        return null;
    }
    // Start from everything the entry carries, so a field this version does not
    // know survives into the result instead of being silently dropped. A field
    // added to the format later is exactly the case a vendored reader has to
    // survive, and one that quietly discards it makes the field invisible to the
    // layers above.
    const normalized = {};
    Object.keys(entry).forEach((field)=>defineOwn(normalized, field, entry[field]));
    defineOwn(normalized, 'capabilities', entry.capabilities.slice());
    defineOwn(normalized, 'notice', entry.notice);
    defineOwn(normalized, 'grace', entry.grace);
    // An absent array and an empty one mean the same thing. Normalizing here
    // keeps `flags.indexOf('trial')` safe at every call site.
    defineOwn(normalized, 'flags', entry.flags === undefined ? [] : entry.flags.slice());
    defineOwn(normalized, presentDateFields[0], entry[presentDateFields[0]]);
    return normalized;
}
/**
 * Reads and verifies one key. Split out from the memoized public entry point so
 * the memo can wrap every exit path uniformly.
 *
 * @param {string} licenseKey The license key to read.
 * @returns {EntitlementKeyData|null}
 */ function readEntitlementKeyData(licenseKey) {
    // The machine-readable block closes the key. Searching backwards means a
    // bracket inside the prose cannot shadow it.
    const blockStart = licenseKey.lastIndexOf('[');
    if (blockStart === -1) {
        return null;
    }
    const blockEnd = licenseKey.indexOf(']', blockStart);
    if (blockEnd === -1) {
        return null;
    }
    const content = licenseKey.slice(blockStart + 1, blockEnd);
    if (content.length <= _constants.CHECKSUM_LENGTH) {
        return null;
    }
    const encodedPayload = content.slice(0, -_constants.CHECKSUM_LENGTH);
    const checksum = content.slice(-_constants.CHECKSUM_LENGTH);
    if (!ENCODED_PAYLOAD.test(encodedPayload) || !CHECKSUM.test(checksum)) {
        return null;
    }
    if ((0, _sha512.sha512)((0, _encoding.stringToUtf8Bytes)(encodedPayload)) !== checksum) {
        return null;
    }
    const payloadJson = (0, _encoding.base64ToString)(encodedPayload);
    if (payloadJson === null) {
        return null;
    }
    let payload;
    try {
        payload = JSON.parse(payloadJson);
    } catch (error) {
        return null;
    }
    if (!isPlainObject(payload) || !isPlainObject(payload.products)) {
        return null;
    }
    const products = {};
    const entries = payload.products;
    let malformed = false;
    Object.keys(entries).forEach((name)=>{
        const entry = normalizeProductEntry(entries[name]);
        if (entry === null) {
            malformed = true;
            return;
        }
        defineOwn(products, name, entry);
    });
    if (malformed) {
        return null;
    }
    return {
        products
    };
}
// The license key is read twice per grid init - the bottom bar
// (`initLicenseNotification`) and the branding UI (`initLicenseBranding`) each resolve the license
// state - and reading runs the full SHA-512 + base64 + JSON parse. A one-entry memo on the key makes
// the second read free. The returned data is treated as read-only by every caller, so sharing one
// object is safe.
let memoizedKey = null;
let memoizedData = null;
function extractEntitlementKeyData(licenseKey) {
    const key = `${licenseKey}`;
    if (key !== memoizedKey) {
        memoizedKey = key;
        memoizedData = readEntitlementKeyData(key);
    }
    return memoizedData;
}
function getProductEntitlement(keyData, productName) {
    if (!hasOwn(keyData.products, productName)) {
        return null;
    }
    const product = keyData.products[productName];
    return isPlainObject(product) ? product : null;
}
