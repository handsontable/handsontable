"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get UNRESTRICTED_GRANTS () {
        return UNRESTRICTED_GRANTS;
    },
    get getLicenseGrants () {
        return getLicenseGrants;
    },
    get getProductCapabilities () {
        return getProductCapabilities;
    },
    get hasCapability () {
        return hasCapability;
    },
    get hasProductGrant () {
        return hasProductGrant;
    }
});
const _extractKeyData = require("./extractKeyData");
const UNRESTRICTED_GRANTS = Object.freeze({
    unrestricted: true,
    products: Object.freeze({})
});
function getLicenseGrants(keyData) {
    const products = {};
    Object.keys(keyData.products).forEach((productName)=>{
        const entitlement = (0, _extractKeyData.getProductEntitlement)(keyData, productName);
        if (entitlement !== null) {
            // Defined, not assigned: the product name comes from the key's JSON, and a plain assignment
            // of "__proto__" would hit the `Object.prototype` setter - replacing the prototype of
            // `products` instead of adding the grant, which then reads back as not granted.
            (0, _extractKeyData.defineOwn)(products, productName, {
                capabilities: entitlement.capabilities.slice()
            });
        }
    });
    return {
        unrestricted: false,
        products
    };
}
function hasProductGrant(grants, productName) {
    return grants.unrestricted || Object.prototype.hasOwnProperty.call(grants.products, productName);
}
function getProductCapabilities(grants, productName) {
    if (grants.unrestricted || !hasProductGrant(grants, productName)) {
        return null;
    }
    // A copy: the descriptor is built once per init, so handing out the live array would let a
    // consumer that sorts or pushes into it rewrite the page's resolved grants. Every other boundary
    // in this module copies for the same reason.
    return grants.products[productName].capabilities.slice();
}
function hasCapability(grants, productName, capability) {
    if (grants.unrestricted) {
        return true;
    }
    return hasProductGrant(grants, productName) && grants.products[productName].capabilities.indexOf(capability) !== -1;
}
