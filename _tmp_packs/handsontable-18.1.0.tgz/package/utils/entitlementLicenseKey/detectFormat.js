"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get detectLicenseKeyFormat () {
        return detectLicenseKeyFormat;
    },
    get isEntitlementKey () {
        return isEntitlementKey;
    }
});
/**
 * The literal keys that stand for a license rather than encode one.
 *
 * Only formats Handsontable itself honors belong here. `gpl-v3` is deliberately absent: the
 * specification lists it among the unchanged legacy keys, but that list covers HyperFormula too and
 * nothing in this library has ever recognized it - the frozen validator rejects it like any other
 * unknown string. Naming it here advertised support that does not exist, and since an unreadable key
 * now blocks the grid, a reader who trusted the table would ship a blocked grid.
 *
 * @type {Record<string, LicenseKeyFormat>}
 */ const LITERAL_KEYS = {
    'non-commercial-and-evaluation': 'non-commercial-and-evaluation'
};
/**
 * The classic 25-character key, once its dashes are stripped.
 *
 * @type {RegExp}
 */ const LEGACY_KEY = /^[0-9a-fA-F]{25}$/;
function detectLicenseKeyFormat(licenseKey) {
    if (typeof licenseKey !== 'string') {
        return 'unknown';
    }
    const key = licenseKey.trim();
    const literalKey = key.toLowerCase();
    if (Object.prototype.hasOwnProperty.call(LITERAL_KEYS, literalKey)) {
        return LITERAL_KEYS[literalKey];
    }
    // The bracketed block closes an entitlement key. Its presence is what
    // separates the new format from everything else, so it is checked before the
    // shape-based ones.
    const blockStart = key.lastIndexOf('[');
    if (blockStart !== -1 && key.indexOf(']', blockStart) !== -1) {
        return 'entitlement';
    }
    if (LEGACY_KEY.test(key.replace(/-/g, ''))) {
        return 'legacy';
    }
    return 'unknown';
}
function isEntitlementKey(licenseKey) {
    return detectLicenseKeyFormat(licenseKey) === 'entitlement';
}
