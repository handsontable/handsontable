"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get classifyEntitlement () {
        return classifyEntitlement;
    },
    get resolveChannels () {
        return resolveChannels;
    }
});
const _encoding = require("./encoding");
const _constants = require("./constants");
/**
 * The UTC midnight of the day an instant falls on. Every window boundary is a
 * UTC midnight, so both sides of every comparison are snapped to one - the
 * local calendar, the locale and DST are inputs the classification must not
 * read at all.
 *
 * @param {number} timestamp The instant, in epoch milliseconds.
 * @returns {number}
 */ function utcMidnightOf(timestamp) {
    return Math.floor(timestamp / _constants.MILLISECONDS_PER_DAY) * _constants.MILLISECONDS_PER_DAY;
}
/**
 * Whole UTC days from today until the last licensed day. `0` on the last
 * licensed day (which is still licensed in full) and negative once it has
 * passed. Both sides are UTC midnights, so the count is a whole number of
 * calendar days and never a rounded fraction.
 *
 * @param {number} expiryTimestamp The UTC midnight of the last licensed day.
 * @param {number} now The current instant, in epoch milliseconds.
 * @returns {number}
 */ function daysUntil(expiryTimestamp, now) {
    return (expiryTimestamp - utcMidnightOf(now)) / _constants.MILLISECONDS_PER_DAY;
}
/**
 * Places a `usage_until` license in its window.
 *
 * The named day is licensed in full: the license runs until the UTC midnight
 * that FOLLOWS it, and the grace period is measured from there. A `notice` of
 * `0` means no advance warning at all, so the notice window is empty rather
 * than one day long.
 *
 * @param {number} expiryTimestamp The UTC midnight of the last licensed day.
 * @param {ProductEntitlement} entitlement The product entry the windows come from.
 * @param {number} now The current instant, in epoch milliseconds.
 * @returns {UsageWindow}
 */ function resolveUsageWindow(expiryTimestamp, entitlement, now) {
    const expiryBoundary = expiryTimestamp + _constants.MILLISECONDS_PER_DAY;
    if (now >= expiryBoundary) {
        return now < expiryBoundary + entitlement.grace * _constants.MILLISECONDS_PER_DAY ? 'soft_stop' : 'hard_stop';
    }
    const daysRemaining = daysUntil(expiryTimestamp, now);
    return entitlement.notice > 0 && daysRemaining <= entitlement.notice ? 'notice' : 'valid';
}
function classifyEntitlement(entitlement, time) {
    const isTrial = entitlement.flags.indexOf(_constants.TRIAL_FLAG) !== -1;
    if (entitlement.release_until !== undefined) {
        const releaseUntil = entitlement.release_until;
        // Fail OPEN when the build release date is unavailable (a bundler consuming the source without
        // the build-time define step, a broken build): a paying customer must never be told their
        // license lapsed because of a build defect. The legacy path stays valid in the same
        // environment.
        const covered = releaseUntil >= time.buildDate || (0, _encoding.parseIsoDateToTimestamp)(time.buildDate) === null;
        return {
            state: covered ? 'release_valid' : 'release_expired',
            isTrial,
            daysRemaining: null,
            licensedUntil: releaseUntil
        };
    }
    const usageUntil = `${entitlement.usage_until}`;
    // Verified at read time, so the date always parses here; the fallback only keeps the arithmetic
    // finite if this is ever called with an unverified entry.
    const expiryTimestamp = (0, _encoding.parseIsoDateToTimestamp)(usageUntil) ?? utcMidnightOf(time.now);
    const window = resolveUsageWindow(expiryTimestamp, entitlement, time.now);
    return {
        state: `${isTrial ? 'trial' : 'usage'}_${window}`,
        isTrial,
        daysRemaining: daysUntil(expiryTimestamp, time.now),
        licensedUntil: usageUntil
    };
}
function resolveChannels(entitlement) {
    return {
        console: entitlement.flags.indexOf(_constants.NO_CONSOLE_WARNS_FLAG) === -1,
        ui: entitlement.flags.indexOf(_constants.NO_UI_WARNS_FLAG) === -1
    };
}
