"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get HANDSONTABLE_PRODUCT () {
        return _constants.HANDSONTABLE_PRODUCT;
    },
    get UNRESTRICTED_GRANTS () {
        return _grants.UNRESTRICTED_GRANTS;
    },
    get classifyEntitlement () {
        return _classify.classifyEntitlement;
    },
    get detectLicenseKeyFormat () {
        return _detectFormat.detectLicenseKeyFormat;
    },
    get extractEntitlementKeyData () {
        return _extractKeyData.extractEntitlementKeyData;
    },
    get getLicenseGrants () {
        return _grants.getLicenseGrants;
    },
    get getProductCapabilities () {
        return _grants.getProductCapabilities;
    },
    get getProductEntitlement () {
        return _extractKeyData.getProductEntitlement;
    },
    get hasCapability () {
        return _grants.hasCapability;
    },
    get hasProductGrant () {
        return _grants.hasProductGrant;
    },
    get isEntitlementKey () {
        return _detectFormat.isEntitlementKey;
    },
    get resolveChannels () {
        return _classify.resolveChannels;
    }
});
const _detectFormat = require("./detectFormat");
const _extractKeyData = require("./extractKeyData");
const _classify = require("./classify");
const _grants = require("./grants");
const _constants = require("./constants");
