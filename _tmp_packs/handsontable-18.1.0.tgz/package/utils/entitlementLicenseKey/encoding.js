"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get base64ToBytes () {
        return base64ToBytes;
    },
    get base64ToString () {
        return base64ToString;
    },
    get bytesToBase64 () {
        return bytesToBase64;
    },
    get parseIsoDateToTimestamp () {
        return parseIsoDateToTimestamp;
    },
    get stringToBase64Url () {
        return stringToBase64Url;
    },
    get stringToUtf8Bytes () {
        return stringToUtf8Bytes;
    },
    get utf8BytesToString () {
        return utf8BytesToString;
    }
});
/* eslint-disable no-bitwise */ /**
 * The base64 alphabet.
 *
 * @type {string}
 */ const BASE64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
function stringToUtf8Bytes(string) {
    const bytes = [];
    for(let i = 0; i < string.length; i += 1){
        let codePoint = string.charCodeAt(i);
        // Combine a surrogate pair into a single code point.
        if (codePoint >= 0xd800 && codePoint <= 0xdbff && i + 1 < string.length) {
            const lowSurrogate = string.charCodeAt(i + 1);
            if (lowSurrogate >= 0xdc00 && lowSurrogate <= 0xdfff) {
                codePoint = (codePoint - 0xd800) * 0x400 + (lowSurrogate - 0xdc00) + 0x10000;
                i += 1;
            }
        }
        if (codePoint < 0x80) {
            bytes.push(codePoint);
        } else if (codePoint < 0x800) {
            bytes.push(0xc0 | codePoint >> 6, 0x80 | codePoint & 0x3f);
        } else if (codePoint < 0x10000) {
            bytes.push(0xe0 | codePoint >> 12, 0x80 | codePoint >> 6 & 0x3f, 0x80 | codePoint & 0x3f);
        } else {
            bytes.push(0xf0 | codePoint >> 18, 0x80 | codePoint >> 12 & 0x3f, 0x80 | codePoint >> 6 & 0x3f, 0x80 | codePoint & 0x3f);
        }
    }
    return bytes;
}
function utf8BytesToString(bytes) {
    let string = '';
    let i = 0;
    while(i < bytes.length){
        const byte = bytes[i];
        let codePoint;
        if (byte < 0x80) {
            codePoint = byte;
            i += 1;
        } else if (byte < 0xe0) {
            codePoint = (byte & 0x1f) << 6 | bytes[i + 1] & 0x3f;
            i += 2;
        } else if (byte < 0xf0) {
            codePoint = (byte & 0x0f) << 12 | (bytes[i + 1] & 0x3f) << 6 | bytes[i + 2] & 0x3f;
            i += 3;
        } else {
            codePoint = (byte & 0x07) << 18 | (bytes[i + 1] & 0x3f) << 12 | (bytes[i + 2] & 0x3f) << 6 | bytes[i + 3] & 0x3f;
            i += 4;
        }
        if (codePoint >= 0x10000) {
            // Split the code point back into a surrogate pair.
            codePoint -= 0x10000;
            string += String.fromCharCode(0xd800 + (codePoint >> 10), 0xdc00 + (codePoint & 0x3ff));
        } else {
            string += String.fromCharCode(codePoint);
        }
    }
    return string;
}
function bytesToBase64(bytes) {
    let base64 = '';
    for(let i = 0; i < bytes.length; i += 3){
        const byte1 = bytes[i];
        const byte2 = bytes[i + 1];
        const byte3 = bytes[i + 2];
        base64 += BASE64_ALPHABET.charAt(byte1 >> 2);
        base64 += BASE64_ALPHABET.charAt((byte1 & 0x03) << 4 | (byte2 === undefined ? 0 : byte2 >> 4));
        base64 += byte2 === undefined ? '=' : BASE64_ALPHABET.charAt((byte2 & 0x0f) << 2 | (byte3 === undefined ? 0 : byte3 >> 6));
        base64 += byte3 === undefined ? '=' : BASE64_ALPHABET.charAt(byte3 & 0x3f);
    }
    return base64;
}
function base64ToBytes(base64) {
    const normalized = `${base64}`.replace(/-/g, '+').replace(/_/g, '/').replace(/=+$/, '');
    if (!/^[A-Za-z0-9+/]*$/.test(normalized) || normalized.length % 4 === 1) {
        return null;
    }
    const bytes = [];
    for(let i = 0; i < normalized.length; i += 4){
        const chunk = [
            0,
            1,
            2,
            3
        ].map((offset)=>{
            const char = normalized.charAt(i + offset);
            // `indexOf('')` would return 0, so the missing characters of the last
            // chunk have to be mapped to -1 explicitly.
            return char === '' ? -1 : BASE64_ALPHABET.indexOf(char);
        });
        bytes.push(chunk[0] << 2 | chunk[1] >> 4);
        if (chunk[2] !== -1) {
            bytes.push((chunk[1] & 0x0f) << 4 | chunk[2] >> 2);
        }
        if (chunk[3] !== -1) {
            bytes.push((chunk[2] & 0x03) << 6 | chunk[3]);
        }
    }
    return bytes;
}
function stringToBase64Url(string) {
    return bytesToBase64(stringToUtf8Bytes(string)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function base64ToString(base64) {
    const bytes = base64ToBytes(base64);
    return bytes === null ? null : utf8BytesToString(bytes);
}
function parseIsoDateToTimestamp(isoDate) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(`${isoDate}`);
    if (match === null) {
        return null;
    }
    const year = parseInt(match[1], 10);
    const month = parseInt(match[2], 10);
    const day = parseInt(match[3], 10);
    // Date.UTC maps years 0-99 to 1900-1999, which would make the round-trip
    // check below report a "not a valid calendar date" lie.
    if (year < 100) {
        return null;
    }
    const timestamp = Date.UTC(year, month - 1, day);
    const date = new Date(timestamp);
    // An impossible date (e.g. "2027-02-30") makes `Date.UTC` roll over to
    // the next month, so a round-trip comparison catches it.
    if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
        return null;
    }
    return timestamp;
}
