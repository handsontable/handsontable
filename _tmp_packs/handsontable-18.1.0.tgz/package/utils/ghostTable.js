"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _renderCell = require("../renderers/renderCell");
const _element = require("./../helpers/dom/element");
const _array = require("./../helpers/array");
const _errors = require("../helpers/errors");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var /**
   * Renders one sampled cell into the TD that will be measured, through the same `renderCell`
   * contract `TableView.cellRenderer` uses: run the cell's own renderer, run the base renderer
   * when that renderer did not chain it itself, then reset the chaining flag. Calling only the
   * cell renderer here would leave the measured TD without `cellProperties.className` and the
   * other base-renderer classes, so AutoRowSize and AutoColumnSize would measure a cell styled
   * differently from the one the user sees.
   *
   * The sampled value must be rendered verbatim — the AutoRowSize and AutoColumnSize samplers
   * already run `formatCellValue` when building samples. Formatting here again would
   * double-format: a date sample already formatted to `1/1/24` fails the ISO-only
   * `parseToLocalDate` and renders as `#bad-value#`, inflating the measured width.
   *
   * @param {HTMLTableCellElement} td The cell element that will be measured.
   * @param {number} row Visual row index.
   * @param {number} column Visual column index.
   * @param {*} value The sampled cell value, already formatted by the sampler.
   * @param {object} cellProperties The cell meta object.
   */ _renderCell1 = /*#__PURE__*/ new WeakSet();
/**
 * @class GhostTable
 */ class GhostTable {
    /**
   * Add row.
   *
   * @param {number} row Visual row index.
   * @param {Map} samples Samples Map object.
   */ addRow(row, samples) {
        if (this.columns.length) {
            (0, _errors.throwWithCause)('Doesn\'t support multi-dimensional table');
        }
        if (!this.rows.length) {
            this.container = this.createContainer(this.hot.rootElement.className);
        }
        const rowObject = {
            row
        };
        this.rows.push(rowObject);
        this.samples = samples;
        this.table = this.createTable(this.hot.table.className);
        this.table.colGroup.appendChild(this.createColGroupsCol(row));
        this.table.tr.appendChild(this.createRow(row));
        this.container.container.appendChild(this.table.fragment);
        rowObject.table = this.table.table;
    }
    /**
   * Add a row consisting of the column headers.
   *
   * @param {Map} samples A map with sampled table values.
   */ addColumnHeadersRow(samples) {
        const colHeader = this.hot.getColHeader(0);
        if (colHeader !== null && colHeader !== undefined) {
            const rowObject = {
                row: -1
            };
            this.rows.push(rowObject);
            this.container = this.createContainer(this.hot.rootElement.className);
            this.samples = samples;
            this.table = this.createTable(this.hot.table.className);
            this.table.colGroup.appendChild(this.createColGroupsCol());
            this.appendColumnHeadersRow();
            this.container.container.appendChild(this.table.fragment);
            rowObject.table = this.table.table;
        }
    }
    /**
   * Add column.
   *
   * @param {number} column Visual column index.
   * @param {Map} samples A map with sampled table values.
   */ addColumn(column, samples) {
        if (this.rows.length) {
            (0, _errors.throwWithCause)('Doesn\'t support multi-dimensional table');
        }
        if (!this.columns.length) {
            this.container = this.createContainer(this.hot.rootElement.className);
        }
        const columnObject = {
            col: column
        };
        this.columns.push(columnObject);
        this.samples = samples;
        this.table = this.createTable(this.hot.table.className);
        if (this.getSetting('useHeaders') && this.hot.getColHeader(column) !== null) {
            // Please keep in mind that the renderable column index equal to the visual columns index for the GhostTable.
            // We render all columns.
            this.hot.view.appendColHeader(column, this.table.th, undefined, -1);
        }
        this.table.tBody.appendChild(this.createCol(column));
        this.container.container.appendChild(this.table.fragment);
        columnObject.table = this.table.table;
    }
    /**
   * Get calculated heights.
   *
   * @param {Function} callback Callback which will be fired for each calculated row.
   */ getHeights(callback) {
        if (!this.injected) {
            this.injectTable();
        }
        (0, _array.arrayEach)(this.rows, (row)=>{
            // Use getBoundingClientRect() instead of offsetHeight for sub-pixel precision.
            // Math.round is used instead of Math.ceil to avoid over-rounding at non-100% browser zoom
            // levels (e.g. 90%), where fractional BCR values like 28.88 would ceil to 29 but
            // a default-height row should remain at 29, not be inflated to 30.
            // For genuinely taller rows the fractional part is typically >= 0.5, so round still
            // produces the correct ceiling.
            const { height } = row.table.getBoundingClientRect();
            callback(row.row, Math.round(height));
        });
    }
    /**
   * Get calculated widths.
   *
   * @param {Function} callback Callback which will be fired for each calculated column.
   */ getWidths(callback) {
        if (!this.injected) {
            this.injectTable();
        }
        (0, _array.arrayEach)(this.columns, (column)=>{
            // In cases when the cell's content produces the width with a decimal point, the width
            // needs to be rounded up to make sure that there will be a space for the cell's content.
            // The `.offsetWidth` always returns the rounded number (floored), so it's not suitable for this case.
            const { width } = column.table.getBoundingClientRect();
            callback(column.col, Math.ceil(width));
        });
    }
    /**
   * Set the Ghost Table settings to the provided object.
   *
   * @param {object} settings New Ghost Table Settings.
   */ setSettings(settings) {
        this.settings = settings;
    }
    /**
   * Set a single setting of the Ghost Table.
   *
   * @param {string} name Setting name.
   * @param {*} value Setting value.
   */ setSetting(name, value) {
        if (!this.settings) {
            this.settings = {
                useHeaders: true
            };
        }
        this.settings[name] = value;
    }
    /**
   * Get the Ghost Table settings.
   *
   * @returns {object|null}
   */ getSettings() {
        return this.settings;
    }
    /**
   * Get a single Ghost Table setting.
   *
   * @param {string} name The setting name to get.
   * @returns {boolean|null}
   */ getSetting(name) {
        if (this.settings) {
            return this.settings[name];
        }
        return null;
    }
    /**
   * Create colgroup col elements.
   *
   * @param {number} row Visual row index.
   * @returns {DocumentFragment}
   */ createColGroupsCol(row) {
        const fragment = this.hot.rootDocument.createDocumentFragment();
        if (this.hot.hasRowHeaders()) {
            fragment.appendChild(this.createColElement(-1, -1));
        }
        this.samples.forEach((sample)=>{
            (0, _array.arrayEach)(sample.strings, (string)=>{
                fragment.appendChild(this.createColElement(string.col, row));
            });
        });
        return fragment;
    }
    /**
   * Create table row element.
   *
   * @param {number} row Visual row index.
   * @returns {DocumentFragment} Returns created table row elements.
   */ createRow(row) {
        const rootDocument = this.hot.rootDocument;
        const fragment = rootDocument.createDocumentFragment();
        const th = rootDocument.createElement('th');
        if (this.hot.hasRowHeaders()) {
            this.hot.view.appendRowHeader(row, th);
            fragment.appendChild(th);
        }
        this.samples.forEach((sample)=>{
            (0, _array.arrayEach)(sample.strings, (string)=>{
                const column = string.col;
                const cellProperties = this.hot.getCellMetaTransient(row, column);
                const td = rootDocument.createElement('td');
                // Indicate that this element is created and supported by GhostTable. It can be useful to
                // exclude rendering performance costly logic or exclude logic which doesn't work within a hidden table.
                td.setAttribute('ghost-table', '1');
                _class_private_method_get(this, _renderCell1, renderCell).call(this, td, row, column, string.value, cellProperties);
                fragment.appendChild(td);
            });
        });
        return fragment;
    }
    /**
   * Creates DOM elements for headers and appends them to the THEAD element of the table.
   */ appendColumnHeadersRow() {
        const rootDocument = this.hot.rootDocument;
        // The headers must sit in a real `<tr>` (`table > thead > tr > th`), mirroring the grid's
        // DOM — the cell styling is scoped with child combinators (#4363), so a `<th>` appended
        // straight into `<thead>` would miss it and measure without padding/borders.
        const headersRow = rootDocument.createElement('tr');
        const columnHeaders = [];
        if (this.hot.hasRowHeaders()) {
            const th = rootDocument.createElement('th');
            columnHeaders.push([
                -1,
                th
            ]);
            headersRow.appendChild(th);
        }
        this.samples.forEach((sample)=>{
            (0, _array.arrayEach)(sample.strings, (string)=>{
                const column = string.col;
                const th = rootDocument.createElement('th');
                columnHeaders.push([
                    column,
                    th
                ]);
                headersRow.appendChild(th);
            });
        });
        // Appending DOM elements for headers
        this.table.tHead.appendChild(headersRow);
        (0, _array.arrayEach)(columnHeaders, (columnHeader)=>{
            const [column, th] = columnHeader;
            // Using source method for filling a header with value.
            this.hot.view.appendColHeader(column, th);
        });
    }
    /**
   * Create table column elements.
   *
   * @param {number} column Visual column index.
   * @returns {DocumentFragment} Returns created column table column elements.
   */ createCol(column) {
        const rootDocument = this.hot.rootDocument;
        const fragment = rootDocument.createDocumentFragment();
        this.samples.forEach((sample)=>{
            (0, _array.arrayEach)(sample.strings, (string)=>{
                const row = string.row;
                const cellProperties = this.hot.getCellMetaTransient(row, column);
                const td = rootDocument.createElement('td');
                const tr = rootDocument.createElement('tr');
                // Indicate that this element is created and supported by GhostTable. It can be useful to
                // exclude rendering performance costly logic or exclude logic which doesn't work within a hidden table.
                td.setAttribute('ghost-table', '1');
                _class_private_method_get(this, _renderCell1, renderCell).call(this, td, row, column, string.value, cellProperties);
                tr.appendChild(td);
                fragment.appendChild(tr);
            });
        });
        return fragment;
    }
    /**
   * Remove table from document and reset internal state.
   */ clean() {
        this.rows.length = 0;
        this.rows[-1] = undefined;
        this.columns.length = 0;
        if (this.samples) {
            this.samples.clear();
        }
        this.samples = null;
        this.removeTable();
    }
    /**
   * Inject generated table into document.
   *
   * @param {HTMLElement} [parent=null] The element to which the ghost table is injected.
   */ injectTable(parent = null) {
        if (!this.injected) {
            (parent || this.hot.rootElement).appendChild(this.container.fragment);
            this.injected = true;
        }
    }
    /**
   * Remove table from document.
   */ removeTable() {
        if (this.injected && this.container.container.parentNode) {
            this.container.container.parentNode.removeChild(this.container.container);
            this.container = null;
            this.injected = false;
        }
    }
    /**
   * Create col element.
   *
   * @param {number} column Visual column index.
   * @param {number} row Visual row index.
   * @returns {HTMLElement}
   */ createColElement(column, row) {
        const col = this.hot.rootDocument.createElement('col');
        let colspan = 0;
        if (row >= 0 && column >= 0) {
            colspan = Number(this.hot.getCellMetaTransient(row, column).colspan);
        }
        let width = this.hot.getColWidth(column);
        if (colspan > 1) {
            for(let nextColumn = column + 1; nextColumn < column + colspan; nextColumn++){
                width += this.hot.getColWidth(nextColumn);
            }
        }
        col.style.width = `${width}px`;
        return col;
    }
    /**
   * Create table element.
   *
   * @param {string} className The CSS classes to add.
   * @returns {object}
   */ createTable(className = '') {
        const rootDocument = this.hot.rootDocument;
        const fragment = rootDocument.createDocumentFragment();
        const table = rootDocument.createElement('table');
        const tHead = rootDocument.createElement('thead');
        const tBody = rootDocument.createElement('tbody');
        const colGroup = rootDocument.createElement('colgroup');
        const tr = rootDocument.createElement('tr');
        const th = rootDocument.createElement('th');
        if (this.isVertical()) {
            table.appendChild(colGroup);
        }
        if (this.isHorizontal()) {
            tr.appendChild(th);
            tHead.appendChild(tr);
            table.style.tableLayout = 'auto';
            table.style.width = 'auto';
        }
        table.appendChild(tHead);
        if (this.isVertical()) {
            tBody.appendChild(tr);
        }
        table.appendChild(tBody);
        (0, _element.addClass)(table, className);
        fragment.appendChild(table);
        return {
            fragment,
            table,
            tHead,
            tBody,
            colGroup,
            tr,
            th
        };
    }
    /**
   * Create container for tables.
   *
   * @param {string} className The CSS classes to add.
   * @returns {object}
   */ createContainer(className = '') {
        const rootDocument = this.hot.rootDocument;
        const fragment = rootDocument.createDocumentFragment();
        const container = rootDocument.createElement('div');
        const containerClassName = `htGhostTable htAutoSize ${className.trim()}`;
        (0, _element.addClass)(container, containerClassName);
        fragment.appendChild(container);
        return {
            fragment,
            container
        };
    }
    /**
   * Checks if table is raised vertically (checking rows).
   *
   * @returns {boolean}
   */ isVertical() {
        return !!(this.rows.length && !this.columns.length);
    }
    /**
   * Checks if table is raised horizontally (checking columns).
   *
   * @returns {boolean}
   */ isHorizontal() {
        return !!(this.columns.length && !this.rows.length);
    }
    /**
   * Initializes the ghost table utility with a reference to the Handsontable instance used for DOM context.
   */ constructor(hotInstance){
        _class_private_method_init(this, _renderCell1);
        /**
   * Handsontable instance.
   *
   * @type {Core}
   */ this.hot = null;
        /**
   * Container element where every table will be injected.
   *
   * @type {HTMLElement|null}
   */ this.container = null;
        /**
   * Flag which determine is table was injected to DOM.
   *
   * @type {boolean}
   */ this.injected = false;
        /**
   * Added rows collection.
   *
   * @type {Array}
   */ this.rows = [];
        /**
   * Added columns collection.
   *
   * @type {Array}
   */ this.columns = [];
        /**
   * Samples prepared for calculations.
   *
   * @type {Map}
   * @default {null}
   */ this.samples = null;
        /**
   * Ghost table settings.
   *
   * @type {object}
   * @default {Object}
   */ this.settings = {
            useHeaders: true
        };
        /**
   * Table element.
   *
   * @type {unknown}
   */ this.table = null;
        this.hot = hotInstance;
    }
}
function renderCell(td, row, column, value, cellProperties) {
    const rendererArgs = [
        this.hot,
        td,
        row,
        column,
        this.hot.colToProp(column),
        value,
        cellProperties
    ];
    (0, _renderCell.renderCell)(this.hot.getCellRenderer(cellProperties), rendererArgs);
}
const _default = GhostTable;
