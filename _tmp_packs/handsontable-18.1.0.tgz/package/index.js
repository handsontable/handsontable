"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CellCoords () {
        return _base.CellCoords;
    },
    get CellRange () {
        return _base.CellRange;
    },
    get IndexMapper () {
        return _translations.IndexMapper;
    },
    get default () {
        return _default;
    }
});
const _base = /*#__PURE__*/ _interop_require_wildcard(require("./base"));
const _registry = require("./registry");
const _eventManager = /*#__PURE__*/ _interop_require_wildcard(require("./eventManager"));
const _translations = require("./translations");
const _jquery = /*#__PURE__*/ _interop_require_default(require("./helpers/wrappers/jquery"));
const _ghostTable = /*#__PURE__*/ _interop_require_default(require("./utils/ghostTable"));
const _parseTable = /*#__PURE__*/ _interop_require_wildcard(require("./utils/parseTable"));
const _array = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/array"));
const _browser = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/browser"));
const _data = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/data"));
const _dateTime = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/dateTime"));
const _errors = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/errors"));
const _feature = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/feature"));
const _function = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/function"));
const _mixed = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/mixed"));
const _number = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/number"));
const _object = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/object"));
const _string = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/string"));
const _unicode = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/unicode"));
const _element = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/dom/element"));
const _event = /*#__PURE__*/ _interop_require_wildcard(require("./helpers/dom/event"));
const _registry1 = require("./editors/registry");
const _factory = require("./editors/factory");
const _registry2 = require("./renderers/registry");
const _factory1 = require("./renderers/factory");
const _registry3 = require("./validators/registry");
const _registry4 = require("./cellTypes/registry");
const _registry5 = require("./plugins/registry");
const _base1 = require("./plugins/base");
const _registry6 = require("./themes/registry");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interop_require_wildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
        return {
            default: obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {
        __proto__: null
    };
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj.default = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
(0, _registry.registerAllModules)();
(0, _jquery.default)(_base.default);
const HOT = _base.default;
// TODO: Remove this exports after rewrite tests about this module
HOT.__GhostTable = _ghostTable.default;
HOT._getListenersCounter = _eventManager.getListenersCounter; // For MemoryLeak tests
HOT._getRegisteredMapsCounter = _translations.getRegisteredMapsCounter; // For MemoryLeak tests
HOT.EventManager = _eventManager.default;
// Export all helpers to the Handsontable object
const HELPERS = [
    _array,
    _browser,
    _data,
    _dateTime,
    _errors,
    _feature,
    _function,
    _mixed,
    _number,
    _object,
    _string,
    _unicode,
    _parseTable
];
const DOM = [
    _element,
    _event
];
HOT.helper = {};
HOT.dom = {};
// Fill general helpers.
_array.arrayEach(HELPERS, (helper)=>{
    _array.arrayEach(Object.getOwnPropertyNames(helper), (key)=>{
        if (key.charAt(0) !== '_') {
            HOT.helper[key] = helper[key];
        }
    });
});
// Fill DOM helpers.
_array.arrayEach(DOM, (helper)=>{
    _array.arrayEach(Object.getOwnPropertyNames(helper), (key)=>{
        if (key.charAt(0) !== '_') {
            HOT.dom[key] = helper[key];
        }
    });
});
// Export cell types.
HOT.cellTypes = HOT.cellTypes ?? {};
_array.arrayEach((0, _registry4.getRegisteredCellTypeNames)(), (cellTypeName)=>{
    HOT.cellTypes[cellTypeName] = (0, _registry4.getCellType)(cellTypeName);
});
HOT.cellTypes.registerCellType = _registry4.registerCellType;
HOT.cellTypes.getCellType = _registry4.getCellType;
// Export all registered editors from the Handsontable.
HOT.editors = HOT.editors ?? {};
_array.arrayEach((0, _registry1.getRegisteredEditorNames)(), (editorName)=>{
    HOT.editors[`${_string.toUpperCaseFirst(editorName)}Editor`] = (0, _registry1.getEditor)(editorName);
});
HOT.editors.registerEditor = _registry1.registerEditor;
HOT.editors.getEditor = _registry1.getEditor;
HOT.editors.editorFactory = _factory.editorFactory;
// Export all registered renderers from the Handsontable.
HOT.renderers = HOT.renderers ?? {};
_array.arrayEach((0, _registry2.getRegisteredRendererNames)(), (rendererName)=>{
    const renderer = (0, _registry2.getRenderer)(rendererName);
    if (rendererName === 'base') {
        HOT.renderers.cellDecorator = renderer;
    }
    HOT.renderers[`${_string.toUpperCaseFirst(rendererName)}Renderer`] = renderer;
});
HOT.renderers.registerRenderer = _registry2.registerRenderer;
HOT.renderers.getRenderer = _registry2.getRenderer;
HOT.renderers.rendererFactory = _factory1.rendererFactory;
// Export all registered validators from the Handsontable.
HOT.validators = HOT.validators ?? {};
_array.arrayEach((0, _registry3.getRegisteredValidatorNames)(), (validatorName)=>{
    HOT.validators[`${_string.toUpperCaseFirst(validatorName)}Validator`] = (0, _registry3.getValidator)(validatorName);
});
HOT.validators.registerValidator = _registry3.registerValidator;
HOT.validators.getValidator = _registry3.getValidator;
// Export all registered plugins from the Handsontable.
// Make sure to initialize the plugin dictionary as an empty object. Otherwise, while
// transpiling the files into ES and CommonJS format, the injected CoreJS helper
// `import "core-js/modules/es.object.get-own-property-names";` won't be processed
// by the `./config/plugin/babel/add-import-extension` babel plugin. Thus, the distribution
// files will be broken. The reason is not known right now (probably it's caused by bug in
// the Babel or missing something in the plugin).
HOT.plugins = HOT.plugins ?? {};
_array.arrayEach((0, _registry5.getPluginsNames)(), (pluginName)=>{
    HOT.plugins[pluginName] = (0, _registry5.getPlugin)(pluginName);
});
HOT.plugins[`${_string.toUpperCaseFirst(_base1.BasePlugin.PLUGIN_KEY)}Plugin`] = _base1.BasePlugin;
HOT.plugins.registerPlugin = _registry5.registerPlugin;
HOT.plugins.getPlugin = _registry5.getPlugin;
// Export themes namespace.
HOT.themes = HOT.themes ?? {};
_base.default.themes.hasTheme = _registry6.hasTheme;
_base.default.themes.getTheme = _registry6.getTheme;
_base.default.themes.getThemeNames = _registry6.getThemeNames;
_base.default.themes.getThemes = _registry6.getThemes;
_base.default.themes.registerTheme = _registry6.registerTheme;
_base.default.themes.reinitTheme = _registry6.reinitTheme;
const _default = _base.default;
