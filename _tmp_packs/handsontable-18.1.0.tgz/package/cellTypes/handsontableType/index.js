"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return _handsontableType.CELL_TYPE;
    },
    get HandsontableCellType () {
        return _handsontableType.HandsontableCellType;
    }
});
const _handsontableType = require("./handsontableType");
