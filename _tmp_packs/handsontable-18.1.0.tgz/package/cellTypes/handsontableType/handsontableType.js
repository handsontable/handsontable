"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return CELL_TYPE;
    },
    get HandsontableCellType () {
        return HandsontableCellType;
    }
});
const _handsontableEditor = require("../../editors/handsontableEditor");
const _handsontableRenderer = require("../../renderers/handsontableRenderer");
const CELL_TYPE = 'handsontable';
const HandsontableCellType = {
    CELL_TYPE,
    editor: _handsontableEditor.HandsontableEditor,
    // displays small gray arrow on right side of the cell
    renderer: _handsontableRenderer.handsontableRenderer
};
