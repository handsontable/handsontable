"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return _intlDateType.CELL_TYPE;
    },
    get IntlDateCellType () {
        return _intlDateType.IntlDateCellType;
    }
});
const _intlDateType = require("./intlDateType");
