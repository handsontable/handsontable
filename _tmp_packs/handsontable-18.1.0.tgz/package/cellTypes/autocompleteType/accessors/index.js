"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get valueGetter () {
        return _valueGetter.valueGetter;
    },
    get valueSetter () {
        return _valueSetter.valueSetter;
    }
});
const _valueGetter = require("./valueGetter");
const _valueSetter = require("./valueSetter");
