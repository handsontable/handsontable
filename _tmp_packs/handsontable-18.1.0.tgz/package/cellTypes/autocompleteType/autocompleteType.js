"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AutocompleteCellType () {
        return AutocompleteCellType;
    },
    get CELL_TYPE () {
        return CELL_TYPE;
    }
});
const _autocompleteEditor = require("../../editors/autocompleteEditor");
const _autocompleteRenderer = require("../../renderers/autocompleteRenderer");
const _autocompleteValidator = require("../../validators/autocompleteValidator");
const _accessors = require("./accessors");
const CELL_TYPE = 'autocomplete';
const AutocompleteCellType = {
    CELL_TYPE,
    editor: _autocompleteEditor.AutocompleteEditor,
    renderer: _autocompleteRenderer.autocompleteRenderer,
    validator: _autocompleteValidator.autocompleteValidator,
    valueGetter: _accessors.valueGetter,
    valueSetter: _accessors.valueSetter,
    parsePastedValue: true
};
