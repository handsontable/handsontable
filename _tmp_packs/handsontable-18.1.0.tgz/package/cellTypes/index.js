"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AUTOCOMPLETE_TYPE () {
        return _autocompleteType.CELL_TYPE;
    },
    get AutocompleteCellType () {
        return _autocompleteType.AutocompleteCellType;
    },
    get CHECKBOX_TYPE () {
        return _checkboxType.CELL_TYPE;
    },
    get CheckboxCellType () {
        return _checkboxType.CheckboxCellType;
    },
    get DATE_TYPE () {
        return _dateType.CELL_TYPE;
    },
    get DROPDOWN_TYPE () {
        return _dropdownType.CELL_TYPE;
    },
    get DateCellType () {
        return _dateType.DateCellType;
    },
    get DropdownCellType () {
        return _dropdownType.DropdownCellType;
    },
    get HANDSONTABLE_TYPE () {
        return _handsontableType.CELL_TYPE;
    },
    get HandsontableCellType () {
        return _handsontableType.HandsontableCellType;
    },
    get INTL_DATETIME_TYPE () {
        return _intlDatetimeType.CELL_TYPE;
    },
    get INTL_DATE_TYPE () {
        return _intlDateType.CELL_TYPE;
    },
    get INTL_TIME_TYPE () {
        return _intlTimeType.CELL_TYPE;
    },
    get IntlDateCellType () {
        return _intlDateType.IntlDateCellType;
    },
    get IntlDatetimeCellType () {
        return _intlDatetimeType.IntlDatetimeCellType;
    },
    get IntlTimeCellType () {
        return _intlTimeType.IntlTimeCellType;
    },
    get MULTISELECT_TYPE () {
        return _multiSelectType.CELL_TYPE;
    },
    get MultiSelectCellType () {
        return _multiSelectType.MultiSelectCellType;
    },
    get NUMERIC_TYPE () {
        return _numericType.CELL_TYPE;
    },
    get NumericCellType () {
        return _numericType.NumericCellType;
    },
    get PASSWORD_TYPE () {
        return _passwordType.CELL_TYPE;
    },
    get PasswordCellType () {
        return _passwordType.PasswordCellType;
    },
    get SELECT_TYPE () {
        return _selectType.CELL_TYPE;
    },
    get SelectCellType () {
        return _selectType.SelectCellType;
    },
    get TEXT_TYPE () {
        return _textType.CELL_TYPE;
    },
    get TIME_TYPE () {
        return _timeType.CELL_TYPE;
    },
    get TextCellType () {
        return _textType.TextCellType;
    },
    get TimeCellType () {
        return _timeType.TimeCellType;
    },
    get getCellType () {
        return _registry.getCellType;
    },
    get getRegisteredCellTypeNames () {
        return _registry.getRegisteredCellTypeNames;
    },
    get getRegisteredCellTypes () {
        return _registry.getRegisteredCellTypes;
    },
    get hasCellType () {
        return _registry.hasCellType;
    },
    get registerAllCellTypes () {
        return registerAllCellTypes;
    },
    get registerCellType () {
        return _registry.registerCellType;
    }
});
const _autocompleteType = require("./autocompleteType");
const _checkboxType = require("./checkboxType");
const _dateType = require("./dateType");
const _dropdownType = require("./dropdownType");
const _handsontableType = require("./handsontableType");
const _intlDateType = require("./intlDateType");
const _intlDatetimeType = require("./intlDatetimeType");
const _intlTimeType = require("./intlTimeType");
const _multiSelectType = require("./multiSelectType");
const _numericType = require("./numericType");
const _passwordType = require("./passwordType");
const _selectType = require("./selectType");
const _textType = require("./textType");
const _timeType = require("./timeType");
const _registry = require("./registry");
function registerAllCellTypes() {
    (0, _registry.registerCellType)(_autocompleteType.AutocompleteCellType);
    (0, _registry.registerCellType)(_checkboxType.CheckboxCellType);
    (0, _registry.registerCellType)(_dateType.DateCellType);
    (0, _registry.registerCellType)(_dropdownType.DropdownCellType);
    (0, _registry.registerCellType)(_handsontableType.HandsontableCellType);
    (0, _registry.registerCellType)(_intlDateType.IntlDateCellType);
    (0, _registry.registerCellType)(_intlDatetimeType.IntlDatetimeCellType);
    (0, _registry.registerCellType)(_intlTimeType.IntlTimeCellType);
    (0, _registry.registerCellType)(_multiSelectType.MultiSelectCellType);
    (0, _registry.registerCellType)(_multiSelectType.LEGACY_CELL_TYPE, _multiSelectType.MultiSelectCellType);
    (0, _registry.registerCellType)(_numericType.NumericCellType);
    (0, _registry.registerCellType)(_passwordType.PasswordCellType);
    (0, _registry.registerCellType)(_selectType.SelectCellType);
    (0, _registry.registerCellType)(_textType.TextCellType);
    (0, _registry.registerCellType)(_timeType.TimeCellType);
}
