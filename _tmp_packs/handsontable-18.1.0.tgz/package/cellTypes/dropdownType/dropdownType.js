"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return CELL_TYPE;
    },
    get DropdownCellType () {
        return DropdownCellType;
    }
});
const _dropdownEditor = require("../../editors/dropdownEditor");
const _dropdownRenderer = require("../../renderers/dropdownRenderer");
const _dropdownValidator = require("../../validators/dropdownValidator");
const _accessors = require("./accessors");
const CELL_TYPE = 'dropdown';
const DropdownCellType = {
    CELL_TYPE,
    editor: _dropdownEditor.DropdownEditor,
    renderer: _dropdownRenderer.dropdownRenderer,
    validator: _dropdownValidator.dropdownValidator,
    filter: false,
    strict: true,
    valueGetter: _accessors.valueGetter,
    valueSetter: _accessors.valueSetter,
    parsePastedValue: true
};
