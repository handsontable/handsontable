"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return _intlTimeType.CELL_TYPE;
    },
    get IntlTimeCellType () {
        return _intlTimeType.IntlTimeCellType;
    }
});
const _intlTimeType = require("./intlTimeType");
