"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return _numericType.CELL_TYPE;
    },
    get NumericCellType () {
        return _numericType.NumericCellType;
    }
});
const _numericType = require("./numericType");
