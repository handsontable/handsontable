"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return _textType.CELL_TYPE;
    },
    get TextCellType () {
        return _textType.TextCellType;
    }
});
const _textType = require("./textType");
