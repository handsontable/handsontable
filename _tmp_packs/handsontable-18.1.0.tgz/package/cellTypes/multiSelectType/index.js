"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return _multiSelectType.CELL_TYPE;
    },
    get LEGACY_CELL_TYPE () {
        return _multiSelectType.LEGACY_CELL_TYPE;
    },
    get MultiSelectCellType () {
        return _multiSelectType.MultiSelectCellType;
    }
});
const _multiSelectType = require("./multiSelectType");
