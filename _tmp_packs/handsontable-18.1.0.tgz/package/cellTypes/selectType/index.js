"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return _selectType.CELL_TYPE;
    },
    get SelectCellType () {
        return _selectType.SelectCellType;
    }
});
const _selectType = require("./selectType");
