"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CELL_TYPE () {
        return CELL_TYPE;
    },
    get CheckboxCellType () {
        return CheckboxCellType;
    }
});
const _checkboxEditor = require("../../editors/checkboxEditor");
const _checkboxRenderer = require("../../renderers/checkboxRenderer");
const _accessors = require("./accessors");
const CELL_TYPE = 'checkbox';
const CheckboxCellType = {
    CELL_TYPE,
    editor: _checkboxEditor.CheckboxEditor,
    renderer: _checkboxRenderer.checkboxRenderer,
    valueSetter: _accessors.valueSetter
};
