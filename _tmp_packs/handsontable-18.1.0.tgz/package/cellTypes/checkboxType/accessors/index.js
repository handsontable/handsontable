"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "valueSetter", {
    enumerable: true,
    get: function() {
        return _valueSetter.valueSetter;
    }
});
const _valueSetter = require("./valueSetter");
