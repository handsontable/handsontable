"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _unicode = require("./helpers/unicode");
const _event = require("./helpers/dom/event");
const _registry = require("./editors/registry");
const _baseEditor = require("./editors/baseEditor");
const _eventManager = /*#__PURE__*/ _interop_require_default(require("./eventManager"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * Whether a close of an editor stranded on a hidden cell is already pending, either scheduled on
   * the next tick or waiting on an async validator to settle. Suppresses duplicate work when one
   * page turn emits the cache-update hook more than once.
   *
   * @type {boolean}
   */ _hiddenCellCloseArmed = /*#__PURE__*/ new WeakMap(), /**
   * Checks whether the cell at the given VISUAL coordinates is hidden by a hiding index map
   * (Pagination's page map, `hiddenRows`, `hiddenColumns`).
   *
   * `IndexMapper#isHidden()` is keyed by PHYSICAL index, so both coordinates are converted. The two
   * index spaces coincide only while no sorting, move or trimming map is active; under
   * `columnSorting` a raw visual index reads a different row's hidden flag, which would both tear
   * down an edit on a fully visible cell and miss the hidden cell this check exists for.
   *
   * @param {number} visualRow The visual row index.
   * @param {number} visualColumn The visual column index.
   * @returns {boolean}
   */ _isCellHidden = /*#__PURE__*/ new WeakSet(), /**
   * Ends an edit when a HIDING index map removes the edited cell from the DOM while the editor is
   * still open.
   *
   * Pagination turning the page, `hiddenRows` and `hiddenColumns` all register a `hiding` map,
   * which drops the cell from the render while its visual index stays valid. The editor used to
   * stay open, pinned to its original pixel position over whatever row slid into that spot, still
   * bound to its original coordinates, and to commit only on a later click - to a row the user
   * could no longer see.
   *
   * This lives in the manager rather than in an editor so that it covers every editor.
   * `SelectEditor` and `MultiSelectEditor` extend `BaseEditor` directly, as does anything built
   * through `editors/factory.ts`, so an editor-level hook reaches none of them.
   *
   * Test on `isHidden()`, NOT on whether the `TD` still resolves. A cell merely scrolled out of the
   * rendered window has no `TD` either, and closing there would silently commit an in-progress edit
   * on every scroll away. That is long-standing behavior in the other direction: the editor hides
   * itself on scroll but keeps `state` at `EDITING`, so the edit survives until the user scrolls
   * back. These hooks never fire on scroll, so that case cannot reach here at all.
   *
   * A TRIMMING map (Filters, `trimRows`) is deliberately out of scope. It collapses the visual
   * index space instead of preserving it, so the edited coordinates silently rebind to a different
   * row that is still rendered and `isHidden()` reads `false`. That defect predates this method.
   *
   * The edit is finished rather than cancelled, which for most editors means it is COMMITTED - the
   * same outcome clicking the pager already produces, since that is an outside click and therefore
   * deselects. The final say belongs to the editor: `DropdownEditor#finishEditing()` rewrites the
   * flag to a discard when the active range no longer contains the edited cell, and
   * `selection.commit()` runs before these hooks, so a dropdown can legitimately discard here.
   * Where the commit is REJECTED - a validator returned `false` under `allowInvalid: false`, which
   * re-selects the hidden cell and restores `EDITING` - the edit is reverted instead, because an
   * editor surviving on a cell the user cannot see is the bug being fixed.
   *
   * @param {BaseEditor} [pendingEditor] The editor this call is retrying for. Supplied only by the
   *                                     async-validation retry below.
   */ _closeEditorWhenCellHidden = /*#__PURE__*/ new WeakSet(), /**
   * OnAfterDocumentKeyDown callback.
   *
   * @param {KeyboardEvent} event The keyboard event object.
   */ _onAfterDocumentKeyDown = /*#__PURE__*/ new WeakSet(), /**
   * OnCellDblClick callback.
   *
   * @param {MouseEvent} event The mouse event object.
   * @param {object} coords The cell coordinates.
   */ _onCellDblClick = /*#__PURE__*/ new WeakSet();
/**
 * Manages the lifecycle of cell editors — opening, closing, and delegating keyboard events to
 * the active editor during user interaction with the grid.
 */ class EditorManager {
    /**
   * Get active editor.
   *
   * @returns {BaseEditor}
   */ getActiveEditor() {
        return this.activeEditor;
    }
    /**
   * Prepare text input to be displayed at given grid cell.
   */ prepareEditor() {
        // A new edit cycle always re-arms the hidden-cell guard. Without this the latch is
        // instance-scoped, so one editor left stuck in `WAITING` with no `postAfterValidate` (a
        // `beforeChange` that cancels the change, for instance) would disable the guard for the rest
        // of the instance's life rather than for that one edit.
        _class_private_field_set(this, _hiddenCellCloseArmed, false);
        if (this.activeEditor && this.activeEditor.isWaiting()) {
            this.closeEditor(false, false, (dataSaved)=>{
                if (dataSaved) {
                    this.prepareEditor();
                }
            });
            return;
        }
        const highlight = this.hot.getSelectedRangeActive()?.highlight;
        if (!highlight || highlight.isHeader()) {
            return;
        }
        const { row: rowNullable, col: colNullable } = highlight;
        const row = rowNullable;
        const col = colNullable;
        const modifiedCellCoords = this.hot.runHooks('modifyGetCellCoords', row, col, false, 'meta');
        let visualRowToCheck = row;
        let visualColumnToCheck = col;
        if (Array.isArray(modifiedCellCoords)) {
            [visualRowToCheck, visualColumnToCheck] = modifiedCellCoords;
        }
        // Getting values using the modified coordinates.
        this.cellProperties = this.hot.getCellMeta(visualRowToCheck, visualColumnToCheck);
        if (!this.isCellEditable()) {
            this.clearActiveEditor();
            return;
        }
        const td = this.hot.getCell(row, col, true);
        // Skip the preparation when the cell is not rendered in the DOM. The cell is scrolled out of
        // the table's viewport.
        if (td) {
            const editorClass = this.hot.getCellEditor(this.cellProperties);
            const prop = this.hot.colToProp(visualColumnToCheck);
            const originalValue = this.hot.getSourceDataAtCell(this.hot.toPhysicalRow(visualRowToCheck), visualColumnToCheck);
            this.activeEditor = (0, _registry.getEditorInstance)(editorClass, this.hot);
            // Using not modified coordinates, as we need to get the table element using selection coordinates.
            // There is an extra translation in the editor for saving value.
            this.activeEditor.prepare(row, col, prop, td, originalValue, this.cellProperties);
        }
    }
    /**
   * Check is editor is opened/showed.
   *
   * @returns {boolean}
   */ isEditorOpened() {
        return this.activeEditor && this.activeEditor.isOpened();
    }
    /**
   * Open editor with initial value.
   *
   * @param {null|string} newInitialValue New value from which editor will start if handled property it's not the `null`.
   * @param {Event} event The event object.
   * @param {boolean} [enableFullEditMode=false] When true, an editor works in full editing mode. Mode disallows closing an editor
   *                                             when arrow keys are pressed.
   */ openEditor(newInitialValue, event, enableFullEditMode = false) {
        if (!this.isCellEditable()) {
            this.clearActiveEditor();
            return;
        }
        const selection = this.hot.getSelectedRangeActive();
        let allowOpening = this.hot.runHooks('beforeBeginEditing', selection.highlight.row, selection.highlight.col, newInitialValue, event, enableFullEditMode);
        // If the above hook does not return boolean then the default behavior is applied which disallows opening
        // an editor after double mouse click for non-contiguous selection (while pressing Ctrl/Cmd) and
        // for multiple selected cells (while pressing SHIFT).
        if (event instanceof MouseEvent && typeof allowOpening !== 'boolean') {
            allowOpening = this.hot.selection.getLayerLevel() === 0 && selection.isSingle();
        }
        if (allowOpening === false) {
            this.clearActiveEditor();
            return;
        }
        if (!this.activeEditor) {
            this.hot.scrollToFocusedCell();
            this.prepareEditor();
        }
        if (this.activeEditor) {
            if (enableFullEditMode) {
                this.activeEditor.enableFullEditMode();
            }
            this.activeEditor.beginEditing(newInitialValue, event);
        }
    }
    /**
   * Close editor, finish editing cell.
   *
   * @param {boolean} restoreOriginalValue If `true`, then closes editor without saving value from the editor into a cell.
   * @param {boolean} isCtrlPressed If `true`, then editor will save value to each cell in the last selected range.
   * @param {Function} callback The callback function, fired after editor closing.
   */ closeEditor(restoreOriginalValue = false, isCtrlPressed = false, callback) {
        if (this.activeEditor) {
            this.activeEditor.finishEditing(restoreOriginalValue, isCtrlPressed, callback);
        } else if (callback) {
            callback(false);
        }
    }
    /**
   * Close editor and save changes.
   *
   * @param {boolean} isCtrlPressed If `true`, then editor will save value to each cell in the last selected range.
   */ closeEditorAndSaveChanges(isCtrlPressed) {
        this.closeEditor(false, isCtrlPressed);
    }
    /**
   * Close editor and restore original value.
   *
   * @param {boolean} isCtrlPressed Indication of whether the CTRL button is pressed.
   */ closeEditorAndRestoreOriginalValue(isCtrlPressed) {
        this.closeEditor(true, isCtrlPressed);
    }
    /**
   * Clears reference to an instance of the active editor.
   *
   * @private
   */ clearActiveEditor() {
        this.activeEditor = undefined;
    }
    /**
   * Checks if the currently selected cell (pointed by selection highlight coords) is editable.
   * Editable cell is when:
   *   - the cell has defined an editor type;
   *   - the cell is not marked as read-only;
   *   - the cell is not hidden.
   *
   * @private
   * @returns {boolean}
   */ isCellEditable() {
        const selection = this.hot.getSelectedRangeActive();
        if (!selection) {
            return false;
        }
        const editorClass = this.hot.getCellEditor(this.cellProperties);
        const { row, col } = selection.highlight;
        if (row === null || col === null) {
            return false;
        }
        if (this.cellProperties.readOnly || !editorClass || _class_private_method_get(this, _isCellHidden, isCellHidden).call(this, row, col)) {
            return false;
        }
        return true;
    }
    /**
   * Controls selection's behavior after clicking `Enter`.
   *
   * @private
   * @param {KeyboardEvent} event The keyboard event object.
   */ moveSelectionAfterEnter(event) {
        if (!this.hot.getSelected()) {
            return;
        }
        const enterMoves = {
            ...typeof this.tableMeta.enterMoves === 'function' ? this.tableMeta.enterMoves(event) : this.tableMeta.enterMoves
        };
        if (event.shiftKey) {
            enterMoves.row = -(enterMoves.row ?? 0);
            enterMoves.col = -(enterMoves.col ?? 0);
        }
        if (this.hot.selection.isMultiple()) {
            this.selection.transformFocus(enterMoves.row ?? 0, enterMoves.col ?? 0);
        } else {
            this.selection.transformStart(enterMoves.row ?? 0, enterMoves.col ?? 0, true);
        }
    }
    /**
   * Destroy the instance.
   */ destroy() {
        this.destroyed = true;
        this.eventManager.destroy();
    }
    /**
   * @param {Core} hotInstance The Handsontable instance.
   * @param {TableMeta} tableMeta The table meta instance.
   * @param {Selection} selection The selection instance.
   */ constructor(hotInstance, tableMeta, selection){
        _class_private_method_init(this, _isCellHidden);
        _class_private_method_init(this, _closeEditorWhenCellHidden);
        _class_private_method_init(this, _onAfterDocumentKeyDown);
        _class_private_method_init(this, _onCellDblClick);
        _class_private_field_init(this, _hiddenCellCloseArmed, {
            writable: true,
            value: void 0
        });
        /**
   * Determines if EditorManager is destroyed.
   *
   * @private
   * @type {boolean}
   */ this.destroyed = false;
        _class_private_field_set(this, _hiddenCellCloseArmed, false);
        this.hot = hotInstance;
        this.tableMeta = tableMeta;
        this.selection = selection;
        this.eventManager = new _eventManager.default(hotInstance);
        this.hot.addHook('afterDocumentKeyDown', (event)=>_class_private_method_get(this, _onAfterDocumentKeyDown, onAfterDocumentKeyDown).call(this, event));
        this.hot.addHook('beforeCompositionStart', (event)=>_class_private_method_get(this, _onAfterDocumentKeyDown, onAfterDocumentKeyDown).call(this, event));
        this.hot.addHook('afterRowSequenceCacheUpdate', ()=>_class_private_method_get(this, _closeEditorWhenCellHidden, closeEditorWhenCellHidden).call(this));
        this.hot.addHook('afterColumnSequenceCacheUpdate', ()=>_class_private_method_get(this, _closeEditorWhenCellHidden, closeEditorWhenCellHidden).call(this));
        this.hot.view._wt.update('onCellDblClick', (event, coords, _elem)=>_class_private_method_get(this, _onCellDblClick, onCellDblClick).call(this, event, coords));
    }
}
function isCellHidden(visualRow, visualColumn) {
    return this.hot.rowIndexMapper.isHidden(this.hot.toPhysicalRow(visualRow)) || this.hot.columnIndexMapper.isHidden(this.hot.toPhysicalColumn(visualColumn));
}
function closeEditorWhenCellHidden(pendingEditor) {
    // Fall back to the captured reference: a rejected validation re-selects the hidden cell, which
    // drives `prepareEditor()` -> `clearActiveEditor()`, so `this.activeEditor` can already be gone
    // by the time a retry lands even though the editor object is still open.
    const editor = this.activeEditor ?? pendingEditor;
    if (!editor || editor.row === null || editor.col === null || !_class_private_method_get(this, _isCellHidden, isCellHidden).call(this, editor.row, editor.col)) {
        return;
    }
    // `finishEditing()` is a silent no-op while an async validator is in flight, which would leave
    // the editor orphaned. Re-enter at the top once validation settles rather than assuming the
    // wait is over: `postAfterValidate` is instance-wide and may fire for an unrelated cell.
    if (editor.isWaiting()) {
        if (!_class_private_field_get(this, _hiddenCellCloseArmed)) {
            _class_private_field_set(this, _hiddenCellCloseArmed, true);
            this.hot.addHookOnce('postAfterValidate', ()=>{
                _class_private_field_set(this, _hiddenCellCloseArmed, false);
                this.hot._registerTimeout(()=>_class_private_method_get(this, _closeEditorWhenCellHidden, closeEditorWhenCellHidden).call(this, editor), 0);
            });
        }
        return;
    }
    if (editor.state !== _baseEditor.EDITOR_STATE.EDITING || _class_private_field_get(this, _hiddenCellCloseArmed)) {
        return;
    }
    _class_private_field_set(this, _hiddenCellCloseArmed, true);
    // Committing writes through `setDataAtCell`, which re-enters this manager (`closeEditor()`,
    // `render()`, `prepareEditor()`). Defer so the write never lands inside the cache update that
    // is still unwinding.
    this.hot._registerTimeout(()=>{
        _class_private_field_set(this, _hiddenCellCloseArmed, false);
        if (this.destroyed || editor.state !== _baseEditor.EDITOR_STATE.EDITING || editor.row === null || editor.col === null || !_class_private_method_get(this, _isCellHidden, isCellHidden).call(this, editor.row, editor.col)) {
            return;
        }
        // Drive the captured editor directly rather than `closeEditor()`, for the same reason as
        // the fallback above: `this.activeEditor` may already have been cleared.
        editor.finishEditing(false, false, (dataSaved)=>{
            if (dataSaved) {
                return;
            }
            // Nothing is lost by reverting - the rejected value never reached the dataset,
            // `validateChanges()` splices it out first.
            editor.finishEditing(true);
        });
    }, 0);
}
function onAfterDocumentKeyDown(event) {
    const selection = this.hot.getSelectedRangeActive();
    if (!this.hot.isListening() || !selection || selection.highlight.isHeader() || (0, _event.isImmediatePropagationStopped)(event)) {
        return;
    }
    const { keyCode } = event;
    // catch CTRL but not right ALT (which in some systems triggers ALT+CTRL)
    const isCtrlPressed = (event.ctrlKey || event.metaKey) && !event.altKey;
    if (!this.activeEditor || this.activeEditor && !this.activeEditor.isWaiting()) {
        if (!(0, _unicode.isFunctionKey)(keyCode) && !(0, _unicode.isCtrlMetaKey)(keyCode) && !isCtrlPressed && !this.isEditorOpened()) {
            this.openEditor('', event);
        }
    }
}
function onCellDblClick(event, coords) {
    if (coords?.isCell()) {
        if (this.hot.getShortcutManager().isCtrlPressed()) {
            this.clearActiveEditor();
        } else {
            this.openEditor(null, event, true);
        }
    }
}
const instances = new WeakMap();
/**
 * @param {Core} hotInstance The Handsontable instance.
 * @param {TableMeta} tableMeta The table meta class instance.
 * @param {Selection} selection The selection instance.
 * @returns {EditorManager}
 */ EditorManager.getInstance = function(hotInstance, tableMeta, selection) {
    let editorManager = instances.get(hotInstance);
    if (!editorManager) {
        editorManager = new EditorManager(hotInstance, tableMeta, selection);
        instances.set(hotInstance, editorManager);
    }
    return editorManager;
};
const _default = EditorManager;
