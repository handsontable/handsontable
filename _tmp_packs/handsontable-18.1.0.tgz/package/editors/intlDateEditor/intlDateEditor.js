"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EDITOR_TYPE () {
        return EDITOR_TYPE;
    },
    get IntlDateEditor () {
        return IntlDateEditor;
    }
});
const _dateEditor = require("../dateEditor");
const EDITOR_TYPE = 'intl-date';
class IntlDateEditor extends _dateEditor.DateEditor {
    /**
   * Returns the unique editor type identifier for the intl-date editor.
   */ static get EDITOR_TYPE() {
        return EDITOR_TYPE;
    }
}
