"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DropdownController", {
    enumerable: true,
    get: function() {
        return DropdownController;
    }
});
const _element = require("../../../helpers/dom/element");
const _object = require("../../../helpers/object");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../../mixins/localHooks"));
const _utils = require("../utils/utils");
const _eventManager = /*#__PURE__*/ _interop_require_default(require("../../../eventManager"));
const _inputController = require("./inputController");
const _utils1 = require("./utils");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * The Handsontable instance GUID used to scope checkbox IDs within the dropdown.
   */ _instanceId = /*#__PURE__*/ new WeakMap(), /**
   * The host div element that contains the search wrapper, separator, and list.
   */ _containerElement = /*#__PURE__*/ new WeakMap(), /**
   * The `<ul>` element that holds the individual checkbox list items.
   */ _dropdownListElement = /*#__PURE__*/ new WeakMap(), /**
   * The `<input>` element used for filtering dropdown entries.
   */ _searchInputElement = /*#__PURE__*/ new WeakMap(), /**
   * The horizontal rule element separating the search input from the item list.
   */ _separatorElement = /*#__PURE__*/ new WeakMap(), /**
   * The wrapper div that groups the search icon and search input.
   */ _searchInputWrapper = /*#__PURE__*/ new WeakMap(), /**
   * The controller managing the search input element and its filter events.
   */ _inputController1 = /*#__PURE__*/ new WeakMap(), /**
   * The root document derived from the container element's owner document.
   */ _rootDocument = /*#__PURE__*/ new WeakMap(), /**
   * The event manager used to register and remove DOM event listeners on checkbox items.
   */ _eventManager1 = /*#__PURE__*/ new WeakMap(), /**
   * Runtime cache storing settings, state flags, and event listener references.
   */ _cache = /*#__PURE__*/ new WeakMap(), /**
   * Updates the focused item index cache and applies the focus highlight to the item at the given position.
   */ _focusItem = /*#__PURE__*/ new WeakSet(), /**
   * Returns true when the dropdown is taller than the space below the cell and there is more space above.
   */ _requiresFlippingVertically = /*#__PURE__*/ new WeakSet(), /**
   * Applies or removes the absolute positioning that renders the dropdown above the edited cell.
   */ _toggleVerticalFlip = /*#__PURE__*/ new WeakSet(), /**
   * Calculates the pixel height of a single dropdown row using CSS custom properties from the container's computed style.
   */ _getEntryHeight = /*#__PURE__*/ new WeakSet(), /**
   * Returns the pixel height occupied by the list items, using either the actual rendered count or the full entry count when calculating the maximum.
   */ _getListHeight = /*#__PURE__*/ new WeakSet(), /**
   * Returns the combined pixel height of the search input wrapper and separator, or 0 when the input is hidden.
   */ _getSearchInputWrapperHeight = /*#__PURE__*/ new WeakSet(), /**
   * Creates a list item element for the given entry, marks it as selected if needed, registers events, and appends it to the list.
   */ _addDropdownItem = /*#__PURE__*/ new WeakSet(), /**
   * Attaches change and click event listeners to the checkbox inside the given list item and stores them for later removal.
   */ _registerEvents = /*#__PURE__*/ new WeakSet(), /**
   * Removes the change and click listeners previously registered on the checkbox inside the given list item.
   */ _unregisterEvents = /*#__PURE__*/ new WeakSet(), /**
   * Resets all cached state values to their initial defaults, clearing listeners and counters.
   */ _resetCache = /*#__PURE__*/ new WeakSet();
class DropdownController {
    /**
   * Builds required DOM elements and inserts them into the container.
   */ init() {
        if (!_class_private_field_get(this, _rootDocument) || !_class_private_field_get(this, _containerElement)) {
            return;
        }
        _class_private_field_set(this, _dropdownListElement, (0, _utils1.createListElement)({
            root: _class_private_field_get(this, _rootDocument)
        }));
        _class_private_field_set(this, _searchInputElement, (0, _utils1.createSearchInputElement)({
            root: _class_private_field_get(this, _rootDocument)
        }));
        const searchIcon = (0, _utils1.createSearchIcon)({
            root: _class_private_field_get(this, _rootDocument)
        });
        _class_private_field_set(this, _searchInputWrapper, (0, _utils1.createSearchInputWrapper)({
            root: _class_private_field_get(this, _rootDocument)
        }));
        _class_private_field_set(this, _separatorElement, (0, _utils1.createSeparatorElement)({
            root: _class_private_field_get(this, _rootDocument)
        }));
        _class_private_field_get(this, _searchInputWrapper).appendChild(searchIcon);
        _class_private_field_get(this, _searchInputWrapper).appendChild(_class_private_field_get(this, _searchInputElement));
        _class_private_field_get(this, _containerElement).appendChild(_class_private_field_get(this, _searchInputWrapper));
        _class_private_field_get(this, _containerElement).appendChild(_class_private_field_get(this, _separatorElement));
        _class_private_field_get(this, _containerElement).appendChild(_class_private_field_get(this, _dropdownListElement));
        _class_private_field_set(this, _inputController1, new _inputController.InputController({
            input: _class_private_field_get(this, _searchInputElement),
            eventManager: _class_private_field_get(this, _eventManager1)
        }));
    }
    /**
   * Stores the maximum number of visible rows used when constraining the dropdown's rendered height.
   */ setVisibleRowsNumberSetting(visibleRowsNumber) {
        _class_private_field_get(this, _cache).visibleRowsNumberSetting = visibleRowsNumber;
    }
    /**
   * Stores a comparator function applied to the source entries before rendering; pass null to remove sorting.
   */ setSourceSortFunction(sourceSortFunction) {
        _class_private_field_get(this, _cache).sourceSortFunction = sourceSortFunction ?? null;
    }
    /**
   * Shows or hides the search input and separator elements and toggles the input controller's listener.
   */ setSearchInputVisibility(searchInput = true) {
        if (!_class_private_field_get(this, _searchInputWrapper) || !_class_private_field_get(this, _separatorElement) || !_class_private_field_get(this, _inputController1)) {
            return;
        }
        _class_private_field_get(this, _searchInputWrapper).style.display = searchInput ? '' : 'none';
        _class_private_field_get(this, _separatorElement).style.display = searchInput ? '' : 'none';
        _class_private_field_get(this, _inputController1).toggle(searchInput);
    }
    /**
   * Populates the dropdown with provided entries and marks selected ones.
   *
   * @param {string[]|object[]} entries Collection of primitive values or `[value, label]` tuples.
   * @param {Array<*>} [checkedValues=[]] Values that should be rendered as checked.
   */ fillDropdown(entries, checkedValues = []) {
        this.removeAllDropdownItems();
        _class_private_field_get(this, _cache).currentlySelectedItemIndex = 0;
        if (!Array.isArray(checkedValues)) {
            checkedValues = [];
        }
        let sortedEntries = entries;
        if (_class_private_field_get(this, _cache).sourceSortFunction) {
            sortedEntries = _class_private_field_get(this, _cache).sourceSortFunction(entries.slice());
        }
        if (!_class_private_field_get(this, _rootDocument) || !_class_private_field_get(this, _dropdownListElement) || _class_private_field_get(this, _instanceId) === null) {
            return;
        }
        sortedEntries.forEach((elem, indexWithinList)=>{
            const itemValue = typeof elem === 'object' && elem !== null && 'value' in elem ? elem.value : elem;
            _class_private_method_get(this, _addDropdownItem, addDropdownItem).call(this, {
                rootDocument: _class_private_field_get(this, _rootDocument),
                itemKey: typeof elem === 'object' && elem !== null && 'key' in elem ? elem.key : undefined,
                itemValue: String(itemValue ?? elem),
                indexWithinList,
                checked: (0, _utils.includesValue)(checkedValues, elem),
                disabled: _class_private_field_get(this, _cache).areCheckboxesDisabled
            });
        });
        _class_private_field_get(this, _cache).entriesCount = sortedEntries.length;
        this.runLocalHooks('afterDropdownFill');
    }
    /**
   * Controls dropdown height based on entry count and configured visible rows.
   *
   * @param {object} availableSpace Available space object.
   * @param {boolean} noFlip If true, the dropdown will not be flipped vertically.
   */ updateDimensions(availableSpace, noFlip = false) {
        const entryHeight = _class_private_method_get(this, _getEntryHeight, getEntryHeight).call(this);
        const requiresFlippingVertically1 = _class_private_method_get(this, _requiresFlippingVertically, requiresFlippingVertically).call(this, availableSpace);
        const availableHeight = requiresFlippingVertically1 ? availableSpace.spaceAbove : availableSpace.spaceBelow;
        if (!noFlip && requiresFlippingVertically1) {
            _class_private_field_get(this, _cache).flippedVertically = true;
        }
        if (_class_private_field_get(this, _cache).entriesCount > 0 && availableHeight < this.getHeight(true)) {
            const maxRenderableItems = Math.max(Math.floor((availableHeight - _class_private_method_get(this, _getSearchInputWrapperHeight, getSearchInputWrapperHeight).call(this)) / entryHeight) - 1, 1);
            _class_private_field_get(this, _cache).actualRenderedItemsCount = _class_private_field_get(this, _cache).visibleRowsNumberSetting ? Math.min(maxRenderableItems, _class_private_field_get(this, _cache).visibleRowsNumberSetting) : maxRenderableItems;
        } else {
            _class_private_field_get(this, _cache).actualRenderedItemsCount = Math.min(_class_private_field_get(this, _cache).entriesCount, _class_private_field_get(this, _cache).visibleRowsNumberSetting ?? _class_private_field_get(this, _cache).entriesCount);
        }
        if (!_class_private_field_get(this, _containerElement)) {
            return;
        }
        if (_class_private_field_get(this, _cache).actualRenderedItemsCount && _class_private_field_get(this, _cache).entriesCount > _class_private_field_get(this, _cache).actualRenderedItemsCount) {
            _class_private_field_get(this, _containerElement).style.height = `${this.getHeight()}px`;
        } else {
            _class_private_field_get(this, _containerElement).style.height = '';
        }
        _class_private_method_get(this, _toggleVerticalFlip, toggleVerticalFlip).call(this, availableSpace);
        _class_private_field_get(this, _containerElement).scrollTop = 0;
    }
    /**
   * Returns the pixel width of the dropdown list element, or 0 if the list is not yet mounted.
   */ getDropdownWidth() {
        return _class_private_field_get(this, _dropdownListElement) ? (0, _utils1.getDropdownWidth)({
            dropdownListElement: _class_private_field_get(this, _dropdownListElement)
        }) : 0;
    }
    /**
   * Unchecks all checkboxes in the dropdown list.
   */ deselectAllItems() {
        if (_class_private_field_get(this, _dropdownListElement)) {
            (0, _utils1.deselectAllItems)({
                dropdownListElement: _class_private_field_get(this, _dropdownListElement)
            });
        }
    }
    /**
   * Focuses the first item in the dropdown list if at least one entry exists.
   */ focusFirstItem() {
        if (_class_private_field_get(this, _cache).entriesCount > 0) {
            _class_private_method_get(this, _focusItem, focusItem).call(this, 0);
        }
    }
    /**
   * Focuses the dropdown item at the given absolute index.
   */ focusItem(index) {
        _class_private_method_get(this, _focusItem, focusItem).call(this, index);
    }
    /**
   * Moves focus to the previous item, or to the search input when already at the first item.
   */ focusPreviousItem() {
        if (!_class_private_field_get(this, _dropdownListElement)) {
            return;
        }
        if (_class_private_field_get(this, _cache).currentlySelectedItemIndex === 0) {
            this.focusSearchInput();
            return;
        }
        (0, _utils1.defocusItem)({
            dropdownListElement: _class_private_field_get(this, _dropdownListElement),
            index: _class_private_field_get(this, _cache).currentlySelectedItemIndex
        });
        _class_private_method_get(this, _focusItem, focusItem).call(this, _class_private_field_get(this, _cache).currentlySelectedItemIndex - 1);
    }
    /**
   * Moves focus to the next item in the list, stopping at the last entry.
   */ focusNextItem() {
        if (!_class_private_field_get(this, _dropdownListElement)) {
            return;
        }
        if (_class_private_field_get(this, _cache).currentlySelectedItemIndex === _class_private_field_get(this, _cache).entriesCount - 1) {
            return;
        }
        (0, _utils1.defocusItem)({
            dropdownListElement: _class_private_field_get(this, _dropdownListElement),
            index: _class_private_field_get(this, _cache).currentlySelectedItemIndex
        });
        _class_private_method_get(this, _focusItem, focusItem).call(this, _class_private_field_get(this, _cache).currentlySelectedItemIndex + 1);
    }
    /**
   * Transfers DOM focus to the search input element.
   */ focusSearchInput() {
        if (_class_private_field_get(this, _searchInputElement)) {
            _class_private_field_get(this, _searchInputElement).focus();
        }
    }
    /**
   * Clears all dropdown items, resets internal cache state, clears the search input value, and resets container styles.
   */ reset() {
        this.removeAllDropdownItems();
        _class_private_method_get(this, _resetCache, resetCache).call(this);
        if (_class_private_field_get(this, _searchInputElement)) {
            _class_private_field_get(this, _searchInputElement).value = '';
        }
        if (_class_private_field_get(this, _containerElement)) {
            _class_private_field_get(this, _containerElement).style.position = '';
            _class_private_field_get(this, _containerElement).style.top = '';
            _class_private_field_get(this, _containerElement).style.height = '';
            _class_private_field_get(this, _containerElement).scrollTop = 0;
        }
    }
    /**
   * Returns true when the dropdown is currently rendered above the edited cell instead of below.
   */ isFlippedVertically() {
        return _class_private_field_get(this, _cache).flippedVertically;
    }
    /**
   * Calculates the total pixel height of the dropdown including the item list and search input wrapper.
   */ getHeight(maxRowsCalculation = false, outerWidth = false) {
        if (!_class_private_field_get(this, _rootDocument) || !_class_private_field_get(this, _containerElement)) {
            return 0;
        }
        const computedStyle = _class_private_field_get(this, _rootDocument).defaultView.getComputedStyle(_class_private_field_get(this, _containerElement));
        return _class_private_method_get(this, _getListHeight, getListHeight).call(this, maxRowsCalculation) + _class_private_method_get(this, _getSearchInputWrapperHeight, getSearchInputWrapperHeight).call(this) + (outerWidth === true ? 2 * parseInt(computedStyle.getPropertyValue('--ht-menu-vertical-padding'), 10) : 0);
    }
    /**
   * Returns the InputController instance that manages the search input, or null if not yet initialized.
   */ getInputController() {
        return _class_private_field_get(this, _inputController1);
    }
    /**
   * Removes all list items from the dropdown, unregisters their event listeners, and clears the checkbox listener cache.
   */ removeAllDropdownItems() {
        if (!_class_private_field_get(this, _dropdownListElement)) {
            return;
        }
        Array.from(_class_private_field_get(this, _dropdownListElement).children).forEach((itemElement)=>_class_private_method_get(this, _unregisterEvents, unregisterEvents).call(this, itemElement));
        _class_private_field_get(this, _cache).checkboxChangeListeners.clear();
        _class_private_field_get(this, _dropdownListElement).innerHTML = '';
    }
    /**
   * Disables all unchecked checkboxes in the dropdown and sets the internal disabled flag.
   */ disableCheckboxes() {
        _class_private_field_get(this, _cache).areCheckboxesDisabled = true;
        if (_class_private_field_get(this, _dropdownListElement)) {
            (0, _utils1.disableUncheckedCheckboxes)({
                dropdownListElement: _class_private_field_get(this, _dropdownListElement)
            });
        }
    }
    /**
   * Re-enables all checkboxes in the dropdown and clears the internal disabled flag.
   */ enableCheckboxes() {
        _class_private_field_get(this, _cache).areCheckboxesDisabled = false;
        if (_class_private_field_get(this, _dropdownListElement)) {
            (0, _utils1.enableAllCheckboxes)({
                dropdownListElement: _class_private_field_get(this, _dropdownListElement)
            });
        }
    }
    /**
   * Creates a dropdown renderer attached to the provided container.
   *
   * @param {HTMLDivElement} containerElement Host element created by the editor.
   * @param {string} instanceId Handsontable instance id.
   */ constructor(containerElement, instanceId){
        _class_private_method_init(this, _focusItem);
        _class_private_method_init(this, _requiresFlippingVertically);
        _class_private_method_init(this, _toggleVerticalFlip);
        _class_private_method_init(this, _getEntryHeight);
        _class_private_method_init(this, _getListHeight);
        _class_private_method_init(this, _getSearchInputWrapperHeight);
        _class_private_method_init(this, _addDropdownItem);
        _class_private_method_init(this, _registerEvents);
        _class_private_method_init(this, _unregisterEvents);
        _class_private_method_init(this, _resetCache);
        _class_private_field_init(this, _instanceId, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _containerElement, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _dropdownListElement, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _searchInputElement, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _separatorElement, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _searchInputWrapper, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _inputController1, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _rootDocument, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _eventManager1, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _cache, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _instanceId, null);
        _class_private_field_set(this, _containerElement, null);
        _class_private_field_set(this, _dropdownListElement, null);
        _class_private_field_set(this, _searchInputElement, null);
        _class_private_field_set(this, _separatorElement, null);
        _class_private_field_set(this, _searchInputWrapper, null);
        _class_private_field_set(this, _inputController1, null);
        _class_private_field_set(this, _rootDocument, null);
        _class_private_field_set(this, _eventManager1, new _eventManager.default(this));
        _class_private_field_set(this, _cache, {
            visibleRowsNumberSetting: null,
            entriesCount: 0,
            flippedVertically: false,
            currentlySelectedItemIndex: 0,
            checkboxChangeListeners: new Map(),
            areCheckboxesDisabled: false,
            sourceSortFunction: null
        });
        _class_private_field_set(this, _containerElement, containerElement);
        _class_private_field_set(this, _rootDocument, _class_private_field_get(this, _containerElement).ownerDocument);
        _class_private_field_set(this, _instanceId, instanceId);
        this.init();
    }
}
function focusItem(index) {
    _class_private_field_get(this, _cache).currentlySelectedItemIndex = index;
    if (_class_private_field_get(this, _dropdownListElement)) {
        (0, _utils1.focusItemAt)({
            dropdownListElement: _class_private_field_get(this, _dropdownListElement),
            index
        });
    }
}
function requiresFlippingVertically(availableSpace) {
    const { spaceAbove, spaceBelow, cellHeight } = availableSpace;
    return this.getHeight(true) > spaceBelow && spaceAbove > spaceBelow + cellHeight;
}
function toggleVerticalFlip(availableSpace) {
    if (!_class_private_field_get(this, _containerElement)) {
        return;
    }
    const { cellHeight } = availableSpace;
    const flipNeeded = _class_private_field_get(this, _cache).flippedVertically;
    if (flipNeeded) {
        _class_private_field_get(this, _containerElement).style.position = 'absolute';
        _class_private_field_get(this, _containerElement).style.top = `${-this.getHeight(false, true) - cellHeight - 2}px`;
    } else {
        _class_private_field_get(this, _containerElement).style.position = '';
        _class_private_field_get(this, _containerElement).style.top = '';
    }
}
function getEntryHeight() {
    if (!_class_private_field_get(this, _rootDocument) || !_class_private_field_get(this, _containerElement)) {
        return 0;
    }
    const computedStyle = _class_private_field_get(this, _rootDocument).defaultView.getComputedStyle(_class_private_field_get(this, _containerElement));
    return 2 * parseInt(computedStyle.getPropertyValue('--ht-menu-item-vertical-padding'), 10) + parseInt(computedStyle.getPropertyValue('--ht-line-height'), 10);
}
function getListHeight(maxRowsCalculation) {
    const maxRenderedItems = _class_private_field_get(this, _cache).entriesCount;
    const actualRenderedItems = maxRowsCalculation ? maxRenderedItems : _class_private_field_get(this, _cache).actualRenderedItemsCount ?? maxRenderedItems;
    const entryHeight = _class_private_method_get(this, _getEntryHeight, getEntryHeight).call(this);
    return actualRenderedItems * entryHeight;
}
function getSearchInputWrapperHeight() {
    if (!_class_private_field_get(this, _inputController1)?.enabled || !_class_private_field_get(this, _searchInputWrapper) || !_class_private_field_get(this, _separatorElement) || !_class_private_field_get(this, _rootDocument) || !_class_private_field_get(this, _containerElement)) {
        return 0;
    }
    const computedStyle = _class_private_field_get(this, _rootDocument).defaultView.getComputedStyle(_class_private_field_get(this, _containerElement));
    const searchInputWrapperHeight = _class_private_field_get(this, _searchInputWrapper).offsetHeight;
    const separatorHeight = _class_private_field_get(this, _separatorElement).offsetHeight + 2 * parseInt(computedStyle.getPropertyValue('--ht-menu-vertical-padding'), 10);
    return searchInputWrapperHeight + separatorHeight;
}
function addDropdownItem({ rootDocument, itemKey, itemValue, indexWithinList, checked = false, disabled = false }) {
    if (!_class_private_field_get(this, _dropdownListElement) || _class_private_field_get(this, _instanceId) === null) {
        return;
    }
    const itemElement = (0, _utils1.createListItemElement)({
        rootDocument,
        instanceId: _class_private_field_get(this, _instanceId),
        itemKey,
        itemValue,
        indexWithinList,
        checked,
        disabled
    });
    if (checked) {
        (0, _utils1.selectItem)(itemElement);
    }
    _class_private_method_get(this, _registerEvents, registerEvents).call(this, itemElement);
    _class_private_field_get(this, _dropdownListElement).appendChild(itemElement);
}
function registerEvents(itemElement) {
    const checkbox = (0, _utils.getCheckboxElement)(itemElement);
    if (!checkbox || !_class_private_field_get(this, _dropdownListElement)) {
        return;
    }
    const checkboxChangeListener = ()=>{
        if (checkbox.dataset.disabled === 'true' && checkbox.checked) {
            checkbox.checked = false;
            return;
        }
        if (checkbox.checked) {
            (0, _utils1.selectItem)(itemElement);
            this.runLocalHooks('afterDropdownItemChecked', checkbox.dataset.key, checkbox.dataset.value);
        } else {
            (0, _utils1.deselectItem)(itemElement);
            this.runLocalHooks('afterDropdownItemUnchecked', checkbox.dataset.key, checkbox.dataset.value);
        }
    };
    const itemClickListener = (event)=>{
        const target = (0, _element.eventTargetEl)(event);
        if (target === checkbox || checkbox.dataset.disabled === 'true' || target.tagName === 'LABEL') {
            return;
        }
        checkbox.checked = !checkbox.checked;
        checkbox.dispatchEvent(new Event('change'));
    };
    _class_private_field_get(this, _cache).checkboxChangeListeners.set(checkbox, {
        change: checkboxChangeListener,
        click: itemClickListener
    });
    _class_private_field_get(this, _eventManager1).addEventListener(checkbox, 'change', checkboxChangeListener);
    _class_private_field_get(this, _eventManager1).addEventListener(itemElement, 'click', itemClickListener);
}
function unregisterEvents(itemElement) {
    const checkbox = (0, _utils.getCheckboxElement)(itemElement);
    if (!checkbox) {
        return;
    }
    const checkboxListeners = _class_private_field_get(this, _cache).checkboxChangeListeners.get(checkbox);
    if (checkboxListeners) {
        _class_private_field_get(this, _eventManager1).removeEventListener(checkbox, 'change', checkboxListeners.change);
        _class_private_field_get(this, _eventManager1).removeEventListener(itemElement, 'click', checkboxListeners.click);
        _class_private_field_get(this, _cache).checkboxChangeListeners.delete(checkbox);
    }
}
function resetCache() {
    _class_private_field_get(this, _cache).visibleRowsNumberSetting = null;
    _class_private_field_get(this, _cache).entriesCount = 0;
    _class_private_field_get(this, _cache).flippedVertically = false;
    _class_private_field_get(this, _cache).currentlySelectedItemIndex = 0;
    _class_private_field_get(this, _cache).checkboxChangeListeners.clear();
    _class_private_field_get(this, _cache).areCheckboxesDisabled = false;
    _class_private_field_get(this, _cache).sourceSortFunction = null;
}
(0, _object.mixin)(DropdownController, _localHooks.default);
