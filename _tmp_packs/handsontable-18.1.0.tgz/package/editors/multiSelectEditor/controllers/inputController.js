"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "InputController", {
    enumerable: true,
    get: function() {
        return InputController;
    }
});
const _object = require("../../../helpers/object");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../../mixins/localHooks"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var /**
   * Runs all `triggerFilter` local hook callbacks with the current input value to initiate
   * entry filtering in the dropdown.
   */ _triggerFilter = /*#__PURE__*/ new WeakSet();
class InputController {
    /**
   * Returns the underlying `<input>` element managed by this controller.
   */ getInputElement() {
        return this.input;
    }
    /**
   * Writes the given string into the input element's value property without firing a DOM input event.
   */ setValue(value) {
        this.input.value = value;
    }
    /**
   * Enables or disables the input controller: passes `true` to start listening for input events,
   * `false` to stop.
   */ toggle(enabled) {
        this.enabled = enabled;
        if (this.input) {
            if (enabled) {
                this.listen();
            } else {
                this.unlisten();
            }
        }
    }
    /**
   * Registers the native `input` event listener on the managed element so that typing triggers `triggerFilter`.
   */ listen() {
        this.eventManager.addEventListener(this.input, 'input', this.onInput);
    }
    /**
   * Removes the previously registered `input` event listener from the managed element.
   */ unlisten() {
        this.eventManager.removeEventListener(this.input, 'input', this.onInput);
    }
    /**
   * Handles the native input event and delegates to the internal filter trigger.
   */ _onInput() {
        _class_private_method_get(this, _triggerFilter, triggerFilter).call(this, this.input.value);
    }
    /**
   * Wires the given input element and event manager, and enables the controller immediately.
   */ constructor({ input, eventManager }){
        _class_private_method_init(this, _triggerFilter);
        /**
   * Bound handler for the native input event, used to trigger filtering.
   */ this.onInput = this._onInput.bind(this);
        this.input = input;
        this.eventManager = eventManager;
        this.enabled = true;
    }
}
function triggerFilter(value) {
    this.runLocalHooks('triggerFilter', value);
}
(0, _object.mixin)(InputController, _localHooks.default);
