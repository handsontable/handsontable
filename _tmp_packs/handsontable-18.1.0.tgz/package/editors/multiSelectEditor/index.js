"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EDITOR_TYPE () {
        return _multiSelectEditor.EDITOR_TYPE;
    },
    get MultiSelectEditor () {
        return _multiSelectEditor.MultiSelectEditor;
    }
});
const _multiSelectEditor = require("./multiSelectEditor");
