"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BaseEditor () {
        return BaseEditor;
    },
    get EDITOR_STATE () {
        return EDITOR_STATE;
    },
    get EDITOR_TYPE () {
        return EDITOR_TYPE;
    }
});
const _mixed = require("../../helpers/mixed");
const _errors = require("../../helpers/errors");
const _console = require("../../helpers/console");
const _object = require("../../helpers/object");
const _hooksRefRegisterer = /*#__PURE__*/ _interop_require_default(require("../../mixins/hooksRefRegisterer"));
const _element = require("../../helpers/dom/element");
const _valueAccessors = require("../../utils/valueAccessors");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const EDITOR_TYPE = 'base';
const EDITOR_STATE = Object.freeze({
    VIRGIN: 'STATE_VIRGIN',
    EDITING: 'STATE_EDITING',
    WAITING: 'STATE_WAITING',
    FINISHED: 'STATE_FINISHED'
});
var /**
   * Calculates the top offset of the edited cell within the overlay's coordinate space.
   *
   * @param {HTMLTableCellElement} TD The edited cell element.
   * @param {string} overlayName The name of the overlay containing the cell.
   * @param {number} firstRowOffset The start position of the rows render calculator.
   * @param {number} verticalScrollPosition The current vertical scroll position.
   * @param {number} scrollbarWidth The scrollbar width in pixels.
   * @returns {number}
   */ _calcCellTopOffset = /*#__PURE__*/ new WeakSet(), /**
   * Calculates the inline-start offset of the edited cell within the overlay's coordinate space.
   *
   * @param {HTMLTableCellElement} TD The edited cell element.
   * @param {string} overlayName The name of the overlay containing the cell.
   * @param {object} overlayTable The Walkontable table instance for the overlay.
   * @param {number} cellWidth The width of the edited cell.
   * @param {number} firstColumnOffset The start position of the columns render calculator.
   * @param {number} horizontalScrollPosition The current horizontal scroll position.
   * @returns {number}
   */ _calcCellStartOffset = /*#__PURE__*/ new WeakSet();
class BaseEditor {
    /**
   * Returns the unique editor type identifier for the base editor.
   */ static get EDITOR_TYPE() {
        return EDITOR_TYPE;
    }
    /**
   * Fires callback after closing editor.
   *
   * @private
   * @param {boolean} result The editor value.
   */ _fireCallbacks(result) {
        if (this._closeCallback) {
            this._closeCallback(result);
            this._closeCallback = null;
        }
    }
    /**
   * Initializes an editor's intance.
   */ init() {}
    /**
   * Required method to get current value from editable element.
   */ getValue() {
        (0, _errors.throwWithCause)('Editor getValue() method unimplemented');
    }
    /**
   * Required method to set new value into editable element.
   */ setValue(_value) {
        (0, _errors.throwWithCause)('Editor setValue() method unimplemented');
    }
    /**
   * Required method to open editor.
   */ open(_event) {
        (0, _errors.throwWithCause)('Editor open() method unimplemented');
    }
    /**
   * Required method to close editor.
   */ close() {
        (0, _errors.throwWithCause)('Editor close() method unimplemented');
    }
    /**
   * Required method to focus editor.
   */ focus() {
        (0, _errors.throwWithCause)('Editor focus() method unimplemented');
    }
    /**
   * Prepares editor's meta data.
   *
   * @param {number} row The visual row index.
   * @param {number} col The visual column index.
   * @param {number|string} prop The column property (passed when datasource is an array of objects).
   * @param {HTMLTableCellElement} td The rendered cell element.
   * @param {*} value The rendered value.
   * @param {object} cellProperties The cell meta object (see {@link Core#getCellMeta}).
   */ prepare(row, col, prop, td, value, cellProperties) {
        this.TD = td;
        this.row = row;
        this.col = col;
        this.prop = prop;
        this.originalValue = value;
        this.cellProperties = cellProperties;
        this.state = this.isOpened() ? this.state : EDITOR_STATE.VIRGIN;
    }
    /**
   * Fallback method to provide extendable editors in ES5.
   *
   * @returns {Function}
   */ extend() {
        return class Editor extends this.constructor {
        };
    }
    /**
   * Saves value from editor into data storage.
   *
   * @param {*} value The editor value.
   * @param {boolean} ctrlDown If `true`, applies value to each cell in the last selected range.
   */ saveValue(value, ctrlDown) {
        let visualRowFrom;
        let visualColumnFrom;
        let visualRowTo;
        let visualColumnTo;
        // if ctrl+enter and multiple cells selected, behave like Excel (finish editing and apply to all cells)
        if (ctrlDown) {
            const activeRange = this.hot.getSelectedRangeActive();
            const topStartCorner = activeRange?.getTopStartCorner();
            const bottomEndCorner = activeRange?.getBottomEndCorner();
            visualRowFrom = topStartCorner?.row ?? this.row;
            visualColumnFrom = topStartCorner?.col ?? this.col;
            visualRowTo = bottomEndCorner?.row ?? this.row;
            visualColumnTo = bottomEndCorner?.col ?? this.col;
        } else {
            [visualRowFrom, visualColumnFrom, visualRowTo, visualColumnTo] = [
                this.row,
                this.col,
                null,
                null
            ];
        }
        const modifiedCellCoords = this.hot.runHooks('modifyGetCellCoords', visualRowFrom, visualColumnFrom, false, 'meta');
        if (Array.isArray(modifiedCellCoords)) {
            [visualRowFrom, visualColumnFrom] = modifiedCellCoords;
        }
        // Saving values using the modified coordinates.
        this.hot.populateFromArray(visualRowFrom, visualColumnFrom, value, visualRowTo, visualColumnTo, 'edit');
    }
    /**
   * Begins editing on a highlighted cell and hides fillHandle corner if was present.
   *
   * @param {*} newInitialValue The initial editor value.
   * @param {Event} event The keyboard event object.
   */ beginEditing(newInitialValue, event) {
        if (this.state !== EDITOR_STATE.VIRGIN) {
            return;
        }
        if (this.row === null || this.col === null) {
            (0, _console.warn)('Editor opened without valid cell coordinates.');
            return;
        }
        const hotInstance = this.hot;
        // We have to convert visual indexes into renderable indexes
        // due to hidden columns don't participate in the rendering process
        const renderableRowIndex = hotInstance.rowIndexMapper.getRenderableFromVisualIndex(this.row);
        const renderableColumnIndex = hotInstance.columnIndexMapper.getRenderableFromVisualIndex(this.col);
        if (renderableRowIndex !== null && renderableColumnIndex !== null) {
            hotInstance.view.scrollViewport({
                row: renderableRowIndex,
                col: renderableColumnIndex
            });
        }
        this.state = EDITOR_STATE.EDITING;
        // Set the editor value only in the full edit mode. In other mode the focusable element has to be empty,
        // otherwise IME (editor for Asia users) doesn't work.
        if (this.isInFullEditMode()) {
            const originalValue = (0, _valueAccessors.getValueGetterValue)(this.originalValue, this.hot.getCellMeta(this.row, this.col));
            const stringifiedInitialValue = typeof newInitialValue === 'string' ? newInitialValue : (0, _mixed.stringify)(originalValue);
            this.setValue(stringifiedInitialValue);
        }
        this.open(event);
        this._opened = true;
        this.focus();
        // only rerender the selections (FillHandle should disappear when beginEditing is triggered)
        hotInstance.view.render();
        hotInstance.runHooks('afterBeginEditing', this.row, this.col);
        this.addHook('beforeDialogShow', ()=>this.cancelChanges());
    }
    /**
   * Finishes editing and start saving or restoring process for editing cell or last selected range.
   *
   * @param {boolean} restoreOriginalValue If true, then closes editor without saving value from the editor into a cell.
   * @param {boolean} ctrlDown If true, then saveValue will save editor's value to each cell in the last selected range.
   * @param {Function} callback The callback function, fired after editor closing.
   */ finishEditing(restoreOriginalValue, ctrlDown, callback) {
        let val;
        if (callback) {
            const previousCloseCallback = this._closeCallback;
            this._closeCallback = (result)=>{
                if (previousCloseCallback) {
                    previousCloseCallback(result);
                }
                callback(result);
                this.hot.view.render();
            };
        }
        if (this.isWaiting()) {
            return;
        }
        if (this.state === EDITOR_STATE.VIRGIN) {
            this.hot._registerTimeout(()=>{
                this._fireCallbacks(true);
            });
            return;
        }
        if (this.state === EDITOR_STATE.EDITING) {
            if (restoreOriginalValue) {
                this.cancelChanges();
                this.hot.view.render();
                return;
            }
            let value = this.getValue();
            if (this.cellProperties.trimWhitespace) {
                value = typeof value === 'string' ? String.prototype.trim.call(value || '') : value;
            }
            if (typeof this.cellProperties.valueParser === 'function') {
                value = this.cellProperties.valueParser(value, this.cellProperties);
            }
            this.state = EDITOR_STATE.WAITING;
            this.saveValue([
                [
                    value
                ]
            ], ctrlDown);
            if (this.hot.getCellValidator(this.cellProperties)) {
                this.hot.addHookOnce('postAfterValidate', (result)=>{
                    this.state = EDITOR_STATE.FINISHED;
                    this.discardEditor(result);
                });
            } else {
                this.state = EDITOR_STATE.FINISHED;
                this.discardEditor(true);
            }
        }
    }
    /**
   * Finishes editing without saving value.
   */ cancelChanges() {
        this.state = EDITOR_STATE.FINISHED;
        this.discardEditor();
    }
    /**
   * Verifies result of validation or closes editor if user's cancelled changes.
   *
   * @param {boolean|undefined} result If `false` and the cell using allowInvalid option,
   *                                   then an editor won't be closed until validation is passed.
   */ discardEditor(result) {
        if (this.state !== EDITOR_STATE.FINISHED) {
            return;
        }
        // validator was defined and failed
        if (result === false && this.cellProperties.allowInvalid !== true) {
            if (this.row === null || this.col === null) {
                return;
            }
            this.hot.selectCell(this.row, this.col);
            this.focus();
            this.state = EDITOR_STATE.EDITING;
            this._fireCallbacks(false);
        } else {
            this.close();
            this._opened = false;
            this._fullEditMode = false;
            this.state = EDITOR_STATE.VIRGIN;
            this._fireCallbacks(true);
            const shortcutManager = this.hot.getShortcutManager();
            shortcutManager.setActiveContextName('grid');
        }
    }
    /**
   * Switch editor into full edit mode. In this state navigation keys don't close editor. This mode is activated
   * automatically after hit ENTER or F2 key on the cell or while editing cell press F2 key.
   */ enableFullEditMode() {
        this._fullEditMode = true;
    }
    /**
   * Checks if editor is in full edit mode.
   *
   * @returns {boolean}
   */ isInFullEditMode() {
        return this._fullEditMode;
    }
    /**
   * Returns information whether the editor is open.
   *
   * @returns {boolean}
   */ isOpened() {
        return this._opened;
    }
    /**
   * Returns information whether the editor is waiting, eg.: for async validation.
   *
   * @returns {boolean}
   */ isWaiting() {
        return this.state === EDITOR_STATE.WAITING;
    }
    /**
   * Gets the object that provides information about the edited cell size and its position
   * relative to the table viewport.
   *
   * The rectangle has six integer properties:
   *  - `top` The top position relative to the table viewport
   *  - `start` The left (or right in RTL) position relative to the table viewport
   *  - `width` The cell's current width;
   *  - `maxWidth` The maximum cell's width after which the editor goes out of the table viewport
   *  - `height` The cell's current height;
   *  - `maxHeight` The maximum cell's height after which the editor goes out of the table viewport
   *
   * @returns {{top: number, start: number, width: number, maxWidth: number, height: number, maxHeight: number} | undefined}
   */ getEditedCellRect() {
        const TD = this.getEditedCell();
        // TD is outside of the viewport.
        if (!TD) {
            return;
        }
        const { wtOverlays, wtViewport } = this.hot.view._wt;
        const rootWindow = this.hot.rootWindow;
        const currentOffset = (0, _element.offset)(TD);
        const cellWidth = (0, _element.outerWidth)(TD);
        const containerOffset = (0, _element.offset)(this.hot.rootElement);
        const containerWidth = (0, _element.outerWidth)(this.hot.rootElement);
        const scrollableContainerTop = wtOverlays.topOverlay?.holder;
        const scrollableContainerLeft = wtOverlays.inlineStartOverlay?.holder;
        const containerScrollTop = scrollableContainerTop !== rootWindow ? scrollableContainerTop.scrollTop : 0;
        const containerScrollLeft = scrollableContainerLeft !== rootWindow ? scrollableContainerLeft.scrollLeft : 0;
        const gridMostRightPos = rootWindow.innerWidth - containerOffset.left - containerWidth;
        const { wtTable: overlayTable } = wtOverlays.getParentOverlay(TD) ?? this.hot.view._wt;
        const overlayName = overlayTable.name;
        const scrollTop = [
            'master',
            'inline_start'
        ].includes(overlayName) ? containerScrollTop : 0;
        const scrollLeft = [
            'master',
            'top',
            'bottom'
        ].includes(overlayName) ? containerScrollLeft : 0;
        // If colHeaders is disabled, cells in the first row have border-top
        const editTopModifier = currentOffset.top === containerOffset.top ? 0 : 1;
        let topPos = currentOffset.top - containerOffset.top - editTopModifier - scrollTop;
        let inlineStartPos = 0;
        if (this.hot.isRtl()) {
            inlineStartPos = rootWindow.innerWidth - currentOffset.left - cellWidth - gridMostRightPos - 1 + scrollLeft;
        } else {
            inlineStartPos = currentOffset.left - containerOffset.left - 1 - scrollLeft;
        }
        // When the scrollable element is Window object then the editor position needs to be compensated
        // by the overlays' position (position relative to the table viewport). In other cases, the overlay's
        // position always returns 0.
        if ([
            'top',
            'top_inline_start_corner'
        ].includes(overlayName)) {
            topPos += wtOverlays.topOverlay?.getOverlayOffset() ?? 0;
        }
        if ([
            'inline_start',
            'top_inline_start_corner'
        ].includes(overlayName)) {
            inlineStartPos += Math.abs(wtOverlays.inlineStartOverlay?.getOverlayOffset() ?? 0);
        }
        const hasColumnHeaders = this.hot.hasColHeaders();
        const renderableRow = this.hot.rowIndexMapper.getRenderableFromVisualIndex(this.row ?? 0);
        const renderableColumn = this.hot.columnIndexMapper.getRenderableFromVisualIndex(this.col ?? 0);
        const nrOfRenderableRowIndexes = this.hot.rowIndexMapper.getRenderableIndexesLength();
        const firstRowIndexOfTheBottomOverlay = nrOfRenderableRowIndexes - this.hot.view._wt.getSetting('fixedRowsBottom');
        if (hasColumnHeaders && (renderableRow ?? 0) <= 0 || renderableRow === firstRowIndexOfTheBottomOverlay) {
            topPos += 1;
        }
        if ((renderableColumn ?? 0) <= 0) {
            inlineStartPos += 1;
        }
        const firstRowOffset = wtViewport.rowsRenderCalculator?.startPosition ?? 0;
        const firstColumnOffset = wtViewport.columnsRenderCalculator?.startPosition ?? 0;
        const horizontalScrollPosition = Math.abs(wtOverlays.inlineStartOverlay?.getScrollPosition() ?? 0);
        const verticalScrollPosition = wtOverlays.topOverlay?.getScrollPosition() ?? 0;
        const scrollbarWidth = (0, _element.getScrollbarWidth)(this.hot.rootDocument);
        const cellTopOffset = _class_private_method_get(this, _calcCellTopOffset, calcCellTopOffset).call(this, TD, overlayName, firstRowOffset, verticalScrollPosition, scrollbarWidth);
        const cellStartOffset = _class_private_method_get(this, _calcCellStartOffset, calcCellStartOffset).call(this, TD, overlayName, overlayTable, cellWidth, firstColumnOffset, horizontalScrollPosition);
        const cellComputedStyle = rootWindow.getComputedStyle(TD);
        const borderPhysicalWidthProp = this.hot.isRtl() ? 'borderRightWidth' : 'borderLeftWidth';
        const inlineStartBorderCompensation = Number.parseInt(cellComputedStyle[borderPhysicalWidthProp], 10) > 0 ? 0 : 1;
        const topBorderCompensation = Number.parseInt(cellComputedStyle.borderTopWidth, 10) > 0 ? 0 : 1;
        const width = (0, _element.outerWidth)(TD) + inlineStartBorderCompensation;
        const height = (0, _element.outerHeight)(TD) + topBorderCompensation;
        const actualVerticalScrollbarWidth = scrollableContainerTop && (0, _element.hasVerticalScrollbar)(scrollableContainerTop) ? scrollbarWidth : 0;
        const actualHorizontalScrollbarWidth = scrollableContainerLeft && (0, _element.hasHorizontalScrollbar)(scrollableContainerLeft) ? scrollbarWidth : 0;
        const maxWidth = this.hot.view.maximumVisibleElementWidth(cellStartOffset) - actualVerticalScrollbarWidth + inlineStartBorderCompensation;
        const maxHeight = Math.max(this.hot.view.maximumVisibleElementHeight(cellTopOffset ?? 0) - actualHorizontalScrollbarWidth + topBorderCompensation, this.hot.stylesHandler.getDefaultRowHeight() ?? 0);
        return {
            top: topPos,
            start: inlineStartPos,
            height,
            maxHeight,
            width,
            maxWidth
        };
    }
    /**
   * Gets the `className` of the edited cell, if it exists.
   *
   * @returns {string}
   */ getEditedCellsLayerClass() {
        const editorSection = this.checkEditorSection();
        switch(editorSection){
            case 'inline-start':
                return 'ht_clone_left ht_clone_inline_start';
            case 'bottom':
                return 'ht_clone_bottom';
            case 'bottom-inline-start-corner':
                return 'ht_clone_bottom_left_corner ht_clone_bottom_inline_start_corner';
            case 'top':
                return 'ht_clone_top';
            case 'top-inline-start-corner':
                return 'ht_clone_top_left_corner ht_clone_top_inline_start_corner';
            default:
                return 'ht_clone_master';
        }
    }
    /**
   * Gets the `HTMLTableCellElement` of the edited cell, if it exists.
   *
   * @returns {HTMLTableCellElement|null}
   */ getEditedCell() {
        if (this.row === null || this.col === null) {
            return null;
        }
        return this.hot.getCell(this.row, this.col, true);
    }
    /**
   * Returns name of the overlay, where editor is placed.
   *
   * @private
   * @returns {string}
   */ checkEditorSection() {
        if (this.row === null || this.col === null) {
            return '';
        }
        const totalRows = this.hot.countRows();
        const settings = this.hot.getSettings();
        let section = '';
        if (this.row < (settings.fixedRowsTop ?? 0)) {
            if (this.col < (settings.fixedColumnsStart ?? 0)) {
                section = 'top-inline-start-corner';
            } else {
                section = 'top';
            }
        } else if (settings.fixedRowsBottom && this.row >= totalRows - settings.fixedRowsBottom) {
            if (this.col < (settings.fixedColumnsStart ?? 0)) {
                section = 'bottom-inline-start-corner';
            } else {
                section = 'bottom';
            }
        } else if (this.col < (settings.fixedColumnsStart ?? 0)) {
            section = 'inline-start';
        }
        return section;
    }
    /**
   * @param {Handsontable} hotInstance A reference to the source instance of the Handsontable.
   */ constructor(hotInstance){
        _class_private_method_init(this, _calcCellTopOffset);
        _class_private_method_init(this, _calcCellStartOffset);
        /**
   * Editor's state.
   *
   * @type {string}
   */ this.state = EDITOR_STATE.VIRGIN;
        /**
   * Flag to store information about editor's opening status.
   *
   * @private
   *
   * @type {boolean}
   */ this._opened = false;
        /**
   * Defines the editor's editing mode. When false, then an editor works in fast editing mode.
   *
   * @private
   *
   * @type {boolean}
   */ this._fullEditMode = false;
        /**
   * Callback to call after closing editor.
   *
   * @private
   *
   * @type {Function}
   */ this._closeCallback = null;
        /**
   * Flag to specify if the editor should be closed after data change.
   *
   * @type {boolean}
   */ this._closeAfterDataChange = true;
        /**
   * Currently rendered cell's `TD` element.
   *
   * @type {HTMLTableCellElement}
   */ this.TD = null;
        /**
   * Visual row index.
   *
   * @type {number}
   */ this.row = null;
        /**
   * Visual column index.
   *
   * @type {number}
   */ this.col = null;
        /**
   * Column property name or a column index, if datasource is an array of arrays.
   *
   * @type {number|string}
   */ this.prop = null;
        /**
   * Original cell's value.
   *
   * @type {*}
   */ this.originalValue = null;
        this.hot = hotInstance;
        this.init();
    }
}
function calcCellTopOffset(TD, overlayName, firstRowOffset, verticalScrollPosition, scrollbarWidth) {
    let cellTopOffset = TD.offsetTop;
    const { wtOverlays } = this.hot.view._wt;
    if ([
        'inline_start',
        'master'
    ].includes(overlayName)) {
        cellTopOffset += firstRowOffset - verticalScrollPosition;
    }
    if ([
        'bottom',
        'bottom_inline_start_corner'
    ].includes(overlayName) && wtOverlays.bottomOverlay?.clone) {
        const { wtViewport: bottomWtViewport, wtTable: bottomWtTable } = wtOverlays.bottomOverlay.clone;
        cellTopOffset += bottomWtViewport.getWorkspaceHeight() - bottomWtTable.getHeight() - scrollbarWidth;
    }
    return cellTopOffset;
}
function calcCellStartOffset(TD, overlayName, overlayTable, cellWidth, firstColumnOffset, horizontalScrollPosition) {
    let cellStartOffset = TD.offsetLeft;
    if (this.hot.isRtl()) {
        if (cellStartOffset >= 0) {
            cellStartOffset = overlayTable.getWidth() - TD.offsetLeft;
        } else {
            // The `offsetLeft` returns negative values when the parent offset element has position relative
            // (it happens when on the cell the selection is applied - the `area` CSS class).
            // When it happens the `offsetLeft` value is calculated from the right edge of the parent element.
            cellStartOffset = Math.abs(cellStartOffset);
        }
        cellStartOffset += firstColumnOffset - horizontalScrollPosition - cellWidth;
    } else if ([
        'top',
        'master',
        'bottom'
    ].includes(overlayName)) {
        cellStartOffset += firstColumnOffset - horizontalScrollPosition;
    }
    return cellStartOffset;
}
(0, _object.mixin)(BaseEditor, _hooksRefRegisterer.default);
