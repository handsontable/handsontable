"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BaseEditor () {
        return _baseEditor.BaseEditor;
    },
    get EDITOR_STATE () {
        return _baseEditor.EDITOR_STATE;
    },
    get EDITOR_TYPE () {
        return _baseEditor.EDITOR_TYPE;
    }
});
const _baseEditor = require("./baseEditor");
