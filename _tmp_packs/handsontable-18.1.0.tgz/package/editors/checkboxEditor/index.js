"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CheckboxEditor () {
        return _checkboxEditor.CheckboxEditor;
    },
    get EDITOR_TYPE () {
        return _checkboxEditor.EDITOR_TYPE;
    }
});
const _checkboxEditor = require("./checkboxEditor");
