"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CheckboxEditor () {
        return CheckboxEditor;
    },
    get EDITOR_TYPE () {
        return EDITOR_TYPE;
    }
});
const _baseEditor = require("../baseEditor");
const _element = require("../../helpers/dom/element");
const EDITOR_TYPE = 'checkbox';
class CheckboxEditor extends _baseEditor.BaseEditor {
    /**
   * Returns the unique editor type identifier for the checkbox editor.
   */ static get EDITOR_TYPE() {
        return EDITOR_TYPE;
    }
    /**
   * Handles the mouseup event on the cell TD element to trigger a checkbox click via a double-click interaction.
   */ beginEditing(initialValue, event) {
        // Just some events connected with the checkbox editor are delegated here. Some `keydown` events like `enter` and
        // `space` key presses are handled inside `checkboxRenderer`. Some events come here from `editorManager`. The below
        // `if` statement was created by the author for the purpose of handling only the `doubleclick` event on the TD
        // element with a checkbox.
        if (event && event.type === 'mouseup' && (0, _element.eventTargetEl)(event).nodeName === 'TD') {
            const checkbox = this.TD.querySelector('input[type="checkbox"]');
            if (!(0, _element.hasClass)(checkbox, 'htBadValue')) {
                checkbox.click();
            }
        }
    }
    /**
   * No-op override — the checkbox editor does not perform a finish step.
   */ finishEditing() {}
    /**
   * No-op override — the checkbox editor requires no DOM initialization.
   */ init() {}
    /**
   * No-op override — the checkbox editor has no visible editing element to open.
   */ open() {}
    /**
   * No-op override — the checkbox editor has no visible editing element to close.
   */ close() {}
    /**
   * Returns undefined because checkbox state is written directly to the cell; no separate value is held.
   */ getValue() {
        return undefined;
    }
    /**
   * No-op override — the checkbox editor writes its value directly via DOM events.
   */ setValue() {}
    /**
   * No-op override — the checkbox editor delegates focus to the native checkbox element.
   */ focus() {}
}
