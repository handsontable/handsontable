"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AutocompleteEditor () {
        return _autocompleteEditor.AutocompleteEditor;
    },
    get EDITOR_TYPE () {
        return _autocompleteEditor.EDITOR_TYPE;
    }
});
const _autocompleteEditor = require("./autocompleteEditor");
