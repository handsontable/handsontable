"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AutocompleteEditor () {
        return AutocompleteEditor;
    },
    get EDITOR_TYPE () {
        return EDITOR_TYPE;
    }
});
const _handsontableEditor = require("../handsontableEditor");
const _array = require("../../helpers/array");
const _object = require("../../helpers/object");
const _element = require("../../helpers/dom/element");
const _mixed = require("../../helpers/mixed");
const _string = require("../../helpers/string");
const _unicode = require("../../helpers/unicode");
const _textRenderer = require("../../renderers/textRenderer");
const _a11y = require("../../helpers/a11y");
const _function = require("../../helpers/function");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
const EDITOR_TYPE = 'autocomplete';
var /**
   * Holds the prefix of the editor's id.
   *
   * @type {string}
   */ _idPrefix = /*#__PURE__*/ new WeakMap(), /**
   * Runs focus method after debounce.
   */ _focusDebounced = /*#__PURE__*/ new WeakMap(), /**
   * Fix width of the internal Handsontable's instance when editor has vertical scroll.
   */ _fixDropdownWidth = /*#__PURE__*/ new WeakSet(), /**
   * Checks if the value is a key/value object.
   *
   * @param {*} value The value to check.
   * @returns {boolean}
   */ _isKeyValueObject = /*#__PURE__*/ new WeakSet();
class AutocompleteEditor extends _handsontableEditor.HandsontableEditor {
    /**
   * Returns the unique editor type identifier for the autocomplete editor.
   */ static get EDITOR_TYPE() {
        return EDITOR_TYPE;
    }
    /**
   * Gets current value from editable element.
   *
   * @returns {string}
   */ getValue() {
        const selectedValue = this.rawChoices.find((value)=>{
            const strippedValue = this.stripValueIfNeeded(value);
            const resolvedValue = _class_private_method_get(this, _isKeyValueObject, isKeyValueObject).call(this, strippedValue) ? strippedValue.value : strippedValue;
            return resolvedValue === this.TEXTAREA.value;
        });
        if ((0, _mixed.isDefined)(selectedValue)) {
            return selectedValue;
        }
        return this.TEXTAREA.value;
    }
    /**
   * Creates an editor's elements and adds necessary CSS classnames.
   */ createElements() {
        super.createElements();
        (0, _element.addClass)(this.htContainer, 'autocompleteEditor');
        (0, _element.addClass)(this.htContainer, this.hot.rootWindow.navigator.platform.indexOf('Mac') === -1 ? '' : 'htMacScroll');
        if (this.hot.getSettings().ariaTags) {
            (0, _element.setAttribute)(this.TEXTAREA, [
                (0, _a11y.A11Y_TEXT)(),
                (0, _a11y.A11Y_COMBOBOX)(),
                (0, _a11y.A11Y_HASPOPUP)('listbox'),
                (0, _a11y.A11Y_AUTOCOMPLETE)()
            ]);
        }
    }
    /**
   * Prepares editor's metadata and configuration of the internal Handsontable's instance.
   *
   * @param {number} row The visual row index.
   * @param {number} col The visual column index.
   * @param {number|string} prop The column property (passed when datasource is an array of objects).
   * @param {HTMLTableCellElement} td The rendered cell element.
   * @param {*} value The rendered value.
   * @param {object} cellProperties The cell meta object (see {@link Core#getCellMeta}).
   */ prepare(row, col, prop, td, value, cellProperties) {
        super.prepare(row, col, prop, td, value, cellProperties);
        if (this.hot.getSettings().ariaTags) {
            (0, _element.setAttribute)(this.TEXTAREA, [
                (0, _a11y.A11Y_EXPANDED)('false'),
                (0, _a11y.A11Y_CONTROLS)(`${_class_private_field_get(this, _idPrefix)}-listbox-${row}-${col}`)
            ]);
        }
        this.htOptions = {
            ...this.htOptions,
            valueGetter: (cellValue)=>_class_private_method_get(this, _isKeyValueObject, isKeyValueObject).call(this, cellValue) ? cellValue.value : cellValue
        };
    }
    /**
   * Opens the editor and adjust its size and internal Handsontable's instance.
   */ open() {
        super.open();
        const trimDropdownSetting = this.cellProperties.trimDropdown;
        const trimDropdown = trimDropdownSetting === undefined ? true : trimDropdownSetting;
        const rootInstanceAriaTagsEnabled = this.hot.getSettings().ariaTags;
        const sourceArray = Array.isArray(this.cellProperties.source) ? this.cellProperties.source : null;
        const sourceSize = sourceArray?.length;
        const { row: rowIndex, col: colIndex } = this;
        this.showEditableElement();
        this.focus();
        this.addHook('beforeKeyDown', (event)=>this.onBeforeKeyDown(event));
        this.htEditor.addHook('afterScroll', _class_private_field_get(this, _focusDebounced));
        this.htEditor.updateSettings({
            colWidths: trimDropdown ? [
                (0, _element.outerWidth)(this.TEXTAREA) - 2
            ] : undefined,
            autoColumnSize: true,
            // With `trimDropdown: false` the list column is sized from its content by
            // AutoColumnSize, so short options produced a list narrower than the edited
            // cell (#13180). Floor the column at the cell width: the option rows stay
            // full-width click targets, and `getTargetEditorWidth()` (which reads
            // `getColWidth(0)`) widens the outer container to match automatically.
            modifyColWidth: trimDropdown ? undefined : (width)=>{
                return Math.max(width ?? 0, (0, _element.outerWidth)(this.TEXTAREA) - 2);
            },
            renderer: (hotInstance, TD, row, col, prop, value, cellProperties)=>{
                (0, _textRenderer.textRenderer)(hotInstance, TD, row, col, prop, value, cellProperties);
                const { filteringCaseSensitive, allowHtml } = this.cellProperties;
                const locale = this.cellProperties.locale;
                const query = this.query;
                const cellValue = (0, _mixed.stringify)(value);
                if (allowHtml) {
                    // `allowHtml` is an explicit opt-in to raw HTML, disabled by default and warned about in
                    // its own documentation. PR #7368 turned sanitizing off for it and for the `html` cell
                    // type deliberately, and `autocompleteRenderer` still writes the cell that way, so the
                    // dropdown keeps matching it: `false` means raw, and silent about it.
                    //
                    // Going through `fastInnerHTML` rather than assigning `innerHTML` directly is what makes
                    // that a stated policy instead of an unguarded sink, and leaves one place to revisit if
                    // a configured `sanitizer` is ever made to cover this content.
                    //
                    // The scope argument is inert while the sanitizer is `false` - nothing reads an option
                    // and nothing warns. It is `this.hot.rootElement`, not the `hotInstance` argument,
                    // because this renderer runs inside `htEditor`, a separate Handsontable instance with
                    // its own settings. That matters the moment the `false` above is revisited: reading the
                    // option off the argument would silently consult the wrong grid.
                    (0, _element.fastInnerHTML)(TD, cellValue, false, 'html', this.hot.rootElement);
                } else if (cellValue && query && query.length > 0) {
                    const indexOfMatch = filteringCaseSensitive === true ? cellValue.indexOf(query) : (0, _string.localeLowerCase)(cellValue, locale).indexOf((0, _string.localeLowerCase)(query, locale));
                    if (indexOfMatch !== -1) {
                        const match = cellValue.slice(indexOfMatch, indexOfMatch + query.length);
                        const { rootDocument } = hotInstance;
                        TD.innerHTML = '';
                        TD.appendChild(rootDocument.createTextNode(cellValue.slice(0, indexOfMatch)));
                        const strong = rootDocument.createElement('strong');
                        strong.textContent = match;
                        TD.appendChild(strong);
                        TD.appendChild(rootDocument.createTextNode(cellValue.slice(indexOfMatch + query.length)));
                    }
                }
                if (rootInstanceAriaTagsEnabled) {
                    (0, _element.setAttribute)(TD, [
                        (0, _a11y.A11Y_OPTION)(),
                        // Add `setsize` and `posinset` only if the source is an array.
                        ...sourceArray ? [
                            (0, _a11y.A11Y_SETSIZE)(sourceSize ?? 0)
                        ] : [],
                        ...sourceArray ? [
                            (0, _a11y.A11Y_POSINSET)(sourceArray.indexOf(value) + 1)
                        ] : [],
                        [
                            'id',
                            `${this.htEditor.rootElement.id}_${row}-${col}`
                        ]
                    ]);
                }
            },
            afterSelectionEnd: (startRow, startCol)=>{
                if (rootInstanceAriaTagsEnabled) {
                    const setA11yAttributes = (TD)=>{
                        (0, _element.setAttribute)(TD, [
                            (0, _a11y.A11Y_SELECTED)()
                        ]);
                        (0, _element.setAttribute)(this.TEXTAREA, ...(0, _a11y.A11Y_ACTIVEDESCENDANT)(TD.id));
                    };
                    const TD = this.htEditor.getCell(startRow, startCol, true);
                    if (TD !== null) {
                        setA11yAttributes(TD);
                    } else {
                        // If TD is null, it means that the cell is not (yet) in the viewport.
                        // Moving the logic to after it's been scrolled to the requested cell.
                        this.htEditor.addHookOnce('afterScrollVertically', ()=>{
                            const renderedTD = this.htEditor.getCell(startRow, startCol, true);
                            if (renderedTD !== null) {
                                setA11yAttributes(renderedTD);
                            }
                        });
                    }
                }
            }
        });
        if (rootInstanceAriaTagsEnabled) {
            // Add `role=presentation` to the main table to prevent the readers from treating the option list as a table.
            const a11yPres = (0, _a11y.A11Y_PRESENTATION)();
            (0, _element.setAttribute)(this.htEditor.view._wt.wtOverlays.wtTable.TABLE, a11yPres[0], a11yPres[1]);
            (0, _element.setAttribute)(this.htEditor.rootElement, [
                (0, _a11y.A11Y_LISTBOX)(),
                (0, _a11y.A11Y_LIVE)('polite'),
                (0, _a11y.A11Y_RELEVANT)('text'),
                [
                    'id',
                    `${_class_private_field_get(this, _idPrefix)}-listbox-${rowIndex}-${colIndex}`
                ]
            ]);
            (0, _element.setAttribute)(this.TEXTAREA, ...(0, _a11y.A11Y_EXPANDED)('true'));
        }
        this.hot._registerTimeout(()=>{
            this.queryChoices(this.TEXTAREA.value);
        });
    }
    /**
   * Closes the editor.
   */ close() {
        this.removeHooksByKey('beforeKeyDown');
        super.close();
        if (this.hot.getSettings().ariaTags) {
            (0, _element.setAttribute)(this.TEXTAREA, [
                (0, _a11y.A11Y_EXPANDED)('false')
            ]);
        }
    }
    /**
   * Verifies result of validation or closes editor if user's cancelled changes.
   *
   * @param {boolean|undefined} result If `false` and the cell using allowInvalid option,
   *                                   then an editor won't be closed until validation is passed.
   */ discardEditor(result) {
        super.discardEditor(result);
        this.hot.view.render();
    }
    /**
   * Prepares choices list based on applied argument.
   *
   * @param {string} query The query.
   */ queryChoices(query) {
        const source = this.cellProperties.source;
        this.query = query;
        if (typeof source === 'function') {
            source.call(this.cellProperties, query, (choices)=>{
                this.rawChoices = choices;
                this.updateChoicesList(this.stripValuesIfNeeded(choices));
            });
        } else if (Array.isArray(source)) {
            this.rawChoices = source;
            this.updateChoicesList(this.stripValuesIfNeeded(source));
        } else {
            this.updateChoicesList([]);
        }
    }
    /**
   * Updates list of the possible completions to choose.
   *
   * @param {Array} choicesList The choices list to process.
   */ updateChoicesList(choicesList) {
        const pos = (0, _element.getCaretPosition)(this.TEXTAREA);
        const endPos = (0, _element.getSelectionEndPosition)(this.TEXTAREA);
        const sortByRelevanceSetting = this.cellProperties.sortByRelevance;
        const filterSetting = this.cellProperties.filter;
        const value = this.stripValueIfNeeded(this.getValue());
        const comparableValue = _class_private_method_get(this, _isKeyValueObject, isKeyValueObject).call(this, value) ? value.value : value;
        let highlightIndex = null;
        let choices = choicesList;
        if (!sortByRelevanceSetting) {
            // Sort a copy, never the passed-in array: `updateChoicesList` is public API and the caller's
            // array (typically the `source` setting) must keep its original order. `Array#toSorted` would
            // do this in one call but is outside the `browser-targets.js` baseline (Firefox 115+,
            // Safari 16+), and swc lowers syntax only — it adds no instance-method polyfills.
            choices = [
                ...choices
            ].sort((a, b)=>(0, _mixed.stringify)(a).localeCompare((0, _mixed.stringify)(b)));
        }
        const filteredChoiceIndexes = [];
        const locale = this.cellProperties.locale;
        const filteringCaseSensitive = this.cellProperties.filteringCaseSensitive;
        const valueToMatch = filteringCaseSensitive ? comparableValue : (0, _string.localeLowerCase)(String(comparableValue), locale);
        for(let i = 0; i < choices.length; i++){
            const currentItem = _class_private_method_get(this, _isKeyValueObject, isKeyValueObject).call(this, choices[i]) ? (0, _string.stripTags)((0, _mixed.stringify)(choices[i].value)) : (0, _string.stripTags)((0, _mixed.stringify)(choices[i]));
            const itemToMatch = filteringCaseSensitive ? currentItem : (0, _string.localeLowerCase)(currentItem, locale);
            if (itemToMatch.indexOf(String(valueToMatch)) !== -1) {
                filteredChoiceIndexes.push(i);
                if (filterSetting === false) {
                    break;
                }
            }
        }
        if (filterSetting === false) {
            if (String(value).length > 0) {
                highlightIndex = filteredChoiceIndexes[0];
            }
        } else {
            choices = filteredChoiceIndexes.map((index)=>choices[index]);
            highlightIndex = choices.indexOf(valueToMatch) > -1 ? choices.indexOf(valueToMatch) : 0;
        }
        this.strippedChoices = choices;
        if (choices.length === 0) {
            this.htEditor.rootElement.style.display = 'none';
        } else {
            this.htEditor.rootElement.style.display = '';
        }
        this.htEditor.loadData((0, _array.pivot)([
            choices
        ]));
        if (choices.length > 0) {
            this.updateDropdownDimensions();
            this.flipDropdownVerticallyIfNeeded();
            this.flipDropdownHorizontallyIfNeeded();
            if (this.cellProperties.strict === true) {
                this.highlightBestMatchingChoice(highlightIndex ?? undefined);
            }
        }
        this.hot.listen();
        (0, _element.setCaretPosition)(this.TEXTAREA, pos, pos === endPos ? undefined : endPos);
    }
    /**
   * Calculates the space above and below the editor and flips it vertically if needed.
   *
   * @private
   * @returns {{ isFlipped: boolean, spaceAbove: number, spaceBelow: number}}
   */ flipDropdownVerticallyIfNeeded() {
        const result = super.flipDropdownVerticallyIfNeeded();
        const { isFlipped, spaceAbove, spaceBelow } = result;
        this.limitDropdownIfNeeded(isFlipped ? spaceAbove : spaceBelow);
        return result;
    }
    /**
   * Checks if the internal table should generate scrollbar or could be rendered without it.
   *
   * @private
   * @param {number} spaceAvailable The free space as height defined in px available for dropdown list.
   */ limitDropdownIfNeeded(spaceAvailable) {
        const dropdownHeight = this.getDropdownHeight();
        if (dropdownHeight > spaceAvailable) {
            const rowHeight = this.htEditor.stylesHandler.getDefaultRowHeight() ?? 0;
            if (rowHeight === 0) {
                return;
            }
            // Show whole rows only, and stop one row short of the boundary: `Math.ceil(...) - 1` is the
            // exact arithmetic of the do/while this replaced ("add rows until one crosses the free
            // space, then step back a row"), so an exactly-fitting space still leaves its last row out.
            // That margin is deliberately preserved - the list is trimmed because it overflows the
            // workspace, and the rendered rows carry a border the raw row height does not.
            //
            // `Math.max(..., 1)` is the fix: without it the height collapsed to 0 whenever the free
            // space was not taller than a single row, rendering the list as an invisible sliver that hid
            // every choice - the flexbox-squeezed grids reported in #8872. The MultiSelect editor's
            // dropdown clamps to one entry the same way (`dropdownController.updateDimensions()`).
            //
            // A caveat this cannot solve here: the grid's root element gets `overflow: clip` whenever a
            // `height` is set, so when the free space is narrower than the forced row, that row is
            // partly clipped by the grid's bottom edge - fully so when the space reaches 0. Making it
            // readable in those extremes needs the dropdown to escape the clipping root (DEV-1656).
            //
            // No border compensation here, unlike `getTargetDropdownHeight()`'s `getTableHeight() + 1`.
            // Adding it was measured and changes nothing a user sees: the clipping root, not the list's
            // own budget, is what bounds the visible row, so the extra pixel only pushes the holder
            // further past the clip (main 31->32px holder, 28px of option visible either way; classic
            // 28->29 and 25; horizon 37->38 and 37).
            const rowsThatFit = Math.max(Math.ceil(spaceAvailable / rowHeight) - 1, 1);
            const height = rowsThatFit * rowHeight;
            if (this.isFlippedVertically) {
                this.htEditor.rootElement.style.top = `${parseInt(this.htEditor.rootElement.style.top, 10) + dropdownHeight - height}px`;
            }
            this.setDropdownHeight(height);
        }
    }
    /**
   * Updates width and height of the internal Handsontable's instance.
   *
   * @private
   */ updateDropdownDimensions() {
        const fractionalScalingCompensation = (0, _element.getFractionalScalingCompensation)();
        const targetWidth = this.getTargetEditorWidth() + fractionalScalingCompensation;
        const targetHeight = this.getTargetEditorHeight() + fractionalScalingCompensation;
        this.htEditor.updateSettings({
            width: targetWidth,
            height: targetHeight
        });
        _class_private_method_get(this, _fixDropdownWidth, fixDropdownWidth).call(this);
        this.htEditor.view._wt.wtTable.alignOverlaysWithTrimmingContainer();
    }
    /**
   * Sets new height of the internal Handsontable's instance.
   *
   * @private
   * @param {number} height The new dropdown height.
   */ setDropdownHeight(height) {
        this.htEditor.updateSettings({
            height
        });
        _class_private_method_get(this, _fixDropdownWidth, fixDropdownWidth).call(this);
        this.htEditor.view._wt.wtTable.alignOverlaysWithTrimmingContainer();
    }
    /**
   * Creates new selection on specified row index, or deselects selected cells.
   *
   * @private
   * @param {number|undefined} index The visual row index.
   */ highlightBestMatchingChoice(index) {
        if (typeof index === 'number') {
            this.htEditor.selectCell(index, 0, undefined, undefined, undefined, false);
        } else {
            this.htEditor.deselectCell();
        }
    }
    /**
   * Calculates the proposed/target editor height that should be set once the editor is opened.
   * The method may be overwritten in the child class to provide a custom size logic.
   *
   * @returns {number}
   */ getTargetEditorHeight() {
        let borderCompensation = 0;
        if (!this.hot.getCurrentThemeName()) {
            const htCoreElement = this.htContainer.querySelector('.htCore');
            if (htCoreElement) {
                const containerStyle = this.hot.rootWindow.getComputedStyle(htCoreElement);
                borderCompensation = parseInt(containerStyle.borderTopWidth, 10) + parseInt(containerStyle.borderBottomWidth, 10);
            }
        }
        const maxItems = Math.min(this.cellProperties.visibleRows, this.strippedChoices.length);
        const height = Array.from({
            length: maxItems
        }, (_, i)=>i).reduce((totalHeight, index)=>{
            // for the first row, we need to add 1px (border-top compensation)
            const rowHeight = (this.hot.stylesHandler.getDefaultRowHeight() ?? 0) + (index === 0 ? 1 : 0);
            return totalHeight + rowHeight;
        }, 0);
        return height + borderCompensation;
    }
    /**
   * Calculates the proposed/target editor width that should be set once the editor is opened.
   * The method may be overwritten in the child class to provide a custom size logic.
   *
   * @returns {number}
   */ getTargetEditorWidth() {
        let borderCompensation = 0;
        if (!this.hot.getCurrentThemeName()) {
            const htCoreElement = this.htContainer.querySelector('.htCore');
            if (htCoreElement) {
                const containerStyle = this.hot.rootWindow.getComputedStyle(htCoreElement);
                borderCompensation = parseInt(containerStyle.borderInlineStartWidth, 10) + parseInt(containerStyle.borderInlineEndWidth, 10);
            }
        }
        return this.htEditor.getColWidth(0) + borderCompensation;
    }
    /**
   * Sanitizes value from potential dangerous tags.
   *
   * @private
   * @param {string} value The value to sanitize.
   * @returns {string}
   */ stripValueIfNeeded(value) {
        return this.stripValuesIfNeeded([
            value
        ])[0];
    }
    /**
   * Sanitizes an array of the values from potential dangerous tags.
   *
   * @private
   * @param {string[]} values The value to sanitize.
   * @returns {Array<string|{key: string, value: string}>}
   */ stripValuesIfNeeded(values) {
        const { allowHtml } = this.cellProperties;
        const processValue = (value)=>(0, _mixed.stringify)(allowHtml ? value : (0, _string.stripTags)(String(value)));
        if (values.every((value)=>(0, _object.isKeyValueObject)(value))) {
            return values.map((value)=>{
                const obj = value;
                return {
                    key: processValue(obj.key),
                    value: processValue(obj.value)
                };
            });
        }
        return values.map((value)=>processValue(value));
    }
    /**
   * OnBeforeKeyDown callback.
   *
   * @private
   * @param {KeyboardEvent} event The keyboard event object.
   */ onBeforeKeyDown(event) {
        if ((0, _unicode.isPrintableChar)(event.keyCode) || event.keyCode === _unicode.KEY_CODES.BACKSPACE || event.keyCode === _unicode.KEY_CODES.DELETE || event.keyCode === _unicode.KEY_CODES.INSERT) {
            // for Windows 10 + FF86 there is need to add delay to make sure that the value taken from
            // the textarea is the freshest value. Otherwise the list of choices does not update correctly (see #7570).
            // On the more modern version of the FF (~ >=91) it seems that the issue is not present or it is
            // more difficult to induce.
            let timeOffset = 10;
            // on ctl+c / cmd+c don't update suggestion list
            if (event.keyCode === _unicode.KEY_CODES.C && (event.ctrlKey || event.metaKey)) {
                return;
            }
            if (!this.isOpened()) {
                timeOffset += 10;
            }
            if (this.htEditor) {
                this.hot._registerTimeout(()=>{
                    this.queryChoices(this.TEXTAREA.value);
                }, timeOffset);
            }
        }
    }
    constructor(...args){
        super(...args), _class_private_method_init(this, _fixDropdownWidth), _class_private_method_init(this, _isKeyValueObject), _class_private_field_init(this, _idPrefix, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _focusDebounced, {
            writable: true,
            value: void 0
        }), /**
   * Query string to turn available values over.
   *
   * @type {string}
   */ this.query = null, /**
   * Contains stripped choices.
   *
   * @type {string[]}
   */ this.strippedChoices = [], /**
   * Contains raw choices.
   *
   * @type {Array}
   */ this.rawChoices = [], _class_private_field_set(this, _idPrefix, this.hot.guid.slice(0, 9)), _class_private_field_set(this, _focusDebounced, (0, _function.debounce)(()=>{
            this.focus();
        }, 100));
    }
}
function fixDropdownWidth() {
    if (this.htEditor.view.hasVerticalScroll()) {
        this.htEditor.updateSettings({
            width: this.getTargetEditorWidth() + (0, _element.getScrollbarWidth)(this.hot.rootDocument)
        });
    }
}
function isKeyValueObject(value) {
    const rec = value;
    return (0, _object.isObject)(value) && (0, _mixed.isDefined)(rec.key) && (0, _mixed.isDefined)(rec.value);
}
