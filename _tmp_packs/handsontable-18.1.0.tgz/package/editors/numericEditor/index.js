"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EDITOR_TYPE () {
        return _numericEditor.EDITOR_TYPE;
    },
    get NumericEditor () {
        return _numericEditor.NumericEditor;
    }
});
const _numericEditor = require("./numericEditor");
