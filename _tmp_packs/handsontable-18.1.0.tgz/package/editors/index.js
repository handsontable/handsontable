"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get AUTOCOMPLETE_EDITOR () {
        return _autocompleteEditor.EDITOR_TYPE;
    },
    get AutocompleteEditor () {
        return _autocompleteEditor.AutocompleteEditor;
    },
    get BASE_EDITOR () {
        return _baseEditor.EDITOR_TYPE;
    },
    get BaseEditor () {
        return _baseEditor.BaseEditor;
    },
    get CHECKBOX_EDITOR () {
        return _checkboxEditor.EDITOR_TYPE;
    },
    get CheckboxEditor () {
        return _checkboxEditor.CheckboxEditor;
    },
    get DATE_EDITOR () {
        return _dateEditor.EDITOR_TYPE;
    },
    get DROPDOWN_EDITOR () {
        return _dropdownEditor.EDITOR_TYPE;
    },
    get DateEditor () {
        return _dateEditor.DateEditor;
    },
    get DropdownEditor () {
        return _dropdownEditor.DropdownEditor;
    },
    get HANDSONTABLE_EDITOR () {
        return _handsontableEditor.EDITOR_TYPE;
    },
    get HandsontableEditor () {
        return _handsontableEditor.HandsontableEditor;
    },
    get INTL_DATETIME_EDITOR () {
        return _intlDatetimeEditor.EDITOR_TYPE;
    },
    get INTL_DATE_EDITOR () {
        return _intlDateEditor.EDITOR_TYPE;
    },
    get INTL_TIME_EDITOR () {
        return _intlTimeEditor.EDITOR_TYPE;
    },
    get IntlDateEditor () {
        return _intlDateEditor.IntlDateEditor;
    },
    get IntlDatetimeEditor () {
        return _intlDatetimeEditor.IntlDatetimeEditor;
    },
    get IntlTimeEditor () {
        return _intlTimeEditor.IntlTimeEditor;
    },
    get MULTI_SELECT_EDITOR () {
        return _multiSelectEditor.EDITOR_TYPE;
    },
    get MultiSelectEditor () {
        return _multiSelectEditor.MultiSelectEditor;
    },
    get NUMERIC_EDITOR () {
        return _numericEditor.EDITOR_TYPE;
    },
    get NumericEditor () {
        return _numericEditor.NumericEditor;
    },
    get PASSWORD_EDITOR () {
        return _passwordEditor.EDITOR_TYPE;
    },
    get PasswordEditor () {
        return _passwordEditor.PasswordEditor;
    },
    get RegisteredEditor () {
        return _registry.RegisteredEditor;
    },
    get SELECT_EDITOR () {
        return _selectEditor.EDITOR_TYPE;
    },
    get SelectEditor () {
        return _selectEditor.SelectEditor;
    },
    get TEXT_EDITOR () {
        return _textEditor.EDITOR_TYPE;
    },
    get TIME_EDITOR () {
        return _timeEditor.EDITOR_TYPE;
    },
    get TextEditor () {
        return _textEditor.TextEditor;
    },
    get TimeEditor () {
        return _timeEditor.TimeEditor;
    },
    get _getEditorInstance () {
        return _registry._getEditorInstance;
    },
    get editorFactory () {
        return _factory.editorFactory;
    },
    get getEditor () {
        return _registry.getEditor;
    },
    get getEditorInstance () {
        return _registry.getEditorInstance;
    },
    get getRegisteredEditorNames () {
        return _registry.getRegisteredEditorNames;
    },
    get getRegisteredEditors () {
        return _registry.getRegisteredEditors;
    },
    get hasEditor () {
        return _registry.hasEditor;
    },
    get registerAllEditors () {
        return registerAllEditors;
    },
    get registerEditor () {
        return _registry.registerEditor;
    }
});
const _autocompleteEditor = require("./autocompleteEditor");
const _baseEditor = require("./baseEditor");
const _checkboxEditor = require("./checkboxEditor");
const _dateEditor = require("./dateEditor");
const _dropdownEditor = require("./dropdownEditor");
const _handsontableEditor = require("./handsontableEditor");
const _intlDateEditor = require("./intlDateEditor");
const _intlDatetimeEditor = require("./intlDatetimeEditor");
const _intlTimeEditor = require("./intlTimeEditor");
const _numericEditor = require("./numericEditor");
const _passwordEditor = require("./passwordEditor");
const _selectEditor = require("./selectEditor");
const _textEditor = require("./textEditor");
const _timeEditor = require("./timeEditor");
const _multiSelectEditor = require("./multiSelectEditor");
const _registry = require("./registry");
const _factory = require("./factory");
function registerAllEditors() {
    (0, _registry.registerEditor)(_baseEditor.BaseEditor);
    (0, _registry.registerEditor)(_autocompleteEditor.AutocompleteEditor);
    (0, _registry.registerEditor)(_checkboxEditor.CheckboxEditor);
    (0, _registry.registerEditor)(_dateEditor.DateEditor);
    (0, _registry.registerEditor)(_dropdownEditor.DropdownEditor);
    (0, _registry.registerEditor)(_handsontableEditor.HandsontableEditor);
    (0, _registry.registerEditor)(_intlDateEditor.IntlDateEditor);
    (0, _registry.registerEditor)(_intlDatetimeEditor.IntlDatetimeEditor);
    (0, _registry.registerEditor)(_intlTimeEditor.IntlTimeEditor);
    (0, _registry.registerEditor)(_numericEditor.NumericEditor);
    (0, _registry.registerEditor)(_passwordEditor.PasswordEditor);
    (0, _registry.registerEditor)(_selectEditor.SelectEditor);
    (0, _registry.registerEditor)(_textEditor.TextEditor);
    (0, _registry.registerEditor)(_timeEditor.TimeEditor);
    (0, _registry.registerEditor)(_multiSelectEditor.MultiSelectEditor);
}
