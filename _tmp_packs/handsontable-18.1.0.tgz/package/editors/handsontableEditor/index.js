"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EDITOR_TYPE () {
        return _handsontableEditor.EDITOR_TYPE;
    },
    get HandsontableEditor () {
        return _handsontableEditor.HandsontableEditor;
    }
});
const _handsontableEditor = require("./handsontableEditor");
