"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EDITOR_TYPE () {
        return _textEditor.EDITOR_TYPE;
    },
    get TextEditor () {
        return _textEditor.TextEditor;
    }
});
const _textEditor = require("./textEditor");
