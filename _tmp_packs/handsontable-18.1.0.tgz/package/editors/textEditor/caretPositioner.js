"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "updateCaretPosition", {
    enumerable: true,
    get: function() {
        return updateCaretPosition;
    }
});
const _element = require("../../helpers/dom/element");
function updateCaretPosition(actionName, textareaElement) {
    const caretPosition = (0, _element.getCaretPosition)(textareaElement);
    const textLines = textareaElement.value.split('\n');
    let newCaretPosition = caretPosition;
    let lineStartIndex = 0;
    for(let i = 0; i < textLines.length; i++){
        const textLine = textLines[i];
        if (i !== 0) {
            lineStartIndex += textLines[i - 1].length + 1;
        }
        const lineEndIndex = lineStartIndex + textLine.length;
        if (actionName === 'home') {
            newCaretPosition = lineStartIndex;
        } else if (actionName === 'end') {
            newCaretPosition = lineEndIndex;
        }
        if (caretPosition <= lineEndIndex) {
            break;
        }
    }
    (0, _element.setCaretPosition)(textareaElement, newCaretPosition, newCaretPosition);
}
