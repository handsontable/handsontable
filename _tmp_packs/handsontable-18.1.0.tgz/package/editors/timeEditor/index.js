"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EDITOR_TYPE () {
        return _timeEditor.EDITOR_TYPE;
    },
    get TimeEditor () {
        return _timeEditor.TimeEditor;
    }
});
const _timeEditor = require("./timeEditor");
