"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get EDITOR_TYPE () {
        return _passwordEditor.EDITOR_TYPE;
    },
    get PasswordEditor () {
        return _passwordEditor.PasswordEditor;
    }
});
const _passwordEditor = require("./passwordEditor");
