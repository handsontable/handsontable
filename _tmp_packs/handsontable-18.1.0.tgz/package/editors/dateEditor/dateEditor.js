"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DateEditor () {
        return DateEditor;
    },
    get EDITOR_TYPE () {
        return EDITOR_TYPE;
    }
});
const _textEditor = require("../textEditor");
const _dateTime = require("../../helpers/dateTime");
const _console = require("../../helpers/console");
const _templateLiteralTag = require("../../helpers/templateLiteralTag");
const _mixed = require("../../helpers/mixed");
const EDITOR_TYPE = 'date';
class DateEditor extends _textEditor.TextEditor {
    /**
   * Returns the unique editor type identifier for the date editor.
   */ static get EDITOR_TYPE() {
        return EDITOR_TYPE;
    }
    /**
   * Initializes the editor and registers an afterSetTheme hook to close on theme changes.
   */ init() {
        super.init();
        this.hot.addHook('afterSetTheme', (themeName, firstRun)=>{
            if (!firstRun) {
                this.close();
            }
        });
    }
    /**
   * Prepares the editor, replacing the display value with the raw ISO source data for the native date input.
   */ prepare(row, col, prop, td, value, cellProperties) {
        super.prepare(row, col, prop, td, value, cellProperties);
        if (cellProperties.datePickerConfig !== undefined) {
            (0, _console.warnOnce)(this.hot.rootElement, 'datePickerConfig', 'The "datePickerConfig" option is not supported. The native date input is used instead of Pikaday.');
        }
        // The value passed to prepare() is the formatted display value (from valueFormatter).
        // Replace originalValue with the raw source data so the native date input receives an ISO string.
        const physicalRow = this.hot.toPhysicalRow(row);
        this.originalValue = this.hot.getSourceDataAtCell(physicalRow, col);
    }
    /**
   * Creates the editor's textarea element as a native date input.
   */ createElements(type) {
        super.createElements('input');
        this.TEXTAREA.setAttribute('type', 'date');
    }
    /**
   * Sets the editor value, falling back to `defaultDate` when the value is empty, and warns if the value is not a valid ISO date string.
   */ setValue(value) {
        if ((0, _mixed.isEmpty)(value)) {
            value = this.cellProperties.defaultDate;
        }
        if (!(0, _dateTime.isValidISODate)(value)) {
            (0, _console.warn)((0, _templateLiteralTag.toSingleLine)`DateEditor: value must be in ISO date format ("YYYY-MM-DD")\x20
        required by the native date input. Received:`, value);
            super.setValue('');
            return;
        }
        super.setValue(value);
    }
    /**
   * Selects all text in the date input element when the editor receives focus.
   */ focus() {
        this.TEXTAREA.select();
    }
    /**
   * Opens the editor and programmatically invokes the native date picker via showPicker().
   */ open() {
        super.open();
        try {
            this.TEXTAREA.showPicker();
        } catch  {
        // Prevents showPicker() user-gesture errors in tests
        }
    }
}
