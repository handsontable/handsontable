"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DropdownEditor () {
        return DropdownEditor;
    },
    get EDITOR_TYPE () {
        return EDITOR_TYPE;
    }
});
const _autocompleteEditor = require("../autocompleteEditor");
const _mixed = require("../../helpers/mixed");
const EDITOR_TYPE = 'dropdown';
class DropdownEditor extends _autocompleteEditor.AutocompleteEditor {
    /**
   * Returns the unique editor type identifier for the dropdown editor.
   */ static get EDITOR_TYPE() {
        return EDITOR_TYPE;
    }
    /**
   * @param {number} row The visual row index.
   * @param {number} col The visual column index.
   * @param {number|string} prop The column property (passed when datasource is an array of objects).
   * @param {HTMLTableCellElement} td The rendered cell element.
   * @param {*} value The rendered value.
   * @param {object} cellProperties The cell meta object (see {@link Core#getCellMeta}).
   */ prepare(row, col, prop, td, value, cellProperties) {
        cellProperties.filter = false;
        cellProperties.strict = true;
        super.prepare(row, col, prop, td, value, cellProperties);
    }
    /**
   * Finishes editing and start saving or restoring process for editing cell or last selected range.
   *
   * @param {boolean} restoreOriginalValue If true, then closes editor without saving value from the editor into a cell.
   * @param {boolean} ctrlDown If true, then saveValue will save editor's value to each cell in the last selected range.
   * @param {Function} callback The callback function, fired after editor closing.
   */ finishEditing(restoreOriginalValue, ctrlDown, callback) {
        if (this.isOpened()) {
            const lastSelectedRange = this.hot.getSelectedRangeActive();
            if ((0, _mixed.isUndefined)(lastSelectedRange) || (0, _mixed.isDefined)(lastSelectedRange) && !lastSelectedRange.includes(this.hot._createCellCoords(this.row, this.col))) {
                restoreOriginalValue = true;
            }
        }
        super.finishEditing(restoreOriginalValue, ctrlDown, callback);
    }
}
