"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "editorFactory", {
    enumerable: true,
    get: function() {
        return editorFactory;
    }
});
const _baseEditor = require("./baseEditor/baseEditor");
const _eventManager = /*#__PURE__*/ _interop_require_default(require("../eventManager"));
const _errors = require("../helpers/errors");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * The shortcuts group used when the editor does not define its own `shortcutsGroup`.
 */ const DEFAULT_SHORTCUTS_GROUP = 'customEditor';
const editorBaseFactory = (params)=>{
    const CustomBaseEditor = _baseEditor.BaseEditor.prototype.extend();
    const skipSuperApply = [
        'close',
        'focus',
        'getValue',
        'open',
        'setValue'
    ];
    const prototypeFns = Object.getOwnPropertyNames(_baseEditor.BaseEditor.prototype);
    const proto = CustomBaseEditor.prototype;
    prototypeFns.forEach((fnName)=>{
        if (params[fnName]) {
            const superFn = CustomBaseEditor.prototype[fnName];
            proto[fnName] = function(...args) {
                if (!skipSuperApply.includes(fnName)) {
                    superFn.apply(this, args);
                }
                return params[fnName](this, ...args);
            };
        }
    });
    Object.keys(params).forEach((fnName)=>{
        if (!prototypeFns.includes(fnName)) {
            proto[fnName] = function(...args) {
                return params[fnName](this, ...args);
            };
        }
    });
    return CustomBaseEditor;
};
const editorFactory = ({ init, afterOpen, afterInit, afterClose, beforeOpen, getValue, setValue, onFocus, shortcuts, value, render, config, shortcutsGroup, position, ...args })=>{
    const registerShortcuts = (editor)=>{
        const shortcutManager = editor.hot.getShortcutManager();
        const editorContext = shortcutManager.getContext('editor');
        const contextConfig = {
            group: shortcutsGroup ?? DEFAULT_SHORTCUTS_GROUP
        };
        if (shortcuts) {
            editorContext.addShortcuts(shortcuts.map((shortcut)=>({
                    ...shortcut,
                    relativeToGroup: shortcut.relativeToGroup ?? 'editorManager.handlingEditor',
                    position: shortcut.position ?? 'before',
                    callback: (event)=>shortcut.callback(editor, event)
                })), contextConfig);
        }
    };
    return editorBaseFactory({
        init (editor) {
            Object.assign(editor, {
                value,
                config,
                render,
                position,
                ...args
            });
            editor._opened = false;
            editor.container = editor.hot.rootDocument.createElement('div');
            editor.container.style.display = 'none';
            if (position === 'portal') {
                editor.hot.rootPortalElement.appendChild(editor.container);
            } else {
                editor.hot.rootElement.appendChild(editor.container);
            }
            init(editor);
            if (!editor.input) {
                (0, _errors.throwWithCause)('Input is not assigned. Assign it in the init callback.');
            }
            editor.container.appendChild(editor.input);
            if (typeof afterInit === 'function') {
                afterInit(editor);
            }
            if (editor.preventCloseElement && editor.preventCloseElement instanceof HTMLElement) {
                editor.eventManager = new _eventManager.default(editor.hot);
                editor.eventManager.addEventListener(editor.preventCloseElement, 'mousedown', (event)=>{
                    event.stopPropagation();
                });
            }
            editor.addHook('afterScrollHorizontally', ()=>editor.refreshDimensions?.());
            editor.addHook('afterScrollVertically', ()=>editor.refreshDimensions?.());
        },
        getValue (editor) {
            if (typeof getValue === 'function') {
                return getValue(editor);
            }
            return editor.value;
        },
        setValue (editor, _value) {
            if (typeof setValue === 'function') {
                setValue(editor, _value);
            } else {
                editor.value = _value;
            }
            if (typeof render === 'function') {
                render(editor);
            }
        },
        refreshDimensions (editor) {
            editor.TD = editor.getEditedCell();
            if (!editor.TD) {
                editor.close();
                return;
            }
            if (!editor._opened) {
                return;
            }
            const containerStyle = editor.container.style;
            containerStyle.display = 'block';
            containerStyle.position = 'absolute';
            if (position === 'portal') {
                const _offset = editor.TD.getBoundingClientRect();
                containerStyle.top = `${editor.hot.rootWindow.pageYOffset + _offset.top}px`;
                containerStyle[editor.hot.isRtl() ? 'right' : 'left'] = `${editor.hot.rootWindow.pageXOffset + _offset[editor.hot.isRtl() ? 'right' : 'left']}px`;
            } else {
                const rect = editor.getEditedCellRect();
                if (!rect) {
                    return;
                }
                containerStyle.top = `${rect.top}px`;
                containerStyle[editor.hot.isRtl() ? 'right' : 'left'] = `${rect.start}px`;
                containerStyle.width = `${rect.width}px`;
                containerStyle.height = `${rect.height}px`;
            }
        },
        open (editor, event) {
            editor.container.classList.add('ht_clone_master');
            editor._opened = true;
            editor.refreshDimensions?.();
            editor.hot.getShortcutManager().setActiveContextName('editor');
            registerShortcuts(editor);
            if (afterOpen) {
                afterOpen(editor, event);
            }
        },
        focus (editor) {
            if (typeof onFocus === 'function') {
                onFocus(editor);
            } else {
                const focusable = editor.container?.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
                focusable?.focus();
            }
        },
        close (editor) {
            editor._opened = false;
            editor.container.style.display = 'none';
            editor.container.classList.remove('ht_clone_master');
            const shortcutManager = editor.hot.getShortcutManager();
            const editorContext = shortcutManager.getContext('editor');
            editorContext.removeShortcutsByGroup(shortcutsGroup ?? DEFAULT_SHORTCUTS_GROUP);
            if (typeof afterClose === 'function') {
                afterClose(editor);
            }
        },
        prepare (editor, row, col, prop, td, originalValue, cellProperties) {
            if (typeof beforeOpen === 'function') {
                beforeOpen(editor, {
                    row,
                    col,
                    prop,
                    td,
                    originalValue,
                    cellProperties
                });
            } else {
                editor.setValue(originalValue);
            }
        }
    });
};
