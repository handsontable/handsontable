"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "FocusGridManager", {
    enumerable: true,
    get: function() {
        return FocusGridManager;
    }
});
const _eventManager = /*#__PURE__*/ _interop_require_default(require("../eventManager"));
const _console = require("../helpers/console");
const _element = require("../helpers/dom/element");
const _function = require("../helpers/function");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
/**
 * Possible focus modes.
 * - CELL - The browser's focus stays on the lastly selected cell element.
 * - MIXED - The browser's focus switches from the lastly selected cell element to the currently active editor's
 * `TEXTAREA` element after a delay defined in the manager.
 *
 * @type {{CELL: string, MIXED: string}}
 */ const FOCUS_MODES = Object.freeze({
    CELL: 'cell',
    MIXED: 'mixed'
});
var /**
   * The Handsontable instance.
   */ _hot = /*#__PURE__*/ new WeakMap(), /**
   * Event manager used for the DOM listeners that track the browser focus within the grid.
   *
   * @type {EventManager}
   */ _eventManager1 = /*#__PURE__*/ new WeakMap(), /**
   * Tracks whether the browser focus currently sits inside the grid's root wrapper or portal.
   * Maintained by `focusin`/`focusout` listeners bound within the grid's own DOM tree, where
   * sandboxed hosts (e.g. Salesforce Lightning Web Security) still report true event targets -
   * unlike `document.activeElement`, which such hosts collapse to the outermost shadow host.
   *
   * @type {boolean}
   */ _hasBrowserFocus = /*#__PURE__*/ new WeakMap(), /**
   * The currently enabled focus mode.
   * Can be either:
   *
   * - 'cell' - The browser's focus stays on the lastly selected cell element.
   * - 'mixed' - The browser's focus switches from the lastly selected cell element to the currently active editor's
   * `TEXTAREA` element after a delay defined in the manager.
   *
   * @type {'cell' | 'mixed'}
   */ _focusMode = /*#__PURE__*/ new WeakMap(), /**
   * The delay after which the focus switches from the lastly selected cell to the active editor's `TEXTAREA`
   * element if the focus mode is set to 'mixed'.
   *
   * @type {number}
   */ _refocusDelay = /*#__PURE__*/ new WeakMap(), /**
   * Getter function for the element to be used when refocusing the browser after a delay. If `null`, the active
   * editor's `TEXTAREA` element will be used.
   *
   * @type {null|Function}
   */ _refocusElementGetter = /*#__PURE__*/ new WeakMap(), /**
   * Map of the debounced `select` functions.
   *
   * @type {Map<number, Function>}
   */ _debouncedSelect = /*#__PURE__*/ new WeakMap(), /**
   * Flag to indicate if the selection has changed.
   *
   * @type {boolean}
   */ _hasSelectionChange = /*#__PURE__*/ new WeakMap(), /**
   * Flag indicating whether automatic focus management for the upcoming selection cycle is suspended.
   * When `true`, `#focusCell` does not steal an externally focused input/textarea/select element,
   * and `#focusEditorElement` does not refocus the editor textarea. Set with `suspend()` and
   * cleared with `resume()`. Mirrors the `viewportScroller.suspend()/resume()` pattern.
   *
   * @type {boolean}
   */ _isSuspended = /*#__PURE__*/ new WeakMap(), /**
   * Get and return the currently selected and highlighted cell/header element.
   *
   * @param {Function} callback Callback function to be called after the cell element is retrieved.
   */ _getSelectedCell = /*#__PURE__*/ new WeakSet(), /**
   * Manage the browser's focus after each cell selection change.
   */ _focusCell = /*#__PURE__*/ new WeakSet(), /**
   * Manage the browser's focus after cell selection end.
   */ _focusEditorElement = /*#__PURE__*/ new WeakSet(), /**
   * Handle the after selection change event.
   */ _onAfterSelectionChange = /*#__PURE__*/ new WeakSet(), /**
   * Focuses the cell after the render event when the selection has changed.
   */ _onAfterRender = /*#__PURE__*/ new WeakSet(), /**
   * Update the manager configuration after calling `updateSettings`.
   *
   * @param {object} newSettings The new settings passed to the `updateSettings` method.
   */ _onUpdateSettings = /*#__PURE__*/ new WeakSet();
class FocusGridManager {
    /**
   * Registers hooks to track selection changes and apply focus logic based on the configured focus mode.
   */ init() {
        const hotSettings = _class_private_field_get(this, _hot).getSettings();
        _class_private_field_set(this, _focusMode, hotSettings.imeFastEdit ? FOCUS_MODES.MIXED : FOCUS_MODES.CELL);
        _class_private_field_get(this, _hot).addHook('afterUpdateSettings', (...args)=>_class_private_method_get(this, _onUpdateSettings, onUpdateSettings).call(this, args[0]));
        _class_private_field_get(this, _hot).addHook('afterSelection', (...args)=>_class_private_method_get(this, _onAfterSelectionChange, onAfterSelectionChange).call(this));
        _class_private_field_get(this, _hot).addHook('afterSelectionFocusSet', (...args)=>_class_private_method_get(this, _onAfterSelectionChange, onAfterSelectionChange).call(this));
        _class_private_field_get(this, _hot).addHook('afterSelectionEnd', (...args)=>_class_private_method_get(this, _focusEditorElement, focusEditorElement).call(this));
        _class_private_field_get(this, _hot).addHook('afterRender', (...args)=>_class_private_method_get(this, _onAfterRender, onAfterRender).call(this));
        _class_private_field_set(this, _eventManager1, new _eventManager.default(_class_private_field_get(this, _hot)));
        const focusRootElements = [
            _class_private_field_get(this, _hot).rootWrapperElement ?? _class_private_field_get(this, _hot).rootElement,
            _class_private_field_get(this, _hot).rootPortalElement
        ].filter((element)=>(0, _element.isHTMLElement)(element));
        focusRootElements.forEach((focusRootElement)=>{
            _class_private_field_get(this, _eventManager1).addEventListener(focusRootElement, 'focusin', ()=>{
                _class_private_field_set(this, _hasBrowserFocus, true);
            });
            _class_private_field_get(this, _eventManager1).addEventListener(focusRootElement, 'focusout', (event)=>{
                const relatedTarget = event.relatedTarget;
                _class_private_field_set(this, _hasBrowserFocus, (0, _element.isHTMLElement)(relatedTarget) && focusRootElements.some((focusRoot)=>focusRoot.contains(relatedTarget)));
            });
        });
    }
    /**
   * Checks whether the browser focus currently sits inside the grid's root wrapper or portal.
   * The state comes from focus events observed within the grid's own DOM tree, so it stays
   * correct in environments where `document.activeElement` cannot be resolved through foreign
   * shadow boundaries.
   *
   * @returns {boolean}
   */ hasBrowserFocus() {
        return _class_private_field_get(this, _hasBrowserFocus);
    }
    /**
   * Checks whether the given focused element proves that the browser focus left the grid.
   * Focus counts as foreign when the element is focusable, holds the browser focus, and is
   * neither a part of the grid or its portal, nor one of the shadow hosts the grid is rendered
   * within, nor the document body (a click on a non-focusable area keeps the focus where it
   * was). Sandboxed hosts (e.g. Salesforce Lightning Web Security) hide the real focused
   * element behind the host chain, so a focused ancestor host cannot prove the focus left the
   * grid - only an unrelated element can.
   *
   * The check mirrors the scope-deactivation rule in the focus scope manager (`scopeManager`
   * unlistens when a focus event lands outside every scope). Sandboxed hosts retarget the
   * window-level focus events that rule depends on, so the mouseup path re-applies the same
   * rule from the deepest reachable focused element. On a regular page both mechanisms agree -
   * this adds no behavior that the scope manager does not already provide there.
   *
   * @param {HTMLElement | null} element The deepest reachable focused element.
   * @returns {boolean}
   */ isForeignFocusTarget(element) {
        const { rootElement, rootWrapperElement, rootPortalElement, rootDocument } = _class_private_field_get(this, _hot);
        // Grid-owned UI hosted in the root wrapper's layout slots or overlay layer (e.g. a
        // plugin's formula bar) lives outside `rootElement`, so `isInternalElement` cannot
        // recognize it. Elements inside `rootElement` are deliberately excluded here: a
        // nested grid's focus must keep counting as foreign for this instance, exactly as
        // `isInternalElement` decides.
        const isWrapperHostedUi = !!rootWrapperElement && rootWrapperElement.contains(element) && !rootElement.contains(element);
        if (element === null || element === rootDocument.body || element === rootDocument.documentElement || (0, _element.isInternalElement)(element, rootElement) || isWrapperHostedUi || rootPortalElement && rootPortalElement.contains(element)) {
            return false;
        }
        return !(0, _element.getShadowHostChain)(rootElement).includes(element);
    }
    /**
   * Get the current focus mode.
   *
   * @returns {'cell' | 'mixed'}
   */ getFocusMode() {
        return _class_private_field_get(this, _focusMode);
    }
    /**
   * Set the focus mode.
   *
   * @param {'cell' | 'mixed'} focusMode The new focus mode.
   */ setFocusMode(focusMode) {
        if (Object.values(FOCUS_MODES).includes(focusMode)) {
            _class_private_field_set(this, _focusMode, focusMode);
        } else {
            (0, _console.warn)(`"${focusMode}" is not a valid focus mode.`);
        }
    }
    /**
   * Get the delay after which the focus will change from the cell elements to the active editor's `TEXTAREA`
   * element if the focus mode is set to 'mixed'.
   *
   * @returns {number} Delay in milliseconds.
   */ getRefocusDelay() {
        return _class_private_field_get(this, _refocusDelay);
    }
    /**
   * Set the delay after which the focus will change from the cell elements to the active editor's `TEXTAREA`
   * element if the focus mode is set to 'mixed'.
   *
   * @param {number} delay Delay in milliseconds.
   */ setRefocusDelay(delay) {
        _class_private_field_set(this, _refocusDelay, delay);
    }
    /**
   * Set the function to be used as the "refocus element" getter. It should return a focusable HTML element.
   *
   * @param {Function} getRefocusElementFunction The refocus element getter.
   */ setRefocusElementGetter(getRefocusElementFunction) {
        _class_private_field_set(this, _refocusElementGetter, getRefocusElementFunction);
    }
    /**
   * Suspend automatic focus management until `resume()` is called. While suspended, an
   * externally focused element (input, textarea, select, or contenteditable located outside
   * Handsontable) keeps the browser focus when a programmatic selection is applied, and the
   * editor textarea is not auto-refocused (`imeFastEdit`). Used by `selectCells()` when
   * `changeListener` is `false`. Note: an `activeElement` of `<body>` or an `<iframe>` element
   * does not count as an external input - in those cases focus still moves to the cell.
   *
   * @since 17.0.2
   */ suspend() {
        _class_private_field_set(this, _isSuspended, true);
    }
    /**
   * Resume automatic focus management. Pair with a prior `suspend()` call.
   *
   * @since 17.0.2
   */ resume() {
        _class_private_field_set(this, _isSuspended, false);
    }
    /**
   * Get the element to be used when refocusing the browser after a delay in case of the focus mode being 'mixed'.
   *
   * @returns {HTMLTextAreaElement|HTMLElement|undefined}
   */ getRefocusElement() {
        if (typeof _class_private_field_get(this, _refocusElementGetter) === 'function') {
            return _class_private_field_get(this, _refocusElementGetter).call(this);
        }
        return _class_private_field_get(this, _hot).getActiveEditor()?.TEXTAREA;
    }
    /**
   * Moves the browser focus to a connected `HTMLElement`. Plugins should call this instead of
   * `element.focus()` so programmatic focus stays in the focus manager layer.
   *
   * @param {HTMLElement} element The element to focus.
   * @param {FocusOptions} [focusOptions] Optional arguments for the native `focus()` call.
   * @returns {boolean} `true` if `focus()` was called, `false` if `element` is not a connected `HTMLElement`.
   */ focusElement(element, focusOptions) {
        if (!(0, _element.isHTMLElement)(element) || !element.isConnected) {
            return false;
        }
        element.focus(focusOptions);
        return true;
    }
    /**
   * Set the browser's focus to the highlighted cell of the last selection.
   *
   * @param {HTMLTableCellElement} [selectedCell] The highlighted cell/header element.
   */ focusOnHighlightedCell(selectedCell) {
        const focusElement = (element)=>{
            const currentHighlightCoords = _class_private_field_get(this, _hot).getSelectedRangeActive()?.highlight;
            if (!currentHighlightCoords) {
                return;
            }
            let elementToBeFocused = _class_private_field_get(this, _hot).runHooks('modifyFocusedElement', currentHighlightCoords.row, currentHighlightCoords.col, element);
            if (!(0, _element.isHTMLElement)(elementToBeFocused)) {
                elementToBeFocused = element;
            }
            if (elementToBeFocused && !_class_private_field_get(this, _hot).getActiveEditor()?.isOpened?.()) {
                this.focusElement(elementToBeFocused, {
                    preventScroll: true
                });
            }
        };
        if (selectedCell) {
            focusElement(selectedCell);
        } else {
            _class_private_method_get(this, _getSelectedCell, getSelectedCell).call(this, (element)=>focusElement(element));
        }
    }
    /**
   * Set the focus to the active editor's `TEXTAREA` element after the provided delay. If no delay is provided, it
   * will be taken from the manager's configuration.
   *
   * @param {number} [delay] Delay in milliseconds.
   */ refocusToEditorTextarea(delay = _class_private_field_get(this, _refocusDelay)) {
        // Re-focus on the editor's `TEXTAREA` element (or a predefined element) if the `imeFastEdit` option is enabled.
        if (_class_private_field_get(this, _hot).getSettings().imeFastEdit && !_class_private_field_get(this, _hot).getActiveEditor()?.isOpened?.()) {
            _class_private_field_get(this, _hot).getActiveEditor()?.refreshValue?.();
            if (!_class_private_field_get(this, _debouncedSelect).has(delay)) {
                _class_private_field_get(this, _debouncedSelect).set(delay, (0, _function.debounce)(()=>{
                    if (!_class_private_field_get(this, _hot).isDestroyed) {
                        this.getRefocusElement()?.select();
                    }
                }, delay));
            }
            _class_private_field_get(this, _debouncedSelect).get(delay)();
        }
    }
    /**
   * Initializes the manager with a reference to the Handsontable instance.
   */ constructor(hotInstance){
        _class_private_method_init(this, _getSelectedCell);
        _class_private_method_init(this, _focusCell);
        _class_private_method_init(this, _focusEditorElement);
        _class_private_method_init(this, _onAfterSelectionChange);
        _class_private_method_init(this, _onAfterRender);
        _class_private_method_init(this, _onUpdateSettings);
        _class_private_field_init(this, _hot, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _eventManager1, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _hasBrowserFocus, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _focusMode, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _refocusDelay, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _refocusElementGetter, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _debouncedSelect, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _hasSelectionChange, {
            writable: true,
            value: void 0
        });
        _class_private_field_init(this, _isSuspended, {
            writable: true,
            value: void 0
        });
        _class_private_field_set(this, _eventManager1, null);
        _class_private_field_set(this, _hasBrowserFocus, false);
        _class_private_field_set(this, _refocusDelay, 1);
        _class_private_field_set(this, _refocusElementGetter, null);
        _class_private_field_set(this, _debouncedSelect, new Map());
        _class_private_field_set(this, _hasSelectionChange, false);
        _class_private_field_set(this, _isSuspended, false);
        _class_private_field_set(this, _hot, hotInstance);
    }
}
function getSelectedCell(callback) {
    const highlight = _class_private_field_get(this, _hot).getSelectedRangeActive()?.highlight;
    if (!highlight || !_class_private_field_get(this, _hot).selection.isCellVisible(highlight)) {
        callback(null);
        return;
    }
    if (highlight.row === null || highlight.col === null) {
        callback(null);
        return;
    }
    const { row, col } = highlight;
    const cell = _class_private_field_get(this, _hot).getCell(row, col, true);
    if (cell === null) {
        _class_private_field_get(this, _hot).addHookOnce('afterScroll', ()=>{
            callback(_class_private_field_get(this, _hot).getCell(row, col, true));
        });
    } else {
        callback(cell);
    }
}
function focusCell() {
    // Capture the suspend flag synchronously. `#getSelectedCell` may defer its callback via
    // `afterScroll` when the target cell is not yet rendered, by which time `resume()` may
    // have run. Reading `this.#isSuspended` inside the callback would miss the suspend window.
    const suspended = _class_private_field_get(this, _isSuspended);
    _class_private_method_get(this, _getSelectedCell, getSelectedCell).call(this, (selectedCell)=>{
        const deepActiveElement = (0, _element.getDeepActiveElement)(_class_private_field_get(this, _hot).rootDocument);
        const activeElement = (0, _element.isHTMLElement)(deepActiveElement) ? deepActiveElement : null;
        // When focus management is suspended and an external focusable element (outside Handsontable)
        // currently owns the browser focus, keep it - do not blur and do not move focus to the cell.
        // This preserves the focus of inputs that live next to the grid when a programmatic selection
        // is applied via `selectCells(..., changeListener = false)`. See #10038.
        if (suspended && activeElement && (0, _element.isOutsideInput)(activeElement)) {
            return;
        }
        // Blurring the `activeElement` removes the unwanted border around the focusable element (#6877)
        // and resets the `document.activeElement` property. The blurring should happen only when the
        // previously selected input element has not belonged to the Handsontable editor. If blurring is
        // triggered for all elements, there is a problem with the disappearing IME editor (#9672).
        if (activeElement && (0, _element.isOutsideInput)(activeElement)) {
            activeElement.blur();
        }
        this.focusOnHighlightedCell(selectedCell);
    });
}
function focusEditorElement() {
    // When focus management is suspended and an external focusable element (outside Handsontable)
    // currently owns the browser focus, skip the `imeFastEdit` refocus - otherwise the debounced
    // `select()` on the editor textarea would steal that external focus. When no external element
    // owns focus, fall through so the default `imeFastEdit` behavior still moves focus to the
    // editor textarea (existing per-editor IME support tests rely on this). See #10038.
    if (_class_private_field_get(this, _isSuspended)) {
        const deepActiveElement = (0, _element.getDeepActiveElement)(_class_private_field_get(this, _hot).rootDocument);
        const activeElement = (0, _element.isHTMLElement)(deepActiveElement) ? deepActiveElement : null;
        if (activeElement && (0, _element.isOutsideInput)(activeElement)) {
            return;
        }
    }
    _class_private_method_get(this, _getSelectedCell, getSelectedCell).call(this, (selectedCell)=>{
        if (this.getFocusMode() === FOCUS_MODES.MIXED && selectedCell?.nodeName === 'TD') {
            this.refocusToEditorTextarea();
        }
    });
}
function onAfterSelectionChange() {
    _class_private_field_set(this, _hasSelectionChange, true);
}
function onAfterRender() {
    if (_class_private_field_get(this, _hasSelectionChange)) {
        _class_private_field_set(this, _hasSelectionChange, false);
        _class_private_method_get(this, _focusCell, focusCell).call(this);
    }
}
function onUpdateSettings(newSettings) {
    if (typeof newSettings.imeFastEdit === 'boolean') {
        this.setFocusMode(newSettings.imeFastEdit ? FOCUS_MODES.MIXED : FOCUS_MODES.CELL);
    }
}
