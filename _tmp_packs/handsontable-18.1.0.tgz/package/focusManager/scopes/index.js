"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "registerAllFocusScopes", {
    enumerable: true,
    get: function() {
        return registerAllFocusScopes;
    }
});
const _grid = require("./grid");
function registerAllFocusScopes(hotInstance) {
    [
        _grid.focusGridScope
    ].forEach((scope)=>scope(hotInstance));
}
