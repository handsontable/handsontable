"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "installFocusDetector", {
    enumerable: true,
    get: function() {
        return installFocusDetector;
    }
});
const _constants = require("../constants");
function installFocusDetector(hot, wrapperElement) {
    const inputTrapTop = createInputElement(hot, _constants.FOCUS_SOURCES.TAB_FROM_ABOVE);
    const inputTrapBottom = createInputElement(hot, _constants.FOCUS_SOURCES.TAB_FROM_BELOW);
    wrapperElement.prepend(inputTrapTop);
    wrapperElement.append(inputTrapBottom);
    return {
        /**
     * Activates the detector by resetting the tabIndex of the input elements.
     */ activate () {
            inputTrapTop.tabIndex = 0;
            inputTrapBottom.tabIndex = 0;
        },
        /**
     * Deactivates the detector by setting tabIndex to -1.
     */ deactivate () {
            inputTrapTop.tabIndex = -1;
            inputTrapBottom.tabIndex = -1;
        },
        /**
     * Destroys the focus detector.
     */ destroy () {
            inputTrapTop.remove();
            inputTrapBottom.remove();
        }
    };
}
/**
 * Creates a new HTML input element.
 *
 * @param {Handsontable} hot The Handsontable instance.
 * @param {'from_above' | 'from_below'} focusSource The source of the focus event.
 * @returns {HTMLInputElement}
 */ function createInputElement(hot, focusSource) {
    const rootDocument = hot.rootDocument;
    const catcher = rootDocument.createElement('div');
    catcher.style.display = 'none';
    catcher.classList.add('htFocusCatcher');
    catcher.dataset.htFocusSource = focusSource;
    return catcher;
}
