/**
 * Focus scope types.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DEFAULT_SHORTCUTS_CONTEXT () {
        return DEFAULT_SHORTCUTS_CONTEXT;
    },
    get FOCUS_SOURCES () {
        return FOCUS_SOURCES;
    },
    get SCOPE_TYPES () {
        return SCOPE_TYPES;
    }
});
const SCOPE_TYPES = Object.freeze({
    INLINE: 'inline',
    MODAL: 'modal'
});
const FOCUS_SOURCES = Object.freeze({
    UNKNOWN: 'unknown',
    CLICK: 'click',
    TAB_FROM_ABOVE: 'tab_from_above',
    TAB_FROM_BELOW: 'tab_from_below'
});
const DEFAULT_SHORTCUTS_CONTEXT = 'grid';
