"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BooleanMap", {
    enumerable: true,
    get: function() {
        return BooleanMap;
    }
});
const _indexMap = require("./indexMap");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var /**
   * Whether every value currently equals the default (no materialized array).
   *
   * @type {boolean}
   */ _allDefault = /*#__PURE__*/ new WeakMap(), /**
   * Number of indexes in the map.
   *
   * @type {number}
   */ _length = /*#__PURE__*/ new WeakMap(), /**
   * Materialized store, or `null` while every value is the default.
   *
   * @type {boolean[] | null}
   */ _store = /*#__PURE__*/ new WeakMap(), /**
   * The default boolean value (`false` for hiding/trimming). Unused when a default function is given.
   *
   * @type {boolean}
   */ _defaultValue = /*#__PURE__*/ new WeakMap(), /**
   * Default factory when one is provided instead of a constant (then the all-default fast path is off).
   *
   * @type {Function | null}
   */ _defaultFn = /*#__PURE__*/ new WeakMap(), /**
   * Returns the default flag for a position — constant, or from the factory when one is set.
   *
   * @private
   * @param {number} index Physical index.
   * @param {number} ordinalNumber Ordinal of the inserted item.
   * @returns {boolean}
   */ _defaultFlagAt = /*#__PURE__*/ new WeakSet(), /**
   * Materializes the all-default state into a `boolean[]` so per-index writes can run.
   *
   * @private
   */ _materialize = /*#__PURE__*/ new WeakSet();
class BooleanMap extends _indexMap.IndexMap {
    /**
   * Get the full list of boolean values. Returns the materialized array by reference (no per-call copy).
   *
   * @returns {boolean[]}
   */ getValues() {
        if (_class_private_field_get(this, _allDefault)) {
            return new Array(_class_private_field_get(this, _length)).fill(_class_private_field_get(this, _defaultValue));
        }
        return _class_private_field_get(this, _store);
    }
    /**
   * Get the boolean value at a physical index.
   *
   * @param {number} index Physical index.
   * @returns {T | undefined}
   */ getValueAtIndex(index) {
        if (index < 0 || index >= _class_private_field_get(this, _length)) {
            return undefined;
        }
        if (_class_private_field_get(this, _allDefault)) {
            return _class_private_field_get(this, _defaultValue);
        }
        return _class_private_field_get(this, _store)[index];
    }
    /**
   * Get the number of indexes.
   *
   * @returns {number}
   */ getLength() {
        return _class_private_field_get(this, _length);
    }
    /**
   * Set new boolean values. Keeps the compact representation when all values equal the default.
   *
   * @param {Array} values List of boolean values.
   */ setValues(values) {
        _class_private_field_set(this, _length, values.length);
        let allDefault = true;
        for(let index = 0; index < values.length; index += 1){
            if (values[index] === true !== _class_private_field_get(this, _defaultValue)) {
                allDefault = false;
                break;
            }
        }
        if (allDefault) {
            _class_private_field_set(this, _allDefault, true);
            _class_private_field_set(this, _store, null);
        } else {
            const store = new Array(values.length);
            for(let index = 0; index < values.length; index += 1){
                store[index] = values[index] === true;
            }
            _class_private_field_set(this, _allDefault, false);
            _class_private_field_set(this, _store, store);
        }
        this.runLocalHooks('change');
    }
    /**
   * Set the boolean value at a single physical index. Materializes the store on the first non-default write.
   *
   * @param {number} index Physical index.
   * @param {*} value The value to set (coerced to boolean).
   * @returns {boolean}
   */ setValueAtIndex(index, value) {
        if (index < 0 || index >= _class_private_field_get(this, _length)) {
            return false;
        }
        const flag = value === true;
        if (_class_private_field_get(this, _allDefault)) {
            if (flag === _class_private_field_get(this, _defaultValue)) {
                // Writing the default into the compact (all-default) state is always a no-op for the
                // stored data; with `skipUnchangedWrites` the `change` hook is skipped too.
                if (!this.skipUnchangedWrites) {
                    this.runLocalHooks('change');
                }
                return true;
            }
            _class_private_method_get(this, _materialize, materialize).call(this);
        }
        if (this.skipUnchangedWrites && _class_private_field_get(this, _store)[index] === flag) {
            return true;
        }
        _class_private_field_get(this, _store)[index] = flag;
        this.runLocalHooks('change');
        return true;
    }
    /**
   * Reset to the all-default state of the given length. O(1) for a constant default — no array is built.
   *
   * @private
   * @param {number} [length] Length of the map.
   */ setDefaultValues(length = _class_private_field_get(this, _length)) {
        _class_private_field_set(this, _length, length);
        if (_class_private_field_get(this, _defaultFn) !== null) {
            // A factory default has no single value, so materialize it (no all-default fast path).
            const store = new Array(length);
            for(let index = 0; index < length; index += 1){
                store[index] = _class_private_method_get(this, _defaultFlagAt, defaultFlagAt).call(this, index, index);
            }
            _class_private_field_set(this, _store, store);
            _class_private_field_set(this, _allDefault, false);
        } else {
            _class_private_field_set(this, _allDefault, true);
            _class_private_field_set(this, _store, null);
        }
        this.runLocalHooks('change');
    }
    /**
   * Add values to the map and reorganize.
   *
   * @private
   * @param {number} insertionIndex Position inside the list.
   * @param {Array} insertedIndexes List of inserted indexes.
   */ insert(insertionIndex, insertedIndexes) {
        const amount = insertedIndexes.length;
        if (amount > 0) {
            if (_class_private_field_get(this, _allDefault)) {
                // Inserting defaults into an all-default map stays all-default; only the length grows.
                _class_private_field_set(this, _length, _class_private_field_get(this, _length) + amount);
            } else {
                // Mirror `getListWithInsertedItems`: splice the default block at `insertedIndexes[0]`.
                const at = insertedIndexes[0];
                const inserted = new Array(amount);
                for(let ordinalNumber = 0; ordinalNumber < amount; ordinalNumber += 1){
                    inserted[ordinalNumber] = _class_private_method_get(this, _defaultFlagAt, defaultFlagAt).call(this, insertedIndexes[ordinalNumber], ordinalNumber);
                }
                const store = _class_private_field_get(this, _store);
                _class_private_field_set(this, _store, store.slice(0, at).concat(inserted, store.slice(at)));
                _class_private_field_set(this, _length, _class_private_field_get(this, _length) + amount);
            }
        }
        super.insert(insertionIndex, insertedIndexes);
    }
    /**
   * Remove values from the map and reorganize.
   *
   * @private
   * @param {Array} removedIndexes List of removed indexes.
   */ remove(removedIndexes) {
        if (_class_private_field_get(this, _allDefault)) {
            // Removing from an all-default map stays all-default; only the length shrinks.
            const seen = new Set();
            for(let i = 0; i < removedIndexes.length; i += 1){
                const removedIndex = removedIndexes[i];
                if (removedIndex >= 0 && removedIndex < _class_private_field_get(this, _length)) {
                    seen.add(removedIndex);
                }
            }
            _class_private_field_set(this, _length, _class_private_field_get(this, _length) - seen.size);
        } else {
            const removed = new Set(removedIndexes);
            const store = _class_private_field_get(this, _store);
            const next = [];
            for(let i = 0; i < _class_private_field_get(this, _length); i += 1){
                if (removed.has(i) === false) {
                    next.push(store[i]);
                }
            }
            _class_private_field_set(this, _store, next);
            _class_private_field_set(this, _length, next.length);
        }
        super.remove(removedIndexes);
    }
    /**
   * Destroys the map instance.
   */ destroy() {
        _class_private_field_set(this, _allDefault, true);
        _class_private_field_set(this, _length, 0);
        _class_private_field_set(this, _store, null);
        super.destroy();
    }
    /**
   * Initializes the boolean map with a default value or factory (defaults to `false`).
   */ constructor(initValueOrFn = false, options = {}){
        super(initValueOrFn, options), _class_private_method_init(this, _defaultFlagAt), _class_private_method_init(this, _materialize), _class_private_field_init(this, _allDefault, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _length, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _store, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _defaultValue, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _defaultFn, {
            writable: true,
            value: void 0
        }), _class_private_field_set(this, _allDefault, true), _class_private_field_set(this, _length, 0), _class_private_field_set(this, _store, null);
        _class_private_field_set(this, _defaultFn, typeof initValueOrFn === 'function' ? initValueOrFn : null);
        _class_private_field_set(this, _defaultValue, initValueOrFn === true);
    }
}
function defaultFlagAt(index, ordinalNumber) {
    if (_class_private_field_get(this, _defaultFn) !== null) {
        return _class_private_field_get(this, _defaultFn).call(this, index, ordinalNumber) === true;
    }
    return _class_private_field_get(this, _defaultValue);
}
function materialize() {
    if (_class_private_field_get(this, _allDefault)) {
        _class_private_field_set(this, _store, new Array(_class_private_field_get(this, _length)).fill(_class_private_field_get(this, _defaultValue)));
        _class_private_field_set(this, _allDefault, false);
    }
}
