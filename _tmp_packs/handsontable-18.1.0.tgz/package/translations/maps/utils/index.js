"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get alterUtilsFactory () {
        return alterUtilsFactory;
    },
    get getDecreasedIndexes () {
        return _actionsOnIndexes.getDecreasedIndexes;
    },
    get getIncreasedIndexes () {
        return _actionsOnIndexes.getIncreasedIndexes;
    }
});
const _actionsOnIndexes = require("./actionsOnIndexes");
const _errors = require("../../../helpers/errors");
const _indexesSequence = require("./indexesSequence");
const _physicallyIndexed = require("./physicallyIndexed");
const alterStrategies = new Map([
    [
        'indexesSequence',
        {
            getListWithInsertedItems: _indexesSequence.getListWithInsertedItems,
            getListWithRemovedItems: _indexesSequence.getListWithRemovedItems
        }
    ],
    [
        'physicallyIndexed',
        {
            getListWithInsertedItems: _physicallyIndexed.getListWithInsertedItems,
            getListWithRemovedItems: _physicallyIndexed.getListWithRemovedItems
        }
    ]
]);
const alterUtilsFactory = (indexationStrategy)=>{
    if (alterStrategies.has(indexationStrategy) === false) {
        (0, _errors.throwWithCause)(`Alter strategy with ID '${indexationStrategy}' does not exist.`);
    }
    return alterStrategies.get(indexationStrategy);
};
