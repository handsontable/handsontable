"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get getDecreasedIndexes () {
        return getDecreasedIndexes;
    },
    get getIncreasedIndexes () {
        return getIncreasedIndexes;
    }
});
const _array = require("../../../helpers/array");
function getDecreasedIndexes(indexedValues, removedIndexes) {
    if (removedIndexes.length === 0) {
        return indexedValues.slice();
    }
    // Sort the removed indexes once, then for each value count how many removed indexes are below it
    // with a binary search. This replaces a per-element `removedIndexes.filter(...)` (O(n × k)) with
    // O(n log k) — the dominant cost when removing many rows from a large dataset.
    const sortedRemoved = Int32Array.from(removedIndexes).sort();
    return (0, _array.arrayMap)(indexedValues, (index)=>{
        let low = 0;
        let high = sortedRemoved.length;
        while(low < high){
            const mid = Math.floor((low + high) / 2);
            if (sortedRemoved[mid] < index) {
                low = mid + 1;
            } else {
                high = mid;
            }
        }
        return index - low;
    });
}
function getIncreasedIndexes(indexedValues, insertedIndexes) {
    const firstInsertedIndex = insertedIndexes[0];
    const amountOfIndexes = insertedIndexes.length;
    return (0, _array.arrayMap)(indexedValues, (index)=>{
        if (index >= firstInsertedIndex) {
            return index + amountOfIndexes;
        }
        return index;
    });
}
