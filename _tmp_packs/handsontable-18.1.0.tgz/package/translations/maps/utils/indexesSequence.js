"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get getListWithInsertedItems () {
        return getListWithInsertedItems;
    },
    get getListWithRemovedItems () {
        return getListWithRemovedItems;
    }
});
const _array = require("../../../helpers/array");
/**
 * Above this many removed indexes a `Set` lookup is used instead of `Array.prototype.includes`,
 * turning the removal scan from O(n × k) into O(n + k). Below it, a linear `includes` is cheaper
 * than building a `Set`.
 *
 * @type {number}
 */ const SET_LOOKUP_THRESHOLD = 16;
function getListWithInsertedItems(indexedValues, insertionIndex, insertedIndexes) {
    return [
        ...indexedValues.slice(0, insertionIndex),
        ...insertedIndexes,
        ...indexedValues.slice(insertionIndex)
    ];
}
function getListWithRemovedItems(indexedValues, removedIndexes) {
    if (removedIndexes.length <= SET_LOOKUP_THRESHOLD) {
        return (0, _array.arrayFilter)(indexedValues, (index)=>removedIndexes.includes(index) === false);
    }
    const removed = new Set(removedIndexes);
    return (0, _array.arrayFilter)(indexedValues, (index)=>removed.has(index) === false);
}
