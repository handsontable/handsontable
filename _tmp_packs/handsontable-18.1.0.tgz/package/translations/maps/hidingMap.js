"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HidingMap", {
    enumerable: true,
    get: function() {
        return HidingMap;
    }
});
const _booleanMap = require("./booleanMap");
const _array = require("../../helpers/array");
class HidingMap extends _booleanMap.BooleanMap {
    /**
   * Get physical indexes which are hidden.
   *
   * Note: Indexes marked as hidden are included in a {@link DataMap}, but aren't rendered.
   *
   * @returns {Array}
   */ getHiddenIndexes() {
        return (0, _array.arrayReduce)(this.getValues(), (indexesList, isHidden, physicalIndex)=>{
            if (isHidden) {
                indexesList.push(physicalIndex);
            }
            return indexesList;
        }, []);
    }
    /**
   * Initializes the hiding map with an optional default value, defaulting to `false` (not hidden).
   *
   * The map stores flags coerced to booleans, so a write of an unchanged flag is provably a no-op —
   * `skipUnchangedWrites` is always on, keeping no-op writes from rebuilding the index caches.
   */ constructor(initValueOrFn = false){
        super(initValueOrFn, {
            skipUnchangedWrites: true
        });
    }
}
