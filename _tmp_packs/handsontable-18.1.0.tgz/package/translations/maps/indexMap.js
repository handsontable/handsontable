"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "IndexMap", {
    enumerable: true,
    get: function() {
        return IndexMap;
    }
});
const _object = require("../../helpers/object");
const _function = require("../../helpers/function");
const _localHooks = /*#__PURE__*/ _interop_require_default(require("../../mixins/localHooks"));
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var _skipUnchangedWrites = /*#__PURE__*/ new WeakMap();
class IndexMap {
    /**
   * Whether `setValueAtIndex` treats a write of a strictly-equal value as a no-op. Read-only;
   * configured through the constructor. Exposed so subclasses that fully override
   * `setValueAtIndex` (e.g. `BooleanMap`) can honor the same contract.
   *
   * @returns {boolean}
   */ get skipUnchangedWrites() {
        return _class_private_field_get(this, _skipUnchangedWrites);
    }
    /**
   * Get full list of values for particular indexes.
   *
   * @param {*} [unused] Unused parameter for TypeScript compatibility.
   * @returns {Array}
   */ getValues(unused) {
        return this.indexedValues;
    }
    /**
   * Get value for the particular index.
   *
   * @param {number} index Index for which value is got.
   * @returns {T | undefined}
   */ getValueAtIndex(index) {
        const values = this.indexedValues;
        if (index < values.length) {
            return values[index];
        }
    }
    /**
   * Set new values for particular indexes.
   *
   * Note: Please keep in mind that `change` hook triggered by the method may not update cache of a collection immediately.
   *
   * @param {Array} values List of set values.
   */ setValues(values) {
        this.indexedValues = values.slice();
        this.runLocalHooks('change');
    }
    /**
   * Set new value for the particular index.
   *
   * @param {number} index The index.
   * @param {*} value The value to save.
   *
   * Note: Please keep in mind that it is not possible to set value beyond the map (not respecting already set
   * map's size). Please use the `setValues` method when you would like to extend the map.
   * Note: Please keep in mind that `change` hook triggered by the method may not update cache of a collection immediately.
   *
   * @returns {boolean}
   */ setValueAtIndex(index, value) {
        if (index < this.indexedValues.length) {
            // A no-op write on an opted-in scalar map: the postcondition already holds, so skip the
            // store and the `change` hook (each `change` rebuilds consumer caches).
            if (this.skipUnchangedWrites && this.indexedValues[index] === value) {
                return true;
            }
            this.indexedValues[index] = value;
            this.runLocalHooks('change');
            return true;
        }
        return false;
    }
    /**
   * Clear all values to the defaults.
   */ clear() {
        this.setDefaultValues();
    }
    /**
   * Get length of the index map.
   *
   * @returns {number}
   */ getLength() {
        return this.getValues().length;
    }
    /**
   * Set default values for elements from `0` to `n`, where `n` is equal to the handled variable.
   *
   * Note: Please keep in mind that `change` hook triggered by the method may not update cache of a collection immediately.
   *
   * @private
   * @param {number} [length] Length of list.
   */ setDefaultValues(length = this.indexedValues.length) {
        // Build the backing array presized instead of growing it with `push` per index. On large
        // datasets the repeated array-growth reallocation dominated load time (~106 ms to seed 1M
        // values); a presized fill/assignment is a tight native loop. Same element type and values.
        if ((0, _function.isFunction)(this.initValueOrFn)) {
            const values = new Array(length);
            const initFn = this.initValueOrFn;
            for(let index = 0; index < length; index += 1){
                values[index] = initFn(index);
            }
            this.indexedValues = values;
        } else {
            this.indexedValues = new Array(length).fill(this.initValueOrFn);
        }
        this.runLocalHooks('change');
    }
    /**
   * Initialize list with default values for particular indexes.
   *
   * @private
   * @param {number} length New length of indexed list.
   * @returns {IndexMap}
   */ init(length) {
        this.setDefaultValues(length);
        this.runLocalHooks('init');
        return this;
    }
    /**
   * Add values to the list.
   *
   * Note: Please keep in mind that `change` hook triggered by the method may not update cache of a collection immediately.
   *
   * @private
   * @param {number} [insertionIndex] Position inside the list.
   * @param {Array} [insertedIndexes] List of inserted indexes.
   */ insert(insertionIndex, insertedIndexes) {
        this.runLocalHooks('change');
    }
    /**
   * Remove values from the list.
   *
   * Note: Please keep in mind that `change` hook triggered by the method may not update cache of a collection immediately.
   *
   * @private
   * @param {Array} [removedIndexes] List of removed indexes.
   */ remove(removedIndexes) {
        this.runLocalHooks('change');
    }
    /**
   * Destroys the Map instance.
   */ destroy() {
        this.clearLocalHooks();
        this.indexedValues = [];
        this.initValueOrFn = null;
    }
    /**
   * Initializes the index map with an optional default value or factory function applied to each
   * index, and optional map behavior options.
   */ constructor(initValueOrFn = null, { skipUnchangedWrites = false } = {}){
        /**
   * Whether `setValueAtIndex` skips the write and the `change` hook when the new value is
   * strictly equal to the stored one. See {@link IndexMapOptions#skipUnchangedWrites}.
   *
   * @type {boolean}
   */ _class_private_field_init(this, _skipUnchangedWrites, {
            writable: true,
            value: void 0
        });
        /**
   * List of values for particular indexes.
   *
   * @private
   * @type {Array}
   */ this.indexedValues = [];
        this.initValueOrFn = initValueOrFn;
        _class_private_field_set(this, _skipUnchangedWrites, skipUnchangedWrites);
    }
}
(0, _object.mixin)(IndexMap, _localHooks.default);
