"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get HidingMap () {
        return _hidingMap.HidingMap;
    },
    get IndexMap () {
        return _indexMap.IndexMap;
    },
    get LinkedPhysicalIndexToValueMap () {
        return _linkedPhysicalIndexToValueMap.LinkedPhysicalIndexToValueMap;
    },
    get PhysicalIndexToValueMap () {
        return _physicalIndexToValueMap.PhysicalIndexToValueMap;
    },
    get TrimmingMap () {
        return _trimmingMap.TrimmingMap;
    },
    get createIndexMap () {
        return createIndexMap;
    }
});
const _hidingMap = require("./hidingMap");
const _indexMap = require("./indexMap");
const _indexesSequence = _export_star(require("./indexesSequence"), exports);
const _linkedPhysicalIndexToValueMap = require("./linkedPhysicalIndexToValueMap");
const _physicalIndexToValueMap = require("./physicalIndexToValueMap");
const _trimmingMap = require("./trimmingMap");
const _errors = require("../../helpers/errors");
_export_star(require("./utils/indexesSequence"), exports);
function _export_star(from, to) {
    Object.keys(from).forEach(function(k) {
        if (k !== "default" && !Object.prototype.hasOwnProperty.call(to, k)) {
            Object.defineProperty(to, k, {
                enumerable: true,
                get: function() {
                    return from[k];
                }
            });
        }
    });
    return from;
}
const availableIndexMapTypes = new Map([
    [
        'hiding',
        _hidingMap.HidingMap
    ],
    [
        'index',
        _indexMap.IndexMap
    ],
    [
        'indexesSequence',
        _indexesSequence.IndexesSequence
    ],
    [
        'linkedPhysicalIndexToValue',
        _linkedPhysicalIndexToValueMap.LinkedPhysicalIndexToValueMap
    ],
    [
        'physicalIndexToValue',
        _physicalIndexToValueMap.PhysicalIndexToValueMap
    ],
    [
        'trimming',
        _trimmingMap.TrimmingMap
    ]
]);
function createIndexMap(mapType, initValueOrFn = null, options = {}) {
    if (!availableIndexMapTypes.has(mapType)) {
        (0, _errors.throwWithCause)(`The provided map type ("${mapType}") does not exist.`);
    }
    return new (availableIndexMapTypes.get(mapType))(initValueOrFn, options);
}
