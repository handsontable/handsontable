"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "IndexesSequence", {
    enumerable: true,
    get: function() {
        return IndexesSequence;
    }
});
const _indexMap = require("./indexMap");
const _indexesSequence = require("./utils/indexesSequence");
const _utils = require("./utils");
function _check_private_redeclaration(obj, privateCollection) {
    if (privateCollection.has(obj)) {
        throw new TypeError("Cannot initialize the same private elements twice on an object");
    }
}
function _class_apply_descriptor_get(receiver, descriptor) {
    if (descriptor.get) {
        return descriptor.get.call(receiver);
    }
    return descriptor.value;
}
function _class_apply_descriptor_set(receiver, descriptor, value) {
    if (descriptor.set) {
        descriptor.set.call(receiver, value);
    } else {
        if (!descriptor.writable) {
            throw new TypeError("attempted to set read only private field");
        }
        descriptor.value = value;
    }
}
function _class_extract_field_descriptor(receiver, privateMap, action) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to " + action + " private field on non-instance");
    }
    return privateMap.get(receiver);
}
function _class_private_field_get(receiver, privateMap) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "get");
    return _class_apply_descriptor_get(receiver, descriptor);
}
function _class_private_field_init(obj, privateMap, value) {
    _check_private_redeclaration(obj, privateMap);
    privateMap.set(obj, value);
}
function _class_private_field_set(receiver, privateMap, value) {
    var descriptor = _class_extract_field_descriptor(receiver, privateMap, "set");
    _class_apply_descriptor_set(receiver, descriptor, value);
    return value;
}
function _class_private_method_get(receiver, privateSet, fn) {
    if (!privateSet.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return fn;
}
function _class_private_method_init(obj, privateSet) {
    _check_private_redeclaration(obj, privateSet);
    privateSet.add(obj);
}
var /**
   * Whether the sequence is currently the identity (`0..#length-1`). When `true`, `indexedValues` is
   * not materialized and `#length` is the source of truth.
   *
   * @type {boolean}
   */ _isIdentity = /*#__PURE__*/ new WeakMap(), /**
   * Length of the sequence while it is the identity. Ignored once materialized.
   *
   * @type {number}
   */ _length = /*#__PURE__*/ new WeakMap(), /**
   * Materializes the identity sequence into `indexedValues` so the array-based paths can run.
   *
   * @private
   */ _materialize = /*#__PURE__*/ new WeakSet(), /**
   * Checks whether the given values are the identity sequence (`0, 1, …, length-1`).
   *
   * @private
   * @param {Array} values Candidate sequence.
   * @returns {boolean}
   */ _isIdentitySequence = /*#__PURE__*/ new WeakSet(), /**
   * Checks whether `insertedIndexes` is the contiguous block `[insertionIndex, …]` — the only shape
   * that keeps an identity sequence identity after an insert.
   *
   * @private
   * @param {number} insertionIndex Position inside the list.
   * @param {Array} insertedIndexes List of inserted indexes.
   * @returns {boolean}
   */ _isContiguousBlockAt = /*#__PURE__*/ new WeakSet(), /**
   * Counts how many distinct removed indexes fall inside the current identity range `[0, #length)`.
   *
   * @private
   * @param {Array} removedIndexes List of removed indexes.
   * @returns {number}
   */ _countInRange = /*#__PURE__*/ new WeakSet();
class IndexesSequence extends _indexMap.IndexMap {
    /**
   * Get sequence of physical indexes.
   *
   * @returns {number[]} Physical indexes.
   */ getValues() {
        if (_class_private_field_get(this, _isIdentity)) {
            const values = new Array(_class_private_field_get(this, _length));
            for(let index = 0; index < _class_private_field_get(this, _length); index += 1){
                values[index] = index;
            }
            return values;
        }
        return this.indexedValues;
    }
    /**
   * Get the physical index at the given position.
   *
   * @param {number} index Position in the sequence.
   * @returns {T | undefined}
   */ getValueAtIndex(index) {
        if (_class_private_field_get(this, _isIdentity)) {
            if (index >= 0 && index < _class_private_field_get(this, _length)) {
                return index;
            }
            return undefined;
        }
        return super.getValueAtIndex(index);
    }
    /**
   * Get length of the sequence.
   *
   * @returns {number}
   */ getLength() {
        return _class_private_field_get(this, _isIdentity) ? _class_private_field_get(this, _length) : this.indexedValues.length;
    }
    /**
   * Set a completely new sequence. Detects the identity case to keep the compact representation.
   *
   * @param {Array} values List of physical indexes.
   */ setValues(values) {
        if (_class_private_method_get(this, _isIdentitySequence, isIdentitySequence).call(this, values)) {
            _class_private_field_set(this, _isIdentity, true);
            _class_private_field_set(this, _length, values.length);
            this.indexedValues = [];
        } else {
            _class_private_field_set(this, _isIdentity, false);
            this.indexedValues = values.slice();
        }
        this.runLocalHooks('change');
    }
    /**
   * Set the physical index at a single position. Materializes the sequence first.
   *
   * @param {number} index The position.
   * @param {*} value The physical index to store.
   * @returns {boolean}
   */ setValueAtIndex(index, value) {
        if (index < this.getLength()) {
            // Check before materializing: re-writing the value the position already holds must not
            // degrade the compact identity representation into a materialized array.
            if (this.skipUnchangedWrites && this.getValueAtIndex(index) === value) {
                return true;
            }
            _class_private_method_get(this, _materialize, materialize).call(this);
            return super.setValueAtIndex(index, value);
        }
        return false;
    }
    /**
   * Reset to the identity sequence of the given length. O(1) — no array is built.
   *
   * @private
   * @param {number} [length] Length of the sequence.
   */ setDefaultValues(length = this.getLength()) {
        _class_private_field_set(this, _isIdentity, true);
        _class_private_field_set(this, _length, length);
        this.indexedValues = [];
        this.runLocalHooks('change');
    }
    /**
   * Add values to the sequence and reorganize.
   *
   * @private
   * @param {number} insertionIndex Position inside the list.
   * @param {Array} insertedIndexes List of inserted indexes.
   */ insert(insertionIndex, insertedIndexes) {
        // Fast path: inserting a contiguous physical block at its own position into an identity sequence
        // yields another identity sequence, so only the length changes.
        if (_class_private_field_get(this, _isIdentity) && _class_private_method_get(this, _isContiguousBlockAt, isContiguousBlockAt).call(this, insertionIndex, insertedIndexes)) {
            _class_private_field_set(this, _length, _class_private_field_get(this, _length) + insertedIndexes.length);
            super.insert(insertionIndex, insertedIndexes);
            return;
        }
        _class_private_method_get(this, _materialize, materialize).call(this);
        const listAfterUpdate = (0, _utils.getIncreasedIndexes)(this.getValues(), insertedIndexes);
        this.indexedValues = (0, _indexesSequence.getListWithInsertedItems)(listAfterUpdate, insertionIndex, insertedIndexes);
        super.insert(insertionIndex, insertedIndexes);
    }
    /**
   * Remove values from the sequence and reorganize.
   *
   * @private
   * @param {Array} removedIndexes List of removed indexes.
   */ remove(removedIndexes) {
        // Fast path: removing any subset of an identity sequence and reindexing the survivors yields
        // another identity sequence, so only the length changes.
        if (_class_private_field_get(this, _isIdentity)) {
            _class_private_field_set(this, _length, _class_private_field_get(this, _length) - _class_private_method_get(this, _countInRange, countInRange).call(this, removedIndexes));
            super.remove(removedIndexes);
            return;
        }
        const listAfterUpdate = (0, _indexesSequence.getListWithRemovedItems)(this.getValues(), removedIndexes);
        this.indexedValues = (0, _utils.getDecreasedIndexes)(listAfterUpdate, removedIndexes);
        super.remove(removedIndexes);
    }
    /**
   * Destroys the map instance.
   */ destroy() {
        _class_private_field_set(this, _isIdentity, true);
        _class_private_field_set(this, _length, 0);
        super.destroy();
    }
    /**
   * Initializes the sequence map with an identity function so each index maps to its own physical value.
   *
   * The sequence stores physical indexes (numbers), so a write of an unchanged index is provably a
   * no-op — `skipUnchangedWrites` is always on, which also preserves the compact identity
   * representation when an identity value is re-written.
   */ constructor(){
        // Not handling custom init function or init value.
        super((index)=>index, {
            skipUnchangedWrites: true
        }), _class_private_method_init(this, _materialize), _class_private_method_init(this, _isIdentitySequence), _class_private_method_init(this, _isContiguousBlockAt), _class_private_method_init(this, _countInRange), _class_private_field_init(this, _isIdentity, {
            writable: true,
            value: void 0
        }), _class_private_field_init(this, _length, {
            writable: true,
            value: void 0
        }), _class_private_field_set(this, _isIdentity, true), _class_private_field_set(this, _length, 0);
    }
}
function materialize() {
    if (_class_private_field_get(this, _isIdentity)) {
        this.indexedValues = this.getValues();
        _class_private_field_set(this, _isIdentity, false);
    }
}
function isIdentitySequence(values) {
    for(let index = 0; index < values.length; index += 1){
        if (values[index] !== index) {
            return false;
        }
    }
    return true;
}
function isContiguousBlockAt(insertionIndex, insertedIndexes) {
    for(let offset = 0; offset < insertedIndexes.length; offset += 1){
        if (insertedIndexes[offset] !== insertionIndex + offset) {
            return false;
        }
    }
    return true;
}
function countInRange(removedIndexes) {
    const seen = new Set();
    for(let i = 0; i < removedIndexes.length; i += 1){
        const removedIndex = removedIndexes[i];
        if (removedIndex >= 0 && removedIndex < _class_private_field_get(this, _length)) {
            seen.add(removedIndex);
        }
    }
    return seen.size;
}
