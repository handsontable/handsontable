"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get IndexMapper () {
        return _indexMapper.IndexMapper;
    },
    get alterUtilsFactory () {
        return _utils.alterUtilsFactory;
    },
    get getDecreasedIndexes () {
        return _utils.getDecreasedIndexes;
    },
    get getIncreasedIndexes () {
        return _utils.getIncreasedIndexes;
    },
    get getRegisteredMapsCounter () {
        return _mapCollection.getRegisteredMapsCounter;
    }
});
const _indexMapper = require("./indexMapper");
const _mapCollection = require("./mapCollections/mapCollection");
const _utils = require("./maps/utils");
_export_star(require("./maps"), exports);
function _export_star(from, to) {
    Object.keys(from).forEach(function(k) {
        if (k !== "default" && !Object.prototype.hasOwnProperty.call(to, k)) {
            Object.defineProperty(to, k, {
                enumerable: true,
                get: function() {
                    return from[k];
                }
            });
        }
    });
    return from;
}
