"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AggregatedCollection", {
    enumerable: true,
    get: function() {
        return AggregatedCollection;
    }
});
const _mapCollection = require("./mapCollection");
const _array = require("../../helpers/array");
const _mixed = require("../../helpers/mixed");
class AggregatedCollection extends _mapCollection.MapCollection {
    /**
   * Get merged values for all indexes.
   *
   * @param {boolean} [readFromCache=true] Determine if read results from the cache.
   * @returns {Array}
   */ getMergedValues(readFromCache = true) {
        if (readFromCache === true) {
            return this.mergedValuesCache;
        }
        const maps = this.get();
        const numberOfMaps = maps.length;
        if (numberOfMaps === 0) {
            return [];
        }
        // Per-map value arrays. For 2 maps of length 5:
        //   maps 0 | [ value, value, value, value, value ]
        //   maps 1 | [ value, value, value, value, value ]
        const mapsValuesMatrix = (0, _array.arrayMap)(maps, (map)=>map.getValues());
        const indexesLength = (0, _mixed.isDefined)(mapsValuesMatrix[0]) && mapsValuesMatrix[0].length || 0;
        const mergedValues = new Array(indexesLength);
        // A single scratch row, reused for every index, is passed to the aggregation function instead
        // of allocating one `[value, value, ...]` array per index. The previous matrix approach built
        // O(rows) throwaway sub-arrays on every sort/trim/hide rebuild (the dominant cost of updateCache
        // on large datasets). The aggregation functions read this array synchronously and never retain
        // it, so reuse is safe.
        const valuesForIndex = new Array(numberOfMaps);
        for(let index = 0; index < indexesLength; index += 1){
            for(let mapIndex = 0; mapIndex < numberOfMaps; mapIndex += 1){
                valuesForIndex[mapIndex] = mapsValuesMatrix[mapIndex][index];
            }
            mergedValues[index] = this.aggregationFunction(valuesForIndex);
        }
        return mergedValues;
    }
    /**
   * Get merged value for particular index.
   *
   * @param {number} index Index for which we calculate single result.
   * @param {boolean} [readFromCache=true] Determine if read results from the cache.
   * @returns {*}
   */ getMergedValueAtIndex(index, readFromCache) {
        const valueAtIndex = this.getMergedValues(readFromCache)[index];
        return (0, _mixed.isDefined)(valueAtIndex) ? valueAtIndex : this.fallbackValue;
    }
    /**
   * Rebuild cache for the collection.
   */ updateCache() {
        this.mergedValuesCache = this.getMergedValues(false);
    }
    /**
   * Initializes the aggregated collection with a function that combines per-index values and a fallback value for indexes with no data.
   */ constructor(aggregationFunction, fallbackValue){
        super(), /**
   * List of merged values. Value for each index is calculated using values inside registered maps.
   *
   * @type {Array}
   */ this.mergedValuesCache = [];
        this.aggregationFunction = aggregationFunction;
        this.fallbackValue = fallbackValue;
    }
}
