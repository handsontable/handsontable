(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Ashus
 * Last updated: Mar 22, 2022
 *
 * Description: Definition file for Czech - Czechia language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'cs-CZ'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Storno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'Žádné volby nejsou dostupné'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Vložit řádek nad'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Vložit řádek pod'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Vložit sloupec vlevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Vložit sloupec vpravo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Smazat řádek',
    'Smazat řádky'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Smazat sloupec',
    'Smazat sloupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Zpět'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Znovu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Pouze pro čtení'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Vymazat obsah sloupce'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Zarovnat'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Vlevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Na střed'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Vpravo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Do bloku'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Nahoru'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Na střed'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Dolů'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Zmrazit sloupec'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Zrušit zmrazení sloupce'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Ohraničení'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Nahoře'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Vpravo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Dole'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Vlevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Zrušit ohraničení'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Přidat komentář'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Upravit komentář'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Vymazat komentář'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Komenář pouze pro čtení'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Sloučit buňky'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Zrušit sloučení buněk'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopírovat'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Vyjmout'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exportovat'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Do CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Do Excelu'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exportuji…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Vložit podřízený řádek'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Oddělit od nadřízeného'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Skrýt sloupec',
    'Skrýt sloupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Zobrazit sloupec',
    'Zobrazit sloupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Skrýt řádek',
    'Skrýt řádky'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Zobrazit řádek',
    'Zobrazit řádky'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Žádné'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Prázdné'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Neprázdné'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Rovná se'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Nerovná se'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Začíná na'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Končí na'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Obsahuje'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Neobsahuje'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Větší než'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Větší nebo se rovná'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Menší než'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Menší nebo se rovná'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Je v rozsahu'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Není v rozsahu'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Po'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Po nebo rovno'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Před'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Před nebo rovno'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Dnes'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Zítra'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Včera'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Prádné buňky'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrovat dle stavu'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrovat dle hodnoty'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'A'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Nebo'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Vybrat vše'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Smazat'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Storno'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Hledat'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Hodnota'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Druhá hodnota'), _define_property(_obj, C.PAGINATION_SECTION, 'Stránkování'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Počet řádků'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] z [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Stránka [currentPage] z [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Přejít na první stránku'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Přejít na předchozí stránku'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Přejít na další stránku'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Přejít na poslední stránku'), _define_property(_obj, C.LOADING_TITLE, 'Načítání...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Zavřít'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Žádná data nejsou k dispozici'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Zatím není co zobrazit.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Nebyly nalezeny žádné výsledky'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Vypadá to, že vaše současné filtry skrývají všechny výsledky.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Resetovat filtry'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Načítání dat'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Čekejte prosím.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Data se nepodařilo načíst'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Řádky se nepodařilo vytvořit'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Řádky se nepodařilo aktualizovat'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Řádky se nepodařilo odstranit'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Požadavek selhal'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Znovu načíst'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);

})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});