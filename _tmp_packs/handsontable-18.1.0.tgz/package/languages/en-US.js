(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Handsoncode
 * Last updated: Nov 15, 2017
 *
 * Description: Definition file for English - United States language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'en-US'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Cancel'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'No available options'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Insert row above'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Insert row below'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Insert column left'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Insert column right'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Remove row',
    'Remove rows'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Remove column',
    'Remove columns'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Undo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Redo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Read only'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Clear column'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Alignment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Left'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Center'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Right'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Justify'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Top'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Middle'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Bottom'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Freeze column'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Unfreeze column'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Borders'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Top'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Right'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Bottom'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Left'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Remove border(s)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Add comment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Edit comment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Delete comment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Read-only comment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Merge cells'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Unmerge cells'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Copy'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Copy with header',
    'Copy with headers'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Copy with group header',
    'Copy with group headers'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Copy header only',
    'Copy headers only'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Cut'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Export'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'To CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'To Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exporting…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Insert child row'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Detach from parent'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Hide column',
    'Hide columns'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Show column',
    'Show columns'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Hide row',
    'Hide rows'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Show row',
    'Show rows'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'None'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Is empty'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Is not empty'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Is equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Is not equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Begins with'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Ends with'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Contains'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Does not contain'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Greater than'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Greater than or equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Less than'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Less than or equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Is between'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Is not between'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'After'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'After or equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Before'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Before or equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Today'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Tomorrow'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Yesterday'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Blank cells'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filter by condition'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filter by value'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'And'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Or'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Select all'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Clear'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Cancel'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Search'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Value'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Second value'), _define_property(_obj, C.PAGINATION_SECTION, 'Pagination'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Page size'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] of [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Page [currentPage] of [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Go to first page'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Go to previous page'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Go to next page'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Go to last page'), _define_property(_obj, C.CHECKBOX_CHECKED, 'Checked'), _define_property(_obj, C.CHECKBOX_UNCHECKED, 'Unchecked'), _define_property(_obj, C.LOADING_TITLE, 'Loading...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Close'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'No data available'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'There’s nothing to display yet.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'No results found'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'It looks like your current filters are hiding all results.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Reset filters'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Loading data'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Please wait.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Could not load data'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Could not create rows'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Could not update rows'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Could not remove rows'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Request failed'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Refetch'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);

})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});