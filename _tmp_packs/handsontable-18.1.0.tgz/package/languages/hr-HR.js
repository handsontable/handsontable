(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Domagoj Lončarić & Ante Živković
 * Last updated: Jan 31, 2024
 *
 * Description: Definition file for Croatian - Croatia language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'hr-HR'
}, _define_property(_obj, C.OK, 'U redu'), _define_property(_obj, C.CANCEL, 'Odustani'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'Nema dostupnih mogućnosti'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Umetni redak iznad'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Umetni redak ispod'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Umetni stupac lijevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Umetni stupac desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Ukloni redak',
    'Ukloni retke'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Ukloni stupac',
    'Ukloni stupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Poništi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Ponovi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Samo za čitanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Očisti stupac'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Poravnanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Lijevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Obostrano'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Gore'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Sredina'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Dolje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Zamrzni stupac'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Odmrzni stupac'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Granice'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Gore'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Dolje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Lijevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Ukloni granicu(e)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Dodaj komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Uredi komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Izbriši komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Komentar samo za čitanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Spoji čelije'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Razdijeli čelije'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopiraj'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Kopiraj sa zaglavljem',
    'Kopiraj sa zaglavljima'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Kopiraj sa grupnim zaglavljem',
    'Kopiraj sa grupnim zaglavljima'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Kopiraj samo zaglavlje',
    'Kopiraj samo zaglavlja'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Izreži'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Izvezi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Kao CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Kao Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Izvoz…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Umetni ugniježđeni redak'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Odvoji ugniježđeni redak'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Sakrij stupac',
    'Sakrij stupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Prikaži stupac',
    'Prikaži stupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Sakrij redak',
    'Sakrij retke'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Prikaži redak',
    'Prikaži retke'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Ništa'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Prazno'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Nije prazno'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Nije jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Počinje s'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Završava s'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Sadrži'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Ne sadrži'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Veće od'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Veće ili jednako od'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Manje od'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Manje ili jednako od'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Između'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Nije između'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Nakon'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Nakon ili jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Prije'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Prije ili jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Danas'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Sutra'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Jučer'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Prazna polja'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtriraj po uvjetu'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtriraj po vrijednosti'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'I'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Ili'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Odaberi sve'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Očisti'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'U redu'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Odustani'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Pretraži'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Vrijednost'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Druga vrijednost'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginacija'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Broj redaka'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] od [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Stranica [currentPage] od [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Idi na prvu stranicu'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Idi na prethodnu stranicu'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Idi na sljedeću stranicu'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Idi na posljednju stranicu'), _define_property(_obj, C.CHECKBOX_CHECKED, 'Označeno'), _define_property(_obj, C.CHECKBOX_UNCHECKED, 'Nije označeno'), _define_property(_obj, C.LOADING_TITLE, 'Učitavanje...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Zatvori'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Nema dostupnih podataka'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Još nema ništa za prikaz.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Nema pronađenih rezultata'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Čini se da vaši trenutni filtri skrivaju sve rezultate.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Resetiraj filtre'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Učitavanje podataka'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Pričekajte.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Nije moguće učitati podatke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Nije moguće stvoriti retke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Nije moguće ažurirati retke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Nije moguće ukloniti retke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Zahtjev nije uspio'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Ponovno učitaj'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);

})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});