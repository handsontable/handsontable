(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Ali Almasi
 * Last updated: Jan 19, 2025
 *
 * Description: Definition file for Farsi - Iran language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'fa-IR',
    languageDirection: 'rtl'
}, _define_property(_obj, C.OK, 'تایید'), _define_property(_obj, C.CANCEL, 'لغو'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'هیچ گزینه ای در دسترس نیست'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'درج ردیف در بالا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'درج ردیف در پایین'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'درج ستون در چپ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'درج ستون در راست'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'حذف ردیف',
    'حذف ردیف ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'حذف ستون',
    'حذف ستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'واگرد'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'بازگردانی'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'فقط خواندنی'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'پاک کردن ستون'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'تراز'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'چپ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'وسط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'راست'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'میزان'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'بالا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'میانه'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'پایین'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'انجماد ستون'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'باز کردن ستون'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'مرز ها'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'بالا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'راست'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'پایین'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'چپ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'حذف مرز (ها)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'افزودن کامنت'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'تغییر کامنت'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'حذف کامنت'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'فقط خواندنی کردن کامنت'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'ادغام سلول ها'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'جدا کردن سلول ها'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'کپی'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'کپی با سر ستون',
    'کپی با سرستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'کپی با سرستون گروه',
    'کپی با سرستون گروه ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'فقط کپی سرستون',
    'فقط کپی سرستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'بریدن'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'خروجی'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'به CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'به Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'در حال صدور…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'درج زیر ردیف'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'جدا کردن از سرردیف'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'پنهان کردن ستون',
    'پنهان کردن ستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'نمایش ستون',
    'نمایش ستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'پنهان کردن ردیف',
    'پنهان کردن ردیف ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'نمایش ردیف',
    'نمایش ردیف ها'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'هیچ'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'خالی است'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'خالی نیست'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'برابر است با'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'برابر نیست با'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'شروع می شود با'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'پایان می یابد با'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'شامل می شود'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'شامل نمی شود'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'بزرگ تر'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'بزرگتر مساوی'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'کوچکتر'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'کوچکتر مساوی'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'در میان است'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'در میان نیست'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'بعد'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'بعد یا مساوی'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'قبل'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'قبل یا مساوی'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'امروز'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'فردا'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'دیروز'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'سلول های خالی'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'فیلتر بر اساس شرایط'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'فیلتر بر اساس مقدار'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'و'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'یا'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'انتخاب همه'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'پاک کردن'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'تایید'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'لغو'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'جستجو'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'مقدار'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'مقدار دوم'), _define_property(_obj, C.PAGINATION_SECTION, 'صفحه‌بندی'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'تعداد سطرها'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'خودکار'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] از [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'صفحه [currentPage] از [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'به اولین صفحه بروید'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'به صفحه قبلی بروید'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'به صفحه بعدی بروید'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'به آخرین صفحه بروید'), _define_property(_obj, C.CHECKBOX_CHECKED, 'چک شده'), _define_property(_obj, C.CHECKBOX_UNCHECKED, 'چک نشده'), _define_property(_obj, C.LOADING_TITLE, 'در حال بارگذاری...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'بستن'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'هیچ داده‌ای در دسترس نیست'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'هنوز چیزی برای نمایش وجود ندارد.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'هیچ نتیجه‌ای یافت نشد'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'به نظر می‌رسد فیلترهای فعلی شما همه نتایج را پنهان می‌کنند.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'بازنشانی فیلترها'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'در حال بارگذاری داده‌ها'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'لطفاً صبر کنید.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'بارگذاری داده‌ها ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'ایجاد ردیف‌ها ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'به‌روزرسانی ردیف‌ها ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'حذف ردیف‌ها ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'درخواست ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'بارگذاری مجدد'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);

})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});