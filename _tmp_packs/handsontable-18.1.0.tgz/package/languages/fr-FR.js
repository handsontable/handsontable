(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Stefan Salzl, Thomas Senn
 * Last updated: Feb 05, 2018
 *
 * Description: Definition file for French - France language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'fr-FR'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Annuler'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Insérer une ligne en haut'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Insérer une ligne en bas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Insérer une colonne à gauche'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Insérer une colonne à droite'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Supprimer une ligne',
    'Supprimer les lignes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Supprimer une colonne',
    'Supprimer les colonnes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Annuler'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Rétablir'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Lecture seule'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Effacer la colonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Alignement'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Gauche'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Droite'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Justifié'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'En haut'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Au milieu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'En bas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Figer la colonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Libérer la colonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Bordures'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Supérieure'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Droite'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Inférieure'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Gauche'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Pas de bordure'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Ajouter commentaire'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Modifier commentaire'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Supprimer commentaire'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Commentaire en lecture seule'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Fusionner les cellules'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Séparer les cellules'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Copier'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Couper'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exporter'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'En CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'En Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exportation…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Insérer une sous-ligne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Détacher de la ligne précédente'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Masquer colonne',
    'Masquer les colonnes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Afficher colonne',
    'Afficher les colonnes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Masquer ligne',
    'Masquer les lignes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Afficher ligne',
    'Afficher les lignes'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Aucun'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Est vide'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'N\'est pas vide'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Egal à'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Est différent de'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Commence par'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Finit par'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Contient'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Ne contient pas'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Supérieur à'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Supérieur ou égal à'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Inférieur à'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Inférieur ou égal à'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Est compris entre'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'N\'est pas compris entre'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Après le'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Après ou égal au'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Avant le'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Avant ou égal au'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Aujourd\'hui'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Demain'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Hier'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Cellules vides'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrer par conditions'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrer par valeurs'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Et'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Ou'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Tout sélectionner'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Effacer la sélection'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Annuler'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Chercher'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Valeur'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Valeur de remplacement'), _define_property(_obj, C.PAGINATION_SECTION, 'Pagination'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Nombre de lignes'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] sur [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Page [currentPage] sur [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Aller à la première page'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Aller à la page précédente'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Aller à la page suivante'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Aller à la dernière page'), _define_property(_obj, C.LOADING_TITLE, 'Chargement...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Fermer'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Aucune donnée disponible'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Il n\'y a rien à afficher pour le moment.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Aucun résultat trouvé'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Il semble que vos filtres actuels masquent tous les résultats.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Réinitialiser les filtres'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Chargement des données'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Veuillez patienter.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Impossible de charger les données'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Impossible de créer les lignes'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Impossible de mettre à jour les lignes'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Impossible de supprimer les lignes'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'La requête a échoué'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Recharger'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);

})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});