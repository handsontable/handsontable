(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Handsoncode
 * Last updated: Feb 9, 2022
 *
 * Description: Definition file for Arabic - Without a specific country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'ar-AR',
    languageDirection: 'rtl'
}, _define_property(_obj, C.OK, 'موافق'), _define_property(_obj, C.CANCEL, 'إلغاء'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'لا توجد خيارات متوفرة'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'إدراج صف للأعلى'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'إدراج صف للأسفل'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'إدراج عمود لليسار'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'إدراج عمود لليمين'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'احدف الصف',
    'احذف الصفوف'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'احدف العمود',
    'احدف الأعمدة'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'تراجع'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'إلغاء التراجع'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'للقراءة فقط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'افرغ العمود'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'المحاذاة'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'يسار'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'وسط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'يمين'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'بالتساوي'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'أعلى'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'متوسط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'أسفل'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'تجميد العمود'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'إلغاء تجميد العمود'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'الحدود'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'أعلى'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'يمين'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'أسفل'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'يسار'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'أحذف الحد(ود)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'أضف تعليقاً'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'تعديل التعليق'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'احذف التعليق'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'تعليق للقراءة فقط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'ادمج الخلايا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'إلغاء دمج الخلايا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'نسخ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'قص'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'تصدير'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'إلى CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'إلى Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'جارٍ التصدير…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'أدخل صفاً فرعياً'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'افصل عن الصف الأصلي'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'إخفاء العمود',
    'إخفاء الأعمدة'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'إظهار العمود',
    'إظهار الأعمدة'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'إخفاء السطر',
    'إخفاء السطور'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'إظهار السطر',
    'إظهار السطور'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'بلا'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'فارغ'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'غير فارغ'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'لا يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'يبداً بـ'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'ينتهي بـ'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'يحتوي'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'لا يحتوي'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'أكبر من'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'أكبر أو يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'أصغر'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'أصغر أو يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'بين'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'خارج المجال'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'بعد'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'بعد أو يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'قبل'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'قبل أو يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'اليوم'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'غداً'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'البارحة'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'خلايا فارغة'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'تصفية حسب الشرط'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'تصفية حسب القيمة'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'و'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'أو'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'اختيار الكل'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'إلغاء'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'موافق'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'إلغاء'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'البحث'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'القيمة'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'القيمة الثانية'), _define_property(_obj, C.PAGINATION_SECTION, 'ترقيم الصفحات'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'عدد الصفوف'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'تلقائي'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] من [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'صفحة [currentPage] من [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'الانتقال إلى الصفحة الأولى'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'الانتقال إلى الصفحة السابقة'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'الانتقال إلى الصفحة التالية'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'الانتقال إلى الصفحة الأخيرة'), _define_property(_obj, C.LOADING_TITLE, 'جاري التحميل...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'إغلاق'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'لا توجد بيانات متاحة'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'لا يوجد شيء للعرض بعد.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'لم يتم العثور على نتائج'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'يبدو أن المرشحات الحالية تخفي جميع النتائج.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'إعادة تعيين المرشحات'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'جارٍ تحميل البيانات'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'يرجى الانتظار.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'تعذر تحميل البيانات'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'تعذر إنشاء الصفوف'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'تعذر تحديث الصفوف'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'تعذر إزالة الصفوف'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'فشل الطلب'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'إعادة التحميل'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);

})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});