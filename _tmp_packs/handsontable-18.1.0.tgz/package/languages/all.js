(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
0(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Handsoncode
 * Last updated: Feb 9, 2022
 *
 * Description: Definition file for Arabic - Without a specific country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'ar-AR',
    languageDirection: 'rtl'
}, _define_property(_obj, C.OK, 'موافق'), _define_property(_obj, C.CANCEL, 'إلغاء'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'لا توجد خيارات متوفرة'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'إدراج صف للأعلى'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'إدراج صف للأسفل'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'إدراج عمود لليسار'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'إدراج عمود لليمين'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'احدف الصف',
    'احذف الصفوف'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'احدف العمود',
    'احدف الأعمدة'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'تراجع'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'إلغاء التراجع'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'للقراءة فقط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'افرغ العمود'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'المحاذاة'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'يسار'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'وسط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'يمين'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'بالتساوي'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'أعلى'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'متوسط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'أسفل'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'تجميد العمود'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'إلغاء تجميد العمود'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'الحدود'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'أعلى'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'يمين'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'أسفل'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'يسار'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'أحذف الحد(ود)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'أضف تعليقاً'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'تعديل التعليق'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'احذف التعليق'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'تعليق للقراءة فقط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'ادمج الخلايا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'إلغاء دمج الخلايا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'نسخ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'قص'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'تصدير'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'إلى CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'إلى Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'جارٍ التصدير…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'أدخل صفاً فرعياً'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'افصل عن الصف الأصلي'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'إخفاء العمود',
    'إخفاء الأعمدة'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'إظهار العمود',
    'إظهار الأعمدة'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'إخفاء السطر',
    'إخفاء السطور'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'إظهار السطر',
    'إظهار السطور'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'بلا'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'فارغ'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'غير فارغ'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'لا يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'يبداً بـ'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'ينتهي بـ'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'يحتوي'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'لا يحتوي'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'أكبر من'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'أكبر أو يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'أصغر'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'أصغر أو يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'بين'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'خارج المجال'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'بعد'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'بعد أو يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'قبل'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'قبل أو يساوي'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'اليوم'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'غداً'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'البارحة'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'خلايا فارغة'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'تصفية حسب الشرط'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'تصفية حسب القيمة'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'و'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'أو'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'اختيار الكل'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'إلغاء'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'موافق'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'إلغاء'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'البحث'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'القيمة'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'القيمة الثانية'), _define_property(_obj, C.PAGINATION_SECTION, 'ترقيم الصفحات'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'عدد الصفوف'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'تلقائي'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] من [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'صفحة [currentPage] من [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'الانتقال إلى الصفحة الأولى'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'الانتقال إلى الصفحة السابقة'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'الانتقال إلى الصفحة التالية'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'الانتقال إلى الصفحة الأخيرة'), _define_property(_obj, C.LOADING_TITLE, 'جاري التحميل...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'إغلاق'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'لا توجد بيانات متاحة'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'لا يوجد شيء للعرض بعد.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'لم يتم العثور على نتائج'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'يبدو أن المرشحات الحالية تخفي جميع النتائج.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'إعادة تعيين المرشحات'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'جارٍ تحميل البيانات'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'يرجى الانتظار.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'تعذر تحميل البيانات'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'تعذر إنشاء الصفوف'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'تعذر تحديث الصفوف'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'تعذر إزالة الصفوف'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'فشل الطلب'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'إعادة التحميل'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
2(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Ashus
 * Last updated: Mar 22, 2022
 *
 * Description: Definition file for Czech - Czechia language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'cs-CZ'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Storno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'Žádné volby nejsou dostupné'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Vložit řádek nad'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Vložit řádek pod'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Vložit sloupec vlevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Vložit sloupec vpravo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Smazat řádek',
    'Smazat řádky'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Smazat sloupec',
    'Smazat sloupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Zpět'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Znovu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Pouze pro čtení'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Vymazat obsah sloupce'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Zarovnat'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Vlevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Na střed'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Vpravo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Do bloku'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Nahoru'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Na střed'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Dolů'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Zmrazit sloupec'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Zrušit zmrazení sloupce'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Ohraničení'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Nahoře'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Vpravo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Dole'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Vlevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Zrušit ohraničení'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Přidat komentář'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Upravit komentář'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Vymazat komentář'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Komenář pouze pro čtení'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Sloučit buňky'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Zrušit sloučení buněk'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopírovat'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Vyjmout'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exportovat'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Do CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Do Excelu'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exportuji…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Vložit podřízený řádek'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Oddělit od nadřízeného'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Skrýt sloupec',
    'Skrýt sloupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Zobrazit sloupec',
    'Zobrazit sloupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Skrýt řádek',
    'Skrýt řádky'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Zobrazit řádek',
    'Zobrazit řádky'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Žádné'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Prázdné'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Neprázdné'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Rovná se'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Nerovná se'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Začíná na'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Končí na'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Obsahuje'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Neobsahuje'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Větší než'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Větší nebo se rovná'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Menší než'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Menší nebo se rovná'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Je v rozsahu'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Není v rozsahu'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Po'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Po nebo rovno'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Před'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Před nebo rovno'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Dnes'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Zítra'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Včera'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Prádné buňky'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrovat dle stavu'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrovat dle hodnoty'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'A'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Nebo'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Vybrat vše'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Smazat'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Storno'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Hledat'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Hodnota'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Druhá hodnota'), _define_property(_obj, C.PAGINATION_SECTION, 'Stránkování'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Počet řádků'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] z [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Stránka [currentPage] z [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Přejít na první stránku'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Přejít na předchozí stránku'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Přejít na další stránku'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Přejít na poslední stránku'), _define_property(_obj, C.LOADING_TITLE, 'Načítání...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Zavřít'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Žádná data nejsou k dispozici'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Zatím není co zobrazit.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Nebyly nalezeny žádné výsledky'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Vypadá to, že vaše současné filtry skrývají všechny výsledky.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Resetovat filtry'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Načítání dat'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Čekejte prosím.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Data se nepodařilo načíst'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Řádky se nepodařilo vytvořit'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Řádky se nepodařilo aktualizovat'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Řádky se nepodařilo odstranit'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Požadavek selhal'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Znovu načíst'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
3(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Stefan Salzl
 * Last updated: Jan 08, 2018
 *
 * Description: Definition file for German - Switzerland language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'de-CH'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Abbrechen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Zeile einfügen oberhalb'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Zeile einfügen unterhalb'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Spalte einfügen links'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Spalte einfügen rechts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Zeile löschen',
    'Zeilen löschen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Spalte löschen',
    'Spalten löschen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Rückgangig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Wiederholen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Nur Lesezugriff'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Spalteninhalt löschen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Ausrichtung'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Linksbündig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Zentriert'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Rechtsbündig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Blocksatz'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Oben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Mitte'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Unten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Spalte fixieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Spaltenfixierung aufheben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Rahmen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Oben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Rechts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Unten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Links'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Kein Rahmen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Kommentar hinzufügen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Kommentar bearbeiten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Kommentar löschen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Schreibschutz Kommentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Zellen verbinden'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Zellen teilen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Ausschneiden'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exportieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Als CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Als Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Wird exportiert…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Nachfolgerzeile einfügen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Von Vorgängerzeile abkoppeln'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Spalte ausblenden',
    'Spalten ausblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Spalte einblenden',
    'Spalten einblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Zeile ausblenden',
    'Zeilen ausblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Zeile einblenden',
    'Zeilen einblenden'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Kein Filter'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Ist leer'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Ist nicht leer'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Ist gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Ist ungleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Beginnt mit'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Endet mit'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Enthält'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Enthält nicht'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Grösser als'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Grösser gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Kleiner als'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Kleiner gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Zwischen'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Ausserhalb'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Nach'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Nach oder gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Vor'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Vor oder gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Heute'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Morgen'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Gestern'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Leere Zellen'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Per Bedingung filtern'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Nach Zahlen filtern'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Und'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Oder'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Alles auswählen'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Auswahl aufheben'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Abbrechen'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Suchen'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Wert'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Alternativwert'), _define_property(_obj, C.PAGINATION_SECTION, 'Seitennavigation'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Anzahl Zeilen'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] von [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Seite [currentPage] von [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Zur ersten Seite wechseln'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Zur vorherigen Seite wechseln'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Zur nächsten Seite wechseln'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Zur letzten Seite wechseln'), _define_property(_obj, C.LOADING_TITLE, 'Lädt...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Schließen'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Keine Daten verfügbar'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Es gibt noch nichts anzuzeigen.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Keine Ergebnisse gefunden'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Es scheint, als würden Ihre aktuellen Filter alle Ergebnisse ausblenden.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Filter zurücksetzen'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Daten werden geladen'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Bitte warten.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Daten konnten nicht geladen werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Zeilen konnten nicht erstellt werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Zeilen konnten nicht aktualisiert werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Zeilen konnten nicht entfernt werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Anfrage fehlgeschlagen'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Neu laden'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
4(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Stefan Salzl
 * Last updated: Jan 08, 2018
 *
 * Description: Definition file for German - Germany language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'de-DE'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Abbrechen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Zeile einfügen oberhalb'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Zeile einfügen unterhalb'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Spalte einfügen links'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Spalte einfügen rechts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Zeile löschen',
    'Zeilen löschen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Spalte löschen',
    'Spalten löschen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Rückgangig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Wiederholen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Nur Lesezugriff'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Spalteninhalt löschen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Ausrichtung'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Linksbündig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Zentriert'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Rechtsbündig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Blocksatz'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Oben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Mitte'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Unten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Spalte fixieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Spaltenfixierung aufheben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Rahmen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Oben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Rechts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Unten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Links'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Kein Rahmen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Kommentar hinzufügen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Kommentar bearbeiten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Kommentar löschen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Schreibschutz Kommentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Zellen verbinden'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Zellen teilen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Ausschneiden'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exportieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Als CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Als Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Wird exportiert…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Nachfolgerzeile einfügen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Von Vorgängerzeile abkoppeln'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Spalte ausblenden',
    'Spalten ausblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Spalte einblenden',
    'Spalten einblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Zeile ausblenden',
    'Zeilen ausblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Zeile einblenden',
    'Zeilen einblenden'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Kein Filter'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Ist leer'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Ist nicht leer'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Ist gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Ist ungleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Beginnt mit'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Endet mit'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Enthält'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Enthält nicht'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Größer als'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Größer gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Kleiner als'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Kleiner gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Zwischen'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Außerhalb'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Nach'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Nach oder gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Vor'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Vor oder gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Heute'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Morgen'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Gestern'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Leere Zellen'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Per Bedingung filtern'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Nach Zahlen filtern'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Und'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Oder'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Alles auswählen'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Auswahl aufheben'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Abbrechen'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Suchen'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Wert'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Alternativwert'), _define_property(_obj, C.PAGINATION_SECTION, 'Seitennavigation'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Anzahl Zeilen'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] von [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Seite [currentPage] von [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Zur ersten Seite wechseln'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Zur vorherigen Seite wechseln'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Zur nächsten Seite wechseln'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Zur letzten Seite wechseln'), _define_property(_obj, C.LOADING_TITLE, 'Lädt...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Schließen'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Keine Daten verfügbar'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Es gibt noch nichts anzuzeigen.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Keine Ergebnisse gefunden'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Es scheint, als würden Ihre aktuellen Filter alle Ergebnisse ausblenden.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Filter zurücksetzen'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Daten werden geladen'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Bitte warten.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Daten konnten nicht geladen werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Zeilen konnten nicht erstellt werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Zeilen konnten nicht aktualisiert werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Zeilen konnten nicht entfernt werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Anfrage fehlgeschlagen'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Neu laden'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
5(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Handsoncode
 * Last updated: Nov 15, 2017
 *
 * Description: Definition file for English - United States language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'en-US'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Cancel'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'No available options'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Insert row above'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Insert row below'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Insert column left'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Insert column right'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Remove row',
    'Remove rows'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Remove column',
    'Remove columns'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Undo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Redo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Read only'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Clear column'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Alignment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Left'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Center'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Right'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Justify'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Top'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Middle'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Bottom'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Freeze column'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Unfreeze column'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Borders'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Top'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Right'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Bottom'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Left'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Remove border(s)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Add comment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Edit comment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Delete comment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Read-only comment'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Merge cells'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Unmerge cells'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Copy'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Copy with header',
    'Copy with headers'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Copy with group header',
    'Copy with group headers'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Copy header only',
    'Copy headers only'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Cut'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Export'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'To CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'To Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exporting…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Insert child row'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Detach from parent'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Hide column',
    'Hide columns'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Show column',
    'Show columns'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Hide row',
    'Hide rows'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Show row',
    'Show rows'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'None'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Is empty'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Is not empty'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Is equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Is not equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Begins with'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Ends with'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Contains'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Does not contain'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Greater than'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Greater than or equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Less than'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Less than or equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Is between'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Is not between'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'After'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'After or equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Before'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Before or equal to'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Today'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Tomorrow'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Yesterday'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Blank cells'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filter by condition'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filter by value'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'And'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Or'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Select all'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Clear'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Cancel'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Search'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Value'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Second value'), _define_property(_obj, C.PAGINATION_SECTION, 'Pagination'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Page size'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] of [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Page [currentPage] of [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Go to first page'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Go to previous page'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Go to next page'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Go to last page'), _define_property(_obj, C.CHECKBOX_CHECKED, 'Checked'), _define_property(_obj, C.CHECKBOX_UNCHECKED, 'Unchecked'), _define_property(_obj, C.LOADING_TITLE, 'Loading...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Close'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'No data available'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'There’s nothing to display yet.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'No results found'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'It looks like your current filters are hiding all results.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Reset filters'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Loading data'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Please wait.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Could not load data'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Could not create rows'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Could not update rows'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Could not remove rows'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Request failed'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Refetch'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
6(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Handsoncode, Enrique Enciso
 * Last updated: Nov 18, 2022
 *
 * Description: Definition file for Spanish - Mexico language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'es-MX'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Cancelar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Insertar fila arriba'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Insertar fila abajo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Insertar columna izquierda'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Insertar columna derecha'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Eliminar fila',
    'Eliminar filas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Eliminar columna',
    'Eliminar columnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Deshacer'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Rehacer'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Solo lectura'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Limpiar columna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Alineación'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Izquierda'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centro'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Derecha'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Justificar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Superior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Medio'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Inferior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Congelar columna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Descongelar columna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Bordes'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Superior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Derecho'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Inferior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Izquierdo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Quitar borde(s)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Agregar comentario'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Editar comentario'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Borrar comentario'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Comentario Solo de lectura'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Unir celdas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Separar celdas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Copiar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Copiar con encabezado',
    'Copiar con encabezados'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Copiar con encabezado de grupo',
    'Copiar con encabezados de grupos'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Copiar solo el encabezado',
    'Copiar solo los encabezados'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Cortar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exportar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'A CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'A Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exportando…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Insertar fila hija'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Separar del padre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Esconder columna',
    'Esconder columnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Mostrar columna',
    'Mostrar columnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Esconder fila',
    'Esconder filas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Mostrar fila',
    'Mostrar filas'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Ninguna'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Está vacío'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'No está vacío'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Es igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'No es igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Comienza con'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Termina con'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Contiene'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'No contiene'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Mayor que'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Mayor o igual que'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Menor que'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Menor o igual que'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Es entre'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'No es entre'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Después'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Después o igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Antes'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Antes o igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Hoy'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Mañana'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Ayer'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Celdas vacías'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrar por condición'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrar por valor'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Y'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'O'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Seleccionar todo'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Borrar'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Cancelar'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Buscar'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Valor'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Valor secundario'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginación'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Filas por página'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] de [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Página [currentPage] de [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Ir a la primera página'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Ir a la página anterior'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Ir a la siguiente página'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Ir a la última página'), _define_property(_obj, C.LOADING_TITLE, 'Cargando...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Cerrar'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'No hay datos disponibles'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'No hay nada que mostrar aún.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'No se encontraron resultados'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Parece que tus filtros actuales están ocultando todos los resultados.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Restablecer filtros'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Cargando datos'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Espere por favor.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'No se pudieron cargar los datos'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'No se pudieron crear las filas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'No se pudieron actualizar las filas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'No se pudieron eliminar las filas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'La solicitud falló'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Volver a cargar'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
7(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Ali Almasi
 * Last updated: Jan 19, 2025
 *
 * Description: Definition file for Farsi - Iran language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'fa-IR',
    languageDirection: 'rtl'
}, _define_property(_obj, C.OK, 'تایید'), _define_property(_obj, C.CANCEL, 'لغو'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'هیچ گزینه ای در دسترس نیست'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'درج ردیف در بالا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'درج ردیف در پایین'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'درج ستون در چپ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'درج ستون در راست'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'حذف ردیف',
    'حذف ردیف ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'حذف ستون',
    'حذف ستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'واگرد'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'بازگردانی'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'فقط خواندنی'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'پاک کردن ستون'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'تراز'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'چپ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'وسط'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'راست'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'میزان'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'بالا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'میانه'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'پایین'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'انجماد ستون'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'باز کردن ستون'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'مرز ها'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'بالا'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'راست'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'پایین'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'چپ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'حذف مرز (ها)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'افزودن کامنت'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'تغییر کامنت'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'حذف کامنت'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'فقط خواندنی کردن کامنت'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'ادغام سلول ها'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'جدا کردن سلول ها'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'کپی'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'کپی با سر ستون',
    'کپی با سرستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'کپی با سرستون گروه',
    'کپی با سرستون گروه ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'فقط کپی سرستون',
    'فقط کپی سرستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'بریدن'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'خروجی'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'به CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'به Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'در حال صدور…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'درج زیر ردیف'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'جدا کردن از سرردیف'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'پنهان کردن ستون',
    'پنهان کردن ستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'نمایش ستون',
    'نمایش ستون ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'پنهان کردن ردیف',
    'پنهان کردن ردیف ها'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'نمایش ردیف',
    'نمایش ردیف ها'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'هیچ'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'خالی است'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'خالی نیست'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'برابر است با'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'برابر نیست با'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'شروع می شود با'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'پایان می یابد با'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'شامل می شود'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'شامل نمی شود'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'بزرگ تر'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'بزرگتر مساوی'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'کوچکتر'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'کوچکتر مساوی'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'در میان است'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'در میان نیست'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'بعد'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'بعد یا مساوی'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'قبل'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'قبل یا مساوی'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'امروز'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'فردا'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'دیروز'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'سلول های خالی'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'فیلتر بر اساس شرایط'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'فیلتر بر اساس مقدار'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'و'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'یا'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'انتخاب همه'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'پاک کردن'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'تایید'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'لغو'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'جستجو'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'مقدار'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'مقدار دوم'), _define_property(_obj, C.PAGINATION_SECTION, 'صفحه‌بندی'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'تعداد سطرها'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'خودکار'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] از [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'صفحه [currentPage] از [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'به اولین صفحه بروید'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'به صفحه قبلی بروید'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'به صفحه بعدی بروید'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'به آخرین صفحه بروید'), _define_property(_obj, C.CHECKBOX_CHECKED, 'چک شده'), _define_property(_obj, C.CHECKBOX_UNCHECKED, 'چک نشده'), _define_property(_obj, C.LOADING_TITLE, 'در حال بارگذاری...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'بستن'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'هیچ داده‌ای در دسترس نیست'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'هنوز چیزی برای نمایش وجود ندارد.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'هیچ نتیجه‌ای یافت نشد'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'به نظر می‌رسد فیلترهای فعلی شما همه نتایج را پنهان می‌کنند.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'بازنشانی فیلترها'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'در حال بارگذاری داده‌ها'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'لطفاً صبر کنید.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'بارگذاری داده‌ها ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'ایجاد ردیف‌ها ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'به‌روزرسانی ردیف‌ها ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'حذف ردیف‌ها ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'درخواست ناموفق بود'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'بارگذاری مجدد'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
8(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Stefan Salzl, Thomas Senn
 * Last updated: Feb 05, 2018
 *
 * Description: Definition file for French - France language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'fr-FR'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Annuler'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Insérer une ligne en haut'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Insérer une ligne en bas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Insérer une colonne à gauche'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Insérer une colonne à droite'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Supprimer une ligne',
    'Supprimer les lignes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Supprimer une colonne',
    'Supprimer les colonnes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Annuler'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Rétablir'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Lecture seule'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Effacer la colonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Alignement'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Gauche'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Droite'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Justifié'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'En haut'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Au milieu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'En bas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Figer la colonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Libérer la colonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Bordures'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Supérieure'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Droite'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Inférieure'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Gauche'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Pas de bordure'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Ajouter commentaire'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Modifier commentaire'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Supprimer commentaire'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Commentaire en lecture seule'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Fusionner les cellules'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Séparer les cellules'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Copier'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Couper'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exporter'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'En CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'En Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exportation…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Insérer une sous-ligne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Détacher de la ligne précédente'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Masquer colonne',
    'Masquer les colonnes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Afficher colonne',
    'Afficher les colonnes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Masquer ligne',
    'Masquer les lignes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Afficher ligne',
    'Afficher les lignes'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Aucun'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Est vide'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'N\'est pas vide'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Egal à'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Est différent de'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Commence par'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Finit par'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Contient'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Ne contient pas'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Supérieur à'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Supérieur ou égal à'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Inférieur à'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Inférieur ou égal à'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Est compris entre'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'N\'est pas compris entre'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Après le'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Après ou égal au'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Avant le'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Avant ou égal au'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Aujourd\'hui'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Demain'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Hier'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Cellules vides'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrer par conditions'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrer par valeurs'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Et'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Ou'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Tout sélectionner'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Effacer la sélection'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Annuler'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Chercher'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Valeur'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Valeur de remplacement'), _define_property(_obj, C.PAGINATION_SECTION, 'Pagination'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Nombre de lignes'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] sur [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Page [currentPage] sur [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Aller à la première page'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Aller à la page précédente'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Aller à la page suivante'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Aller à la dernière page'), _define_property(_obj, C.LOADING_TITLE, 'Chargement...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Fermer'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Aucune donnée disponible'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Il n\'y a rien à afficher pour le moment.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Aucun résultat trouvé'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Il semble que vos filtres actuels masquent tous les résultats.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Réinitialiser les filtres'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Chargement des données'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Veuillez patienter.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Impossible de charger les données'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Impossible de créer les lignes'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Impossible de mettre à jour les lignes'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Impossible de supprimer les lignes'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'La requête a échoué'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Recharger'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
9(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Domagoj Lončarić & Ante Živković
 * Last updated: Jan 31, 2024
 *
 * Description: Definition file for Croatian - Croatia language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'hr-HR'
}, _define_property(_obj, C.OK, 'U redu'), _define_property(_obj, C.CANCEL, 'Odustani'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'Nema dostupnih mogućnosti'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Umetni redak iznad'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Umetni redak ispod'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Umetni stupac lijevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Umetni stupac desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Ukloni redak',
    'Ukloni retke'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Ukloni stupac',
    'Ukloni stupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Poništi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Ponovi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Samo za čitanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Očisti stupac'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Poravnanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Lijevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Obostrano'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Gore'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Sredina'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Dolje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Zamrzni stupac'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Odmrzni stupac'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Granice'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Gore'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Dolje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Lijevo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Ukloni granicu(e)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Dodaj komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Uredi komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Izbriši komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Komentar samo za čitanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Spoji čelije'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Razdijeli čelije'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopiraj'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Kopiraj sa zaglavljem',
    'Kopiraj sa zaglavljima'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Kopiraj sa grupnim zaglavljem',
    'Kopiraj sa grupnim zaglavljima'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Kopiraj samo zaglavlje',
    'Kopiraj samo zaglavlja'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Izreži'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Izvezi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Kao CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Kao Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Izvoz…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Umetni ugniježđeni redak'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Odvoji ugniježđeni redak'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Sakrij stupac',
    'Sakrij stupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Prikaži stupac',
    'Prikaži stupce'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Sakrij redak',
    'Sakrij retke'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Prikaži redak',
    'Prikaži retke'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Ništa'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Prazno'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Nije prazno'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Nije jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Počinje s'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Završava s'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Sadrži'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Ne sadrži'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Veće od'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Veće ili jednako od'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Manje od'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Manje ili jednako od'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Između'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Nije između'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Nakon'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Nakon ili jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Prije'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Prije ili jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Danas'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Sutra'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Jučer'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Prazna polja'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtriraj po uvjetu'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtriraj po vrijednosti'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'I'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Ili'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Odaberi sve'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Očisti'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'U redu'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Odustani'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Pretraži'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Vrijednost'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Druga vrijednost'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginacija'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Broj redaka'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] od [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Stranica [currentPage] od [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Idi na prvu stranicu'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Idi na prethodnu stranicu'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Idi na sljedeću stranicu'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Idi na posljednju stranicu'), _define_property(_obj, C.CHECKBOX_CHECKED, 'Označeno'), _define_property(_obj, C.CHECKBOX_UNCHECKED, 'Nije označeno'), _define_property(_obj, C.LOADING_TITLE, 'Učitavanje...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Zatvori'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Nema dostupnih podataka'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Još nema ništa za prikaz.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Nema pronađenih rezultata'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Čini se da vaši trenutni filtri skrivaju sve rezultate.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Resetiraj filtre'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Učitavanje podataka'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Pričekajte.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Nije moguće učitati podatke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Nije moguće stvoriti retke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Nije moguće ažurirati retke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Nije moguće ukloniti retke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Zahtjev nije uspio'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Ponovno učitaj'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
11(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Andrea Cattaneo
 * Last updated: Sep 14, 2018
 *
 * Description: Definition file for Italian - Italy language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'it-IT'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Annulla'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Inserisci riga sopra'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Inserisci riga sotto'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Inserisci colonna a sinistra'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Inserisci colonna a destra'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Rimuovi riga',
    'Rimuovi righe'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Rimuovi colonna',
    'Rimuovi colonne'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Annulla'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Ripeti'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Sola lettura'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Svuota colonna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Allineamento'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Sinistra'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centro'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Destra'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Giustificato'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'In alto'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'A metà'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'In basso'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Blocca colonna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Sblocca colonna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Bordi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Sopra'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Destra'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Sotto'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Sinistra'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Rimuovi bordo(i)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Aggiungi commento'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Modifica commento'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Rimuovi commento'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Commento in sola lettura'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Unisci celle'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Separa celle'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Copia'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Copia con intestazione',
    'Copia con intestazioni'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, 'Copia con intestazione completa'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Copia solo intestazione',
    'Copia solo intestazioni'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Taglia'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Esporta'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'In CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'In Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Esportazione in corso…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Inserisci riga figlia'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Scollega da riga madre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Nascondi colonna',
    'Nascondi colonne'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Mostra colonna',
    'Mostra colonne'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Nascondi riga',
    'Nascondi righe'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Mostra riga',
    'Mostra righe'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Nessuna'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'È vuoto'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Non è vuoto'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'È uguale a'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'È diverso da'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Inizia con'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Termina con'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Contiene'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Non contiene'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Maggiore'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Maggiore o uguale'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Minore'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Minore o uguale'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'È compreso tra'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Non è compreso tra'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Dopo'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Dopo o uguale a'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Prima'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Prima o uguale a'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Oggi'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Domani'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Ieri'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Celle vuote'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtra per condizione'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtra per valore'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'E'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'O'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Seleziona tutto'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Pulisci'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Annulla'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Cerca'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Valore'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Sostituisci con'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginazione'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Numero righe'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] di [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Pagina [currentPage] di [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Vai alla prima pagina'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Vai alla pagina precedente'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Vai alla pagina successiva'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Vai all\'ultima pagina'), _define_property(_obj, C.LOADING_TITLE, 'Caricamento...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Chiudi'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Nessun dato disponibile'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Non c\'è ancora nulla da visualizzare.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Nessun risultato trovato'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Sembra che i tuoi filtri attuali stiano nascondendo tutti i risultati.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Reimposta filtri'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Caricamento dati'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Attendere prego.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Impossibile caricare i dati'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Impossibile creare le righe'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Impossibile aggiornare le righe'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Impossibile rimuovere le righe'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Richiesta non riuscita'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Ricarica'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
12(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: hand-dot
 * Last updated: Jan 9, 2023
 *
 * Description: Definition file for Japanese - Japan language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'ja-JP'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'キャンセル'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, '行を上に挿入'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, '行を下に挿入'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, '列を左に挿入'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, '列を右に挿入'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    '行を削除',
    '行を削除'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    '列を削除',
    '列を削除'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, '元に戻す'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'やり直し'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, '読み取り専用'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, '列をクリア'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, '配置'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, '左揃え'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, '中央揃え'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, '右揃え'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, '両端揃え'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, '上揃え'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, '中央揃え(垂直)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, '下揃え'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, '列を固定'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, '列の固定を解除'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, '枠線'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, '上'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, '右'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, '下'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, '左'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, '枠線を削除'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'コメントを追加'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'コメントを編集'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'コメントを削除'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, '読み取り専用コメント'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'セルを結合'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'セルの結合を解除'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'コピー'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'ヘッダ付きでコピー',
    'ヘッダ付きでコピー'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'グループヘッダ付きでコピー',
    'グループヘッダ付きでコピー'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'ヘッダのみコピー',
    'ヘッダのみコピー'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, '切り取り'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'エクスポート'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'CSVへ'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Excelへ'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'エクスポート中…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, '子の行を挿入'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, '親の行と切り離す'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    '列を非表示',
    '列を非表示'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    '列を表示',
    '列を表示'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    '行を非表示',
    '行を非表示'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    '行を表示',
    '行を表示'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'なし'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, '空白'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, '空白ではない'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, '次と等しい'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, '次と等しくない'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, '次で始まる'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, '次で終わる'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, '次を含む'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, '次を含まない'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, '次より大きい'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, '以上'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, '次より小さい'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, '以下'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, '次の間にある'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, '次の間にない'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, '次より後の日付'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, '次以降の日付'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, '次より前の日付'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, '次以前の日付'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, '今日'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, '明日'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, '昨日'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, '空白のセル'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, '条件でフィルタ'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, '値でフィルタ'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'かつ'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'もしくは'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'すべて選択'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'クリア'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'キャンセル'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, '検索'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, '値'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, '値2'), _define_property(_obj, C.PAGINATION_SECTION, 'ページネーション'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, '行数'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, '自動'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] / 全[total]件'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'ページ [currentPage] / [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, '最初のページへ移動'), _define_property(_obj, C.PAGINATION_PREV_PAGE, '前のページへ移動'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, '次のページへ移動'), _define_property(_obj, C.PAGINATION_LAST_PAGE, '最後のページへ移動'), _define_property(_obj, C.LOADING_TITLE, '読み込み中...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, '閉じる'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'データがありません'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, '表示するデータがまだありません。'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, '結果が見つかりません'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, '現在のフィルターがすべての結果を非表示にしているようです。'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'フィルターをリセット'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'データを読み込み中'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'お待ちください。'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'データを読み込めませんでした'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, '行を作成できませんでした'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, '行を更新できませんでした'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, '行を削除できませんでした'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'リクエストに失敗しました'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, '再読み込み'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
13(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Hwang, Gun-gu
 * Last updated: Aug 20, 2018
 *
 * Description: Definition file for Korean - Korea language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'ko-KR'
}, _define_property(_obj, C.OK, '확인'), _define_property(_obj, C.CANCEL, '취소'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, '위쪽에 행 삽입'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, '아래쪽에 행 삽입'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, '왼쪽에 열 삽입'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, '오른쪽에 열 삽입'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    '행 삭제',
    '여러 행 삭제'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    '열 삭제',
    '여러 열 삭제'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, '되돌리기'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, '다시하기'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, '읽기 전용'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, '열 지우기'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, '정렬'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, '왼쪽'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, '중앙'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, '오른쪽'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, '자동'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, '위쪽'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, '가운데'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, '아래쪽'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, '열 고정'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, '열 고정 해제'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, '테두리'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, '위쪽'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, '오른쪽'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, '아래쪽'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, '왼쪽'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, '테두리 지우기'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, '댓글 달기'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, '댓글 편집'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, '댓글 삭제'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, '읽기 전용 댓글'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, '셀 병합'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, '셀 병합 해제'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, '복사'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, '잘라내기'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, '내보내기'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'CSV로'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Excel로'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, '내보내는 중…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, '자녀 행 추가'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, '부모행에서 제거'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    '열 숨기기',
    '여러 열 숨기기'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    '열 숨기기 해제',
    '여러 열 숨기기 해제'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    '행 숨기기',
    '여러 행 숨기기'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    '행 숨기기 해제',
    '여러 행 숨기기 해제'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, '조건없음'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, '비어있음'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, '비어있지 않음'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, '같'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, '같지 않음'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, '시작 문자'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, '끝 문자'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, '포함'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, '포함하지 않음'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, '보다 큼'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, '크거나 같음'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, '보다 작'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, '작거나 같음'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, '사이'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, '사이 제외'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, '다음'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, '다음 이후 포함'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, '전'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, '이전 포함'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, '오늘'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, '내일'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, '어제'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, '공란'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, '조건부 필터'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, '값 필터'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, '그리고'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, '또는'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, '전체선택'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, '지우기'), _define_property(_obj, C.FILTERS_BUTTONS_OK, '확인'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, '취소'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, '찾기'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, '값'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, '두번째 값'), _define_property(_obj, C.PAGINATION_SECTION, '페이지 매김'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, '행 수'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, '자동'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] / 총 [total]건'), _define_property(_obj, C.PAGINATION_NAV_SECTION, '페이지 [currentPage] / [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, '첫 페이지로 이동'), _define_property(_obj, C.PAGINATION_PREV_PAGE, '이전 페이지로 이동'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, '다음 페이지로 이동'), _define_property(_obj, C.PAGINATION_LAST_PAGE, '마지막 페이지로 이동'), _define_property(_obj, C.LOADING_TITLE, '로딩 중...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, '닫기'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, '사용 가능한 데이터가 없습니다'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, '아직 표시할 내용이 없습니다.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, '결과를 찾을 수 없습니다'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, '현재 필터가 모든 결과를 숨기고 있는 것 같습니다.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, '필터 재설정'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, '데이터 로드 중'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, '잠시만 기다려 주세요.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, '데이터를 불러올 수 없습니다'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, '행을 만들 수 없습니다'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, '행을 업데이트할 수 없습니다'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, '행을 제거할 수 없습니다'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, '요청이 실패했습니다'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, '다시 불러오기'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
14(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Edgars Voroboks, NullIsNot0
 * Last updated: Dec 5, 2022
 *
 * Description: Definition file for Latvian - Latvia language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'lv-LV'
}, _define_property(_obj, C.OK, 'Labi'), _define_property(_obj, C.CANCEL, 'Atcelt'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'Nav pieejamu opciju'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Ievietot rindu augšā'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Ievietot rindu apakšā'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Ievietot kolonnu pa kreisi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Ievietot kolonnu pa labi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Dzēst rindu',
    'Dzēst rindas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Dzēst kolonnu',
    'Dzēst kolonnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Atsaukt'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Pārtaisīt'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Lasīšanas režīms'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Notīrīt kolonnu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Izvietojums'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Pa kreisi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centrēts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Pa labi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Izlīdzināts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Augšā'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Pa vidu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Apakšā'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Iesaldēt kolonnu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Atsaldēt kolonnu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Robežas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Augšā'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Pa labi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Apakšā'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Pa kreisi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Noņemt robežu(-as)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Pievienot komentāru'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Labot komentāru'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Dzēst komentāru'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Tikai lasāms komentārs'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Apvienot šūnas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Atvienot šunas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopēt'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Kopēt ar galveni',
    'Kopēt ar galvenēm'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Kopēt ar grupas galveni',
    'Kopēt ar grupas galvenēm'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Kopēt tikai galveni',
    'Kopēt tikai galvenes'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Izgriezt'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Eksportēt'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Kā CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Kā Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Eksportē…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Ievietot pakārtoto rindu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Atdalīt no vecāka'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Palēpt kolonnu',
    'Palēpt kolonnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Rādīt kolonnu',
    'Rādīt kolonnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Palēpt rindu',
    'Paslēpt rindas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Rādīt rindu',
    'Rādīt rindas'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Nekas'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Ir tukšs'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Nav tukšs'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Vienāds ar'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Nav vienāds ar'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Sākas ar'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Beidzas ar'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Satur'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Nesatur'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Lielāks par'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Lielāks vai vienāds ar'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Mazāks par'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Mazāks vai vienāds ar'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Ir starp'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Nav starp'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Pēc'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Pēc vai vienāds'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Pirms'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Pirms vai vienāds'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Šodien'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Rītdien'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Vakar'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Tukšas šūnas'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrēt pēc nosacījuma'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrēt pēc vērtības'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Un'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Vai'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Izvēlēties visu'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Notīrīt'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'Labi'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Atcelt'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Meklēt'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Vērtība'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Otra vērtība'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginācija'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Rindu skaits'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] no [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Lapa [currentPage] no [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Pāriet uz pirmo lapu'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Pāriet uz iepriekšējo lapu'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Pāriet uz nākamo lapu'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Pāriet uz pēdējo lapu'), _define_property(_obj, C.LOADING_TITLE, 'Ielādē...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Aizvērt'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Nav pieejamu datu'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Vēl nav ko rādīt.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Rezultāti nav atrasti'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Šķiet, ka jūsu pašreizējie filtri paslēpj visus rezultātus.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Atiestatīt filtrus'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Ielādē datus'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Lūdzu, uzgaidiet.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Nevarēja ielādēt datus'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Nevarēja izveidot rindas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Nevarēja atjaunināt rindas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Nevarēja noņemt rindas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Pieprasījums neizdevās'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Pārlādēt'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
15(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Simon Borøy-Johnsen (TheSimoms)
 * Last updated: Dec 19, 2017
 *
 * Description: Definition file for Norwegian Bokmål - Norway language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'nb-NO'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Avbryt'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Sett inn over'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Sett inn under'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Sett inn til venstre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Sett inn til høyre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Fjern rad',
    'Fjern rader'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Fjern kolonne',
    'Fjern kolonner'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Angre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Gjør om'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Skrivebeskyttet'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Tøm kolonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Juster'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Venstre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Midtstill'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Høyre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Tilpasset'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Øverst'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'På midten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Nederst'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Frys kolonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Frigi kolonne'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Kantlinjer'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Over'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Til høyre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Under'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Til venstre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Fjern kantlinje(r)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Legg til kommentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Endre kommentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Fjern kommentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Skrivebeskytt kommentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Slå sammen celler'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Opphev sammenslåing'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopier'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Klipp ut'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Eksporter'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Til CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Til Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Eksporterer…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Sett inn underrad'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Frigi fra gruppe'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Skjul kolonne',
    'Skjul kolonner'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Vis kolonne',
    'Vis kolonner'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Skjul rad',
    'Skjul rader'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Vis rad',
    'Vis rader'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Ingen'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Er tom'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Er ikke tom'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Er lik'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Er ikke lik'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Begynner med'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Slutter med'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Inneholder'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Inneholder ikke'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Større enn'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Større enn eller lik'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Mindre enn'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Mindre enn eller lik'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Er mellom'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Er ikke mellom'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Etter'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Etter eller lik'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Før'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Før eller lik'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'I dag'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'I morgen'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'I går'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Tomme celler'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrer etter betingelse'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrer etter verdi'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Og'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Eller'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Velg alle'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Tøm'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Avbryt'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Søk'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Verdi'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Andre verdi'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginering'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Antall rader'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] av [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Side [currentPage] av [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Gå til første side'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Gå til forrige side'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Gå til neste side'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Gå til siste side'), _define_property(_obj, C.LOADING_TITLE, 'Laster...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Lukk'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Ingen data tilgjengelig'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Det er ingenting å vise ennå.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Ingen resultater funnet'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Det ser ut til at dine nåværende filtre skjuler alle resultater.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Tilbakestill filtre'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Laster inn data'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Vennligst vent.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Kunne ikke laste inn data'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Kunne ikke opprette rader'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Kunne ikke oppdatere rader'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Kunne ikke fjerne rader'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Forespørselen mislyktes'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Hent på nytt'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
16(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Tomas Rapkauskas, Anton Brouwer, webjazznl
 * Last updated: Dec 5, 2022
 *
 * Description: Definition file for Dutch - The Netherlands language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'nl-NL'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Annuleren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Rij boven invoegen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Rij onder invoegen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Kolom links invoegen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Kolom rechts invoegen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Rij verwijderen',
    'Rijen verwijderen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Kolom verwijderen',
    'Kolommen verwijderen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Ongedaan maken'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Opnieuw uitvoeren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Alleen lezen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Kolom leegmaken'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Uitlijning'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Links'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Gecentreerd'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Rechts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Uitvullen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Boven'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Midden'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Onder'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Kolom blokkeren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Kolom blokkering opheffen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Randen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Boven'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Rechts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Onder'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Links'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Rand(en) verwijderen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Opmerking toevoegen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Opmerking bewerken'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Opmerking verwijderen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Opmerking Alleen-lezen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Cellen samenvoegen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Samenvoeging van cellen opheffen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopiëren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Kopiëren met koptekst',
    'Kopiëren met kopteksten'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Kopiëren met groepskoptekst',
    'Kopiëren met groepskopteksten'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Kopiëren koptekst',
    'Kopiëren kopteksten'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Knippen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exporteren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Naar CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Naar Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exporteren…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Geneste rij invoegen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Geneste rij ontkoppelen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Kolom verbergen',
    'Kolommen verbergen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Kolom zichbaar maken',
    'Kolommen zichtbaar maken'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Rij verbergen',
    'Rijen verbergen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Rij zichtbaar maken',
    'Rijen zichtbaar maken'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Geen'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Is leeg'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Is niet leeg'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Is gelijk aan'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Is niet gelijk aan'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Begint met'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Eindigt op'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Bevat'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Bevat niet'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Is groter'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Is groter of gelijk aan'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Is kleiner dan'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Is kleiner dan of gelijk aan'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Is tussen'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Ligt niet tussen'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Na'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Na of gelijk aan'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Voor'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Voor of gelijk aan'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Vandaag'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Morgen'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Gisteren'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Cellen leegmaken'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filteren op conditie'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filteren op waarde'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'En'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Of'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Alles selecteren'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Leeg maken'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Annuleren'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Zoeken'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Waarde'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Tweede waarde'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginering'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Aantal rijen'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] van [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Pagina [currentPage] van [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Ga naar eerste pagina'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Ga naar vorige pagina'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Ga naar volgende pagina'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Ga naar laatste pagina'), _define_property(_obj, C.LOADING_TITLE, 'Laden...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Sluiten'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Geen gegevens beschikbaar'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Er is nog niets te tonen.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Geen resultaten gevonden'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Het lijkt erop dat uw huidige filters alle resultaten verbergen.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Filters resetten'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Gegevens laden'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Even geduld.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Gegevens konden niet worden geladen'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Rijen konden niet worden aangemaakt'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Rijen konden niet worden bijgewerkt'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Rijen konden niet worden verwijderd'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Verzoek mislukt'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Opnieuw laden'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
17(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Handsoncode
 * Last updated: Dec 5, 2022
 *
 * Description: Definition file for Polish - Poland language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'pl-PL'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Anuluj'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'Brak dostępnych opcji'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Wstaw wiersz powyżej'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Wstaw wiersz poniżej'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Wstaw kolumnę z lewej'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Wstaw kolumnę z prawej'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Usuń wiersz',
    'Usuń wiersze'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Usuń kolumnę',
    'Usuń kolumny'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Cofnij'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Ponów'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Tylko do odczytu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Wyczyść kolumnę'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Wyrównanie'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Do lewej'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Do środka'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Do prawej'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Wyjustuj'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Do góry'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Wyśrodkuj'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Do dołu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Zablokuj kolumnę'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Odblokuj kolumnę'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Obramowanie'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Krawędź górna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Krawędź prawa'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Krawędź dolna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Krawędź lewa'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Usuń obramowanie(a)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Dodaj komentarz'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Edytuj komentarz'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Usuń komentarz'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Komentarz tylko do odczytu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Scal komórki'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Rozdziel komórki'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopiuj'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Kopiuj z nagłówkiem',
    'Kopiuj z nagłówkami'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Kopiuj z nagłówkiem grupowym',
    'Kopiuj z nagłówkami grupowymi'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Kopiuj sam nagłówek',
    'Kopiuj same nagłówki'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Wytnij'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Eksportuj'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Do CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Do Excela'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Eksportowanie…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Wstaw wiersz podrzędny'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Odłącz od nadrzędnego'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Ukryj kolumnę',
    'Ukryj kolumny'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Pokaż kolumnę',
    'Pokaż kolumny'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Ukryj wiersz',
    'Ukryj wiersze'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Pokaż wiersz',
    'Pokaż wiersze'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Brak'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Komórka jest pusta'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Komórka nie jest pusta'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Jest równe'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Jest różne od'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Tekst zaczyna się od'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Tekst kończy się na'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Tekst zawiera fragment'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Tekst nie zawiera fragmentu'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Większe niż'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Większe lub równe'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Mniejsze niż'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Mniejsze lub równe'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Jest pomiędzy'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Nie jest pomiędzy'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Data późniejsza niż'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Data późniejsza lub równa'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Data wcześniejsza niż'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Data wcześniejsza lub równa'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Dzisiaj'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Jutro'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Wczoraj'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Puste miejsca'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtruj wg warunku'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtruj wg wartości'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Oraz'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Lub'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Zaznacz wszystko'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Wyczyść'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Anuluj'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Szukaj'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Wartość'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Druga wartość'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginacja'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Liczba wierszy'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] z [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Strona [currentPage] z [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Przejdź do pierwszej strony'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Przejdź do poprzedniej strony'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Przejdź do następnej strony'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Przejdź do ostatniej strony'), _define_property(_obj, C.CHECKBOX_CHECKED, 'Zaznaczony'), _define_property(_obj, C.CHECKBOX_UNCHECKED, 'Odznaczony'), _define_property(_obj, C.LOADING_TITLE, 'Ładowanie...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Zamknij'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Brak dostępnych danych'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Nie ma jeszcze nic do wyświetlenia.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Nie znaleziono wyników'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Wygląda na to, że Twoje obecne filtry ukrywają wszystkie wyniki.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Resetuj filtry'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Wczytywanie danych'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Proszę czekać.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Nie udało się wczytać danych'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Nie udało się utworzyć wierszy'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Nie udało się zaktualizować wierszy'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Nie udało się usunąć wierszy'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Żądanie nie powiodło się'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Ponów pobieranie'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
18(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Júlio C. Zuppa
 * Last updated: Jan 12, 2018
 *
 * Description: Definition file for Portuguese - Brazil language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'pt-BR'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Cancelar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Inserir linha acima'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Inserir linha abaixo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Inserir coluna esquerda'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Inserir coluna direita'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Excluir linha',
    'Excluir linhas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Excluir coluna',
    'Excluir colunas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Desfazer'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Refazer'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Somente leitura'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Limpar coluna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Alinhamento'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Esquerda'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centralizado'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Direita'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Justificado'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Superior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Meio'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Inferior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Congelar coluna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Descongelar coluna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Bordas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Superior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Direita'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Inferior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Esquerda'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Excluir bordas(s)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Incluir comentário'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Editar comentário'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Remover comentário'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Comentário somente leitura'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Mesclar células'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Desfazer mesclagem de células'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Copiar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Recortar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exportar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Para CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Para Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exportando…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Inserir linha filha'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Desanexar da linha pai'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Ocultar coluna',
    'Ocultar colunas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Exibir coluna',
    'Exibir colunas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Ocultar linha',
    'Ocultar linhas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Exibir linha',
    'Exibir linhas'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Nenhum'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'É vazio'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Não é vazio'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'É igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'É diferente de'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Começa com'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Termina com'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Contém'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Não contém'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Maior que'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Maior ou igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Menor que'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Maior ou igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Está entre'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Não está entre'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Depois'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Depois ou igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Antes'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Antes ou igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Hoje'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Amanhã'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Ontem'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Células vazias'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrar por condição'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrar por valor'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'E'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Ou'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Selecionar tudo'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Limpar'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Cancelar'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Localizar'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Valor'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Segundo valor'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginação'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Linhas por página'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] de [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Página [currentPage] de [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Ir para a primeira página'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Ir para a página anterior'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Ir para a próxima página'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Ir para a última página'), _define_property(_obj, C.LOADING_TITLE, 'Carregando...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Fechar'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Nenhum dado disponível'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Não há nada para exibir ainda.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Nenhum resultado encontrado'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Parece que seus filtros atuais estão ocultando todos os resultados.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Redefinir filtros'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Carregando dados'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Aguarde.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Não foi possível carregar os dados'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Não foi possível criar as linhas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Não foi possível atualizar as linhas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Não foi possível remover as linhas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Falha na solicitação'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Recarregar'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
19(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Alexey Rogachev
 * Last updated: Feb 28, 2018
 *
 * Description: Definition file for Russian - Russia language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'ru-RU'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Отмена'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Вставить строку выше'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Вставить строку ниже'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Вставить столбец слева'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Вставить столбец справа'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Удалить строку',
    'Удалить строки'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Удалить столбец',
    'Удалить столбцы'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Отменить'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Повторить'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Только для чтения'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Очистить столбец'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Выравнивание'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'По левому краю'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'По центру'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'По правому краю'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'По ширине'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'По верхнему краю'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'По центру'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'По нижнему краю'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Закрепить столбец'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Открепить столбец'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Границы'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Сверху'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Справа'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Снизу'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Слева'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Удалить границу(ы)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Добавить комментарий'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Редактировать комментарий'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Удалить комментарий'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Комментарий только для чтения'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Объединить ячейки'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Разделить ячейки'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Копировать'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Вырезать'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Экспортировать'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'В CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'В Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Экспорт…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Вставить дочернюю строку'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Отделить от родителя'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Скрыть столбец',
    'Скрыть столбцы'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Показать столбец',
    'Показать столбцы'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Скрыть строку',
    'Скрыть строки'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Показать строку',
    'Показать строки'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Отсутствует'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Пусто'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Не пусто'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Равно'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Не равно'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Начинается на'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Заканчивается на'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Содержит'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Не содержит'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Больше чем'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Больше или равно'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Меньше чем'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Меньше или равно'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Между'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Не между'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'После'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'После или равно'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'До'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'До или равно'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Сегодня'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Завтра'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Вчера'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Пустые ячейки'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Фильтр по условию'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Фильтр по значению'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'И'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Или'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Выбрать все'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Убрать'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Отмена'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Поиск'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Значение'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Второе значение'), _define_property(_obj, C.PAGINATION_SECTION, 'Пагинация'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Количество строк'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Авто'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] из [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Страница [currentPage] из [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Перейти на первую страницу'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Перейти на предыдущую страницу'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Перейти на следующую страницу'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Перейти на последнюю страницу'), _define_property(_obj, C.LOADING_TITLE, 'Загрузка...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Закрыть'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Данные недоступны'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Пока нечего отображать.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Результаты не найдены'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Похоже, что ваши текущие фильтры скрывают все результаты.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Сбросить фильтры'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Загрузка данных'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Подождите.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Не удалось загрузить данные'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Не удалось создать строки'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Не удалось обновить строки'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Не удалось удалить строки'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Запрос не выполнен'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Повторить загрузку'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
20(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Author: Ivan Zarkovic
 * Last updated: May 9, 2022
 *
 * Description: Definition file for Serbian - Republic of Serbia language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'sr-SP'
}, _define_property(_obj, C.OK, 'U redu'), _define_property(_obj, C.CANCEL, 'Otkaži'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NO_ITEMS, 'Nema dostupnih opcija'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Unesi red iznad'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Unesi red ispod'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Unesi kolonu levo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Insert kolonu desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Ukloni red',
    'Ukloni redove'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Ukloni kolonu',
    'Ukloni kolone'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Poništi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Ponovi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Samo za čitanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Obriši kolonu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Poravnanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Levo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Složeno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Gore'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Sredina'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Dole'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Zamrzni kolonu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Odmrzni kolonu'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Ivica'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Gore'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Desno'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Dole'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Levo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Ukloni ivicu(e)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Dodaj komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Izmeni komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Obriši komentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Komentar samo za čitanje'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Spoji ćelije'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Odvoji ćelije'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopiraj'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Kopiraj sa zaglavljem',
    'Kopiraj sa zaglavljima'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Kopiraj sa zaglavljem grupe',
    'Kopiraj sa zaglavljima grupe'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Kopiraj samo zaglavlje',
    'Kopiraj samo zaglavlja'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Iseci'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Izvezi'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Kao CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Kao Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Izvoz…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Unesi ugnježdeni red'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Odvoji ugnježdeni red'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Sakrij kolonu',
    'Sakrij kolone'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Prikaži kolonu',
    'Prikaži kolone'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Sakrij red',
    'Sakrij redove'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Prikaži red',
    'Prikaži redove'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Nema'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Je prazno'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Nije prazno'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Je jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Nije jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Počinje sa'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Završava se sa'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Sadrži'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Ne sadrži'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Veće od'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Veće od ili jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Manje od'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Manje od ili jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Je između'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Nije između'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Posle'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Posle ili jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Pre'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Pre ili jednako'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Danas'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Sutra'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Juče'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Prazne ćelije'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtriraj po uslovu'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtriraj po vrednosti'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'I'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Ili'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Selektuj sve'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Očisti'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'U redu'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Otkaži'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Pretraga'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Vrednost'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Druga vrednost'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginacija'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Broj redova'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] od [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Stranica [currentPage] od [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Idi na prvu stranicu'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Idi na prethodnu stranicu'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Idi na sledeću stranicu'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Idi na poslednju stranicu'), _define_property(_obj, C.LOADING_TITLE, 'Učitavanje...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Zatvori'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Nema dostupnih podataka'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Još uvek nema ništa za prikaz.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Nema pronađenih rezultata'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Izgleda da vaši trenutni filteri skrivaju sve rezultate.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Resetuj filtere'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Učitavanje podataka'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Sačekajte.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Nije moguće učitati podatke'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Nije moguće kreirati redove'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Nije moguće ažurirati redove'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Nije moguće ukloniti redove'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Zahtev nije uspeo'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Ponovo učitaj'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
21(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: soakit, HChenZi
 * Last updated: Mar 09, 2023
 *
 * Description: Definition file for Chinese - China language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'zh-CN'
}, _define_property(_obj, C.OK, '确认'), _define_property(_obj, C.CANCEL, '取消'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, '上方插入行'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, '下方插入行'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, '左方插入列'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, '右方插入列'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    '移除该行',
    '移除多行'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    '移除该列',
    '移除多列'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, '撤销'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, '恢复'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, '只读'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, '清空该列'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, '对齐'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, '左对齐'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, '水平居中'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, '右对齐'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, '两端对齐'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, '顶端对齐'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, '垂直居中'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, '底端对齐'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, '冻结该列'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, '取消冻结'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, '边框'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, '上'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, '右'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, '下'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, '左'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, '移除边框'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, '插入批注'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, '编辑批注'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, '删除批注'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, '只读批注'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, '合并'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, '取消合并'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, '复制'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, '带标题的复制'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, '带标题组的复制'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, '仅复制标题'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, '剪切'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, '导出'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, '为 CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, '为 Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, '正在导出…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, '插入子行'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, '与母行分离'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    '隐藏该列',
    '隐藏多列'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    '显示该列',
    '显示多列'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    '隐藏该行',
    '隐藏多行'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    '显示该行',
    '显示多行'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, '无'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, '为空'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, '不为空'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, '等于'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, '不等于'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, '开头是'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, '结尾是'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, '包含'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, '不包含'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, '大于'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, '大于或等于'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, '小于'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, '小于或等于'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, '在此范围'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, '不在此范围'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, '之后'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, '之后或等于'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, '之前'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, '之前或等于'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, '今天'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, '明天'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, '昨天'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, '空白单元格'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, '按条件过滤'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, '按值过滤'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, '且'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, '或'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, '全选'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, '清除'), _define_property(_obj, C.FILTERS_BUTTONS_OK, '确认'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, '取消'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, '搜索'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, '值'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, '第二值'), _define_property(_obj, C.PAGINATION_SECTION, '分页'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, '每页行数'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, '自动'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] 共 [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, '第 [currentPage] 页，共 [totalPages] 页'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, '转到第一页'), _define_property(_obj, C.PAGINATION_PREV_PAGE, '转到上一页'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, '转到下一页'), _define_property(_obj, C.PAGINATION_LAST_PAGE, '转到最后一页'), _define_property(_obj, C.LOADING_TITLE, '加载中...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, '关闭'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, '暂无数据'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, '暂无内容可显示。'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, '未找到结果'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, '看起来您当前的过滤器隐藏了所有结果。'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, '重置过滤器'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, '正在加载数据'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, '请稍候。'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, '无法加载数据'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, '无法创建行'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, '无法更新行'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, '无法删除行'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, '请求失败'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, '重新加载'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
22(__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Phyllis Yen
 * Last updated: Mar 9, 2018
 *
 * Description: Definition file for Chinese - Taiwan language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'zh-TW'
}, _define_property(_obj, C.OK, '確認'), _define_property(_obj, C.CANCEL, '取消'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, '上方插入列'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, '下方插入列'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, '左方插入欄'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, '右方插入欄'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    '移除該列',
    '移除多列'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    '移除該欄',
    '移除多欄'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, '復原'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, '取消復原'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, '唯讀'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, '清空該欄'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, '對齊'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, '靠左'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, '水平置中'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, '靠右'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, '左右對齊'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, '靠上'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, '垂直置中'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, '靠下'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, '凍結欄位'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, '取消凍結欄位'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, '邊界'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, '上'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, '右'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, '下'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, '左'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, '移除邊界'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, '加入評論'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, '編輯評論'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, '刪除評論'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, '唯讀評論'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, '合併欄位'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, '取消合併欄位'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, '複製'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, '剪下'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, '匯出'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, '為 CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, '為 Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, '正在匯出…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, '插入子列'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, '與母列分離'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    '隱藏該欄',
    '隱藏多欄'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    '顯示該欄',
    '顯示多欄'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    '隱藏該列',
    '隱藏多列'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    '顯示該列',
    '顯示多列'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, '無'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, '為空'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, '不為空'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, '等於'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, '不等於'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, '開頭是'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, '結尾是'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, '包含'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, '不包含'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, '大於'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, '大於或等於'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, '小於'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, '小於或等於'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, '在此範圍'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, '不在此範圍'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, '之後'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, '之後或等於'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, '之前'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, '之前或等於'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, '今天'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, '明天'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, '昨天'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, '空白格'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, '依條件過濾'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, '依值過濾'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, '且'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, '或'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, '全選'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, '清除'), _define_property(_obj, C.FILTERS_BUTTONS_OK, '確認'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, '取消'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, '搜尋'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, '值'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, '第二值'), _define_property(_obj, C.PAGINATION_SECTION, '分頁'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, '每頁行數'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, '自動'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] 共 [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, '第 [currentPage] 頁，共 [totalPages] 頁'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, '轉到第一頁'), _define_property(_obj, C.PAGINATION_PREV_PAGE, '轉到上一頁'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, '轉到下一頁'), _define_property(_obj, C.PAGINATION_LAST_PAGE, '轉到最後一頁'), _define_property(_obj, C.LOADING_TITLE, '載入中...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, '關閉'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, '暫無資料'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, '暫無內容可顯示。'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, '未找到結果'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, '看起來您目前的過濾器隱藏了所有結果。'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, '重設過濾器'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, '正在載入資料'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, '請稍候。'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, '無法載入資料'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, '無法建立列'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, '無法更新列'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, '無法刪除列'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, '要求失敗'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, '重新載入'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);


},
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  arAR: () => (/* reexport safe */ _ar_AR__rspack_import_0["default"]),
  csCZ: () => (/* reexport safe */ _cs_CZ__rspack_import_1["default"]),
  deCH: () => (/* reexport safe */ _de_CH__rspack_import_2["default"]),
  deDE: () => (/* reexport safe */ _de_DE__rspack_import_3["default"]),
  enUS: () => (/* reexport safe */ _en_US__rspack_import_4["default"]),
  esMX: () => (/* reexport safe */ _es_MX__rspack_import_5["default"]),
  faIR: () => (/* reexport safe */ _fa_IR__rspack_import_6["default"]),
  frFR: () => (/* reexport safe */ _fr_FR__rspack_import_7["default"]),
  hrHR: () => (/* reexport safe */ _hr_HR__rspack_import_8["default"]),
  itIT: () => (/* reexport safe */ _it_IT__rspack_import_9["default"]),
  jaJP: () => (/* reexport safe */ _ja_JP__rspack_import_10["default"]),
  koKR: () => (/* reexport safe */ _ko_KR__rspack_import_11["default"]),
  lvLV: () => (/* reexport safe */ _lv_LV__rspack_import_12["default"]),
  nbNO: () => (/* reexport safe */ _nb_NO__rspack_import_13["default"]),
  nlNL: () => (/* reexport safe */ _nl_NL__rspack_import_14["default"]),
  plPL: () => (/* reexport safe */ _pl_PL__rspack_import_15["default"]),
  ptBR: () => (/* reexport safe */ _pt_BR__rspack_import_16["default"]),
  ruRU: () => (/* reexport safe */ _ru_RU__rspack_import_17["default"]),
  srSP: () => (/* reexport safe */ _sr_SP__rspack_import_18["default"]),
  zhCN: () => (/* reexport safe */ _zh_CN__rspack_import_19["default"]),
  zhTW: () => (/* reexport safe */ _zh_TW__rspack_import_20["default"])
});
/* import */ var _ar_AR__rspack_import_0 = __webpack_require__(0);
/* import */ var _cs_CZ__rspack_import_1 = __webpack_require__(2);
/* import */ var _de_CH__rspack_import_2 = __webpack_require__(3);
/* import */ var _de_DE__rspack_import_3 = __webpack_require__(4);
/* import */ var _en_US__rspack_import_4 = __webpack_require__(5);
/* import */ var _es_MX__rspack_import_5 = __webpack_require__(6);
/* import */ var _fa_IR__rspack_import_6 = __webpack_require__(7);
/* import */ var _fr_FR__rspack_import_7 = __webpack_require__(8);
/* import */ var _hr_HR__rspack_import_8 = __webpack_require__(9);
/* import */ var _it_IT__rspack_import_9 = __webpack_require__(11);
/* import */ var _ja_JP__rspack_import_10 = __webpack_require__(12);
/* import */ var _ko_KR__rspack_import_11 = __webpack_require__(13);
/* import */ var _lv_LV__rspack_import_12 = __webpack_require__(14);
/* import */ var _nb_NO__rspack_import_13 = __webpack_require__(15);
/* import */ var _nl_NL__rspack_import_14 = __webpack_require__(16);
/* import */ var _pl_PL__rspack_import_15 = __webpack_require__(17);
/* import */ var _pt_BR__rspack_import_16 = __webpack_require__(18);
/* import */ var _ru_RU__rspack_import_17 = __webpack_require__(19);
/* import */ var _sr_SP__rspack_import_18 = __webpack_require__(20);
/* import */ var _zh_CN__rspack_import_19 = __webpack_require__(21);
/* import */ var _zh_TW__rspack_import_20 = __webpack_require__(22);























})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});