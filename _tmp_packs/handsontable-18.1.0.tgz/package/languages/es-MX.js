(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Handsoncode, Enrique Enciso
 * Last updated: Nov 18, 2022
 *
 * Description: Definition file for Spanish - Mexico language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'es-MX'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Cancelar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Insertar fila arriba'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Insertar fila abajo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Insertar columna izquierda'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Insertar columna derecha'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Eliminar fila',
    'Eliminar filas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Eliminar columna',
    'Eliminar columnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Deshacer'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Rehacer'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Solo lectura'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Limpiar columna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Alineación'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Izquierda'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Centro'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Derecha'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Justificar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Superior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Medio'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Inferior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Congelar columna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Descongelar columna'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Bordes'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Superior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Derecho'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Inferior'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Izquierdo'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Quitar borde(s)'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Agregar comentario'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Editar comentario'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Borrar comentario'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Comentario Solo de lectura'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Unir celdas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Separar celdas'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Copiar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_HEADERS, [
    'Copiar con encabezado',
    'Copiar con encabezados'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_WITH_COLUMN_GROUP_HEADERS, [
    'Copiar con encabezado de grupo',
    'Copiar con encabezados de grupos'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY_COLUMN_HEADERS_ONLY, [
    'Copiar solo el encabezado',
    'Copiar solo los encabezados'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Cortar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exportar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'A CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'A Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Exportando…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Insertar fila hija'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Separar del padre'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Esconder columna',
    'Esconder columnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Mostrar columna',
    'Mostrar columnas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Esconder fila',
    'Esconder filas'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Mostrar fila',
    'Mostrar filas'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Ninguna'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Está vacío'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'No está vacío'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Es igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'No es igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Comienza con'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Termina con'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Contiene'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'No contiene'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Mayor que'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Mayor o igual que'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Menor que'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Menor o igual que'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Es entre'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'No es entre'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Después'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Después o igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Antes'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Antes o igual a'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Hoy'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Mañana'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Ayer'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Celdas vacías'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Filtrar por condición'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Filtrar por valor'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Y'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'O'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Seleccionar todo'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Borrar'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Cancelar'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Buscar'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Valor'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Valor secundario'), _define_property(_obj, C.PAGINATION_SECTION, 'Paginación'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Filas por página'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] de [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Página [currentPage] de [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Ir a la primera página'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Ir a la página anterior'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Ir a la siguiente página'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Ir a la última página'), _define_property(_obj, C.LOADING_TITLE, 'Cargando...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Cerrar'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'No hay datos disponibles'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'No hay nada que mostrar aún.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'No se encontraron resultados'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Parece que tus filtros actuales están ocultando todos los resultados.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Restablecer filtros'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Cargando datos'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Espere por favor.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'No se pudieron cargar los datos'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'No se pudieron crear las filas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'No se pudieron actualizar las filas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'No se pudieron eliminar las filas'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'La solicitud falló'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Volver a cargar'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);

})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});