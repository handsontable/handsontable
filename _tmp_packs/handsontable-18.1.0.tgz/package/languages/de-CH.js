(function webpackUniversalModuleDefinition(root, factory) {

      if(typeof exports === 'object' && typeof module === 'object') {
          module.exports = factory(require("handsontable"));
      }else if(typeof define === 'function' && define.amd) {
          
          define(["handsontable"], factory);

          } else {
          var a = typeof exports === 'object' ? factory(require("handsontable")) : factory(root["Handsontable"]);

          for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];

      }

      })(typeof self !== 'undefined' ? self : this, (__rspack_external__1) => {
          return (() => {
"use strict";
var __webpack_modules__ = ({
1(module) {
module.exports = __rspack_external__1;

},

});
// The module cache
var __webpack_module_cache__ = {};

// The require function
function __webpack_require__(moduleId) {

// Check if module is in cache
var cachedModule = __webpack_module_cache__[moduleId];
if (cachedModule !== undefined) {
return cachedModule.exports;
}
// Create a new module (and put it into the cache)
var module = (__webpack_module_cache__[moduleId] = {
exports: {}
});
// Execute the module function
__webpack_modules__[moduleId](module, module.exports, __webpack_require__);

// Return the exports of the module
return module.exports;

}

// webpack/runtime/compat_get_default_export
(() => {
// getDefaultExport function for compatibility with non-ESM modules
__webpack_require__.n = (module) => {
	var getter = module && module.__esModule ?
		() => (module['default']) :
		() => (module);
	__webpack_require__.d(getter, { a: getter });
	return getter;
};

})();
// webpack/runtime/define_property_getters
(() => {
__webpack_require__.d = (exports, definition) => {
	for(var key in definition) {
        if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
            Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
        }
    }
};
})();
// webpack/runtime/has_own_property
(() => {
__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
})();
// webpack/runtime/make_namespace_object
(() => {
// define __esModule on exports
__webpack_require__.r = (exports) => {
	if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
		Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
	}
	Object.defineProperty(exports, '__esModule', { value: true });
};
})();
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  "default": () => (__rspack_default_export)
});
/* import */ var handsontable__rspack_import_0 = __webpack_require__(1);
/* import */ var handsontable__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(handsontable__rspack_import_0);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
/**
 * @preserve
 * Authors: Stefan Salzl
 * Last updated: Jan 08, 2018
 *
 * Description: Definition file for German - Switzerland language-country.
 */ 
var C = (handsontable__rspack_import_0_default().languages.dictionaryKeys);
var _obj;
var dictionary = (_obj = {
    languageCode: 'de-CH'
}, _define_property(_obj, C.OK, 'OK'), _define_property(_obj, C.CANCEL, 'Abbrechen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_ABOVE, 'Zeile einfügen oberhalb'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ROW_BELOW, 'Zeile einfügen unterhalb'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_LEFT, 'Spalte einfügen links'), _define_property(_obj, C.CONTEXTMENU_ITEMS_INSERT_RIGHT, 'Spalte einfügen rechts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_ROW, [
    'Zeile löschen',
    'Zeilen löschen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COLUMN, [
    'Spalte löschen',
    'Spalten löschen'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNDO, 'Rückgangig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REDO, 'Wiederholen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY, 'Nur Lesezugriff'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CLEAR_COLUMN, 'Spalteninhalt löschen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT, 'Ausrichtung'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_LEFT, 'Linksbündig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_CENTER, 'Zentriert'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_RIGHT, 'Rechtsbündig'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_JUSTIFY, 'Blocksatz'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_TOP, 'Oben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_MIDDLE, 'Mitte'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ALIGNMENT_BOTTOM, 'Unten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_FREEZE_COLUMN, 'Spalte fixieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNFREEZE_COLUMN, 'Spaltenfixierung aufheben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS, 'Rahmen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_TOP, 'Oben'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_RIGHT, 'Rechts'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_BOTTOM, 'Unten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_BORDERS_LEFT, 'Links'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_BORDERS, 'Kein Rahmen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_ADD_COMMENT, 'Kommentar hinzufügen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EDIT_COMMENT, 'Kommentar bearbeiten'), _define_property(_obj, C.CONTEXTMENU_ITEMS_REMOVE_COMMENT, 'Kommentar löschen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_READ_ONLY_COMMENT, 'Schreibschutz Kommentar'), _define_property(_obj, C.CONTEXTMENU_ITEMS_MERGE_CELLS, 'Zellen verbinden'), _define_property(_obj, C.CONTEXTMENU_ITEMS_UNMERGE_CELLS, 'Zellen teilen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_COPY, 'Kopieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_CUT, 'Ausschneiden'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT, 'Exportieren'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_CSV, 'Als CSV'), _define_property(_obj, C.CONTEXTMENU_ITEMS_EXPORT_FILE_XLSX, 'Als Excel'), _define_property(_obj, C.EXPORT_FILE_DIALOG_TITLE, 'Wird exportiert…'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_INSERT_CHILD, 'Nachfolgerzeile einfügen'), _define_property(_obj, C.CONTEXTMENU_ITEMS_NESTED_ROWS_DETACH_CHILD, 'Von Vorgängerzeile abkoppeln'), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_COLUMN, [
    'Spalte ausblenden',
    'Spalten ausblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_COLUMN, [
    'Spalte einblenden',
    'Spalten einblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_HIDE_ROW, [
    'Zeile ausblenden',
    'Zeilen ausblenden'
]), _define_property(_obj, C.CONTEXTMENU_ITEMS_SHOW_ROW, [
    'Zeile einblenden',
    'Zeilen einblenden'
]), _define_property(_obj, C.FILTERS_CONDITIONS_NONE, 'Kein Filter'), _define_property(_obj, C.FILTERS_CONDITIONS_EMPTY, 'Ist leer'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EMPTY, 'Ist nicht leer'), _define_property(_obj, C.FILTERS_CONDITIONS_EQUAL, 'Ist gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_EQUAL, 'Ist ungleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BEGINS_WITH, 'Beginnt mit'), _define_property(_obj, C.FILTERS_CONDITIONS_ENDS_WITH, 'Endet mit'), _define_property(_obj, C.FILTERS_CONDITIONS_CONTAINS, 'Enthält'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_CONTAIN, 'Enthält nicht'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN, 'Grösser als'), _define_property(_obj, C.FILTERS_CONDITIONS_GREATER_THAN_OR_EQUAL, 'Grösser gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN, 'Kleiner als'), _define_property(_obj, C.FILTERS_CONDITIONS_LESS_THAN_OR_EQUAL, 'Kleiner gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BETWEEN, 'Zwischen'), _define_property(_obj, C.FILTERS_CONDITIONS_NOT_BETWEEN, 'Ausserhalb'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER, 'Nach'), _define_property(_obj, C.FILTERS_CONDITIONS_AFTER_OR_EQUAL, 'Nach oder gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE, 'Vor'), _define_property(_obj, C.FILTERS_CONDITIONS_BEFORE_OR_EQUAL, 'Vor oder gleich'), _define_property(_obj, C.FILTERS_CONDITIONS_TODAY, 'Heute'), _define_property(_obj, C.FILTERS_CONDITIONS_TOMORROW, 'Morgen'), _define_property(_obj, C.FILTERS_CONDITIONS_YESTERDAY, 'Gestern'), _define_property(_obj, C.FILTERS_VALUES_BLANK_CELLS, 'Leere Zellen'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_CONDITION, 'Per Bedingung filtern'), _define_property(_obj, C.FILTERS_DIVS_FILTER_BY_VALUE, 'Nach Zahlen filtern'), _define_property(_obj, C.FILTERS_LABELS_CONJUNCTION, 'Und'), _define_property(_obj, C.FILTERS_LABELS_DISJUNCTION, 'Oder'), _define_property(_obj, C.FILTERS_BUTTONS_SELECT_ALL, 'Alles auswählen'), _define_property(_obj, C.FILTERS_BUTTONS_CLEAR, 'Auswahl aufheben'), _define_property(_obj, C.FILTERS_BUTTONS_OK, 'OK'), _define_property(_obj, C.FILTERS_BUTTONS_CANCEL, 'Abbrechen'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SEARCH, 'Suchen'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_VALUE, 'Wert'), _define_property(_obj, C.FILTERS_BUTTONS_PLACEHOLDER_SECOND_VALUE, 'Alternativwert'), _define_property(_obj, C.PAGINATION_SECTION, 'Seitennavigation'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_SECTION, 'Anzahl Zeilen'), _define_property(_obj, C.PAGINATION_PAGE_SIZE_AUTO, 'Auto'), _define_property(_obj, C.PAGINATION_COUNTER_SECTION, '[start] - [end] von [total]'), _define_property(_obj, C.PAGINATION_NAV_SECTION, 'Seite [currentPage] von [totalPages]'), _define_property(_obj, C.PAGINATION_FIRST_PAGE, 'Zur ersten Seite wechseln'), _define_property(_obj, C.PAGINATION_PREV_PAGE, 'Zur vorherigen Seite wechseln'), _define_property(_obj, C.PAGINATION_NEXT_PAGE, 'Zur nächsten Seite wechseln'), _define_property(_obj, C.PAGINATION_LAST_PAGE, 'Zur letzten Seite wechseln'), _define_property(_obj, C.LOADING_TITLE, 'Lädt...'), _define_property(_obj, C.NOTIFICATION_BUTTONS_CLOSE, 'Schließen'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE, 'Keine Daten verfügbar'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION, 'Es gibt noch nichts anzuzeigen.'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_FILTERS, 'Keine Ergebnisse gefunden'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_FILTERS, 'Es scheint, als würden Ihre aktuellen Filter alle Ergebnisse ausblenden.'), _define_property(_obj, C.EMPTY_DATA_STATE_BUTTONS_FILTERS_RESET, 'Filter zurücksetzen'), _define_property(_obj, C.EMPTY_DATA_STATE_TITLE_LOADING, 'Daten werden geladen'), _define_property(_obj, C.EMPTY_DATA_STATE_DESCRIPTION_LOADING, 'Bitte warten.'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_FETCH, 'Daten konnten nicht geladen werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_CREATE, 'Zeilen konnten nicht erstellt werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_UPDATE, 'Zeilen konnten nicht aktualisiert werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REMOVE, 'Zeilen konnten nicht entfernt werden'), _define_property(_obj, C.DATA_PROVIDER_ERRORS_REQUEST_FAILED, 'Anfrage fehlgeschlagen'), _define_property(_obj, C.DATA_PROVIDER_BUTTONS_REFETCH, 'Neu laden'), _obj);
handsontable__rspack_import_0_default().languages.registerLanguageDictionary(dictionary);
/* export default */ const __rspack_default_export = (dictionary);

})();

__webpack_exports__ = __webpack_exports__.___;return __webpack_exports__;
})()

});