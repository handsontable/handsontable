import React from 'react';
import { HotTableProps, HotTableRef } from './types';
declare const HotTableInner: React.ForwardRefExoticComponent<Pick<HotTableProps, string | number> & React.RefAttributes<HotTableRef>>;
export default HotTableInner;
export { HotTableInner };
