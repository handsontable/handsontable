import Handsontable from 'handsontable/base';
import { HotTableProps } from './types';
export declare class SettingsMapper {
    /**
     * Parse component settings into Handsontable-compatible settings.
     *
     * @param {Object} properties Object containing properties from the HotTable object.
     * @param {Object} additionalSettings Additional settings.
     * @param {boolean} additionalSettings.isInit Flag determining whether the settings are being set during initialization.
     * @param {string[]} additionalSettings.initOnlySettingKeys Array of keys that can be set only during initialization.
     * @returns {Object} Handsontable-compatible settings object.
     */
    static getSettings(properties: HotTableProps, { prevProps, isInit, initOnlySettingKeys }?: {
        prevProps?: HotTableProps;
        isInit?: boolean;
        initOnlySettingKeys?: Array<keyof Handsontable.GridSettings>;
    }): Handsontable.GridSettings;
}
