import React, { DependencyList, FC, MutableRefObject, ReactNode, Ref, RefObject, Dispatch } from 'react';
import Handsontable from 'handsontable/base';
import { HotEditorHooks, UseHotEditorImpl } from './types';
/**
 * Create a class to be passed to the Handsontable's settings.
 *
 * @param {RefObject<HotEditorHooks>} hooksRef Reference to component-based editor overridden hooks object.
 * @param {RefObject} instanceRef Reference to Handsontable-native custom editor class instance.
 * @returns {Function} A class to be passed to the Handsontable editor settings.
 */
export declare function makeEditorClass(hooksRef: MutableRefObject<HotEditorHooks | null>, instanceRef: MutableRefObject<Handsontable.editors.BaseEditor | null>): typeof Handsontable.editors.BaseEditor;
interface EditorContextType {
    hooksRef: Ref<HotEditorHooks>;
    hotCustomEditorInstanceRef: RefObject<Handsontable.editors.BaseEditor>;
}
/**
 * Context to provide Handsontable-native custom editor class instance to overridden hooks object.
 */
export declare const EditorContext: React.Context<EditorContextType | undefined>;
interface EditorContextProviderProps {
    hooksRef: Ref<HotEditorHooks>;
    hotCustomEditorInstanceRef: RefObject<Handsontable.editors.BaseEditor>;
    children: ReactNode;
}
/**
 * Provider of the context that exposes Handsontable-native editor instance and passes hooks object
 * for custom editor components.
 *
 * @param {Ref} hooksRef Reference for component-based editor overridden hooks object.
 * @param {RefObject} hotCustomEditorInstanceRef  Reference to Handsontable-native editor instance.
 */
export declare const EditorContextProvider: FC<EditorContextProviderProps>;
/**
 * Hook that allows encapsulating custom behaviours of component-based editor by customizing passed ref with overridden hooks object.
 *
 * @param {HotEditorHooks} overriddenHooks Overrides specific for the custom editor.
 * @param {DependencyList} deps Overridden hooks object React dependency list.
 * @returns {UseHotEditorImpl} Editor API methods
 */
export declare function useHotEditor<T>(overriddenHooks?: HotEditorHooks, deps?: DependencyList): UseHotEditorImpl<T>;
declare type EditorChildrenProps<T> = {
    value: T;
    setValue: Dispatch<T>;
    finishEditing: () => void;
    isOpen: boolean;
    row: number | undefined;
    col: number | undefined;
    mainElementRef: React.RefObject<HTMLDivElement>;
};
declare type EditorRenderProp<T> = (props: EditorChildrenProps<T>) => React.ReactNode;
declare type EditorComponentProps = {
    onPrepare?: (row: number, column: number, prop: string | number, TD: HTMLTableCellElement, originalValue: any, cellProperties: Handsontable.CellProperties) => void;
    onOpen?: () => void;
    onClose?: () => void;
    onFocus?: () => void;
    shortcutsGroup?: string;
    shortcuts?: {
        keys: string[][];
        callback: (props: any, event: KeyboardEvent) => boolean | void;
        group?: string;
        runOnlyIf?: () => boolean;
        captureCtrl?: boolean;
        preventDefault?: boolean;
        stopPropagation?: boolean;
        relativeToGroup?: string;
        position?: "before" | "after";
        forwardToContext?: any;
    }[];
};
export declare function EditorComponent<T = any>({ onPrepare, onClose, onOpen, onFocus, children, shortcutsGroup, shortcuts, }: EditorComponentProps & {
    children?: EditorRenderProp<T>;
}): React.ReactElement;
export {};
