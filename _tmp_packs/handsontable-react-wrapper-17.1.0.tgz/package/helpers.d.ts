import React, { ComponentType, CSSProperties, DependencyList, EffectCallback, ReactNode, ReactPortal } from 'react';
import { HotTableProps } from './types';
/**
 * Warning message for the `autoRowSize`/`autoColumnSize` compatibility check.
 */
export declare const AUTOSIZE_WARNING: string;
/**
 * Warning message for the `hot-renderer` obsolete renderer passing method.
 */
export declare const OBSOLETE_HOTRENDERER_WARNING: string;
/**
 * Warning message for the `hot-editor` obsolete editor passing method.
 */
export declare const OBSOLETE_HOTEDITOR_WARNING: string;
/**
 * Warning message for the unexpected children of HotTable component.
 */
export declare const UNEXPECTED_HOTTABLE_CHILDREN_WARNING: string;
/**
 * Warning message for the unexpected children of HotColumn component.
 */
export declare const UNEXPECTED_HOTCOLUMN_CHILDREN_WARNING: string;
/**
 * Message for the warning thrown if the Handsontable instance has been destroyed.
 */
export declare const HOT_DESTROYED_WARNING: string;
/**
 * Default classname given to the wrapper container.
 */
export declare const DEFAULT_CLASSNAME = "hot-wrapper-editor-container";
/**
 * Logs warn to the console if the `console` object is exposed.
 *
 * @param {...*} args Values which will be logged.
 */
export declare function warn(...args: any[]): void;
/**
 * Detect if `hot-renderer` or `hot-editor` is defined, and if so, throw an incompatibility warning.
 *
 * @returns {boolean} 'true' if the warning was issued
 */
export declare function displayObsoleteRenderersEditorsWarning(children: ReactNode): boolean;
/**
 * Detect if children of specified type are defined, and if so, throw an incompatibility warning.
 *
 * @param {ReactNode} children Component children nodes
 * @param {ComponentType} Component Component type to check
 * @returns {boolean} 'true' if the warning was issued
 */
export declare function displayChildrenOfTypeWarning(children: ReactNode, Component: ComponentType): boolean;
/**
 * Detect if children is defined, and if so, throw an incompatibility warning.
 *
 * @param {ReactNode} children Component children nodes
 * @returns {boolean} 'true' if the warning was issued
 */
export declare function displayAnyChildrenWarning(children: ReactNode): boolean;
/**
 * Create an editor portal.
 *
 * @param {Document} doc Document to be used.
 * @param {ComponentType} Editor Editor component or render function.
 * @returns {ReactPortal} The portal for the editor.
 */
export declare function createEditorPortal(doc: Document | null, Editor: HotTableProps['editor'] | undefined | boolean): ReactPortal | null;
/**
 * Render a cell component to an external DOM node.
 *
 * @param {React.ReactElement} rElement React element to be used as a base for the component.
 * @param {Document} [ownerDocument] The owner document to set the portal up into.
 * @param {String} portalKey The key to be used for the portal.
 * @param {HTMLElement} [cachedContainer] The cached container to be used for the portal.
 * @returns {{portal: ReactPortal, portalContainer: HTMLElement}} An object containing the portal and its container.
 */
export declare function createPortal(rElement: React.ReactElement, ownerDocument: Document | null | undefined, portalKey: string, cachedContainer?: HTMLElement): {
    portal: ReactPortal;
    portalContainer: HTMLElement;
};
/**
 * Get an object containing the `id`, `className` and `style` keys, representing the corresponding props passed to the
 * component.
 *
 * @param {HotTableProps} props Object containing the React element props.
 * @param {Boolean} randomizeId If set to `true`, the function will randomize the `id` property when no `id` was present in the `prop` object.
 * @returns An object containing the `id`, `className` and `style` keys, representing the corresponding props passed to the
 * component.
 */
export declare function getContainerAttributesProps(props: HotTableProps, randomizeId?: boolean): {
    id?: string;
    className: string;
    style: CSSProperties;
};
/**
 * Checks if the environment that the code runs in is a browser.
 *
 * @returns {boolean}
 */
export declare function isCSR(): boolean;
/**
 * Deep-compare plain objects and arrays used by wrapper settings.
 *
 * @param {unknown} previousValue Previous value.
 * @param {unknown} currentValue Current value.
 * @returns {boolean} `true` if values are equivalent.
 */
export declare function areEquivalentSettingsValue(previousValue: unknown, currentValue: unknown): boolean;
/**
 * A variant of useEffect hook that does not trigger on initial mount, only updates
 *
 * @param effect Effect function
 * @param deps Effect dependencies
 */
export declare function useUpdateEffect(effect: EffectCallback, deps?: DependencyList): void;
