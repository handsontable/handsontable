import { InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * A constant representing the non-commercial and evaluation license.
 * */
export declare const NON_COMMERCIAL_LICENSE = "non-commercial-and-evaluation";
/**
 * Type representing a theme name.
 * Possible values include predefined themes and any custom string.
 */
export declare enum PredefinedTheme {
    Main = "ht-theme-main",
    MainDark = "ht-theme-main-dark",
    MainDarkAuto = "ht-theme-main-dark-auto",
    Horizon = "ht-theme-horizon",
    HorizonDark = "ht-theme-horizon-dark",
    HorizonDarkAuto = "ht-theme-horizon-dark-auto"
}
export type ThemeName = PredefinedTheme | string;
/**
 * Interface for the Handsontable global configuration.
 */
export interface HotGlobalConfig {
    /**
     * The license key for Handsontable.
     */
    license?: string;
    /**
     * The name of the theme to be used.
     */
    themeName?: ThemeName;
    /**
     * The theme to be used (ThemeBuilder instance or theme name string).
     * When set, takes precedence over `themeName` for Handsontable 17+.
     */
    theme?: object | string;
    /**
     * The language code to be used for localization.
     * For example, 'en-US', 'pl-PL', etc.
     * **Note:** The language must be chosen from the languages supported by Handsontable and registered in the application.
     */
    language?: string;
    /**
     * The layout direction for the Handsontable instance.
     * This property defines whether the layout should be left-to-right ('ltr'), right-to-left ('rtl'),
     * or inherit the direction from the parent element ('inherit').
     */
    layoutDirection?: 'ltr' | 'rtl' | 'inherit';
}
/**
 * Injection token for providing a global default configuration.
 */
export declare const HOT_GLOBAL_CONFIG: InjectionToken<HotGlobalConfig>;
/**
 * Service for configuring Handsontable settings.
 * This service allows setting and retrieving global configuration.
 */
export declare class HotGlobalConfigService {
    /**
     * The default configuration object for Handsontable.
     *
     * This object is used as the initial value for the configuration BehaviorSubject.
     * It can be overridden by a global configuration provided through the
     * {@link HOT_GLOBAL_CONFIG} injection token.
     *
     * @private
     * @type {HotGlobalConfig}
     */
    private defaultConfig;
    /**
     * A BehaviorSubject that holds the current Handsontable configuration.
     *
     * New configuration values can be emitted by calling next() on this subject.
     * This allows subscribers to react to configuration changes dynamically.
     *
     * @private
     * @type {BehaviorSubject<HotGlobalConfig>}
     */
    private configSubject;
    /**
     * An Observable stream of the current Handsontable configuration.
     *
     * Components can subscribe to this observable to receive updates whenever the configuration changes.
     *
     * @returns The configuration as an observable stream.
     */
    get config$(): Observable<HotGlobalConfig>;
    constructor(globalConfig: HotGlobalConfig);
    /**
     * Sets the global configuration for Handsontable.
     *
     * @param config - An object containing configuration options.
     *                 Each Handsontable instance can override this configuration by providing its own settings.
     */
    setConfig(config: HotGlobalConfig): void;
    /**
     * Retrieves the current Handsontable configuration.
     *
     * @returns An object with the current settings.
     */
    getConfig(): HotGlobalConfig;
    /**
     * Resets the configuration to the default settings.
     * This method updates the configuration BehaviorSubject with the default configuration.
     */
    resetConfig(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotGlobalConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HotGlobalConfigService>;
}
