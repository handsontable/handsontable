import { ApplicationRef, ComponentRef, EnvironmentInjector, TemplateRef, Type } from '@angular/core';
import Handsontable from 'handsontable/base';
import { HotCellRendererComponent } from './hot-cell-renderer.component';
import { HotCellRendererAdvancedComponent } from './hot-cell-renderer-advanced.component';
import * as i0 from "@angular/core";
export declare const INVALID_RENDERER_WARNING: string;
export declare const INVALID_ADVANCED_RENDERER_WARNING: string;
/**
 * Type guard that checks if the given object is a TemplateRef.
 *
 * @param obj - The object to check.
 * @returns True if the object is a TemplateRef; otherwise, false.
 */
export declare function isTemplateRef<T>(obj: any): obj is TemplateRef<T>;
/**
 * Type guard to check if an object is an instance of HotCellRendererComponent.
 *
 * @param obj - The object to check.
 * @returns True if the object is a HotCellRendererComponent, false otherwise.
 */
export declare function isHotCellRendererComponent(obj: any): obj is Type<HotCellRendererComponent>;
/**
 * Type guard to check if an object is an instance of HotCellRendererAdvancedComponent.
 *
 * @param obj - The object to check.
 * @returns True if the object is a HotCellRendererAdvancedComponent, false otherwise.
 */
export declare function isAdvancedHotCellRendererComponent(obj: any): obj is Type<HotCellRendererAdvancedComponent>;
/**
 * Service for dynamically creating Angular components or templates as custom renderers for Handsontable.
 *
 * This service allows you to create a renderer function that wraps a given Angular component or TemplateRef
 * so that it can be used as a Handsontable renderer.
 *
 * @example
 * const customRenderer = dynamicComponentService.createRendererFromComponent(MyRendererComponent, { someProp: value });
 * // Use customRenderer in your Handsontable configuration
 */
export declare class DynamicComponentService {
    private appRef;
    private environmentInjector;
    constructor(appRef: ApplicationRef, environmentInjector: EnvironmentInjector);
    /**
     * Creates a custom renderer function for Handsontable from an Angular component or TemplateRef.
     * The generated renderer function will be used by Handsontable to render cell content.
     *
     * @param component - The Angular component type or TemplateRef to use as renderer.
     * @param componentProps - An object containing additional properties to use by the renderer.
     * @param register - If true, registers the renderer with Handsontable using the component's name.
     * @returns A renderer function that can be used in Handsontable's configuration.
     */
    createRendererFromComponent(component: Type<HotCellRendererComponent> | TemplateRef<any>, componentProps?: Record<string, any>, register?: boolean): (instance: Handsontable.Core, td: HTMLTableCellElement, row: number, col: number, prop: string | number, value: any, cellProperties: Handsontable.CellProperties) => HTMLTableCellElement;
    /**
     * Creates a custom renderer function using rendererFactory from Handsontable.
     * This is an alternative implementation that uses the factory pattern.
     *
     * @param component - The Angular component type to use as renderer.
     * @param componentProps - An object containing additional properties to use by the renderer.
     * @param register - If true, registers the renderer with Handsontable using the component's name.
     * @returns A renderer function that can be used in Handsontable's configuration.
     */
    createRendererWithFactory(component: Type<HotCellRendererAdvancedComponent>, componentProps?: Record<string, any>, register?: boolean): (instance: Handsontable.Core, td: HTMLTableCellElement, row: number, column: number, prop: string | number, value: any, cellProperties: Handsontable.CellProperties) => void;
    /**
     * Attaches an embedded view created from a TemplateRef to a given DOM element.
     *
     * @param template - The TemplateRef to create an embedded view from.
     * @param tdEl - The target DOM element (a table cell) to which the view will be appended.
     * @param properties - Context object providing properties to be used within the template.
     */
    private attachTemplateToElement;
    /**
     * Dynamically creates an Angular component of the given type.
     *
     * @param component - The Angular component type to be created.
     * @param rendererParameters - An object containing input properties to assign to the component instance.
     * @returns The ComponentRef of the dynamically created component.
     */
    private createComponent;
    /**
     * Attaches a dynamically created component's view to a specified DOM container element.
     *
     * @param componentRef - The reference to the dynamically created component.
     * @param container - The target DOM element to which the component's root node will be appended.
     */
    private attachComponentToElement;
    /**
     * Destroys a dynamically created component and detaches its view from the Angular application.
     *
     * @param componentRef - The reference to the component to be destroyed.
     */
    destroyComponent<T>(componentRef: ComponentRef<T>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DynamicComponentService>;
}
