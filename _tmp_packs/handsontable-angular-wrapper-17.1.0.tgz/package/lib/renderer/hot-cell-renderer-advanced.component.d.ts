import Handsontable from 'handsontable/base';
import * as i0 from "@angular/core";
/**
 * Abstract base component for creating advanced custom cell renderer components for Handsontable.
 *
 * This class provides a common interface and properties required by any custom cell renderer.
 *
 * @template TValue - The type of the component renderer.
 * @template TProps - The type of additional renderer properties.
 */
export declare abstract class HotCellRendererAdvancedComponent<TValue extends string | number | boolean | Record<string, any> | Array<any> = string, TProps extends {} = any> {
    static readonly RENDERER_MARKER: unique symbol;
    value: TValue;
    instance: Handsontable;
    td: HTMLTableCellElement;
    row: number;
    col: number;
    prop: string;
    /**
     * The cell properties provided by Handsontable, extended with optional renderer-specific properties.
     */
    cellProperties: Handsontable.CellProperties & {
        rendererProps?: TProps;
    };
    /**
     * Retrieves the renderer-specific properties from the cell properties.
     *
     * @returns The additional properties for the renderer.
     */
    getProps(): TProps;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotCellRendererAdvancedComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HotCellRendererAdvancedComponent<any, any>, "hot-cell-renderer-advanced", never, { "value": { "alias": "value"; "required": false; }; "instance": { "alias": "instance"; "required": false; }; "td": { "alias": "td"; "required": false; }; "row": { "alias": "row"; "required": false; }; "col": { "alias": "col"; "required": false; }; "prop": { "alias": "prop"; "required": false; }; "cellProperties": { "alias": "cellProperties"; "required": false; }; }, {}, never, never, true, never>;
}
