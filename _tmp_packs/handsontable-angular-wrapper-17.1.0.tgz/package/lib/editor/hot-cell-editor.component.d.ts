import { EventEmitter } from '@angular/core';
import { CellProperties } from 'handsontable/settings';
import * as i0 from "@angular/core";
/**
 * Abstract class representing a Handsontable editor in angular.
 */
export declare abstract class HotCellEditorComponent<T extends string | number | boolean> {
    static readonly EDITOR_MARKER: unique symbol;
    /** The tabindex attribute for the editor. */
    protected tabindex: number;
    /** The data-hot-input attribute for the editor. */
    protected dataHotInput: string;
    /** The handsontableInput class for the editor. */
    protected handsontableInputClass: boolean;
    /** The height of the editor as a percentage of the parent container. */
    protected heightFitParentContainer: number;
    /** The width of the editor as a percentage of the parent container. */
    protected widthFitParentContainer: number;
    /** The row index of the cell being edited. */
    row: number;
    /** The column index of the cell being edited. */
    column: number;
    /** The property name of the cell being edited. */
    prop: string | number;
    /** The original value of the cell being edited. */
    originalValue: T;
    /** The cell properties of the cell being edited. */
    cellProperties: CellProperties;
    /** Event emitted when the edit is finished.
     * The data will be saved to the model.
     */
    finishEdit: EventEmitter<void>;
    /** Event emitted when the edit is canceled.
     * The entered data will be reverted to the original value.
     */
    cancelEdit: EventEmitter<void>;
    /** The current value of the editor. */
    private _value;
    /** Event triggered by Handsontable on closing the editor.
     * The user can define their own actions for
     * the custom editor to be called after the base logic. */
    onClose(): void;
    /** Event triggered by Handsontable on open the editor.
     * The user can define their own actions for
     * the custom editor to be called after the base logic. */
    onOpen(event?: Event): void;
    /** Event triggered by Handsontable on focus the editor.
     * The user have to define focus logic.
     * @example
     * ```typescript
     * component({
     *  template: `<input #inputElement>`
     * })
     * class CustomEditor extends HotEditor<string> {
     *   @ViewChild('inputElement') inputElement!: ElementRef;
     *
     *   onFocus(): void {
     *     this.inputElement.nativeElement.focus();
     *   }
     * }
     * ```
     */
    abstract onFocus(): void;
    /**
     * Gets the current value of the editor.
     * @returns The current value of the editor.
     */
    getValue(): T;
    /**
     * Sets the current value of the editor.
     * @param value The value to set.
     */
    setValue(value: T): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotCellEditorComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HotCellEditorComponent<any>, never, never, { "row": { "alias": "row"; "required": false; }; "column": { "alias": "column"; "required": false; }; "prop": { "alias": "prop"; "required": false; }; "originalValue": { "alias": "originalValue"; "required": false; }; "cellProperties": { "alias": "cellProperties"; "required": false; }; }, { "finishEdit": "finishEdit"; "cancelEdit": "cancelEdit"; }, never, never, true, never>;
}
