import { EventEmitter } from '@angular/core';
import { ExtendedEditor } from 'handsontable/editors/factory';
import { CellProperties } from 'handsontable/settings';
import { KeyboardShortcutConfig } from './models/keyboard-shortcut-config';
import * as i0 from "@angular/core";
/**
 * Abstract class representing a Handsontable editor in angular.
 */
export declare abstract class HotCellEditorAdvancedComponent<T extends string | number | boolean | Record<string, any> | Array<any>> {
    static readonly EDITOR_MARKER: unique symbol;
    /** The height of the editor as a percentage of the parent container. */
    protected heightFitParentContainer: number;
    /** The width of the editor as a percentage of the parent container. */
    protected widthFitParentContainer: number;
    /** The row index of the cell being edited. */
    row: number;
    /** The column index of the cell being edited. */
    column: number;
    /** The property name of the cell being edited. */
    prop: string | number;
    /** The original value of the cell being edited. */
    originalValue: T;
    /** The cell properties of the cell being edited. */
    cellProperties: CellProperties;
    /** Event emitted when the edit is finished.
     * The data will be saved to the model.
     */
    finishEdit: EventEmitter<void>;
    /** Event emitted when the edit is canceled.
     * The entered data will be reverted to the original value.
     */
    cancelEdit: EventEmitter<void>;
    /** The current value of the editor. */
    protected value: T;
    /** Event triggered by Handsontable on focus the editor.
     * The user have to define focus logic.
     */
    onFocus(editor?: ExtendedEditor<T>): void;
    /**
     * Gets the current value of the editor.
     * @returns The current value of the editor.
     */
    getValue(): T;
    /**
     * Sets the current value of the editor.
     * @param value The value to set.
     */
    setValue(value: T): void;
    /** The position of the editor in the DOM. Used by Handsontable API. Available in advanced mode. */
    position: 'container' | 'portal';
    /** The shortcuts available for the editor. Available in advanced mode. */
    shortcuts?: KeyboardShortcutConfig[];
    /** The group name for the shortcuts. Available in advanced mode.*/
    shortcutsGroup?: string;
    /** Configuration. Available in advanced mode. */
    config?: any;
    /** Lifecycle hook called after the editor is opened. Available in advanced mode.*/
    afterOpen(editor: ExtendedEditor<T>, event?: Event): void;
    /** Lifecycle hook called after the editor is closed. Available in advanced mode. */
    afterClose(editor: ExtendedEditor<T>): void;
    /** Lifecycle hook called after the editor is initialized. Available in advanced mode.*/
    afterInit(editor: ExtendedEditor<T>): void;
    /** Lifecycle hook called before the editor is opened. Available in advanced mode. */
    beforeOpen(editor: ExtendedEditor<T>, { row, col, prop, td, originalValue, cellProperties, }: {
        row: number;
        col: number;
        prop: string | number;
        td: HTMLTableCellElement;
        originalValue: any;
        cellProperties: CellProperties;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotCellEditorAdvancedComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HotCellEditorAdvancedComponent<any>, never, never, { "row": { "alias": "row"; "required": false; }; "column": { "alias": "column"; "required": false; }; "prop": { "alias": "prop"; "required": false; }; "originalValue": { "alias": "originalValue"; "required": false; }; "cellProperties": { "alias": "cellProperties"; "required": false; }; }, { "finishEdit": "finishEdit"; "cancelEdit": "cancelEdit"; }, never, never, true, never>;
}
