import { ComponentRef } from '@angular/core';
import { HotCellEditorAdvancedComponent } from './hot-cell-editor-advanced.component';
/**
 * Factory function to create a custom Handsontable editor adapter for Angular components.
 *
 * This adapter integrates Angular components with Handsontable's editor system using the new
 * editorFactory API, allowing you to use Angular components as custom cell editors while
 * maintaining full Angular lifecycle management and change detection.
 *
 * @returns A custom editor class that can be used in Handsontable column settings.
 *
 */
export declare const FactoryEditorAdapter: (componentRef: ComponentRef<HotCellEditorAdvancedComponent<any>>) => any;
