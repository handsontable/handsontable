import Handsontable from 'handsontable/base';
/**
 * Adapter for BaseEditor from Handsontable.
 */
export declare class BaseEditorAdapter extends Handsontable.editors.BaseEditor {
    /** Reference to the custom editor component. */
    private _componentRef?;
    /** Reference to the editor placeholder component. */
    private _editorPlaceHolderRef;
    /** Flag indicating whether the placeholder is ready. */
    private _isPlaceholderReady;
    /** Subscription for the finish edit event. */
    private _finishEditSubscription?;
    /** Subscription for the cancel edit event. */
    private _cancelEditSubscription?;
    /**
     * Creates an instance of BaseEditorAdapter.
     * @param instance The Handsontable instance.
     */
    constructor(instance: Handsontable.Core);
    /**
     * Prepares the editor for editing. Parameters are passed from Handsontable.
     * @param row The row index.
     * @param column The column index.
     * @param prop The property name.
     * @param TD The table cell element.
     * @param originalValue The original value of the cell.
     * @param cellProperties The cell properties.
     */
    prepare(row: number, column: number, prop: string | number, TD: HTMLTableCellElement, originalValue: any, cellProperties: Handsontable.CellProperties): void;
    /**
     * Closes the editor. This event is triggered by Handsontable.
     */
    close(): void;
    /**
     * Focuses the editor. This event is triggered by Handsontable.
     */
    focus(): void;
    /**
     * Gets the value from the editor.
     * @returns The value from the editor.
     */
    getValue(): any;
    /**
     * Opens the editor. This event is triggered by Handsontable.
     * When opening, we set the shortcut context to 'editor'.
     * This allows the built-in keyboard shortcuts to operate within the editor.
     * @param event The event that triggered the opening of the editor.
     * @remarks When entering edit mode using double-click, keyboard shortcuts do not work.
     */
    open(event?: Event): void;
    /**
     * Sets the value for the custom editor.
     * @param newValue The value to set.
     */
    setValue(newValue?: any): void;
    /**
     * Applies properties to the custom editor and editor placeholder.
     */
    private applyPropsToEditor;
    /**
     * Creates the editor placeholder and append it to hot rootElement.
     * @param injector The environment injector.
     */
    private createEditorPlaceholder;
    /**
     * Handles the after column resize event.
     * Helps adjust the editor size to the column size and update its position.
     */
    private onAfterColumnResize;
    /**
     * Handles the after row resize event.
     * Helps adjust the editor size to the column size and update its position.
     */
    private onAfterRowResize;
    /**
     * Handles the after destroy event.
     */
    private onAfterDestroy;
    /**
     * Resets the editor placeholder state.
     * We need to reset the editor placeholder state because we use it
     * to store multiple references to the custom editor.
     */
    private resetEditorState;
}
