/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@handsontable/angular-wrapper" />
export * from './public-api';
