import React from 'react';
import { HotTableProps, HotTableRef } from './types';
declare const HotTableInner: React.ForwardRefExoticComponent<HotTableProps & React.RefAttributes<HotTableRef>>;
export default HotTableInner;
export { HotTableInner };
