import React, { Dispatch, ReactPortal } from 'react';
export declare type RenderersPortalManagerRef = Dispatch<ReactPortal[]>;
/**
 * Component used to manage the renderer component portals.
 */
export declare const RenderersPortalManager: React.ForwardRefExoticComponent<React.RefAttributes<React.Dispatch<React.ReactPortal[]>>>;
