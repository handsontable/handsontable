import { ModuleWithProviders } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "./hot-table.component";
import * as i2 from "./editor/custom-editor-placeholder.component";
export declare class HotTableModule {
    /**
     * Placeholder for the library version.
     * Replaced automatically during the pre-build/post-build process.
     */
    static version: string;
    constructor();
    static forRoot(): ModuleWithProviders<HotTableModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HotTableModule, [typeof i1.HotTableComponent, typeof i2.CustomEditorPlaceholderComponent], never, [typeof i1.HotTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HotTableModule>;
}
