import { EnvironmentInjector, NgZone } from '@angular/core';
import { DynamicComponentService } from '../renderer/hot-dynamic-renderer-component.service';
import { GridSettings, GridSettingsInternal } from '../models/grid-settings';
import * as i0 from "@angular/core";
/**
 * Service to resolve and apply custom settings for Handsontable settings object.
 */
export declare class HotSettingsResolver {
    private dynamicComponentService;
    private readonly environmentInjector;
    constructor(dynamicComponentService: DynamicComponentService, environmentInjector: EnvironmentInjector);
    /**
     * Applies custom settings to the provided GridSettings.
     * @param settings The original grid settings.
     * @param ngZone The NgZone instance to run hooks inside the zone context.
     * @returns The merged grid settings with custom settings applied.
     */
    applyCustomSettings(settings: GridSettings, ngZone: NgZone): GridSettingsInternal;
    /**
     * Ensures that hook callbacks in the provided grid settings run inside Angular's zone.
     *
     * @param settings The original grid settings.
     * @param ngZone The NgZone instance to run hooks inside the zone context.
     */
    private wrapHooksInNgZone;
    /**
     * Updates the column renderer for columns with a custom renderer.
     * @param mergedSettings The merged grid settings.
     */
    private updateColumnRendererForGivenCustomRenderer;
    /**
     * Updates the column editor for columns with a custom editor.
     * @param mergedSettings The merged grid settings.
     */
    private updateColumnEditorForGivenCustomEditor;
    /**
     * Updates the column validator for columns with a custom validator.
     * @param mergedSettings The merged grid settings.
     */
    private updateColumnValidatorForGivenCustomValidator;
    private isCustomValidatorFn;
    private isEditorComponentRefType;
    private isAdvancedEditorComponentRefType;
    private isRendererComponentRefType;
    private isAdvancedRendererComponentRefType;
    private isTemplateRef;
    private isCustomRenderer;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotSettingsResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HotSettingsResolver>;
}
