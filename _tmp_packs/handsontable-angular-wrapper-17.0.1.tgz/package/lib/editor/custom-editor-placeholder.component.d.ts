import { ComponentRef, ViewContainerRef } from '@angular/core';
import { HotCellEditorComponent } from './hot-cell-editor.component';
import { HotCellEditorAdvancedComponent } from './hot-cell-editor-advanced.component';
import * as i0 from "@angular/core";
/**
 * Component representing a placeholder for a custom editor in Handsontable.
 * It is used only within the wrapper.
 */
export declare class CustomEditorPlaceholderComponent {
    /** The top position of the editor. */
    top: number;
    /** The left position of the editor. */
    left: number;
    /** The height of the editor. */
    height: number;
    /** The width of the editor. */
    width: number;
    set isVisible(value: boolean);
    placeholderCustomClass: string;
    /** The reference to the component instance of the editor. */
    set componentRef(hotEditorComponentRef: ComponentRef<HotCellEditorComponent<any>> | ComponentRef<HotCellEditorAdvancedComponent<any>>);
    /** The container for the editor's input placeholder. */
    container: ViewContainerRef;
    /** The display style of the editor. */
    get display(): string;
    private _isVisible;
    /**
     * Detaches the container from the Handsontable.
     */
    detachEditor(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomEditorPlaceholderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomEditorPlaceholderComponent, "ng-component", never, { "top": { "alias": "top"; "required": false; }; "left": { "alias": "left"; "required": false; }; "height": { "alias": "height"; "required": false; }; "width": { "alias": "width"; "required": false; }; "isVisible": { "alias": "isVisible"; "required": false; }; "placeholderCustomClass": { "alias": "placeholderCustomClass"; "required": false; }; "componentRef": { "alias": "componentRef"; "required": false; }; }, {}, never, never, false, never>;
}
