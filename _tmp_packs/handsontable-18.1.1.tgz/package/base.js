"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get CellCoords () {
        return _src.CellCoords;
    },
    get CellRange () {
        return _src.CellRange;
    },
    get IndexMapper () {
        return _translations.IndexMapper;
    },
    get default () {
        return _default;
    }
});
const _core = /*#__PURE__*/ _interop_require_default(require("./core"));
const _rootInstance = require("./utils/rootInstance");
const _dataMap = require("./dataMap");
const _hooks = require("./core/hooks");
const _registry = require("./i18n/registry");
const _registry1 = require("./cellTypes/registry");
const _registry2 = require("./renderers/registry");
const _baseRenderer = require("./renderers/baseRenderer");
const _textType = require("./cellTypes/textType");
const _baseEditor = require("./editors/baseEditor");
const _src = require("./3rdparty/walkontable/src");
const _registry3 = require("./themes/registry");
const _textEditor = require("./editors/textEditor/textEditor");
const _element = require("./helpers/dom/element");
const _translations = require("./translations");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const CoreClass = _core.default;
// register default mandatory cell type for the Base package
(0, _registry1.registerCellType)(_textType.TextCellType);
(0, _registry2.registerRenderer)(_baseRenderer.baseRenderer);
/**
 * Handsontable factory function and static namespace.
 * Implemented as a typed const so that declaration emit produces a merge with declare namespace Handsontable.
 */ const Handsontable = function Handsontable(rootElement, userSettings) {
    const instance = new CoreClass(rootElement, userSettings || {}, _rootInstance.rootInstanceSymbol);
    instance.init();
    return instance;
};
// Static members
// Cast: base package only seeds BaseEditor/TextEditor; index.ts fills the rest at runtime.
Handsontable.editors = {
    BaseEditor: _baseEditor.BaseEditor,
    TextEditor: _textEditor.TextEditor
};
Handsontable.dom = {
    empty: _element.empty
};
Handsontable.helper = {};
Handsontable.Core = function(rootElement, userSettings = {}) {
    return new CoreClass(rootElement, userSettings, _rootInstance.rootInstanceSymbol);
};
Handsontable.DefaultSettings = (0, _dataMap.metaSchemaFactory)();
Handsontable.hooks = _hooks.Hooks.getSingleton();
Handsontable.CellCoords = _src.CellCoords;
Handsontable.CellRange = _src.CellRange;
Handsontable.packageName = 'handsontable';
Handsontable.buildDate = "15/09/2026 08:36:16";
Handsontable.version = "18.1.1";
Handsontable.languages = {
    dictionaryKeys: _registry.dictionaryKeys,
    getLanguageDictionary: _registry.getLanguageDictionary,
    getLanguagesDictionaries: _registry.getLanguagesDictionaries,
    registerLanguageDictionary: _registry.registerLanguageDictionary,
    getTranslatedPhrase: _registry.getTranslatedPhrase
};
Handsontable.themes = {
    hasTheme: _registry3.hasTheme,
    getTheme: _registry3.getTheme,
    getThemeNames: _registry3.getThemeNames,
    getThemes: _registry3.getThemes,
    registerTheme: _registry3.registerTheme,
    reinitTheme: _registry3.reinitTheme
};
const _default = Handsontable;
