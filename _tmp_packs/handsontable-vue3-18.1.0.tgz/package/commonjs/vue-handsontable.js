'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var vue = require('vue');
var Handsontable = require('handsontable/base');

function _interopDefaultCompat (e) { return e && typeof e === 'object' && 'default' in e ? e : { default: e }; }

var Handsontable__default = /*#__PURE__*/_interopDefaultCompat(Handsontable);

function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}
function _defineProperty(e, r, t) {
  return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: true,
    configurable: true,
    writable: true
  }) : e[r] = t, e;
}
function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = true,
      o = false;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = true, n = r;
    } finally {
      try {
        if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function (r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread2(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), true).forEach(function (r) {
      _defineProperty(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}
function _slicedToArray(r, e) {
  return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _toPrimitive(t, r) {
  if ("object" != typeof t || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r);
    if ("object" != typeof i) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == typeof i ? i : i + "";
}
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return _arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
  }
}

var unassignedPropSymbol = Symbol('unassigned');

/**
 * Message for the warning thrown if the Handsontable instance has been destroyed.
 */
var HOT_DESTROYED_WARNING = 'The Handsontable instance bound to this component was destroyed and cannot be' + ' used properly.';

/**
 * Check if at specified `key` there is any value for `object`.
 *
 * @param {object} object Object to search value at specyfic key.
 * @param {string} key String key to check.
 * @returns {boolean}
 */
function hasOwnProperty(object, key) {
  return Object.prototype.hasOwnProperty.call(object, key);
}

/**
 * Generate an object containing all the available Handsontable properties and plugin hooks.
 *
 * @param {string} source Source for the factory (either 'HotTable' or 'HotColumn').
 * @returns {object}
 */
function propFactory(source) {
  var registeredHooks = Handsontable__default["default"].hooks.getRegistered();
  var propSchema = {};
  Object.assign(propSchema, Handsontable__default["default"].DefaultSettings);

  // eslint-disable-next-line no-restricted-syntax, guard-for-in
  for (var prop in propSchema) {
    propSchema[prop] = {
      "default": unassignedPropSymbol
    };
  }
  for (var i = 0; i < registeredHooks.length; i++) {
    propSchema[registeredHooks[i]] = {
      "default": unassignedPropSymbol
    };
  }
  propSchema.settings = {
    "default": unassignedPropSymbol
  };
  if (source === 'HotTable') {
    propSchema.id = {
      type: String,
      "default": "hot-".concat(Math.random().toString(36).substring(5))
    };
  }
  return propSchema;
}

/**
 * Filter out all of the unassigned props, and return only the one passed to the component.
 *
 * @param {object} props Object containing all the possible props.
 * @returns {object} Object containing only used props.
 */
function filterPassedProps(props) {
  var filteredProps = {};
  var columnSettingsProp = props.settings;
  if (columnSettingsProp !== unassignedPropSymbol) {
    // eslint-disable-next-line no-restricted-syntax
    for (var propName in columnSettingsProp) {
      if (hasOwnProperty(columnSettingsProp, propName) && columnSettingsProp[propName] !== unassignedPropSymbol) {
        filteredProps[propName] = columnSettingsProp[propName];
      }
    }
  }

  // eslint-disable-next-line no-restricted-syntax
  for (var _propName in props) {
    if (hasOwnProperty(props, _propName) && _propName !== 'settings' && props[_propName] !== unassignedPropSymbol) {
      filteredProps[_propName] = props[_propName];
    }
  }
  return filteredProps;
}

/**
 * Prepare the settings object to be used as the settings for Handsontable, based on the props provided to the component.
 *
 * @param {HotTableProps} props The props passed to the component.
 * @param {Handsontable.GridSettings} currentSettings The current Handsontable settings.
 * @returns {Handsontable.GridSettings} An object containing the properties, ready to be used within Handsontable.
 */
function prepareSettings(props, currentSettings) {
  var assignedProps = filterPassedProps(props);
  var hotSettingsInProps = props.settings ? props.settings : assignedProps;
  var additionalHotSettingsInProps = props.settings ? assignedProps : null;
  var initOnlySettingKeys = (currentSettings === null || currentSettings === void 0 ? void 0 : currentSettings._initOnlySettings) || [];
  var newSettings = {};

  // eslint-disable-next-line no-restricted-syntax
  for (var key in hotSettingsInProps) {
    if (hasOwnProperty(hotSettingsInProps, key) && hotSettingsInProps[key] !== void 0 && !initOnlySettingKeys.includes(key) && (currentSettings && key !== 'data' ? !simpleEqual(currentSettings[key], hotSettingsInProps[key]) : true)) {
      newSettings[key] = hotSettingsInProps[key];
    }
  }

  // eslint-disable-next-line no-restricted-syntax
  for (var _key in additionalHotSettingsInProps) {
    if (hasOwnProperty(additionalHotSettingsInProps, _key) && _key !== 'id' && _key !== 'settings' && additionalHotSettingsInProps[_key] !== void 0 && !initOnlySettingKeys.includes(_key) && (currentSettings && _key !== 'data' ? !simpleEqual(currentSettings[_key], additionalHotSettingsInProps[_key]) : true)) {
      newSettings[_key] = additionalHotSettingsInProps[_key];
    }
  }
  return newSettings;
}

/**
 * Compare two objects using `JSON.stringify`.
 * *Note: * As it's using the stringify function to compare objects, the property order in both objects is
 * important. It will return `false` for the same objects, if they're defined in a different order.
 *
 * @param {object} objectA First object to compare.
 * @param {object} objectB Second object to compare.
 * @returns {boolean} `true` if they're the same, `false` otherwise.
 */
function simpleEqual(objectA, objectB) {
  // Shared across both stringify calls so the same Node/function instance maps
  // to the same identity token in objectA's string and objectB's string.
  var identityMap = new WeakMap();
  var nextIdentityId = 0;
  var stringifyToJSON = function stringifyToJSON(val) {
    var seen = new WeakSet();
    return JSON.stringify(val, function (key, value) {
      if (_typeof(value) === 'object' && value !== null) {
        if (seen.has(value)) {
          return undefined;
        }
        seen.add(value);

        // DOM nodes carry framework metadata as enumerable own properties
        // (e.g., Vue 3 attaches `_vnode` to the mount root). Recursing into them
        // can reach getters that throw - see GH #11220 - and produces noise that
        // is irrelevant to settings equality. Replace each Node with an identity
        // token so reference equality is still detected.
        if (typeof Node !== 'undefined' && value instanceof Node) {
          var id = identityMap.get(value);
          if (id === undefined) {
            nextIdentityId += 1;
            id = "__hot_node_".concat(nextIdentityId, "__");
            identityMap.set(value, id);
          }
          return id;
        }
      }
      return value;
    });
  };
  if (typeof objectA === 'function' && typeof objectB === 'function') {
    return objectA.toString() === objectB.toString();
  } else if (_typeof(objectA) !== _typeof(objectB)) {
    return false;
  } else {
    try {
      return stringifyToJSON(objectA) === stringifyToJSON(objectB);
    } catch (e) {
      // If either side cannot be serialized (e.g., contains a throwing getter),
      // assume the values are not equal so the wrapper still updates settings.
      return false;
    }
  }
}

var version="18.1.0";

var HotTable = vue.defineComponent({
  name: 'HotTable',
  props: propFactory('HotTable'),
  provide: function provide() {
    return {
      columnsCache: this.columnsCache,
      refreshColumns: this.refreshColumns
    };
  },
  watch: {
    $props: {
      handler: function handler(props) {
        var settings = prepareSettings(props, this.hotInstance ? this.hotInstance.getSettings() : void 0);
        if (!this.hotInstance || settings === void 0) {
          return;
        }
        if (settings.data) {
          if (this.hotInstance.isColumnModificationAllowed() || !this.hotInstance.isColumnModificationAllowed() && this.hotInstance.countSourceCols() === this.miscCache.currentSourceColumns) {
            // If the dataset dimensions change, update the index mappers.
            this.matchHotMappersSize();

            // Data is automatically synchronized by reference.
            delete settings.data;
          }
        }

        // If there are another options changed, update the HOT settings, render the table otherwise.
        if (Object.keys(settings).length) {
          this.hotInstance.updateSettings(settings);
        } else {
          this.hotInstance.render();
        }
        this.miscCache.currentSourceColumns = this.hotInstance.countSourceCols();
      },
      deep: true,
      immediate: true
    }
  },
  data: function data() {
    return {
      /* eslint-disable vue/no-reserved-keys */
      __hotInstance: null,
      /* eslint-enable vue/no-reserved-keys */
      miscCache: {
        currentSourceColumns: null
      },
      columnSettings: null,
      columnsCache: new Map(),
      columnsRefreshScheduled: false,
      get hotInstance() {
        if (!this.__hotInstance || this.__hotInstance && !this.__hotInstance.isDestroyed) {
          // Will return the Handsontable instance or `null` if it's not yet been created.
          return this.__hotInstance;
        } else {
          /* eslint-disable-next-line no-console */
          console.warn(HOT_DESTROYED_WARNING);
          return null;
        }
      },
      set hotInstance(hotInstance) {
        this.__hotInstance = hotInstance;
      }
    };
  },
  methods: {
    /**
     * Initialize Handsontable.
     */
    hotInit: function hotInit() {
      var newSettings = prepareSettings(this.$props);
      newSettings.columns = this.columnSettings ? this.columnSettings : newSettings.columns;
      this.hotInstance = vue.markRaw(new Handsontable__default["default"].Core(this.$el, newSettings));
      this.hotInstance.init();
      this.miscCache.currentSourceColumns = this.hotInstance.countSourceCols();
    },
    matchHotMappersSize: function matchHotMappersSize() {
      var _this = this;
      if (!this.hotInstance) {
        return;
      }
      var data = this.hotInstance.getSourceData();
      var rowsToRemove = [];
      var columnsToRemove = [];
      var indexMapperRowCount = this.hotInstance.rowIndexMapper.getNumberOfIndexes();
      var isColumnModificationAllowed = this.hotInstance.isColumnModificationAllowed();
      var indexMapperColumnCount = 0;
      if (data && data.length !== indexMapperRowCount) {
        if (data.length < indexMapperRowCount) {
          for (var r = data.length; r < indexMapperRowCount; r++) {
            rowsToRemove.push(r);
          }
        }
      }
      if (isColumnModificationAllowed) {
        var _data$;
        indexMapperColumnCount = this.hotInstance.columnIndexMapper.getNumberOfIndexes();
        if (data && data[0] && ((_data$ = data[0]) === null || _data$ === void 0 ? void 0 : _data$.length) !== indexMapperColumnCount) {
          if (data[0].length < indexMapperColumnCount) {
            for (var c = data[0].length; c < indexMapperColumnCount; c++) {
              columnsToRemove.push(c);
            }
          }
        }
      }
      this.hotInstance.batch(function () {
        if (rowsToRemove.length > 0) {
          _this.hotInstance.rowIndexMapper.removeIndexes(rowsToRemove);
        } else {
          _this.hotInstance.rowIndexMapper.insertIndexes(indexMapperRowCount - 1, data.length - indexMapperRowCount);
        }
        if (isColumnModificationAllowed && data.length !== 0) {
          if (columnsToRemove.length > 0) {
            _this.hotInstance.columnIndexMapper.removeIndexes(columnsToRemove);
          } else {
            _this.hotInstance.columnIndexMapper.insertIndexes(indexMapperColumnCount - 1, data[0].length - indexMapperColumnCount);
          }
        }
      });
    },
    /**
     * Get settings for the columns provided in the `hot-column` components.
     *
     * The columns are ordered by the document position of each `hot-column`'s
     * anchor node, not by the `columnsCache` insertion order. This keeps the
     * order correct when columns are inserted in the middle, removed, or
     * reordered, and when a `hot-column` is nested inside a wrapper component.
     *
     * @returns {HotTableProps[] | undefined}
     */
    getColumnSettings: function getColumnSettings() {
      var orderedColumns = Array.from(this.columnsCache.entries()).sort(function (_ref, _ref2) {
        var _ref3 = _slicedToArray(_ref, 1),
          columnA = _ref3[0];
        var _ref4 = _slicedToArray(_ref2, 1),
          columnB = _ref4[0];
        var anchorA = columnA.$el;
        var anchorB = columnB.$el;
        if (!anchorA || !anchorB) {
          return 0;
        }
        var position = anchorA.compareDocumentPosition(anchorB);

        // eslint-disable-next-line no-bitwise
        if (position & Node.DOCUMENT_POSITION_FOLLOWING) {
          return -1;
        }

        // eslint-disable-next-line no-bitwise
        if (position & Node.DOCUMENT_POSITION_PRECEDING) {
          return 1;
        }
        return 0;
      }).map(function (_ref5) {
        var _ref6 = _slicedToArray(_ref5, 2),
          columnSettings = _ref6[1];
        return columnSettings;
      });
      return orderedColumns.length ? orderedColumns : void 0;
    },
    /**
     * Re-read the column settings declared by `hot-column` children and push them
     * to the Handsontable instance. Called by children on mount, prop change, and
     * unmount, and by the parent on reorder. Multiple notifications in the same
     * tick are coalesced into a single `updateSettings` call.
     */
    refreshColumns: function refreshColumns() {
      var _this2 = this;
      if (this.columnsRefreshScheduled) {
        return;
      }
      this.columnsRefreshScheduled = true;
      this.$nextTick(function () {
        _this2.columnsRefreshScheduled = false;
        if (!_this2.hotInstance) {
          return;
        }
        var newColumnSettings = _this2.getColumnSettings();
        var previousColumnSettings = _this2.columnSettings;

        // Each `hot-column` rebuilds its settings object whenever its props change,
        // so an unchanged column keeps the same object reference. Comparing the
        // arrays by reference and order is cheaper than a deep compare and avoids
        // an `updateSettings` call on unrelated re-renders (e.g. data-only updates).
        var isUnchanged = !previousColumnSettings && !newColumnSettings || !!previousColumnSettings && !!newColumnSettings && previousColumnSettings.length === newColumnSettings.length && previousColumnSettings.every(function (settings, index) {
          return settings === newColumnSettings[index];
        });
        if (isUnchanged) {
          return;
        }
        _this2.columnSettings = newColumnSettings || null;
        _this2.hotInstance.updateSettings({
          columns: newColumnSettings || void 0
        });
      });
    }
  },
  mounted: function mounted() {
    this.columnSettings = this.getColumnSettings();
    this.hotInit();
  },
  updated: function updated() {
    // Reordering keyed `hot-column` children reuses their instances and fires no
    // child lifecycle hook, so the children cannot notify on their own. The slot
    // vnodes do change, which re-renders `HotTable` - refresh from here to cover
    // reorders (coalesced with any child-triggered refresh).
    this.refreshColumns();
  },
  beforeUnmount: function beforeUnmount() {
    if (this.hotInstance) {
      this.hotInstance.destroy();
    }
  },
  version: version
});

var _hoisted_1 = ["id"];
function render(_ctx, _cache, $props, $setup, $data, $options) {
  return vue.openBlock(), vue.createElementBlock("div", {
    id: _ctx.id,
    style: {
      "height": "100%"
    }
  }, [vue.createCommentVNode(" `hot-column` children render invisible comment anchors in source order.\n         Handsontable appends its own DOM to this container without clearing\n         pre-existing nodes, so the anchors survive; the parent reads their\n         document position to order the columns. "), vue.renderSlot(_ctx.$slots, "default")], 8 /* PROPS */, _hoisted_1);
}

HotTable.render = render;
HotTable.__file = "src/HotTable.vue";

var HotColumn = vue.defineComponent({
  name: 'HotColumn',
  props: propFactory('HotColumn'),
  inject: ['columnsCache', 'refreshColumns'],
  methods: {
    /**
     * Create the column settings based on the data provided to the `hot-column`
     * component and it's child components.
     */
    createColumnSettings: function createColumnSettings() {
      var assignedProps = filterPassedProps(this.$props);
      var columnSettings = _objectSpread2({}, assignedProps);
      if (assignedProps.renderer) {
        columnSettings.renderer = assignedProps.renderer;
      }
      if (assignedProps.editor) {
        columnSettings.editor = assignedProps.editor;
      }
      this.columnsCache.set(this, columnSettings);
    }
  },
  watch: {
    $props: {
      handler: function handler() {
        this.createColumnSettings();
        this.refreshColumns();
      },
      deep: true
    }
  },
  mounted: function mounted() {
    this.createColumnSettings();
    this.refreshColumns();
  },
  unmounted: function unmounted() {
    this.columnsCache["delete"](this);
    this.refreshColumns();
  },
  render: function render() {
    // Render an (invisible) comment anchor instead of nothing, so the parent
    // `HotTable` can order columns by the anchors' document position. This keeps
    // ordering correct for dynamic inserts, removals, and reorders - and works
    // regardless of how deeply the `hot-column` is nested inside wrapper
    // components - because `provide`/`inject` and the anchor both cross nesting.
    return vue.createCommentVNode('hot-column');
  }
});

HotColumn.__file = "src/HotColumn.vue";

exports.HotColumn = HotColumn;
exports.HotTable = HotTable;
exports["default"] = HotTable;
