import { EnvironmentInjector, NgZone } from '@angular/core';
import { DynamicComponentService } from '../renderer/hot-dynamic-renderer-component.service';
import { GridSettings, GridSettingsInternal } from '../models/grid-settings';
import { ColumnSettings } from '../models/column-settings';
import * as i0 from "@angular/core";
/**
 * Service to resolve and apply custom settings for Handsontable settings object.
 */
export declare class HotSettingsResolver {
    private readonly dynamicComponentService;
    private readonly environmentInjector;
    private readonly ngZone;
    constructor(dynamicComponentService: DynamicComponentService, environmentInjector: EnvironmentInjector, ngZone: NgZone);
    /**
     * Applies custom settings to the provided GridSettings.
     * @param settings The original grid settings.
     * @param previousColumns The previously resolved columns (from the prior settings cycle). When
     *   supplied, an editor component already created for a column whose editor type is unchanged is
     *   recycled instead of being recreated, avoiding needless Angular component teardown/rebuild.
     * @returns The merged grid settings with custom settings applied.
     */
    applyCustomSettings(settings: GridSettings, previousColumns?: ColumnSettings[]): GridSettingsInternal;
    /**
     * Ensures that hook callbacks in the provided grid settings run inside Angular's zone.
     *
     * @param settings The original grid settings.
     */
    private wrapHooksInNgZone;
    /**
     * Updates the column renderer for columns with a custom renderer.
     * @param mergedSettings The merged grid settings.
     */
    private updateColumnRendererForGivenCustomRenderer;
    /**
     * Updates the column editor for columns with a custom editor.
     *
     * Iterates by original column index (not a filtered subset) so each column can be matched against
     * the column at the same index in `previousColumns` for editor-component recycling.
     *
     * @param mergedSettings The merged grid settings.
     * @param previousColumns The previously resolved columns, used to recycle editor components.
     */
    private updateColumnEditorForGivenCustomEditor;
    /**
     * Returns the previous column's editor component ref when it can be reused for the new column, or
     * `undefined` to signal a fresh component is needed.
     *
     * A ref is only recycled when, at the same index, both the editor component type AND the logical
     * column identity (its `data` binding) are unchanged. The component-type check alone would already
     * be functionally safe — a Handsontable editor is not per-cell rendered state but a single
     * on-demand component that `BaseEditorAdapter`/`FactoryEditorAdapter` re-prepare on every edit
     * (`prepare()` re-reads the ref from the *current* column meta and `applyPropsToEditor()` re-applies
     * the full cell context on each `open()`). The extra `data` check is a defensive guard: when columns
     * are reordered/shortened so a *different* logical column lands on an index, we build a fresh editor
     * rather than carry the previous column's instance over, so no custom editor that caches
     * column-specific config at construction can leak stale state into the new cell.
     *
     * @param previousColumn The column at the same index in the previous settings cycle.
     * @param currentColumn The column now occupying this index.
     * @param editorType The editor component type requested for the new column.
     */
    private reusableEditorRef;
    /**
     * Updates the column validator for columns with a custom validator.
     * @param mergedSettings The merged grid settings.
     */
    private updateColumnValidatorForGivenCustomValidator;
    private isCustomValidatorFn;
    private isEditorComponentRefType;
    private isAdvancedEditorComponentRefType;
    private isRendererComponentRefType;
    private isAdvancedRendererComponentRefType;
    private isTemplateRef;
    private isCustomRenderer;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotSettingsResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HotSettingsResolver>;
}
