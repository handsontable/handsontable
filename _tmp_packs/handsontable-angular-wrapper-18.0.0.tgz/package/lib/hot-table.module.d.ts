import * as i0 from "@angular/core";
import * as i1 from "./hot-table.component";
export declare class HotTableModule {
    static readonly version = "18.0.0";
    static ɵfac: i0.ɵɵFactoryDeclaration<HotTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HotTableModule, never, [typeof i1.HotTableComponent], [typeof i1.HotTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HotTableModule>;
}
