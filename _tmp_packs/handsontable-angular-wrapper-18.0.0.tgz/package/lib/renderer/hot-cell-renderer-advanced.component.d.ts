import { HotCellRendererBase } from './hot-cell-renderer-base.directive';
import * as i0 from "@angular/core";
/**
 * Abstract base component for creating advanced custom cell renderer components for Handsontable.
 *
 * Extend this component and provide your own template to implement a custom renderer.
 * Unlike {@link HotCellRendererComponent}, this variant also accepts object and array values.
 *
 * @template TValue - The type of the component renderer.
 * @template TProps - The type of additional renderer properties.
 */
export declare abstract class HotCellRendererAdvancedComponent<TValue extends string | number | boolean | Record<string, any> | Array<any> = string, TProps extends {} = any> extends HotCellRendererBase<TValue, TProps> {
    static readonly RENDERER_MARKER: unique symbol;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotCellRendererAdvancedComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HotCellRendererAdvancedComponent<any, any>, "hot-cell-renderer-advanced", never, {}, {}, never, never, true, never>;
}
