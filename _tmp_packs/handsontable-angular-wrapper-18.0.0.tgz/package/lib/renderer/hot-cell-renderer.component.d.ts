import { HotCellRendererBase } from './hot-cell-renderer-base.directive';
import * as i0 from "@angular/core";
/**
 * Abstract base component for creating custom cell renderer components for Handsontable.
 *
 * Extend this component and provide your own template to implement a custom renderer.
 * Value type is limited to primitives (`string | number | boolean`).
 * For object and array values use {@link HotCellRendererAdvancedComponent}.
 *
 * @template TValue - The type of the component renderer.
 * @template TProps - The type of additional renderer properties.
 */
export declare abstract class HotCellRendererComponent<TValue extends string | number | boolean = string, TProps extends {} = any> extends HotCellRendererBase<TValue, TProps> {
    static readonly RENDERER_MARKER: unique symbol;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotCellRendererComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HotCellRendererComponent<any, any>, "hot-cell-renderer", never, {}, {}, never, never, true, never>;
}
