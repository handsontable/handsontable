import { ApplicationRef, ComponentRef, EnvironmentInjector, TemplateRef, Type } from '@angular/core';
import Handsontable from 'handsontable/base';
import { HotCellRendererComponent } from './hot-cell-renderer.component';
import { HotCellRendererAdvancedComponent } from './hot-cell-renderer-advanced.component';
import * as i0 from "@angular/core";
export declare const INVALID_RENDERER_WARNING: string;
export declare const INVALID_ADVANCED_RENDERER_WARNING: string;
/**
 * Type guard that checks if the given object is a TemplateRef.
 *
 * @param obj - The object to check.
 * @returns True if the object is a TemplateRef; otherwise, false.
 */
export declare function isTemplateRef<T>(obj: any): obj is TemplateRef<T>;
/**
 * Type guard to check if an object is an instance of HotCellRendererComponent.
 *
 * @param obj - The object to check.
 * @returns True if the object is a HotCellRendererComponent, false otherwise.
 */
export declare function isHotCellRendererComponent(obj: any): obj is Type<HotCellRendererComponent>;
/**
 * Type guard to check if an object is an instance of HotCellRendererAdvancedComponent.
 *
 * @param obj - The object to check.
 * @returns True if the object is a HotCellRendererAdvancedComponent, false otherwise.
 */
export declare function isAdvancedHotCellRendererComponent(obj: any): obj is Type<HotCellRendererAdvancedComponent>;
/**
 * Service for dynamically creating Angular components or templates as custom renderers for Handsontable.
 *
 * This service allows you to create a renderer function that wraps a given Angular component or TemplateRef
 * so that it can be used as a Handsontable renderer.
 *
 * @example
 * const customRenderer = dynamicComponentService.createRendererFromComponent(MyRendererComponent, { someProp: value });
 * // Use customRenderer in your Handsontable configuration
 */
export declare class DynamicComponentService {
    private appRef;
    private environmentInjector;
    private readonly _tdComponentRefs;
    private readonly _tdEmbeddedViews;
    private readonly _instanceComponentRefs;
    private readonly _instanceEmbeddedViews;
    private readonly _hookedInstances;
    constructor(appRef: ApplicationRef, environmentInjector: EnvironmentInjector);
    /**
     * Creates a custom renderer function for Handsontable from an Angular component or TemplateRef.
     * The generated renderer function will be used by Handsontable to render cell content.
     *
     * @param component - The Angular component type or TemplateRef to use as renderer.
     * @param componentProps - An object containing additional properties to use by the renderer.
     * @param register - If true, registers the renderer with Handsontable using the component's name.
     * @returns A renderer function that can be used in Handsontable's configuration.
     */
    createRendererFromComponent(component: Type<HotCellRendererComponent> | TemplateRef<any>, componentProps?: Record<string, any>, register?: boolean): (instance: Handsontable.Core, td: HTMLTableCellElement, row: number, col: number, prop: string | number, value: any, cellProperties: Handsontable.CellProperties) => HTMLTableCellElement;
    /**
     * Creates a custom renderer function using rendererFactory from Handsontable.
     * This is an alternative implementation that uses the factory pattern.
     *
     * @param component - The Angular component type to use as renderer.
     * @param componentProps - An object containing additional properties to use by the renderer.
     * @param register - If true, registers the renderer with Handsontable using the component's name.
     * @returns A renderer function that can be used in Handsontable's configuration.
     */
    createRendererWithFactory(component: Type<HotCellRendererAdvancedComponent>, componentProps?: Record<string, any>, register?: boolean): (instance: Handsontable, td: HTMLTableCellElement, row: number, column: number, prop: string | number, value: unknown, cellProperties: import("handsontable/settings").CellProperties) => void;
    /**
     * Destroys all renderer components and embedded views attached to cells within a container element.
     * Must be called before destroying the Handsontable instance to prevent Angular component leaks.
     *
     * @param container - The root DOM element of the Handsontable instance.
     * @param instance - The Handsontable instance whose registries should be torn down. When omitted
     *   (e.g. test stubs), only refs reachable through TDs still in the container are destroyed.
     */
    cleanupContainer(container: HTMLElement, instance?: Handsontable.Core): void;
    /**
     * Registers a one-time `afterViewRender` hook on the given Handsontable instance that sweeps
     * renderer refs whose TD is no longer connected to the document. Handsontable recycles a pool of
     * TD elements while virtualizing rows; cells that leave the viewport are never re-rendered, so
     * without this sweep their Angular components stay attached to ApplicationRef and leak.
     *
     * Guarded against instances that do not expose `addHook` (e.g. test stubs).
     *
     * @param instance - The Handsontable instance whose render cycle drives the sweep.
     */
    private registerSweepHook;
    /**
     * Destroys every renderer ref/view tracked for the given instance whose root node is no longer
     * attached to the document.
     *
     * @param instance - The Handsontable instance whose registries should be swept.
     */
    private sweepDetachedViews;
    /**
     * @returns True if any of the view's root nodes is still connected to the document.
     */
    private isViewConnected;
    /**
     * Destroys the renderer ref/view previously attached to a cell and clears the cell content,
     * so a fresh renderer can take over the TD without leaking the old one.
     *
     * @param instance - The Handsontable instance owning the cell, used to update its registries.
     * @param td - The table cell whose previous content should be torn down.
     */
    private replaceCellContent;
    /**
     * Tracks a component ref both by its TD (for fast replacement) and in the instance registry
     * (for sweeping and full teardown).
     */
    private trackComponentRef;
    /**
     * Tracks an embedded view both by its TD (for fast replacement) and in the instance registry
     * (for sweeping and full teardown).
     */
    private trackEmbeddedView;
    /**
     * Returns the per-instance registry set for the given instance, creating it on first use.
     */
    private registryFor;
    /**
     * Attaches an embedded view created from a TemplateRef to a given DOM element.
     *
     * @param template - The TemplateRef to create an embedded view from.
     * @param tdEl - The target DOM element (a table cell) to which the view will be appended.
     * @param properties - Context object providing properties to be used within the template.
     * @returns The created EmbeddedViewRef so the caller can track and destroy it later.
     */
    private attachTemplateToElement;
    /**
     * Dynamically creates an Angular component of the given type.
     *
     * @param component - The Angular component type to be created.
     * @param rendererParameters - An object containing input properties to assign to the component instance.
     * @returns The ComponentRef of the dynamically created component.
     */
    private createComponent;
    /**
     * Renders an Angular component into the given cell, recycling the component already attached to
     * the TD when it is of the same type. Handsontable recycles its pool of TD elements heavily while
     * virtualizing rows, so recreating an Angular component on every re-render would cause needless
     * teardown/instantiation churn and GC pressure. When the type matches we only refresh the inputs.
     *
     * @param td - The target table cell.
     * @param component - The renderer component type to render.
     * @param properties - The renderer parameters to feed as component inputs.
     */
    private renderComponent;
    /**
     * Assigns every renderer parameter as an input on the given component ref.
     *
     * @param componentRef - The component ref whose inputs should be set.
     * @param rendererParameters - The renderer parameters to assign.
     */
    private applyInputs;
    /**
     * Attaches a dynamically created component's view to a specified DOM container element.
     *
     * @param componentRef - The reference to the dynamically created component.
     * @param container - The target DOM element to which the component's root node will be appended.
     */
    private attachComponentToElement;
    /**
     * Destroys a dynamically created component and detaches its view from the Angular application.
     *
     * Idempotent: a TD recycled after `sweepDetachedViews` already destroyed its ref still maps to that
     * stale ref in `_tdComponentRefs`, so the next render path may reach this with an already-destroyed
     * ref. Guarding on `destroyed` skips the redundant detach/destroy instead of relying on Angular's
     * internal no-op behaviour.
     *
     * @param componentRef - The reference to the component to be destroyed.
     */
    destroyComponent<T>(componentRef: ComponentRef<T>): void;
    /**
     * Destroys an embedded view. Idempotent for the same reason as {@link destroyComponent}: a recycled
     * TD can still map to an already-destroyed view in `_tdEmbeddedViews`.
     *
     * @param view - The embedded view to destroy.
     */
    private destroyEmbeddedView;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DynamicComponentService>;
}
