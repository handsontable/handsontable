import Handsontable from 'handsontable/base';
import * as i0 from "@angular/core";
/**
 * Shared base directive for HotCellRendererComponent and HotCellRendererAdvancedComponent.
 * Holds all @Input() properties and getProps() that both renderer variants share.
 *
 * @template TValue - The type of the rendered cell value.
 * @template TProps - The type of additional renderer properties.
 */
export declare abstract class HotCellRendererBase<TValue extends string | number | boolean | Record<string, any> | Array<any> = string, TProps extends {} = any> {
    value: TValue;
    instance: Handsontable;
    td: HTMLTableCellElement;
    row: number;
    col: number;
    prop: string | number;
    cellProperties: Handsontable.CellProperties & {
        rendererProps?: TProps;
    };
    getProps(): TProps;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotCellRendererBase<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HotCellRendererBase<any, any>, never, never, { "value": { "alias": "value"; "required": false; }; "instance": { "alias": "instance"; "required": false; }; "td": { "alias": "td"; "required": false; }; "row": { "alias": "row"; "required": false; }; "col": { "alias": "col"; "required": false; }; "prop": { "alias": "prop"; "required": false; }; "cellProperties": { "alias": "cellProperties"; "required": false; }; }, {}, never, never, true, never>;
}
