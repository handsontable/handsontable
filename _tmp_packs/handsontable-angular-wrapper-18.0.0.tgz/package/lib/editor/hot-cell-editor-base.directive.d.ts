import Handsontable from 'handsontable/base';
import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Shared base directive for HotCellEditorComponent and HotCellEditorAdvancedComponent.
 * Holds all @Input(), @Output() and @HostBinding() declarations that both editor variants share.
 *
 * @template T - The type of the edited cell value.
 */
export declare abstract class HotCellEditorBase<T extends string | number | boolean | Record<string, any> | Array<any>> {
    protected heightFitParentContainer: number;
    protected widthFitParentContainer: number;
    row: number;
    column: number;
    prop: string | number;
    originalValue: T;
    cellProperties: Handsontable.CellProperties;
    finishEdit: EventEmitter<void>;
    cancelEdit: EventEmitter<void>;
    protected value: T;
    getValue(): T;
    setValue(value: T): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotCellEditorBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HotCellEditorBase<any>, never, never, { "row": { "alias": "row"; "required": false; }; "column": { "alias": "column"; "required": false; }; "prop": { "alias": "prop"; "required": false; }; "originalValue": { "alias": "originalValue"; "required": false; }; "cellProperties": { "alias": "cellProperties"; "required": false; }; }, { "finishEdit": "finishEdit"; "cancelEdit": "cancelEdit"; }, never, never, true, never>;
}
