import { HotCellEditorBase } from './hot-cell-editor-base.directive';
import * as i0 from "@angular/core";
/**
 * Abstract class representing a basic Handsontable cell editor in Angular.
 *
 * Extend this class and decorate the subclass with `@Component()` to implement a custom editor.
 * Value type is limited to primitives (`string | number | boolean`).
 * For object and array values use {@link HotCellEditorAdvancedComponent}.
 */
export declare abstract class HotCellEditorComponent<T extends string | number | boolean> extends HotCellEditorBase<T> {
    static readonly EDITOR_MARKER: unique symbol;
    /** The tabindex attribute for the editor. */
    protected tabindex: number;
    /** The data-hot-input attribute for the editor. */
    protected dataHotInput: string;
    /** The handsontableInput class for the editor. */
    protected handsontableInputClass: boolean;
    /** Event triggered by Handsontable on closing the editor. */
    onClose(): void;
    /** Event triggered by Handsontable on opening the editor. */
    onOpen(event?: Event): void;
    /**
     * Event triggered by Handsontable on focusing the editor.
     * Must be implemented by the subclass to move focus to the actual input element.
     * @example
     * ```typescript
     * @Component({ template: `<input #inputElement>` })
     * class CustomEditor extends HotCellEditorComponent<string> {
     *   @ViewChild('inputElement') inputElement!: ElementRef;
     *   onFocus(): void { this.inputElement.nativeElement.focus(); }
     * }
     * ```
     */
    abstract onFocus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotCellEditorComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HotCellEditorComponent<any>, never, never, {}, {}, never, never, true, never>;
}
