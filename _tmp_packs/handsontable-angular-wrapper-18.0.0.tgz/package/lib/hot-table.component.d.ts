import { AfterViewInit, ElementRef, EnvironmentInjector, NgZone, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import Handsontable from 'handsontable/base';
import { HotSettingsResolver } from './services/hot-settings-resolver.service';
import { HotGlobalConfigService } from './services/hot-global-config.service';
import { GridSettings } from './models/grid-settings';
import { DynamicComponentService } from './renderer/hot-dynamic-renderer-component.service';
import * as i0 from "@angular/core";
export declare const HOT_DESTROYED_WARNING: string;
export declare class HotTableComponent implements AfterViewInit, OnChanges, OnDestroy {
    private _hotSettingsResolver;
    private _hotConfig;
    ngZone: NgZone;
    private readonly environmentInjector;
    private readonly _dynamicComponentService;
    /** The data for the Handsontable instance. */
    data: Handsontable.GridSettings['data'] | null;
    /** The settings for the Handsontable instance. */
    settings: GridSettings;
    /** The container element for the Handsontable instance. */
    container: ElementRef<HTMLDivElement>;
    /** The Handsontable instance. */
    private __hotInstance;
    private readonly _destroyRef;
    constructor(_hotSettingsResolver: HotSettingsResolver, _hotConfig: HotGlobalConfigService, ngZone: NgZone, environmentInjector: EnvironmentInjector, _dynamicComponentService: DynamicComponentService);
    /**
     * Gets the Handsontable instance.
     * @returns The Handsontable instance or `null` if it's not yet been created or has been destroyed.
     */
    get hotInstance(): Handsontable | null;
    /**
     * Sets the Handsontable instance.
     * @param hotInstance The Handsontable instance to set.
     */
    private set hotInstance(value);
    /**
     * Initializes the Handsontable instance after the view has been initialized.
     * The initial settings of the table are also prepared here
     */
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Destroys the Handsontable instance and clears the columns from custom editors.
     */
    ngOnDestroy(): void;
    /**
     * Updates the Handsontable instance with new settings.
     * @param newSettings The new settings to apply to the Handsontable instance.
     */
    private updateHotTable;
    /**
     * Merges the provided Handsontable grid settings with the global configuration.
     *
     * This method retrieves the global configuration from the HotGlobalConfigService and negotiates the final
     * Handsontable settings by giving precedence to the provided settings.
     * Additionally, the `layoutDirection` is only merged if the Handsontable instance has not yet been initialized.
     *
     * @param settings - The grid settings provided by the user or component.
     * @returns The final negotiated grid settings after merging with global defaults.
     */
    private getNegotiatedSettings;
    static ɵfac: i0.ɵɵFactoryDeclaration<HotTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HotTableComponent, "hot-table", never, { "data": { "alias": "data"; "required": false; }; "settings": { "alias": "settings"; "required": false; }; }, {}, never, never, true, never>;
}
