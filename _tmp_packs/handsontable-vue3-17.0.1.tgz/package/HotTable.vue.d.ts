import { VNode } from 'vue';
import Handsontable from 'handsontable/base';
import { HotTableProps } from './types';
declare const HotTable: import("vue").DefineComponent<{}, {}, {
    __hotInstance: Handsontable;
    miscCache: {
        currentSourceColumns: any;
    };
    columnSettings: HotTableProps[];
    columnsCache: Map<VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>, HotTableProps>;
    hotInstance: Handsontable;
}, {}, {
    /**
     * Initialize Handsontable.
     */
    hotInit(): void;
    matchHotMappersSize(): void;
    /**
     * Get settings for the columns provided in the `hot-column` components.
     *
     * @returns {HotTableProps[] | undefined}
     */
    getColumnSettings(): HotTableProps[] | void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {
    [x: string]: any;
}, {}, {}, {}, string, () => {
    columnsCache: any;
}, true, {}, any>;
export default HotTable;
export { HotTable };
