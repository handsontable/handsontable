declare const HotColumn: import("vue").DefineComponent<{}, {}, {}, {}, {
    /**
     * Create the column settings based on the data provided to the `hot-column`
     * component and it's child components.
     */
    createColumnSettings(): void;
}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {
    [x: string]: any;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default HotColumn;
export { HotColumn };
