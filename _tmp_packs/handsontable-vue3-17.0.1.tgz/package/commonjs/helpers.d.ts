import Handsontable from 'handsontable/base';
import { HotTableProps, VueProps } from './types';
/**
 * Message for the warning thrown if the Handsontable instance has been destroyed.
 */
export declare const HOT_DESTROYED_WARNING: string;
/**
 * Check if at specified `key` there is any value for `object`.
 *
 * @param {object} object Object to search value at specyfic key.
 * @param {string} key String key to check.
 * @returns {boolean}
 */
export declare function hasOwnProperty(object: unknown, key: string): boolean;
/**
 * Generate an object containing all the available Handsontable properties and plugin hooks.
 *
 * @param {string} source Source for the factory (either 'HotTable' or 'HotColumn').
 * @returns {object}
 */
export declare function propFactory(source: 'HotTable' | 'HotColumn'): VueProps<HotTableProps>;
/**
 * Filter out all of the unassigned props, and return only the one passed to the component.
 *
 * @param {object} props Object containing all the possible props.
 * @returns {object} Object containing only used props.
 */
export declare function filterPassedProps(props: any): VueProps<HotTableProps>;
/**
 * Prepare the settings object to be used as the settings for Handsontable, based on the props provided to the component.
 *
 * @param {HotTableProps} props The props passed to the component.
 * @param {Handsontable.GridSettings} currentSettings The current Handsontable settings.
 * @returns {Handsontable.GridSettings} An object containing the properties, ready to be used within Handsontable.
 */
export declare function prepareSettings(props: HotTableProps, currentSettings?: Handsontable.GridSettings): HotTableProps;
